/**
 * Harness Initializer - 初始化 Harness 系統
 * 
 * 檢查環境依賴並初始化目錄結構
 */

const fs = require('fs').promises;
const path = require('path');
const { execSync } = require('child_process');

const HARNESS_DIR = '/home/opc/.hermes/harness';
const REQUIRED_DIRS = [
  'core',
  'core/initializers',
  'tests/unit',
  'tests/integration',
  'tests/e2e',
  'tests/fixtures',
  'reports',
  'scripts',
  'config'
];

const REQUIRED_PACKAGES = [
  'puppeteer',
  'playwright',
  'chrome-remote-interface',
  'winston',
  'dotenv'
];

async function checkNode() {
  console.log('Checking Node.js...');
  try {
    const version = process.version;
    console.log(`✅ Node.js ${version} installed`);
    return true;
  } catch (e) {
    console.log('❌ Node.js not found');
    return false;
  }
}

async function checkChrome() {
  console.log('\nChecking Chrome/Chromium...');
  try {
    // Try to find Chrome
    const locations = [
      '/usr/bin/google-chrome',
      '/usr/bin/chromium',
      '/usr/bin/chromium-browser',
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
    ];
    
    for (const loc of locations) {
      try {
        await fs.access(loc);
        console.log(`✅ Found Chrome at ${loc}`);
        return true;
      } catch (e) {
        // Try next
      }
    }
    
    console.log('⚠️ Chrome not found in common locations');
    console.log('   Puppeteer will download Chromium automatically on first run');
    return true;
  } catch (e) {
    return false;
  }
}

async function createDirs() {
  console.log('\nCreating directory structure...');
  for (const dir of REQUIRED_DIRS) {
    const fullPath = path.join(HARNESS_DIR, dir);
    await fs.mkdir(fullPath, { recursive: true });
    console.log(`   ✅ ${dir}`);
  }
}

async function installDependencies() {
  console.log('\nChecking npm dependencies...');
  
  // Check if node_modules exists
  const nodeModulesPath = path.join(HARNESS_DIR, 'node_modules');
  try {
    await fs.access(nodeModulesPath);
    console.log('   ✅ Dependencies already installed');
    return true;
  } catch (e) {
    // Need to install
  }
  
  console.log('   📦 Installing dependencies (this may take a few minutes)...');
  try {
    execSync('npm install', {
      cwd: HARNESS_DIR,
      stdio: 'inherit'
    });
    console.log('   ✅ Dependencies installed');
    return true;
  } catch (e) {
    console.log('   ⚠️ npm install failed, trying with --legacy-peer-deps');
    try {
      execSync('npm install --legacy-peer-deps', {
        cwd: HARNESS_DIR,
        stdio: 'inherit'
      });
      console.log('   ✅ Dependencies installed');
      return true;
    } catch (e2) {
      console.log('   ❌ Failed to install dependencies');
      return false;
    }
  }
}

async function createConfig() {
  console.log('\nCreating configuration files...');
  
  const config = {
    harness: {
      version: '1.0.0',
      headless: true,
      browser: 'chromium',
      viewport: { width: 1280, height: 720 },
      timeout: 30000,
      retryAttempts: 3
    },
    reporting: {
      outputDir: '/home/opc/.hermes/harness/reports',
      formats: ['json', 'md', 'html'],
      autoUpload: true,
      uploadTarget: 'gdrive'
    },
    monitoring: {
      errorThreshold: {
        blocking: 0,
        warning: 10,
        info: 50
      },
      networkThreshold: {
        slowMs: 1000,
        failedCount: 5
      }
    }
  };
  
  const configPath = path.join(HARNESS_DIR, 'config/default.json');
  await fs.writeFile(configPath, JSON.stringify(config, null, 2));
  console.log('   ✅ config/default.json');
  
  // Create env example
  const envExample = `# Hermes Harness Environment Variables

# Logging
HARNESS_LOG_LEVEL=info

# Browser
HARNESS_BROWSER=chromium
HARNESS_HEADLESS=true

# Paths
HARNESS_OUTPUT_DIR=/home/opc/.hermes/harness/reports

# GDrive (for auto-upload)
RCLONE_CONFIG=/home/opc/.config/rclone/rclone.conf
`;
  
  const envPath = path.join(HARNESS_DIR, '.env.example');
  await fs.writeFile(envPath, envExample);
  console.log('   ✅ .env.example');
}

async function createReadme() {
  console.log('\nCreating README...');
  
  const readme = `# Hermes Debug Harness

Debug Harness System for Hermes Agent

## 結構

\`\`\`
harness/
├── core/               # 核心模組
│   ├── index.js        # 主入口
│   ├── input-collector.js
│   ├── error-detector.js
│   ├── network-monitor.js
│   ├── state-inspector.js
│   ├── report-generator.js
│   └── initializers/
├── tests/              # 測試用例
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── reports/            # 報告輸出
├── scripts/            # 腳本工具
└── config/            # 配置文件
\`\`\`

## 快速開始

\`\`\`bash
cd /home/opc/.hermes/harness

# 運行所有測試
npm test

# 運行特定級別測試
npm run test:unit
npm run test:integration
npm run test:e2e

# 生成報告
npm run report:generate
\`\`\`

## 核心功能

1. **Input Collector** - 收集用戶操作序列
2. **Error Detector** - 攔截並分類錯誤
3. **Network Monitor** - 監控 API 請求/回應
4. **State Inspector** - 檢查前端狀態
5. **Report Generator** - 生成多格式報告

## 狀態

🟢 已初始化 - 待使用
`;

  const readmePath = path.join(HARNESS_DIR, 'README.md');
  await fs.writeFile(readmePath, readme);
  console.log('   ✅ README.md');
}

async function main() {
  console.log('========================================');
  console.log('🔧 Hermes Debug Harness - Initializer');
  console.log('========================================\n');

  // Check environment
  const nodeOk = await checkNode();
  const chromeOk = await checkChrome();
  
  if (!nodeOk) {
    console.log('\n❌ Node.js is required but not installed');
    process.exit(1);
  }

  // Create structure
  await createDirs();
  
  // Create config
  await createConfig();
  
  // Create README
  await createReadme();
  
  // Install dependencies
  await installDependencies();

  console.log('\n========================================');
  console.log('✅ Harness 初始化完成！');
  console.log('========================================');
  console.log('\n下一步:');
  console.log('  cd /home/opc/.hermes/harness');
  console.log('  npm test');
  console.log('\n或運行演示測試:');
  console.log('  node scripts/run-tests.js');
  console.log('\n查看 README:');
  console.log('  cat /home/opc/.hermes/harness/README.md');
}

main().catch(e => {
  console.error('Initialization failed:', e);
  process.exit(1);
});
