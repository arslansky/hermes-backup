'use strict';

const { execSync, spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

/**
 * Sandbox - Security Isolation for command execution
 * Modes: 'strict' (block dangerous ops), 'standard' (allow most), 'permissive' (allow all)
 */
class Sandbox {
  constructor(options = {}) {
    this.mode = options.mode || 'standard';
    this.id = options.id || `sandbox_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.resourceLimits = {
      maxMemory: options.maxMemory || 512, // MB
      maxCpuTime: options.maxCpuTime || 30, // seconds
      maxFileSize: options.maxFileSize || 10, // MB
      ...options.resourceLimits
    };
    this.allowedPaths = options.allowedPaths || [process.cwd(), os.homedir()];
    this.blockedPatterns = [
      /rm\s+-rf\s+\//,
      /sudo\s+/,
      /chmod\s+777/,
      /eval\s*\(/,
      /exec\s*\(/,
      />\s*\/dev\/sda/,
      /mkfs/,
      /dd\s+if=/,  
      /:\(\)\s*\{/,
      /wget\s+.*\|.*sh/,
      /curl\s+.*\|.*sh/
    ];
    this.executionLog = [];
    this.createdAt = Date.now();
  }

  /**
   * Execute a command within sandbox restrictions
   * @param {string} command - The command to execute
   * @param {object} options - Execution options
   * @returns {object} { stdout, stderr, exitCode }
   */
  exec(command, options = {}) {
    const validation = this._validateCommand(command);
    if (!validation.allowed) {
      const error = new Error(`Sandbox blocked: ${validation.reason}`);
      error.code = 'SANDBOX_BLOCKED';
      return {
        stdout: '',
        stderr: error.message,
        exitCode: 1
      };
    }

    const timeout = options.timeout || (this.resourceLimits.maxCpuTime * 1000);
    const maxBuffer = options.maxBuffer || (this.resourceLimits.maxFileSize * 1024 * 1024);
    
    const record = {
      command,
      timestamp: Date.now(),
      mode: this.mode
    };

    try {
      const result = execSync(command, {
        encoding: 'utf8',
        timeout,
        maxBuffer,
        shell: options.shell || true,
        cwd: options.cwd || process.cwd(),
        env: { ...process.env, ...options.env },
        stdio: ['pipe', 'pipe', 'pipe'],
        ...(options.uid ? { uid: options.uid } : {}),
        ...(options.gid ? { gid: options.gid } : {})
      });

      // execSync returns the stdout string directly on success (with encoding)
      const stdout = typeof result === 'string' ? result : (result.stdout || '');
      const stderr = (result && result.stderr) || '';
      
      record.stdout = stdout;
      record.stderr = stderr;
      record.exitCode = 0;
      this.executionLog.push(record);

      return { stdout, stderr, exitCode: 0 };
    } catch (err) {
      let stdout = '';
      let stderr = err.stderr || err.message || '';
      let exitCode = err.status || 1;

      if (err.stdout) stdout = err.stdout;
      if (err.killed) stderr = '[SANDBOX] Process killed: exceeded resource limit';

      record.stdout = stdout;
      record.stderr = stderr;
      record.exitCode = exitCode;
      this.executionLog.push(record);

      return { stdout, stderr, exitCode };
    }
  }

  /**
   * Validate command against sandbox rules
   */
  _validateCommand(command) {
    if (typeof command !== 'string' || !command.trim()) {
      return { allowed: false, reason: 'Empty command' };
    }

    if (this.mode === 'permissive') {
      return { allowed: true };
    }

    for (const pattern of this.blockedPatterns) {
      if (pattern.test(command)) {
        return { 
          allowed: false, 
          reason: `Command matches blocked pattern: ${pattern}` 
        };
      }
    }

    if (this.mode === 'strict') {
      // In strict mode, also block network commands, file writes outside allowed paths
      const strictBlocked = [
        /nc\s+/,
        /netcat/,
        /nmap/,
        /ssh\s+/,
        /scp\s+/,
        /telnet/,
        /ftp\s+/,
        /wget\s+/,
        /curl\s+/,
        /python\s+-m\s+http/,
        /node\s+-e/,
        /shred/,
        /wipefs/
      ];
      for (const pattern of strictBlocked) {
        if (pattern.test(command)) {
          return { 
            allowed: false, 
            reason: `Strict mode blocks: ${pattern}` 
          };
        }
      }
    }

    return { allowed: true };
  }

  /**
   * Get execution history for this sandbox
   */
  getHistory() {
    return [...this.executionLog];
  }

  /**
   * Get sandbox status/info
   */
  getInfo() {
    return {
      id: this.id,
      mode: this.mode,
      resourceLimits: this.resourceLimits,
      commandsExecuted: this.executionLog.length,
      createdAt: this.createdAt,
      allowedPaths: this.allowedPaths
    };
  }
}

/**
 * SandboxManager - Manages multiple sandboxes with resource limits
 */
class SandboxManager {
  constructor(options = {}) {
    this.sandboxes = new Map();
    this.globalLimits = {
      maxSandboxes: options.maxSandboxes || 10,
      totalMemory: options.totalMemory || 2048, // MB
      totalCpuTime: options.totalCpuTime || 120, // seconds
      ...options.globalLimits
    };
    this.usage = {
      activeSandboxes: 0,
      totalMemoryUsed: 0,
      totalCpuTimeUsed: 0
    };
  }

  /**
   * Create a new sandbox
   * @param {string} id - Unique identifier for the sandbox
   * @param {object} options - Sandbox configuration
   * @returns {Sandbox}
   */
  createSandbox(id, options = {}) {
    if (this.sandboxes.has(id)) {
      throw new Error(`Sandbox "${id}" already exists`);
    }

    if (this.sandboxes.size >= this.globalLimits.maxSandboxes) {
      throw new Error(`Maximum number of sandboxes (${this.globalLimits.maxSandboxes}) reached`);
    }

    const memoryLimit = options.maxMemory || 256;
    if (this.usage.totalMemoryUsed + memoryLimit > this.globalLimits.totalMemory) {
      throw new Error(`Memory limit would be exceeded (${this.usage.totalMemoryUsed + memoryLimit} > ${this.globalLimits.totalMemory} MB)`);
    }

    const sandbox = new Sandbox({ id, ...options });
    this.sandboxes.set(id, sandbox);
    this.usage.activeSandboxes++;
    this.usage.totalMemoryUsed += memoryLimit;

    return sandbox;
  }

  /**
   * Destroy a sandbox by ID
   * @param {string} id 
   */
  destroySandbox(id) {
    const sandbox = this.sandboxes.get(id);
    if (!sandbox) {
      throw new Error(`Sandbox "${id}" not found`);
    }

    const memoryFreed = sandbox.resourceLimits.maxMemory;
    this.sandboxes.delete(id);
    this.usage.activeSandboxes--;
    this.usage.totalMemoryUsed = Math.max(0, this.usage.totalMemoryUsed - memoryFreed);
  }

  /**
   * List all active sandboxes
   * @returns {Array}
   */
  listSandboxes() {
    return Array.from(this.sandboxes.values()).map(s => s.getInfo());
  }

  /**
   * Get a sandbox by ID
   * @param {string} id
   * @returns {Sandbox|undefined}
   */
  getSandbox(id) {
    return this.sandboxes.get(id);
  }

  /**
   * Get manager status
   */
  getStatus() {
    return {
      totalSandboxes: this.sandboxes.size,
      globalLimits: this.globalLimits,
      usage: this.usage,
      sandboxList: this.listSandboxes()
    };
  }

  /**
   * Clean up all sandboxes
   */
  destroyAll() {
    const ids = Array.from(this.sandboxes.keys());
    for (const id of ids) {
      this.destroySandbox(id);
    }
  }
}

module.exports = { Sandbox, SandboxManager };
