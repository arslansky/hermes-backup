/**
 * Hermes Debug Harness - Core Module
 * 
 * 調試工具系統核心，負責整合所有監控元件
 * 
 * @module harness/core
 * 
 * 🌲 Depth-First Debugging 架構:
 * - CapabilityAnalyzer: 能力維度 DFS 探索
 * - DepthFirstDebugger: 協調各組件進行深度優先診斷
 * - ErrorDetector: 錯誤捕獲 + 觸發 DFS 分析
 * - ReportGenerator: 樹狀錯誤報告輸出
 */

const { EventEmitter } = require('events');
const winston = require('winston');

// Core components
const InputCollector = require('./input-collector');
const ErrorDetector = require('./error-detector');
const NetworkMonitor = require('./network-monitor');
const StateInspector = require('./state-inspector');
const ReportGenerator = require('./report-generator');

// DFS Components (新增)
const CapabilityAnalyzer = require('./capability-analyzer');
const DepthFirstDebugger = require('./depth-first-debugger');

// Logger configuration
const logger = winston.createLogger({
  level: process.env.HARNESS_LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      const metaStr = Object.keys(meta).length ? JSON.stringify(meta) : '';
      return `[${timestamp}] ${level}: ${message} ${metaStr}`;
    })
  ),
  transports: [
    new winston.transports.File({ filename: '/home/opc/.hermes/harness/reports/harness.log' }),
    new winston.transports.Console()
  ]
});

/**
 * DebugHarness - 整合所有監控元件的調試框架
 */
class DebugHarness extends EventEmitter {
  constructor(options = {}) {
    super();
    
    this.options = {
      headless: options.headless ?? true,
      browser: options.browser ?? 'chromium',  // 'chromium' | 'firefox' | 'webkit'
      viewport: options.viewport ?? { width: 1280, height: 720 },
      outputDir: options.outputDir || '/home/opc/.hermes/harness/reports',
      enableDeepAnalysis: options.enableDeepAnalysis ?? true,  // 🌲 DFS toggle
      ...options
    };
    
    this.browser = null;
    this.context = null;
    this.page = null;
    
    // Core components
    this.inputCollector = null;
    this.errorDetector = null;
    this.networkMonitor = null;
    this.stateInspector = null;
    this.reportGenerator = null;
    
    // 🌲 Depth-First Analysis components
    this.capabilityAnalyzer = null;
    this.depthFirstDebugger = null;
    
    // State
    this.isInitialized = false;
    this.sessionId = this._generateSessionId();
    
    logger.info('DebugHarness instance created', { 
      sessionId: this.sessionId,
      deepAnalysis: this.options.enableDeepAnalysis
    });
  }
  
  /**
   * 初始化 Harness 和所有監控元件
   */
  async init() {
    if (this.isInitialized) {
      logger.warn('Harness already initialized');
      return;
    }
    
    logger.info('Initializing DebugHarness...');
    
    try {
      // Initialize core components
      this.errorDetector = new ErrorDetector({ 
        logger,
        enableDeepAnalysis: this.options.enableDeepAnalysis
      });
      this.networkMonitor = new NetworkMonitor({ logger });
      this.stateInspector = new StateInspector({ logger });
      this.reportGenerator = new ReportGenerator({
        outputDir: this.options.outputDir,
        logger,
        enableTreeReport: this.options.enableDeepAnalysis
      });
      
      // 🌲 Initialize Depth-First Analysis components
      if (this.options.enableDeepAnalysis) {
        this.capabilityAnalyzer = new CapabilityAnalyzer({ logger });
        this.depthFirstDebugger = new DepthFirstDebugger({ logger });
        
        logger.info('Depth-First Analysis components initialized');
      }
      
      // Emit ready event
      this.isInitialized = true;
      this.emit('ready');
      
      logger.info('DebugHarness initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize DebugHarness', { error: error.message });
      throw error;
    }
  }
  
  /**
   * 連接到現有的瀏覽器頁面 (CDP)
   */
  async connectToPage(wsEndpoint) {
    const CDP = require('chrome-remote-interface');
    
    try {
      logger.info('Connecting to browser via CDP', { wsEndpoint });
      
      const client = await CDP({ target: wsEndpoint });
      this.page = client;
      
      // Setup all monitors
      await this._setupMonitors();
      
      logger.info('Connected to page successfully');
      return client;
    } catch (error) {
      logger.error('Failed to connect to page', { error: error.message });
      throw error;
    }
  }
  
  /**
   * 啟動新的瀏覽器實例 (Puppeteer)
   */
  async launchBrowser() {
    const puppeteer = require('puppeteer');
    
    try {
      logger.info('Launching browser...');
      
      this.browser = await puppeteer.launch({
        headless: this.options.headless,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu'
        ]
      });
      
      this.context = await this.browser.createBrowserContext();
      this.page = await this.context.newPage();
      await this.page.setViewport(this.options.viewport);
      
      // Setup all monitors
      await this._setupMonitors();
      
      logger.info('Browser launched successfully');
      return this.page;
    } catch (error) {
      logger.error('Failed to launch browser', { error: error.message });
      throw error;
    }
  }
  
  /**
   * 設置所有監控器
   */
  async _setupMonitors() {
    // Setup Error Detector
    this.errorDetector.attach(this.page);
    this.errorDetector.on('error', (error) => {
      this.emit('harness:error', error);
      logger.error('Error detected', { error });
    });
    
    // Setup Network Monitor
    this.networkMonitor.attach(this.page);
    this.networkMonitor.on('networkEvent', (event) => {
      this.emit('harness:network', event);
    });
    
    // Setup State Inspector
    this.stateInspector.attach(this.page);
    this.stateInspector.on('stateChange', (change) => {
      this.emit('harness:stateChange', change);
    });
    
    // Setup Input Collector (basic click/keyboard capture)
    this.inputCollector = new InputCollector({ page: this.page, logger });
    await this.inputCollector.setup();
    
    logger.info('All monitors attached');
  }
  
  /**
   * 收集錯誤
   */
  collectErrors() {
    return this.errorDetector.getErrors();
  }
  
  /**
   * 收集網絡請求
   */
  collectNetworkCalls() {
    return this.networkMonitor.getCalls();
  }
  
  /**
   * 收集狀態快照
   */
  collectState() {
    return this.stateInspector.getSnapshot();
  }
  
  /**
   * 🌲 手動觸發 Depth-First 分析
   * 
   * 當你需要對特定錯誤進行深度分析時調用
   */
  async analyzeDepthFirst(error, context = {}) {
    if (!this.options.enableDeepAnalysis) {
      logger.warn('Deep analysis is disabled');
      return null;
    }
    
    const result = await this.depthFirstDebugger.diagnose(error, context);
    
    logger.info('Manual DFS analysis complete', {
      rootCause: result.rootCause?.label,
      confidence: result.confidence
    });
    
    return result;
  }
  
  /**
   * 獲取 DFS 分析歷史
   */
  getDFSAnalysisHistory() {
    if (!this.depthFirstDebugger) return [];
    return this.depthFirstDebugger.getHistory();
  }
  
  /**
   * 生成完整報告
   */
  async generateReport(testName = 'unspecified') {
    const report = await this.reportGenerator.generate({
      sessionId: this.sessionId,
      testName,
      timestamp: new Date().toISOString(),
      errors: this.collectErrors(),
      networkCalls: this.collectNetworkCalls(),
      state: this.collectState()
    });
    
    logger.info('Report generated', { reportPath: report.path });
    return report;
  }
  
  /**
   * 清理資源
   */
  async cleanup() {
    logger.info('Cleaning up Harness resources...');
    
    if (this.page && !this.options.useExistingBrowser) {
      await this.page.close().catch(() => {});
    }
    
    if (this.browser) {
      await this.browser.close().catch(() => {});
    }
    
    this.isInitialized = false;
    this.emit('closed');
    
    logger.info('Harness cleanup complete');
  }
  
  /**
   * 生成 session ID
   */
  _generateSessionId() {
    return `harness-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

module.exports = DebugHarness;

// Export DFS components for direct access if needed
module.exports.CapabilityAnalyzer = CapabilityAnalyzer;
module.exports.DepthFirstDebugger = DepthFirstDebugger;
