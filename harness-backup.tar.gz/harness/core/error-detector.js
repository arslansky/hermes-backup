/**
 * Error Detector - 攔截並分類錯誤
 * 
 * 監控 console.error, exceptions, promise rejections
 * 
 * 整合 Depth-First Debugging：
 * 當錯誤發生時，唔再只係簡單分類，
 * 而係觸發 DFS 分析，深入探索根本原因
 */

const { EventEmitter } = require('events');
const DepthFirstDebugger = require('./depth-first-debugger');

class ErrorDetector extends EventEmitter {
  constructor({ logger, enableDeepAnalysis = true } = {}) {
    super();
    this.logger = logger;
    this.errors = [];
    this.warnings = [];
    this.page = null;
    
    // Depth-First Debugger 整合
    this.enableDeepAnalysis = enableDeepAnalysis;
    this.debugger = null;
    if (this.enableDeepAnalysis) {
      this.debugger = new DepthFirstDebugger({ logger });
    }
    
    // Error severity levels
    this.Severity = {
      BLOCKING: '🔴 BLOCKING',
      WARNING: '🟡 WARNING',
      INFO: '⚪ INFO'
    };
    
    // Error sources
    this.Source = {
      NETWORK: '🌐 Network',
      RUNTIME: '⚡ Runtime',
      RENDER: '🎨 Render',
      STATE: '📦 State',
      AUTH: '🔐 Auth'
    };
  }
  
  /**
   * 附加到頁面
   */
  attach(page) {
    this.page = page;
    this._setupListeners();
  }
  
  /**
   * 設置監聽器
   */
  _setupListeners() {
    // Console messages
    this.page.on('console', async (msg) => {
      const type = msg.type();
      const text = msg.text();
      const location = msg.location();
      
      if (type === 'error') {
        const error = this._classifyError({
          type: 'console',
          text,
          location,
          timestamp: Date.now()
        });
        
        // Depth-First Analysis
        if (this.enableDeepAnalysis && this.debugger) {
          try {
            const context = { location };
            const diagnosis = await this.debugger.diagnose(error, context);
            error.diagnosis = {
              rootCause: diagnosis.rootCause,
              fixActions: diagnosis.fixActions,
              confidence: diagnosis.confidence
            };
          } catch (diagErr) {
            this.logger.warn('DFS diagnosis failed for console error', { error: diagErr.message });
          }
        }
        
        this.errors.push(error);
        this.emit('error', error);
      } else if (type === 'warning') {
        const warning = {
          type: 'warning',
          text,
          location,
          timestamp: Date.now()
        };
        this.warnings.push(warning);
        this.emit('warning', warning);
      }
    });
    
    // Page errors (uncaught exceptions)
    this.page.on('pageerror', async (error) => {
      const err = this._classifyError({
        type: 'pageerror',
        message: error.message,
        stack: error.stack,
        timestamp: Date.now()
      });
      
      // Depth-First Analysis: 深入分析呢個錯誤
      if (this.enableDeepAnalysis && this.debugger) {
        try {
          const context = {
            stack: error.stack,
            page: this.page ? await this.page.title().catch(() => 'unknown') : 'unknown'
          };
          const diagnosis = await this.debugger.diagnose(err, context);
          
          // 將診斷結果附加到錯誤
          err.diagnosis = {
            rootCause: diagnosis.rootCause,
            fixActions: diagnosis.fixActions,
            confidence: diagnosis.confidence,
            exploredNodes: diagnosis.exploredNodes
          };
          
          this.logger.info('DFS diagnosis for pageerror', {
            rootCause: diagnosis.rootCause?.label,
            confidence: diagnosis.confidence
          });
        } catch (diagErr) {
          this.logger.warn('DFS diagnosis failed', { error: diagErr.message });
        }
      }
      
      this.errors.push(err);
      this.emit('error', err);
    });
    
    // Unhandled promise rejections
    this.page.on('requestfailed', (request) => {
      const failure = request.failure();
      const error = {
        type: 'requestfailed',
        url: request.url(),
        method: request.method(),
        error: failure?.errorText,
        timestamp: Date.now(),
        severity: this.Severity.BLOCKING,
        source: this.Source.NETWORK
      };
      this.errors.push(error);
      this.emit('error', error);
    });
    
    this.logger.info('ErrorDetector listeners attached');
  }
  
  /**
   * 分類錯誤
   */
  _classifyError(error) {
    const text = error.text || error.message || '';
    let severity = this.Severity.INFO;
    let source = this.Source.RUNTIME;
    
    // Determine severity and source based on error characteristics
    if (text.includes('net::') || text.includes('fetch') || text.includes('Failed to fetch')) {
      severity = this.Severity.BLOCKING;
      source = this.Source.NETWORK;
    } else if (text.includes('401') || text.includes('403') || text.includes('Unauthorized')) {
      severity = this.Severity.BLOCKING;
      source = this.Source.AUTH;
    } else if (text.includes('Cannot read') || text.includes('is not a function')) {
      severity = this.Severity.BLOCKING;
      source = this.Source.RUNTIME;
    } else if (text.includes('Warning') || text.includes('React')) {
      severity = this.Severity.WARNING;
      source = this.Source.RENDER;
    } else if (text.includes('state') || text.includes('Redux') || text.includes('store')) {
      severity = this.Severity.WARNING;
      source = this.Source.STATE;
    }
    
    return {
      ...error,
      severity,
      source,
      id: `err-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
    };
  }
  
  /**
   * 獲取所有錯誤
   */
  getErrors() {
    return [...this.errors];
  }
  
  /**
   * 獲取所有警告
   */
  getWarnings() {
    return [...this.warnings];
  }
  
  /**
   * 按嚴重性獲取錯誤
   */
  getErrorsBySeverity(severity) {
    return this.errors.filter(e => e.severity === severity);
  }
  
  /**
   * 按來源獲取錯誤
   */
  getErrorsBySource(source) {
    return this.errors.filter(e => e.source === source);
  }
  
  /**
   * 清除所有錯誤記錄
   */
  clear() {
    this.errors = [];
    this.warnings = [];
  }
  
  /**
   * 獲取錯誤摘要
   */
  getSummary() {
    return {
      total: this.errors.length,
      blocking: this.errors.filter(e => e.severity === this.Severity.BLOCKING).length,
      warning: this.errors.filter(e => e.severity === this.Severity.WARNING).length,
      info: this.errors.filter(e => e.severity === this.Severity.INFO).length,
      bySource: {
        network: this.errors.filter(e => e.source === this.Source.NETWORK).length,
        runtime: this.errors.filter(e => e.source === this.Source.RUNTIME).length,
        render: this.errors.filter(e => e.source === this.Source.RENDER).length,
        state: this.errors.filter(e => e.source === this.Source.STATE).length,
        auth: this.errors.filter(e => e.source === this.Source.AUTH).length
      }
    };
  }
}

module.exports = ErrorDetector;
