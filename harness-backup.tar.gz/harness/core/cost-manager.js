'use strict';

/**
 * TokenBucket - Rate limiter using token bucket algorithm
 * Implements token bucket rate limiting with burst support
 */
class TokenBucket {
  /**
   * @param {object} options
   * @param {number} options.tokensPerSecond - Refill rate
   * @param {number} options.burstCapacity - Maximum burst size
   * @param {number} options.initialTokens - Starting tokens (default: burstCapacity)
   */
  constructor(options = {}) {
    this.tokensPerSecond = options.tokensPerSecond || 10;
    this.burstCapacity = options.burstCapacity || this.tokensPerSecond;
    this.tokens = options.initialTokens !== undefined ? options.initialTokens : this.burstCapacity;
    this.lastRefill = Date.now();
    this.totalConsumed = 0;
    this.maxWaitTime = options.maxWaitTime || 60000; // 60s max wait
  }

  /**
   * Consume tokens from the bucket
   * @param {number} count - Number of tokens to consume
   * @returns {boolean} - Whether tokens were available
   */
  consume(count = 1) {
    this.refill();
    
    if (this.tokens >= count) {
      this.tokens -= count;
      this.totalConsumed += count;
      return true;
    }
    return false;
  }

  /**
   * Refill tokens based on elapsed time
   */
  refill() {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000; // seconds
    const tokensToAdd = elapsed * this.tokensPerSecond;
    
    if (tokensToAdd > 0) {
      this.tokens = Math.min(this.burstCapacity, this.tokens + tokensToAdd);
      this.lastRefill = now;
    }
  }

  /**
   * Get estimated wait time before tokens are available
   * @param {number} count - Number of tokens needed
   * @returns {number} - Wait time in milliseconds
   */
  getWaitTime(count = 1) {
    this.refill();
    
    if (this.tokens >= count) {
      return 0;
    }

    const deficit = count - this.tokens;
    const waitSeconds = deficit / this.tokensPerSecond;
    const waitMs = waitSeconds * 1000;
    
    return Math.min(waitMs, this.maxWaitTime);
  }

  /**
   * Get bucket status
   */
  getStatus() {
    this.refill();
    return {
      current: this.tokens,
      capacity: this.burstCapacity,
      fillRate: this.tokensPerSecond,
      available: this.tokens,
      totalConsumed: this.totalConsumed
    };
  }
}

/**
 * CostManager - Tracks tokens and cost per session/model
 */
class CostManager {
  constructor(options = {}) {
    this.usage = new Map(); // model -> { inputTokens, outputTokens, cost, calls }
    this.buckets = new Map(); // model -> TokenBucket
    this.sessionStart = Date.now();
    this.defaultLimits = {
      tokensPerSecond: options.tokensPerSecond || 50,
      burstCapacity: options.burstCapacity || 200,
      maxCostPerSession: options.maxCostPerSession || 100, // dollars
      maxTokensPerSession: options.maxTokensPerSession || 10000000 // 10M tokens
    };
    this.sessionCost = 0;
    this.sessionTokens = 0;
  }

  /**
   * Track token usage for a model
   * @param {string} model - Model identifier
   * @param {number} inputTokens - Number of input tokens
   * @param {number} outputTokens - Number of output tokens
   * @param {object} options
   * @param {number} options.costPerToken - Override cost per token
   */
  trackUsage(model, inputTokens, outputTokens, options = {}) {
    // Ensure model has a bucket
    if (!this.buckets.has(model)) {
      this._createModelBucket(model, options);
    }

    // Check if we can consume tokens
    const totalTokens = inputTokens + outputTokens;
    const bucket = this.buckets.get(model);
    const waitTime = bucket.getWaitTime(totalTokens);
    
    if (waitTime > 0) {
      return {
        success: false,
        waitTime,
        message: `Rate limited. Wait ${Math.round(waitTime)}ms`
      };
    }

    bucket.consume(totalTokens);

    // Get or create model usage entry
    if (!this.usage.has(model)) {
      this.usage.set(model, {
        inputTokens: 0,
        outputTokens: 0,
        cost: 0,
        calls: 0,
        costPerToken: options.costPerToken || 0.001 // default $0.001 per token
      });
    }

    const entry = this.usage.get(model);
    const costPerToken = options.costPerToken || entry.costPerToken;
    const callCost = (inputTokens + outputTokens) * costPerToken;

    entry.inputTokens += inputTokens;
    entry.outputTokens += outputTokens;
    entry.cost += callCost;
    entry.calls += 1;
    entry.costPerToken = costPerToken;

    this.sessionCost += callCost;
    this.sessionTokens += totalTokens;

    return {
      success: true,
      cost: callCost,
      totalTokens,
      inputTokens,
      outputTokens
    };
  }

  /**
   * Get cost for a specific model
   * @param {string} model
   * @returns {object|null}
   */
  getCost(model) {
    const entry = this.usage.get(model);
    if (!entry) return null;
    return {
      model,
      inputTokens: entry.inputTokens,
      outputTokens: entry.outputTokens,
      totalTokens: entry.inputTokens + entry.outputTokens,
      cost: entry.cost,
      calls: entry.calls,
      averageCostPerCall: entry.calls > 0 ? entry.cost / entry.calls : 0
    };
  }

  /**
   * Get total cost across all models
   * @returns {number}
   */
  getTotalCost() {
    let total = 0;
    for (const entry of this.usage.values()) {
      total += entry.cost;
    }
    return total;
  }

  /**
   * Get complete usage report
   * @returns {object}
   */
  getUsageReport() {
    const modelReports = [];
    let totalInput = 0;
    let totalOutput = 0;
    let totalCalls = 0;

    for (const [model, data] of this.usage.entries()) {
      modelReports.push({
        model,
        inputTokens: data.inputTokens,
        outputTokens: data.outputTokens,
        totalTokens: data.inputTokens + data.outputTokens,
        cost: data.cost,
        calls: data.calls,
        costPerToken: data.costPerToken
      });
      totalInput += data.inputTokens;
      totalOutput += data.outputTokens;
      totalCalls += data.calls;
    }

    // Bucket statuses
    const rateLimitStatus = {};
    for (const [model, bucket] of this.buckets.entries()) {
      rateLimitStatus[model] = bucket.getStatus();
    }

    return {
      sessionDuration: Date.now() - this.sessionStart,
      totalCost: this.getTotalCost(),
      totalTokens: this.sessionTokens,
      totalInputTokens: totalInput,
      totalOutputTokens: totalOutput,
      totalCalls,
      models: modelReports,
      rateLimits: rateLimitStatus,
      limits: { ...this.defaultLimits },
      withinBudget: this.sessionCost <= this.defaultLimits.maxCostPerSession,
      withinTokenLimit: this.sessionTokens <= this.defaultLimits.maxTokensPerSession
    };
  }

  /**
   * Set rate limits for a specific model
   * @param {string} model
   * @param {object} limits
   */
  setModelLimits(model, limits = {}) {
    if (this.buckets.has(model)) {
      const existing = this.buckets.get(model);
      if (limits.tokensPerSecond) existing.tokensPerSecond = limits.tokensPerSecond;
      if (limits.burstCapacity) existing.burstCapacity = limits.burstCapacity;
      if (limits.maxWaitTime) existing.maxWaitTime = limits.maxWaitTime;
    } else {
      this._createModelBucket(model, limits);
    }
  }

  /**
   * Get per-model rate limit status
   * @param {string} model
   * @returns {object|null}
   */
  getModelRateLimit(model) {
    const bucket = this.buckets.get(model);
    if (!bucket) return null;
    return bucket.getStatus();
  }

  /**
   * Create a token bucket for a model
   */
  _createModelBucket(model, options = {}) {
    this.buckets.set(model, new TokenBucket({
      tokensPerSecond: options.tokensPerSecond || this.defaultLimits.tokensPerSecond,
      burstCapacity: options.burstCapacity || this.defaultLimits.burstCapacity,
      maxWaitTime: options.maxWaitTime
    }));
  }

  /**
   * Reset all usage tracking
   */
  reset() {
    this.usage.clear();
    this.buckets.clear();
    this.sessionCost = 0;
    this.sessionTokens = 0;
    this.sessionStart = Date.now();
  }
}

module.exports = { CostManager, TokenBucket };
