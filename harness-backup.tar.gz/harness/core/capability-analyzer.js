/**
 * Capability Analyzer - Depth-First 錯誤分析器
 * 
 * 核心哲學：當錯誤發生，唔好再嘗試同一樣嘢（try harder）
 * 而係問：「系統缺少什麼能力導致呢個錯誤？」
 * 然後深度探索呢個能力維度，一路行到底，遇到阻礙先返回
 * 
 * 呢個係 Harness Framework 既 "Depth-First Debugging" 核心引擎
 */

const { EventEmitter } = require('events');

// 能力維度樹 - 定義每個 Error Source 下面既能力維度
// DFS 遍歷時，我哋會沿住呢棵樹一條路徑行到底
const CAPABILITY_DIMENSIONS = {
  NETWORK: {
    label: '🌐 Network',
    dimensions: [
      {
        name: 'connectivity',
        label: '連接能力',
        tests: [
          { type: 'ping', desc: '測試基礎網絡連接' },
          { type: 'dns', desc: 'DNS 解析是否正常' },
          { type: 'firewall', desc: '防火牆是否阻擋' }
        ],
        subDimensions: ['dns_lookup', 'tcp_handshake', 'ssl_handshake', 'proxy_connect']
      },
      {
        name: 'authentication',
        label: '認證能力',
        tests: [
          { type: 'token_expiry', desc: 'Token 是否過期' },
          { type: 'scope', desc: 'Scope 是否足夠' },
          { type: 'refresh', desc: 'Refresh token 是否有效' }
        ],
        subDimensions: ['bearer_token', 'api_key', 'oauth2', 'jwt_expiry']
      },
      {
        name: 'rate_limit',
        label: '速率限制',
        tests: [
          { type: 'quota', desc: '是否超出配額' },
          { type: 'throttle', desc: '是否被節流' },
          { type: 'backoff', desc: '是否需要退避' }
        ],
        subDimensions: ['requests_per_second', 'daily_limit', 'monthly_quota']
      },
      {
        name: 'proxy',
        label: '代理能力',
        tests: [
          { type: 'proxy_config', desc: '代理配置是否正確' },
          { type: 'proxy_auth', desc: '代理認證是否通過' }
        ],
        subDimensions: ['http_proxy', 'socks_proxy', 'proxy_pac']
      },
      {
        name: 'ssl',
        label: 'SSL/TLS',
        tests: [
          { type: 'certificate', desc: '證書是否有效' },
          { type: 'tls_version', desc: 'TLS 版本是否支援' },
          { type: 'cipher_suite', desc: '加密套件是否匹配' }
        ],
        subDimensions: ['cert_expiry', 'self_signed', 'chain_trust']
      }
    ]
  },
  
  RUNTIME: {
    label: '⚡ Runtime',
    dimensions: [
      {
        name: 'memory',
        label: '記憶體能力',
        tests: [
          { type: 'heap_usage', desc: '堆記憶體使用率' },
          { type: 'memory_leak', desc: '是否有記憶體泄漏' },
          { type: 'gc_pressure', desc: 'GC 壓力是否過高' }
        ],
        subDimensions: ['heap_size', 'stack_size', 'buffer_alloc']
      },
      {
        name: 'api_support',
        label: 'API 支援',
        tests: [
          { type: 'feature_detection', desc: '功能是否支援' },
          { type: 'polyfill', desc: '是否需要 polyfill' },
          { type: 'version', desc: 'API 版本是否匹配' }
        ],
        subDimensions: ['es6_features', 'webapi', 'node_api']
      },
      {
        name: 'feature_flag',
        label: '功能開關',
        tests: [
          { type: 'flag_enabled', desc: '功能開關是否開啟' },
          { type: 'rollout', desc: ' rollout 百分比是否覆蓋' },
          { type: 'overrides', desc: '是否有本地覆蓋' }
        ],
        subDimensions: ['remote_config', 'local_overrides', 'experiment_groups']
      },
      {
        name: 'permission',
        label: '權限能力',
        tests: [
          { type: 'notification', desc: '通知權限是否授予' },
          { type: 'geolocation', desc: '位置權限是否授予' },
          { type: 'storage', desc: '儲存權限是否授予' }
        ],
        subDimensions: ['camera', 'microphone', 'notifications']
      }
    ]
  },
  
  STATE: {
    label: '📦 State',
    dimensions: [
      {
        name: 'store_initialization',
        label: 'Store 初始化',
        tests: [
          { type: 'created', desc: 'Store 是否已創建' },
          { type: 'configured', desc: '是否正確配置' },
          { type: 'middleware', desc: 'Middleware 是否掛載' }
        ],
        subDimensions: ['reducer_tree', 'middleware_chain', 'devtools']
      },
      {
        name: 'state_sync',
        label: '狀態同步',
        tests: [
          { type: 'consistent', desc: '狀態是否一致' },
          { type: 'conflict', desc: '是否有衝突' },
          { type: 'rollback', desc: '是否需要回滾' }
        ],
        subDimensions: ['optimistic_update', 'server_state', 'local_cache']
      },
      {
        name: 'immutability',
        label: '不可變性',
        tests: [
          { type: 'frozen', desc: '狀態是否被 freeze' },
          { type: 'mutated', desc: '是否有地方直接修改' }
        ],
        subDimensions: ['deep_freeze', 'immer', 'persistent_data']
      },
      {
        name: 'transaction',
        label: '事務處理',
        tests: [
          { type: 'atomic', desc: '是否原子性操作' },
          { type: 'rollback', desc: '失敗是否正確回滾' }
        ],
        subDimensions: ['saga_effects', 'thunk_chain', 'side_effects']
      }
    ]
  },
  
  RENDER: {
    label: '🎨 Render',
    dimensions: [
      {
        name: 'dom_element',
        label: 'DOM 元素',
        tests: [
          { type: 'exists', desc: '元素是否存在' },
          { type: 'visible', desc: '元素是否可見' },
          { type: 'attached', desc: '是否附加到 DOM' }
        ],
        subDimensions: ['query_selector', 'shadow_dom', 'iframe_content']
      },
      {
        name: 'css_support',
        label: 'CSS 支援',
        tests: [
          { type: 'flexbox', desc: 'Flexbox 是否支援' },
          { type: 'grid', desc: 'Grid 是否支援' },
          { type: 'custom_properties', desc: 'CSS 變量是否支援' }
        ],
        subDimensions: ['vendor_prefix', 'modern_css', 'css_houdini']
      },
      {
        name: 'animation',
        label: '動畫能力',
        tests: [
          { type: 'requestAnimationFrame', desc: 'RAF 是否可用' },
          { type: 'web_animations', desc: 'Web Animations API' },
          { type: 'transition', desc: 'CSS Transition' }
        ],
        subDimensions: ['performance', 'vsync', 'compositor_thread']
      },
      {
        name: 'asset_loading',
        label: '資源載入',
        tests: [
          { type: 'image', desc: '圖片是否載入成功' },
          { type: 'font', desc: '字體是否載入成功' },
          { type: 'stylesheet', desc: '樣式表是否載入成功' }
        ],
        subDimensions: ['preload', 'lazy_load', 'cache_hit']
      }
    ]
  },
  
  AUTH: {
    label: '🔐 Auth',
    dimensions: [
      {
        name: 'token_validity',
        label: 'Token 有效性',
        tests: [
          { type: 'not_expired', desc: 'Token 是否過期' },
          { type: 'not_revoked', desc: 'Token 是否被撤銷' },
          { type: 'signature', desc: '簽名是否正確' }
        ],
        subDimensions: ['access_token', 'id_token', 'refresh_token']
      },
      {
        name: 'scope',
        label: '權限範圍',
        tests: [
          { type: 'required_scopes', desc: '必要 Scope 是否滿足' },
          { type: 'sufficient', desc: 'Scope 是否足夠' }
        ],
        subDimensions: ['read', 'write', 'admin', 'custom']
      },
      {
        name: 'session',
        label: 'Session',
        tests: [
          { type: 'active', desc: 'Session 是否活躍' },
          { type: 'timeout', desc: '是否超時' },
          { type: 'invalidated', desc: '是否被無效化' }
        ],
        subDimensions: ['cookie', 'server_session', 'client_session']
      }
    ]
  }
};

/**
 * Hypothesis - 代表一次能力測試假設
 */
class Hypothesis {
  constructor({ dimension, test, error, context }) {
    this.id = `hyp-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    this.dimension = dimension;
    this.test = test;
    this.error = error;
    this.context = context;
    this.confidence = 0.0;
    this.evidence = [];
    this.is_root_cause = false;
    this.children = [];
    this.visited = false;
    this.timestamp = new Date().toISOString();
  }
  
  /**
   * 添加證據
   */
  addEvidence(evidence) {
    this.evidence.push({
      type: evidence.type || 'observation',
      data: evidence.data,
      timestamp: new Date().toISOString()
    });
    
    // 重新計算 confidence
    this._recalculateConfidence();
  }
  
  /**
   * 標記為根本原因
   */
  markAsRootCause() {
    this.is_root_cause = true;
  }
  
  /**
   * 重新計算置信度
   */
  _recalculateConfidence() {
    // 簡單的置信度計算：證據越多，置信度越高
    const baseConfidence = 0.3;
    const evidenceBonus = Math.min(0.5, this.evidence.length * 0.15);
    const contextBonus = this.context ? 0.2 : 0;
    
    this.confidence = Math.min(1.0, baseConfidence + evidenceBonus + contextBonus);
  }
}

/**
 * Capability Analyzer - Depth-First 能力分析器
 * 
 * 使用 DFS 遍歷能力維度樹，尋找錯誤的根本原因
 */
class CapabilityAnalyzer extends EventEmitter {
  constructor({ logger, maxDepth = 5 } = {}) {
    super();
    this.logger = logger || console;
    this.maxDepth = maxDepth;
    
    // 能力維度配置
    this.capabilityDimensions = CAPABILITY_DIMENSIONS;
    
    // 當前分析結果
    this.currentAnalysis = null;
    
    // 分析歷史
    this.analysisHistory = [];
  }
  
  /**
   * 主入口：Depth-First 分析錯誤
   * 
   * @param {Object} error - 錯誤對象（來自 ErrorDetector）
   * @param {Object} context - 額外上下文（網絡請求結果、狀態快照等）
   * @returns {Object} - 分析結果，包含根本原因 + 探索路徑
   */
  analyze(error, context = {}) {
    this.logger.info('CapabilityAnalyzer: Starting DFS analysis', { 
      errorType: error.type, 
      source: error.source,
      errorText: error.text || error.message
    });
    
    // Step 1: 構建分析樹
    const tree = this._buildAnalysisTree(error, context);
    
    // Step 2: Depth-First Search
    const result = this._depthFirstSearch(tree, 0);
    
    // Step 3: 生成建議
    const recommendation = this._generateRecommendation(result, error, context);
    
    // 保存結果
    this.currentAnalysis = {
      error,
      context,
      tree,
      result,
      recommendation,
      timestamp: new Date().toISOString()
    };
    
    this.analysisHistory.push(this.currentAnalysis);
    
    this.logger.info('CapabilityAnalyzer: DFS analysis complete', {
      rootCause: result?.node?.dimension,
      confidence: result?.node?.confidence,
      exploredPaths: result?.exploredPaths
    });
    
    return this.currentAnalysis;
  }
  
  /**
   * 構建分析樹
   * 
   * 根據 error source，構建對應的能力維度樹
   */
  _buildAnalysisTree(error, context) {
    const source = error.source; // e.g., 'NETWORK', 'RUNTIME'
    const sourceConfig = this.capabilityDimensions[source];
    
    if (!sourceConfig) {
      // 未知 source，創建通用節點
      return {
        error,
        context,
        dimensionName: 'unknown',
        label: 'Unknown Error Source',
        children: [],
        visited: false,
        depth: 0
      };
    }
    
    // 構建根節點
    const root = {
      error,
      context,
      dimensionName: 'root',
      label: sourceConfig.label,
      children: [],
      visited: false,
      depth: 0
    };
    
    // 為每個主要維度創建子節點
    for (const dim of sourceConfig.dimensions) {
      const dimNode = {
        dimension: dim,
        dimensionName: dim.name,
        label: dim.label,
        error,
        context,
        children: [],
        visited: false,
        depth: 1,
        parent: root
      };
      
      // 為每個子維度創建葉節點
      for (const subDim of dim.subDimensions || []) {
        const subNode = {
          subDimension: subDim,
          dimensionName: `${dim.name}.${subDim}`,
          label: subDim,
          error,
          context,
          children: [],
          visited: false,
          depth: 2,
          parent: dimNode
        };
        dimNode.children.push(subNode);
      }
      
      root.children.push(dimNode);
    }
    
    return root;
  }
  
  /**
   * 核心 DFS 搜索
   * 
   * 沿住樹一路行到底，找到根本原因就停（backtrack）
   */
  _depthFirstSearch(node, depth) {
    if (depth > this.maxDepth || node.visited) {
      return { node: null, exploredPaths: depth };
    }
    
    node.visited = true;
    const exploredPaths = [];
    
    // 創建 Hypothesis 來評估呢個節點
    const hypothesis = this._evaluateNode(node);
    
    this.logger.info(`[DFS] Exploring: ${node.dimensionName}`, {
      depth,
      confidence: hypothesis.confidence,
      evidenceCount: hypothesis.evidence.length
    });
    
    // 檢查呢個節點是否係根本原因
    if (this._isDecisive(hypothesis)) {
      hypothesis.markAsRootCause();
      
      return {
        node: hypothesis,
        exploredPaths: exploredPaths.length + 1,
        path: this._reconstructPath(node)
      };
    }
    
    // 繼續深度探索
    if (node.children && node.children.length > 0) {
      // DFS: 揀第一個未訪問的子節點繼續
      for (const child of node.children) {
        if (!child.visited) {
          const childResult = this._depthFirstSearch(child, depth + 1);
          
          if (childResult.node) {
            // 找到根本原因，一路返回
            return childResult;
          }
          
          exploredPaths.push(childResult.exploredPaths);
        }
      }
    }
    
    // 所有子路徑都探索完，呢個節點唔係根本原因
    // 返回 alternative paths
    return {
      node: hypothesis,
      exploredPaths: exploredPaths.length,
      alternatives: this._collectAlternatives(node),
      path: this._reconstructPath(node)
    };
  }
  
  /**
   * 評估節點，生成 Hypothesis
   */
  _evaluateNode(node) {
    const hypothesis = new Hypothesis({
      dimension: node.dimensionName,
      test: node.label,
      error: node.error,
      context: node.context
    });
    
    // 根據錯誤信息和節點維度，生成假設
    const errorText = (node.error.text || node.error.message || '').toLowerCase();
    const dimensionName = node.dimensionName.toLowerCase();
    
    // 嘗試匹配錯誤模式和維度
    if (dimensionName.includes('network') || dimensionName.includes('connectivity')) {
      if (errorText.includes('fetch') || errorText.includes('net::') || errorText.includes('connection')) {
        hypothesis.addEvidence({
          type: 'pattern_match',
          data: 'Error text matches connectivity issue'
        });
        hypothesis.addEvidence({
          type: 'diagnostic',
          data: 'Possible DNS/DNS resolution failure or firewall blocking'
        });
      }
    }
    
    if (dimensionName.includes('auth') || dimensionName.includes('authentication')) {
      if (errorText.includes('401') || errorText.includes('unauthorized') || errorText.includes('token')) {
        hypothesis.addEvidence({
          type: 'pattern_match',
          data: 'Error text matches authentication issue'
        });
        hypothesis.addEvidence({
          type: 'diagnostic',
          data: 'Bearer token may be expired or invalid'
        });
      }
    }
    
    if (dimensionName.includes('rate_limit')) {
      if (errorText.includes('429') || errorText.includes('rate') || errorText.includes('quota')) {
        hypothesis.addEvidence({
          type: 'pattern_match',
          data: 'Error text matches rate limit issue'
        });
      }
    }
    
    if (dimensionName.includes('ssl') || dimensionName.includes('certificate')) {
      if (errorText.includes('ssl') || errorText.includes('certificate') || errorText.includes('tls')) {
        hypothesis.addEvidence({
          type: 'pattern_match',
          data: 'Error text matches SSL/certificate issue'
        });
      }
    }
    
    if (dimensionName.includes('memory')) {
      if (errorText.includes('memory') || errorText.includes('heap') || errorText.includes('allocation')) {
        hypothesis.addEvidence({
          type: 'pattern_match',
          data: 'Error text matches memory issue'
        });
      }
    }
    
    // 根據 context 添加證據
    if (node.context) {
      if (node.context.responseHeaders) {
        hypothesis.addEvidence({
          type: 'context',
          data: 'Has response headers from failed request'
        });
      }
      if (node.context.stack) {
        hypothesis.addEvidence({
          type: 'context',
          data: 'Has stack trace available'
        });
      }
    }
    
    return hypothesis;
  }
  
  /**
   * 判斷 Hypothesis 是否足夠確定（係根本原因）
   */
  _isDecisive(hypothesis) {
    // 置信度 > 0.7 且有明確證據
    if (hypothesis.confidence >= 0.7 && hypothesis.evidence.length >= 2) {
      return true;
    }
    
    // 特殊模式匹配：明確的錯誤類型
    const evidenceTexts = hypothesis.evidence.map(e => 
      (e.data || '').toString().toLowerCase()
    ).join(' ');
    
    if (evidenceTexts.includes('pattern_match') && hypothesis.confidence >= 0.5) {
      return true;
    }
    
    return false;
  }
  
  /**
   * 收集替代路徑（當主路徑失敗時）
   */
  _collectAlternatives(node) {
    const alternatives = [];
    
    if (node.children) {
      for (const child of node.children) {
        if (!child.visited) {
          alternatives.push({
            dimensionName: child.dimensionName,
            label: child.label,
            reason: 'Not explored in main DFS path'
          });
        }
      }
    }
    
    return alternatives;
  }
  
  /**
   * 重構從根到當前節點的路徑
   */
  _reconstructPath(node) {
    const path = [];
    let current = node;
    
    while (current) {
      path.unshift({
        dimensionName: current.dimensionName,
        label: current.label || current.dimension?.label
      });
      current = current.parent;
    }
    
    return path;
  }
  
  /**
   * 生成修復建議
   */
  _generateRecommendation(result, error, context) {
    const recommendations = [];
    
    if (!result.node) {
      return {
        message: 'Could not determine root cause',
        actions: [],
        severity: 'unknown'
      };
    }
    
    const rootCause = result.node;
    const dimension = rootCause.dimension;
    
    // 根據維度生成具體建議
    const actionMap = {
      'connectivity': {
        message: 'Network connectivity issue detected',
        actions: [
          { cmd: 'Check internet connection', type: 'diagnostic' },
          { cmd: 'Verify DNS resolution: nslookup <domain>', type: 'diagnostic' },
          { cmd: 'Check firewall rules', type: 'diagnostic' },
          { cmd: 'Try curl or wget to test endpoint', type: 'diagnostic' }
        ]
      },
      'authentication': {
        message: 'Authentication failure - token may be expired or invalid',
        actions: [
          { cmd: 'openclaw auth refresh', type: 'fix', platform: 'openclaw' },
          { cmd: 'openclaw auth verify', type: 'diagnostic', platform: 'openclaw' },
          { cmd: 'Check token expiry in gateway logs', type: 'diagnostic' }
        ]
      },
      'rate_limit': {
        message: 'Rate limit exceeded',
        actions: [
          { cmd: 'Implement exponential backoff', type: 'fix' },
          { cmd: 'Check API quota in dashboard', type: 'diagnostic' },
          { cmd: 'Reduce request frequency', type: 'workaround' }
        ]
      },
      'ssl': {
        message: 'SSL/TLS certificate issue',
        actions: [
          { cmd: 'Check certificate expiry: openssl x509 -enddate', type: 'diagnostic' },
          { cmd: 'Verify certificate chain: openssl verify', type: 'diagnostic' },
          { cmd: 'Renew or reinstall certificate', type: 'fix' }
        ]
      },
      'memory': {
        message: 'Memory issue detected',
        actions: [
          { cmd: 'Check heap usage in browser DevTools', type: 'diagnostic' },
          { cmd: 'Review memory allocation patterns', type: 'diagnostic' },
          { cmd: 'Consider increasing memory limits', type: 'fix' }
        ]
      }
    };
    
    // 匹配維度名稱（可能係 "network.connectivity" 或 "authentication"）
    const dimensionKey = dimension.split('.')[0];
    const action = actionMap[dimensionKey] || {
      message: `Issue in ${dimension} dimension`,
      actions: [
        { cmd: `Investigate ${dimension} configuration`, type: 'diagnostic' }
      ]
    };
    
    return {
      rootCause: dimension,
      confidence: rootCause.confidence,
      message: action.message,
      actions: action.actions,
      evidence: rootCause.evidence,
      severity: rootCause.confidence >= 0.8 ? 'HIGH' : 'MEDIUM',
      alternativePaths: result.alternatives || []
    };
  }
  
  /**
   * 獲取分析歷史
   */
  getHistory() {
    return [...this.analysisHistory];
  }
  
  /**
   * 獲取最新分析結果
   */
  getLatestAnalysis() {
    return this.currentAnalysis;
  }
  
  /**
   * 清除歷史
   */
  clearHistory() {
    this.analysisHistory = [];
    this.currentAnalysis = null;
  }
  
  /**
   * 獲取能力維度配置（用於調試/展示）
   */
  getCapabilityDimensions() {
    return this.capabilityDimensions;
  }
}

module.exports = CapabilityAnalyzer;
module.exports.CAPABILITY_DIMENSIONS = CAPABILITY_DIMENSIONS;
module.exports.Hypothesis = Hypothesis;
