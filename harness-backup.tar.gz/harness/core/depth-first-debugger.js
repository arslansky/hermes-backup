/**
 * Depth-First Debugger - 核心調試引擎
 * 
 * 對比傳統 BFS Debugging：
 * - BFS: 一次過檢查所有可能性（表面）
 * - DFS: 揀一條路徑，行到底，找出根本原因
 * 
 * 呢個模塊係 Harness Framework 既 "大腦"
 * 負責協調 ErrorDetector、NetworkMonitor、StateInspector
 * 進行深度優先的故障根因分析
 */

const { EventEmitter } = require('events');
const CapabilityAnalyzer = require('./capability-analyzer');

/**
 * DiagnosticNode - 診斷樹中的節點
 */
class DiagnosticNode {
  constructor({ type, label, data, parent = null }) {
    this.id = `diag-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    this.type = type; // 'error' | 'state' | 'network' | 'capability'
    this.label = label;
    this.data = data;
    this.parent = parent;
    this.children = [];
    this.visited = false;
    this.depth = parent ? parent.depth + 1 : 0;
    this.timestamp = new Date().toISOString();
  }
  
  /**
   * 添加子節點
   */
  addChild(node) {
    node.parent = this;
    this.children.push(node);
    return node;
  }
  
  /**
   * 獲取路徑到根節點
   */
  getPath() {
    const path = [];
    let current = this;
    while (current) {
      path.unshift(current);
      current = current.parent;
    }
    return path;
  }
}

/**
 * DiagnosticResult - 診斷結果
 */
class DiagnosticResult {
  constructor() {
    this.rootCause = null;
    this.fixActions = [];
    this.confidence = 0;
    this.exploredNodes = 0;
    this.alternativePaths = [];
    this.diagnosticTree = null;
    this.timestamp = new Date().toISOString();
  }
  
  /**
   * 設置根本原因
   */
  setRootCause(node, confidence) {
    this.rootCause = {
      id: node.id,
      type: node.type,
      label: node.label,
      data: node.data,
      path: node.getPath().map(n => ({ type: n.type, label: n.label }))
    };
    this.confidence = confidence;
  }
  
  /**
   * 添加修復動作
   */
  addFixAction(action) {
    this.fixActions.push({
      ...action,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * 添加替代路徑
   */
  addAlternative(path) {
    this.alternativePaths.push(path);
  }
  
  /**
   * 轉換為 JSON
   */
  toJSON() {
    return {
      rootCause: this.rootCause,
      fixActions: this.fixActions,
      confidence: this.confidence,
      exploredNodes: this.exploredNodes,
      alternativePaths: this.alternativePaths,
      diagnosticTree: this._treeToJSON(this.diagnosticTree),
      timestamp: this.timestamp
    };
  }
  
  /**
   * 將樹結構轉為 JSON（去除循環引用）
   */
  _treeToJSON(node) {
    if (!node) return null;
    return {
      id: node.id,
      type: node.type,
      label: node.label,
      depth: node.depth,
      children: node.children.map(c => this._treeToJSON(c))
    };
  }
}

/**
 * Depth-First Debugger - 核心調試引擎
 */
class DepthFirstDebugger extends EventEmitter {
  constructor({ logger, maxDepth = 8 } = {}) {
    super();
    this.logger = logger || console;
    this.maxDepth = maxDepth;
    
    // 核心組件
    this.capabilityAnalyzer = new CapabilityAnalyzer({ logger, maxDepth });
    
    // 診斷結果
    this.currentResult = null;
    
    // 診斷歷史
    this.diagnosticHistory = [];
    
    // 配置
    this.config = {
      enableCapabilityAnalysis: true,
      enableNetworkAnalysis: true,
      enableStateAnalysis: true,
      autoCorrelateErrors: true
    };
  }
  
  /**
   * 主入口：診斷並獲取修復方案
   * 
   * @param {Object} error - 錯誤對象
   * @param {Object} context - 系統上下文（網絡請求、狀態快照等）
   * @returns {DiagnosticResult} - 包含根本原因 + 修復動作
   */
  async diagnose(error, context = {}) {
    this.logger.info('DepthFirstDebugger: Starting diagnosis', {
      errorType: error.type,
      source: error.source
    });
    
    // 創建診斷結果對象
    const result = new DiagnosticResult();
    
    // Step 1: 構建診斷樹
    const tree = this._buildDiagnosticTree(error, context);
    result.diagnosticTree = tree;
    
    // Step 2: 執行 DFS 診斷
    const dfsResult = await this._executeDepthFirstSearch(tree, result);
    
    // Step 3: 如果有 CapabilityAnalyzer 結果，合併
    if (this.config.enableCapabilityAnalysis) {
      const capabilityResult = this.capabilityAnalyzer.analyze(error, context);
      this._mergeCapabilityResult(result, capabilityResult);
    }
    
    // Step 4: 生成修復動作
    this._generateFixActions(result, error, context);
    
    // 保存結果
    this.currentResult = result;
    this.diagnosticHistory.push(result);
    
    this.logger.info('DepthFirstDebugger: Diagnosis complete', {
      rootCause: result.rootCause?.label,
      confidence: result.confidence,
      fixActions: result.fixActions.length
    });
    
    return result;
  }
  
  /**
   * 構建診斷樹
   * 
   * 根據錯誤和上下文，構建一棵診斷樹
   * 樹的結構反映了問題的層次關係
   */
  _buildDiagnosticTree(error, context) {
    // 根節點：錯誤本身
    const root = new DiagnosticNode({
      type: 'error',
      label: 'Root Error',
      data: error
    });
    
    // 如果有網絡上下文
    if (context.network && this.config.enableNetworkAnalysis) {
      const networkNode = this._buildNetworkNode(context.network);
      root.addChild(networkNode);
    }
    
    // 如果有狀態上下文
    if (context.state && this.config.enableStateAnalysis) {
      const stateNode = this._buildStateNode(context.state);
      root.addChild(stateNode);
    }
    
    // Capability 維度節點（由 CapabilityAnalyzer 提供）
    if (this.config.enableCapabilityAnalysis) {
      const capabilityNode = new DiagnosticNode({
        type: 'capability',
        label: 'Capability Analysis',
        data: { source: error.source }
      });
      
      const dims = this.capabilityAnalyzer.getCapabilityDimensions();
      const sourceDims = dims[error.source];
      
      if (sourceDims) {
        for (const dim of sourceDims.dimensions) {
          const dimNode = new DiagnosticNode({
            type: 'capability_dimension',
            label: dim.label,
            data: { dimension: dim.name }
          });
          
          capabilityNode.addChild(dimNode);
        }
      }
      
      root.addChild(capabilityNode);
    }
    
    return root;
  }
  
  /**
   * 構建網絡節點
   */
  _buildNetworkNode(networkContext) {
    const node = new DiagnosticNode({
      type: 'network',
      label: 'Network Context',
      data: {
        url: networkContext.url,
        status: networkContext.status,
        duration: networkContext.duration
      }
    });
    
    // 如果有失敗的請求，添加子節點
    if (networkContext.failed) {
      node.addChild(new DiagnosticNode({
        type: 'network_failure',
        label: `Request Failed: ${networkContext.status || 'Network Error'}`,
        data: {
          error: networkContext.error,
          status: networkContext.status
        }
      }));
    }
    
    // 如果有認證問題
    if (networkContext.status === 401 || networkContext.status === 403) {
      node.addChild(new DiagnosticNode({
        type: 'auth_issue',
        label: 'Authentication/Authorization Issue',
        data: { status: networkContext.status }
      }));
    }
    
    return node;
  }
  
  /**
   * 構建狀態節點
   */
  _buildStateNode(stateContext) {
    const node = new DiagnosticNode({
      type: 'state',
      label: 'State Context',
      data: {}
    });
    
    // Redux 狀態
    if (stateContext.redux) {
      node.addChild(new DiagnosticNode({
        type: 'redux_state',
        label: 'Redux Store',
        data: { hasState: !!stateContext.redux }
      }));
    }
    
    // Vuex 狀態
    if (stateContext.vuex) {
      node.addChild(new DiagnosticNode({
        type: 'vuex_state',
        label: 'Vuex Store',
        data: { hasState: !!stateContext.vuex }
      }));
    }
    
    return node;
  }
  
  /**
   * 執行深度優先搜索
   */
  async _executeDepthFirstSearch(node, result) {
    let visitedCount = 0;
    
    // DFS 遞歸遍历
    const visit = async (n, depth = 0) => {
      if (depth > this.maxDepth || n.visited) {
        return null;
      }
      
      n.visited = true;
      visitedCount++;
      
      // 評估呢個節點
      const evaluation = this._evaluateNode(n);
      
      if (evaluation.is_decisive) {
        // 找到決定性節點（根本原因）
        result.setRootCause(n, evaluation.confidence);
        return n;
      }
      
      // 繼續深度探索子節點
      for (const child of n.children) {
        if (!child.visited) {
          const found = await visit(child, depth + 1);
          if (found) {
            return found;
          }
        }
      }
      
      // 所有子節點都探索完
      return null;
    };
    
    const rootCause = await visit(node);
    
    result.exploredNodes = visitedCount;
    
    // 如果冇找到根本原因，標記為未知
    if (!rootCause && !result.rootCause) {
      result.setRootCause(node, 0.1);
    }
    
    // 收集替代路徑
    this._collectAlternativePaths(node, result);
    
    return result;
  }
  
  /**
   * 評估節點
   */
  _evaluateNode(node) {
    // 根據節點類型和數據，評估係唔係根本原因
    
    let is_decisive = false;
    let confidence = 0.1;
    
    switch (node.type) {
      case 'error':
        // 根錯誤節點通常唔係最終根本原因
        confidence = 0.2;
        break;
        
      case 'network_failure':
        // 網絡失敗通常係根本原因或接近根本原因
        if (node.data.status >= 500) {
          is_decisive = true;
          confidence = 0.9;
        } else if (node.data.status === 401 || node.data.status === 403) {
          is_decisive = true;
          confidence = 0.95;
        } else if (node.data.status >= 400) {
          confidence = 0.7;
        }
        break;
        
      case 'auth_issue':
        // 認證問題幾乎永遠係根本原因
        is_decisive = true;
        confidence = 0.95;
        break;
        
      case 'capability_dimension':
        // 能力維度節點需要進一步探索
        confidence = 0.3;
        break;
        
      default:
        confidence = 0.2;
    }
    
    return { is_decisive, confidence };
  }
  
  /**
   * 收集替代路徑
   */
  _collectAlternativePaths(node, result) {
    const collect = (n, path = []) => {
      if (!n.visited && n.type !== 'error') {
        result.addAlternative([...path, { type: n.type, label: n.label }]);
      }
      
      for (const child of n.children) {
        collect(child, [...path, { type: n.type, label: n.label }]);
      }
    };
    
    collect(node);
  }
  
  /**
   * 合併 CapabilityAnalyzer 的結果
   */
  _mergeCapabilityResult(result, capabilityResult) {
    if (!capabilityResult || !capabilityResult.recommendation) {
      return;
    }
    
    const rec = capabilityResult.recommendation;
    
    // 如果 CapabilityAnalyzer 置信度更高，更新根本原因
    if (rec.confidence > result.confidence) {
      result.confidence = rec.confidence;
      result.rootCause = {
        type: 'capability',
        label: rec.rootCause,
        data: {
          message: rec.message,
          evidence: rec.evidence
        },
        path: [{ type: 'capability', label: rec.rootCause }]
      };
    }
    
    // 添加 CapabilityAnalyzer 生成的修復動作
    if (rec.actions) {
      for (const action of rec.actions) {
        result.addFixAction({
          ...action,
          source: 'capability_analyzer'
        });
      }
    }
  }
  
  /**
   * 生成修復動作
   */
  _generateFixActions(result, error, context) {
    // 如果已經有修復動作（從 CapabilityAnalyzer），唔好重複添加
    if (result.fixActions.length > 0) {
      return;
    }
    
    const rootCause = result.rootCause;
    
    if (!rootCause) {
      result.addFixAction({
        type: 'diagnostic',
        cmd: 'Further investigation needed',
        message: 'Could not determine specific fix action'
      });
      return;
    }
    
    // 根據根本原因類型生成修復動作
    switch (rootCause.type) {
      case 'network_failure':
        if (rootCause.data.status >= 500) {
          result.addFixAction({
            type: 'fix',
            cmd: 'check_server_logs',
            message: 'Server error detected - check server-side logs'
          });
        } else if (rootCause.data.status === 404) {
          result.addFixAction({
            type: 'fix',
            cmd: 'verify_endpoint',
            message: 'Endpoint not found - verify URL is correct'
          });
        } else {
          result.addFixAction({
            type: 'diagnostic',
            cmd: 'check_network',
            message: 'Network request failed - verify connectivity'
          });
        }
        break;
        
      case 'auth_issue':
        result.addFixAction({
          type: 'fix',
          cmd: 'openclaw auth refresh',
          message: 'Re-authenticate to refresh credentials'
        });
        result.addFixAction({
          type: 'diagnostic',
          cmd: 'openclaw status',
          message: 'Verify current authentication status'
        });
        break;
        
      case 'capability':
        result.addFixAction({
          type: 'diagnostic',
          cmd: 'investigate_capability',
          message: `Investigate ${rootCause.label} capability`
        });
        break;
        
      default:
        result.addFixAction({
          type: 'diagnostic',
          cmd: 'manual_review',
          message: 'Manual review recommended for this issue'
        });
    }
  }
  
  /**
   * 獲取當前診斷結果
   */
  getCurrentResult() {
    return this.currentResult;
  }
  
  /**
   * 獲取診斷歷史
   */
  getHistory() {
    return this.diagnosticHistory.map(r => r.toJSON ? r.toJSON() : r);
  }
  
  /**
   * 清除歷史
   */
  clearHistory() {
    this.diagnosticHistory = [];
    this.currentResult = null;
  }
  
  /**
   * 配置組件
   */
  configure(options) {
    this.config = { ...this.config, ...options };
    return this;
  }
}

module.exports = DepthFirstDebugger;
module.exports.DiagnosticNode = DiagnosticNode;
module.exports.DiagnosticResult = DiagnosticResult;
