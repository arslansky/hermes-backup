'use strict';

const fs = require('fs');
const path = require('path');

/**
 * Represents a single test case for evaluation.
 */
class TestCase {
  constructor({ id, name, prompt, expected, evaluator_type, rubric } = {}) {
    this.id = id || `test-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    this.name = name || '';
    this.prompt = prompt || '';
    this.expected = expected !== undefined ? expected : '';
    this.evaluator_type = evaluator_type || 'exact_match';
    this.rubric = rubric || '';
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      prompt: this.prompt,
      expected: this.expected,
      evaluator_type: this.evaluator_type,
      rubric: this.rubric
    };
  }
}

/**
 * Benchmark definition loader.
 * Supports loading from JSON and YAML-like (simple key-value) files.
 */
class BenchmarkDefinition {
  constructor({ id, name, description, test_cases, metadata } = {}) {
    this.id = id || `benchmark-${Date.now()}`;
    this.name = name || '';
    this.description = description || '';
    this.test_cases = (test_cases || []).map(tc => tc instanceof TestCase ? tc : new TestCase(tc));
    this.metadata = metadata || {};
  }

  get testCount() {
    return this.test_cases.length;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      testCount: this.testCount,
      test_cases: this.test_cases.map(tc => tc.toJSON()),
      metadata: this.metadata
    };
  }
}

/**
 * Scoring utilities for various evaluation types.
 */
const scorers = {
  /**
   * Exact string match (whitespace-trimmed, case-sensitive by default).
   */
  exact_match(actual, expected, options = {}) {
    const { caseSensitive = true, trim = true } = options;
    let a = String(actual);
    let e = String(expected);
    if (trim) { a = a.trim(); e = e.trim(); }
    if (!caseSensitive) { a = a.toLowerCase(); e = e.toLowerCase(); }
    return { passed: a === e, score: a === e ? 1 : 0, details: null };
  },

  /**
   * Check if expected string is contained in actual output.
   */
  contains(actual, expected, options = {}) {
    const { caseSensitive = true } = options;
    let a = String(actual);
    let e = String(expected);
    if (!caseSensitive) { a = a.toLowerCase(); e = e.toLowerCase(); }
    const found = a.includes(e);
    return { passed: found, score: found ? 1 : 0, details: null };
  },

  /**
   * Regular expression match.
   */
  regex(actual, pattern, options = {}) {
    const { flags = '' } = options;
    const re = new RegExp(pattern, flags);
    const matches = re.test(String(actual));
    return { passed: matches, score: matches ? 1 : 0, details: null };
  },

  /**
   * LLM judge evaluation (calls evaluate function or runs subprocess).
   * In the base implementation, we accept an external evaluator function.
   */
  async llm_judge(actual, expected, options = {}) {
    const { evaluatorFn, prompt, rubric, model } = options;
    if (typeof evaluatorFn === 'function') {
      const result = await evaluatorFn({ actual, expected, prompt, rubric, model });
      if (result && typeof result === 'object') {
        return { passed: !!result.passed, score: result.score ?? (result.passed ? 1 : 0), details: result.details || null };
      }
      return { passed: !!result, score: result ? 1 : 0, details: null };
    }
    // Fallback: simple contains check with the rubric if available
    if (rubric) {
      return scorers.contains(actual, rubric, { caseSensitive: false });
    }
    // Default fallback: exact_match
    return scorers.exact_match(actual, expected);
  },

  /**
   * Code execution evaluation: runs the output as code or compares execution result.
   */
  async code_execution(actual, expected, options = {}) {
    const { executeFn, input, timeout } = options;
    if (typeof executeFn === 'function') {
      const result = await executeFn({ code: actual, input, timeout });
      if (result && typeof result === 'object') {
        const match = String(result.output || '') === String(expected);
        return { passed: match, score: match ? 1 : 0, details: result.error || null };
      }
      return { passed: false, score: 0, details: 'Execution returned no result' };
    }
    // Fallback: compare as exact match
    return scorers.exact_match(actual, expected);
  }
};

/**
 * Evaluation result for a single test case.
 */
class EvalResult {
  constructor({ testCase, actual, passed, score, details, error } = {}) {
    this.testCaseId = testCase ? (testCase.id || testCase.testCaseId) : '';
    this.testCaseName = testCase ? (testCase.name || '') : '';
    this.actual = actual !== undefined ? actual : '';
    this.passed = !!passed;
    this.score = typeof score === 'number' ? score : 0;
    this.details = details || null;
    this.error = error || null;
    this.timestamp = new Date().toISOString();
  }

  toJSON() {
    return {
      testCaseId: this.testCaseId,
      testCaseName: this.testCaseName,
      actual: this.actual,
      passed: this.passed,
      score: this.score,
      details: this.details,
      error: this.error,
      timestamp: this.timestamp
    };
  }
}

/**
 * Evaluation report generated after running a benchmark.
 */
class EvalReport {
  constructor({ benchmark, results, startTime, endTime } = {}) {
    this.benchmarkId = benchmark ? (benchmark.id || '') : '';
    this.benchmarkName = benchmark ? (benchmark.name || '') : '';
    this.benchmarkDescription = benchmark ? (benchmark.description || '') : '';
    this.results = results || [];
    this.startTime = startTime || new Date().toISOString();
    this.endTime = endTime || new Date().toISOString();
    this._computeSummary();
  }

  _computeSummary() {
    const total = this.results.length;
    const passed = this.results.filter(r => r.passed).length;
    const totalScore = this.results.reduce((sum, r) => sum + r.score, 0);
    this.total = total;
    this.passed = passed;
    this.failed = total - passed;
    this.passRate = total > 0 ? (passed / total) * 100 : 0;
    this.averageScore = total > 0 ? (totalScore / total) * 100 : 0;
    this.totalScore = totalScore;
  }

  get summary() {
    return {
      benchmarkId: this.benchmarkId,
      benchmarkName: this.benchmarkName,
      total: this.total,
      passed: this.passed,
      failed: this.failed,
      passRate: this.passRate,
      averageScore: this.averageScore,
      totalScore: this.totalScore,
      startTime: this.startTime,
      endTime: this.endTime,
      duration: new Date(this.endTime) - new Date(this.startTime)
    };
  }

  toJSON() {
    return {
      summary: this.summary,
      results: this.results.map(r => r.toJSON())
    };
  }

  /**
   * Generate a Markdown report string.
   */
  toMarkdown() {
    const s = this.summary;
    let md = `# Evaluation Report: ${s.benchmarkName}\n\n`;
    md += `**Benchmark ID:** ${s.benchmarkId}\n\n`;
    md += `## Summary\n\n`;
    md += `| Metric | Value |\n`;
    md += `|--------|-------|\n`;
    md += `| Total Tests | ${s.total} |\n`;
    md += `| Passed | ${s.passed} |\n`;
    md += `| Failed | ${s.failed} |\n`;
    md += `| Pass Rate | ${s.passRate.toFixed(2)}% |\n`;
    md += `| Average Score | ${s.averageScore.toFixed(2)}% |\n`;
    md += `| Duration | ${s.duration}ms |\n\n`;

    md += `## Results\n\n`;
    md += `| # | Test Case | Status | Score | Details |\n`;
    md += `|---|-----------|--------|-------|---------|\n`;

    this.results.forEach((r, i) => {
      const status = r.passed ? '✅ PASS' : '❌ FAIL';
      const details = r.details ? String(r.details).replace(/\n/g, ' ').substring(0, 80) : (r.error || '-');
      md += `| ${i + 1} | ${r.testCaseName} | ${status} | ${(r.score * 100).toFixed(0)}% | ${details} |\n`;
    });

    md += `\n---\n*Generated at: ${new Date().toISOString()}*\n`;
    return md;
  }
}

/**
 * Main benchmark runner.
 * Loads benchmark definitions and runs agents against test cases.
 */
class BenchmarkRunner {
  constructor(options = {}) {
    this.benchmarks = [];
    this.results = [];
    this.reports = [];
    this.defaultAgent = options.agent || null;
    this.workDir = options.workDir || process.cwd();
    this.scorers = { ...scorers, ...(options.customScorers || {}) };
    this.tracer = options.tracer || null;
  }

  /**
   * Load a benchmark definition from a file (JSON or simple YAML-like format).
   * @param {string} filePath - Path to the benchmark definition file.
   * @returns {BenchmarkDefinition}
   */
  loadBenchmark(filePath) {
    const resolvedPath = path.resolve(this.workDir, filePath);
    const content = fs.readFileSync(resolvedPath, 'utf-8');
    const ext = path.extname(filePath).toLowerCase();

    let data;
    if (ext === '.json') {
      data = JSON.parse(content);
    } else if (ext === '.yaml' || ext === '.yml') {
      // Simple YAML-like parser for basic structures (no nested arrays beyond test_cases)
      data = this._parseSimpleYaml(content);
    } else {
      // Try JSON first, then fallback to YAML-like
      try {
        data = JSON.parse(content);
      } catch {
        data = this._parseSimpleYaml(content);
      }
    }

    const benchmark = new BenchmarkDefinition(data);
    this.benchmarks.push(benchmark);
    return benchmark;
  }

  /**
   * Add a benchmark definition programmatically.
   * @param {BenchmarkDefinition|Object} benchmarkDef
   * @returns {BenchmarkDefinition}
   */
  addBenchmark(benchmarkDef) {
    const bm = benchmarkDef instanceof BenchmarkDefinition
      ? benchmarkDef
      : new BenchmarkDefinition(benchmarkDef);
    this.benchmarks.push(bm);
    return bm;
  }

  /**
   * Run all loaded benchmarks with optional custom agent function.
   * @param {Function} agentFn - Async function that takes { prompt, testCase } and returns the output string.
   * @param {Object} options - Run options.
   * @param {string[]} options.benchmarkIds - Specific benchmark IDs to run (runs all if empty).
   * @param {Object} options.scorerOptions - Options passed to scorers.
   * @returns {Promise<{ scores, pass_rate, summary, reports: EvalReport[] }>}
   */
  async run(agentFn, options = {}) {
    const agent = agentFn || this.defaultAgent;
    if (!agent || typeof agent !== 'function') {
      throw new Error('Agent function is required. Pass it to run() or constructor options.agent');
    }

    const { benchmarkIds = [], scorerOptions = {} } = options;
    const benchmarksToRun = benchmarkIds.length > 0
      ? this.benchmarks.filter(b => benchmarkIds.includes(b.id))
      : this.benchmarks;

    if (benchmarksToRun.length === 0) {
      return { scores: {}, pass_rate: 0, summary: 'No benchmarks to run', reports: [] };
    }

    this.reports = [];

    for (const benchmark of benchmarksToRun) {
      const results = [];
      const startTime = new Date().toISOString();

      for (const testCase of benchmark.test_cases) {
        let result;
        try {
          const actual = await agent({ prompt: testCase.prompt, testCase });
          const scorerFn = this.scorers[testCase.evaluator_type];
          if (!scorerFn) {
            throw new Error(`Unknown evaluator_type: ${testCase.evaluator_type}`);
          }

          const evalOpts = Object.assign({},
            scorerOptions,
            { prompt: testCase.prompt, rubric: testCase.rubric }
          );

          const scoreResult = await (typeof scorerFn === 'function' ? scorerFn(actual, testCase.expected, evalOpts) : scorerFn(actual, testCase.expected, evalOpts));

          result = new EvalResult({
            testCase,
            actual,
            passed: scoreResult.passed,
            score: scoreResult.score,
            details: scoreResult.details
          });
        } catch (err) {
          result = new EvalResult({
            testCase,
            actual: '',
            passed: false,
            score: 0,
            error: err.message
          });
        }
        results.push(result);
      }

      const endTime = new Date().toISOString();
      const report = new EvalReport({ benchmark, results, startTime, endTime });
      this.reports.push(report);
    }

    return this._aggregateResults();
  }

  /**
   * Run a single test case against an agent.
   * @param {TestCase} testCase
   * @param {Function} agentFn
   * @param {Object} options
   * @returns {Promise<EvalResult>}
   */
  async runSingle(testCase, agentFn, options = {}) {
    const agent = agentFn || this.defaultAgent;
    if (!agent) throw new Error('Agent function required');

    const { scorerOptions = {} } = options;
    const tc = testCase instanceof TestCase ? testCase : new TestCase(testCase);

    try {
      const actual = await agent({ prompt: tc.prompt, testCase: tc });
      const scorerFn = this.scorers[tc.evaluator_type];
      if (!scorerFn) throw new Error(`Unknown evaluator_type: ${tc.evaluator_type}`);

      const evalOpts = Object.assign({}, scorerOptions, { prompt: tc.prompt, rubric: tc.rubric });
      const scoreResult = await scorerFn(actual, tc.expected, evalOpts);

      return new EvalResult({
        testCase: tc,
        actual,
        passed: scoreResult.passed,
        score: scoreResult.score,
        details: scoreResult.details
      });
    } catch (err) {
      return new EvalResult({
        testCase: tc,
        actual: '',
        passed: false,
        score: 0,
        error: err.message
      });
    }
  }

  /**
   * Add a custom scorer.
   * @param {string} name - Scorer name.
   * @param {Function} fn - Scorer function (actual, expected, options) => { passed, score, details }.
   */
  addScorer(name, fn) {
    this.scorers[name] = fn;
  }

  /**
   * Aggregate all report results.
   */
  _aggregateResults() {
    const allResults = this.reports.flatMap(r => r.results);
    const total = allResults.length;
    const passed = allResults.filter(r => r.passed).length;

    return {
      scores: allResults.reduce((acc, r) => {
        acc[r.testCaseId] = { passed: r.passed, score: r.score, details: r.details, error: r.error };
        return acc;
      }, {}),
      pass_rate: total > 0 ? (passed / total) * 100 : 0,
      summary: this.reports.map(r => r.summary),
      reports: this.reports
    };
  }

  /**
   * Generate JSON report for all runs.
   * @returns {Object}
   */
  generateJSONReport() {
    return {
      generatedAt: new Date().toISOString(),
      reports: this.reports.map(r => r.toJSON())
    };
  }

  /**
   * Generate Markdown report for all runs.
   * @returns {string}
   */
  generateMarkdownReport() {
    return this.reports.map(r => r.toMarkdown()).join('\n\n---\n\n');
  }

  /**
   * Simple YAML-like parser for basic flat structures.
   * Supports top-level keys and a 'test_cases' array of objects.
   */
  _parseSimpleYaml(content) {
    const lines = content.split('\n');
    const result = {};
    const currentSection = { key: null, items: [] };
    let inTestCases = false;
    let currentTestCase = null;

    for (const rawLine of lines) {
      const line = rawLine.replace(/^\s*#.*$/, ''); // strip comments
      if (line.trim() === '' || line.trim().startsWith('#')) continue;

      const indent = line.search(/\S/);
      const trimmed = line.trim();

      // test_cases array start
      if (trimmed === 'test_cases:' || trimmed.startsWith('test_cases:')) {
        inTestCases = true;
        continue;
      }

      if (inTestCases) {
        if (trimmed.startsWith('- ')) {
          // Save previous test case
          if (currentTestCase) {
            currentSection.items.push(currentTestCase);
          }
          currentTestCase = {};
          const val = trimmed.substring(2).trim();
          // Could be inline key: value
          const colonIdx = val.indexOf(':');
          if (colonIdx > 0) {
            const k = val.substring(0, colonIdx).trim();
            const v = val.substring(colonIdx + 1).trim().replace(/^['"](.*)['"]$/, '$1');
            currentTestCase[k] = v;
          }
        } else if (indent >= 4 && currentTestCase) {
          // sub-property of test case
          const colonIdx = trimmed.indexOf(':');
          if (colonIdx > 0) {
            const k = trimmed.substring(0, colonIdx).trim();
            let v = trimmed.substring(colonIdx + 1).trim();
            // Handle multiline with |
            if (v === '|') {
              v = ''; // skip, will be collected but we keep simple
            } else {
              v = v.replace(/^['"](.*)['"]$/, '$1');
            }
            currentTestCase[k] = v;
          }
        }
      } else {
        // Top-level key
        const colonIdx = trimmed.indexOf(':');
        if (colonIdx > 0) {
          const k = trimmed.substring(0, colonIdx).trim();
          let v = trimmed.substring(colonIdx + 1).trim();
          v = v.replace(/^['"](.*)['"]$/, '$1');
          result[k] = v;
        }
      }
    }

    // Save last test case
    if (currentTestCase) {
      currentSection.items.push(currentTestCase);
    }
    if (currentSection.items.length > 0) {
      result.test_cases = currentSection.items;
    }

    return result;
  }
}

module.exports = {
  TestCase,
  BenchmarkDefinition,
  BenchmarkRunner,
  EvalResult,
  EvalReport,
  scorers
};
