/**
 * DFS Analyzer - 可直接 require 的錯誤分析模組
 * 
 * 用法:
 *   const { analyze } = require('./dfs-analyzer');
 *   
 *   try {
 *     await myFunction();
 *   } catch (error) {
 *     const result = analyze(error, { context: 'myModule' });
 *     console.log('建議:', result.fixActions);
 *   }
 */

const CapabilityAnalyzer = require('./capability-analyzer');
const DepthFirstDebugger = require('./depth-first-debugger');

/**
 * 分析錯誤
 * 
 * @param {Error|string} error - 錯誤對象或錯誤信息
 * @param {Object} options - 配置選項
 * @param {string} options.context - 上下文（模組名稱等）
 * @param {string} options.source - 錯誤來源
 * @returns {Object} 分析結果
 */
async function analyze(error, options = {}) {
  const debugger_ = new DepthFirstDebugger({ logger: { info: () => {}, warn: () => {} } });
  
  // 構建錯誤對象
  const errorObj = {
    type: 'integrated',
    text: error instanceof Error ? error.message : String(error),
    source: options.source || guessSource(error instanceof Error ? error.message : String(error)),
    timestamp: Date.now(),
    stack: error instanceof Error ? error.stack : undefined
  };
  
  // 執行分析 (async)
  const result = await debugger_.diagnose(errorObj, { context: options.context });
  
  return {
    rootCause: result.rootCause,
    confidence: result.confidence,
    fixActions: result.fixActions,
    alternatives: result.alternativePaths,
    exploredNodes: result.exploredNodes
  };
}

/**
 * 猜測錯誤來源
 */
function guessSource(text) {
  const lower = text.toLowerCase();
  if (lower.includes('net::') || lower.includes('fetch') || lower.includes('http') || lower.includes('connection') || lower.includes('socket')) {
    return 'NETWORK';
  }
  if (lower.includes('401') || lower.includes('403') || lower.includes('unauthorized') || lower.includes('auth') || lower.includes('token') || lower.includes('jwt')) {
    return 'AUTH';
  }
  if (lower.includes('redux') || lower.includes('state') || lower.includes('store') || lower.includes('vuex') || lower.includes('zustand')) {
    return 'STATE';
  }
  if (lower.includes('dom') || lower.includes('css') || lower.includes('render') || lower.includes('undefined')) {
    return 'RENDER';
  }
  return 'RUNTIME';
}

/**
 * 快速分析並打印結果
 */
function analyzeAndPrint(error, options = {}) {
  const result = analyze(error, options);
  
  console.log('\n🌲 DFS Analysis Result');
  console.log('─'.repeat(50));
  console.log(`Root Cause: ${result.rootCause?.label || 'Unknown'}`);
  console.log(`Confidence: ${Math.round(result.confidence * 100)}%`);
  
  if (result.fixActions && result.fixActions.length > 0) {
    console.log('\n🛠️  Suggested Fixes:');
    result.fixActions.forEach((action, i) => {
      const cmd = typeof action === 'string' ? action : (action.cmd || action.message || JSON.stringify(action));
      console.log(`   ${i + 1}. ${cmd}`);
    });
  }
  
  if (result.alternatives && result.alternatives.length > 0) {
    console.log('\n🔄 Alternative Paths:');
    result.alternatives.slice(0, 3).forEach((alt, i) => {
      console.log(`   ${i + 1}. ${alt.label || alt.dimensionName}`);
    });
  }
  
  console.log('─'.repeat(50));
  
  return result;
}

module.exports = {
  analyze,
  analyzeAndPrint,
  guessSource,
  CapabilityAnalyzer,
  DepthFirstDebugger
};
