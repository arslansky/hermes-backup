'use strict';

const fs = require('fs');
const path = require('path');

/**
 * SessionReplayer - Replays saved Hermes trajectories
 * Loads and plays back session trajectories step by step
 */

class SessionReplayer {
  constructor(options = {}) {
    this.trajectoriesDir = options.trajectoriesDir || 
      path.join(process.env.HOME || '/home/opc', '.hermes', 'trajectories');
    this.session = null;
    this.currentStep = -1;
    this.steps = [];
    this.playbackState = 'stopped'; // 'stopped', 'playing', 'paused'
    this.playInterval = null;
  }

  /**
   * Load a session trajectory by ID
   * @param {string} sessionId - Session identifier or file path
   * @returns {object} - Loaded session info
   */
  load(sessionId) {
    // Check if sessionId is a full path or just an ID
    let filePath = sessionId;
    if (!fs.existsSync(sessionId)) {
      filePath = path.join(this.trajectoriesDir, `${sessionId}.json`);
      if (!fs.existsSync(filePath)) {
        // Try without .json
        filePath = path.join(this.trajectoriesDir, sessionId);
        if (!fs.existsSync(filePath)) {
          throw new Error(`Session "${sessionId}" not found in ${this.trajectoriesDir}`);
        }
      }
    }

    const raw = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(raw);

    this.session = {
      id: data.id || sessionId,
      filePath,
      createdAt: data.createdAt || data.timestamp || Date.now(),
      model: data.model || 'unknown',
      metadata: data.metadata || {}
    };

    // Parse steps from trajectory data
    this.steps = this._parseSteps(data);
    this.currentStep = -1;
    this.playbackState = 'stopped';

    return {
      session: this.session,
      totalSteps: this.steps.length,
      loaded: true
    };
  }

  /**
   * Parse trajectory steps from various data formats
   */
  _parseSteps(data) {
    let steps = [];

    if (Array.isArray(data.steps)) {
      steps = data.steps;
    } else if (Array.isArray(data.messages)) {
      steps = data.messages.map((msg, i) => ({
        step: i + 1,
        type: msg.role || 'unknown',
        content: msg.content || '',
        timestamp: msg.timestamp || data.createdAt,
        metadata: msg.metadata || {}
      }));
    } else if (Array.isArray(data.events)) {
      steps = data.events.map((evt, i) => ({
        step: i + 1,
        type: evt.type || 'event',
        content: typeof evt.data === 'string' ? evt.data : JSON.stringify(evt.data),
        timestamp: evt.timestamp || data.createdAt,
        metadata: evt.metadata || {}
      }));
    } else if (data.content) {
      // Single step session
      steps = [{
        step: 1,
        type: 'content',
        content: typeof data.content === 'string' ? data.content : JSON.stringify(data.content),
        timestamp: data.createdAt,
        metadata: data.metadata || {}
      }];
    }

    // Ensure each step has required fields
    return steps.map((s, i) => ({
      step: s.step || (i + 1),
      type: s.type || 'message',
      role: s.role || s.type || 'assistant',
      content: s.content || '',
      timestamp: s.timestamp || Date.now(),
      metadata: s.metadata || {},
      tokens: s.tokens || s.usage?.total_tokens || 0
    }));
  }

  /**
   * Advance one step forward
   * @returns {object|null} - Current step after advancing, or null if at end
   */
  step() {
    if (!this.session) {
      throw new Error('No session loaded. Call load() first.');
    }

    if (this.currentStep >= this.steps.length - 1) {
      return null;
    }

    this.currentStep++;
    this.playbackState = 'paused';
    
    return this.getCurrentState();
  }

  /**
   * Step backward
   * @returns {object|null} - Previous step, or null if at beginning
   */
  stepBack() {
    if (!this.session) {
      throw new Error('No session loaded. Call load() first.');
    }

    if (this.currentStep <= 0) {
      return null;
    }

    this.currentStep--;
    this.playbackState = 'paused';
    
    return this.getCurrentState();
  }

  /**
   * Play all steps from current position
   * @param {function} onStep - Optional callback for each step
   * @returns {Array} - All remaining steps
   */
  play(onStep = null) {
    if (!this.session) {
      throw new Error('No session loaded. Call load() first.');
    }

    this.playbackState = 'playing';
    const results = [];

    while (this.currentStep < this.steps.length - 1) {
      const step = this.step();
      results.push(step);
      if (onStep) onStep(step);
    }

    this.playbackState = 'stopped';
    return results;
  }

  /**
   * Get the current state (step data + progress info)
   * @returns {object|null}
   */
  getCurrentState() {
    if (!this.session || this.currentStep < 0 || this.currentStep >= this.steps.length) {
      return null;
    }

    const step = this.steps[this.currentStep];
    return {
      step: step,
      progress: {
        current: this.currentStep + 1,
        total: this.steps.length,
        percentage: Math.round(((this.currentStep + 1) / this.steps.length) * 100)
      },
      session: this.session
    };
  }

  /**
   * Get ASCII timeline visualization
   * @param {object} options
   * @param {number} options.width - Timeline width in characters
   * @returns {string}
   */
  getTimeline(options = {}) {
    if (!this.session || this.steps.length === 0) {
      return '[No session loaded]';
    }

    const width = options.width || 60;
    const total = this.steps.length;
    const current = this.currentStep + 1;

    // Build step type legend
    const typeCounts = {};
    for (const step of this.steps) {
      typeCounts[step.type] = (typeCounts[step.type] || 0) + 1;
    }

    const typeColors = {
      'user': 'U',
      'assistant': 'A',
      'system': 'S',
      'tool': 'T',
      'function': 'F',
      'content': 'C',
      'message': 'M',
      'event': 'E',
      'error': 'X'
    };

    let timeline = '';
    timeline += `Session: ${this.session.id}\n`;
    timeline += `Model: ${this.session.model}\n`;
    timeline += `Steps: ${current}/${total} (${this.session.createdAt ? new Date(this.session.createdAt).toLocaleString() : 'N/A'})\n`;
    timeline += '\n';

    // Timeline bar
    const barWidth = Math.min(width, 50);
    const filled = Math.round((current / total) * barWidth);
    const empty = barWidth - filled;
    
    timeline += '[' + '='.repeat(filled) + '>'.repeat(empty > 0 ? 1 : 0) + ' '.repeat(Math.max(0, empty - 1)) + ']\n';
    timeline += ` ${current}/${total} steps (${Math.round((current/total)*100)}%)\n`;
    timeline += '\n';

    // Step markers
    timeline += 'Steps: ';
    const maxMarkers = Math.min(total, width - 8);
    const stepInterval = Math.max(1, Math.floor(total / maxMarkers));
    
    for (let i = 0; i < total; i += stepInterval) {
      const step = this.steps[i];
      const marker = typeColors[step.type] || '?';
      if (i <= this.currentStep) {
        timeline += marker;
      } else {
        timeline += '.';
      }
      if (i + stepInterval < total) {
        const gaps = Math.max(0, Math.min(3, stepInterval - 1));
        timeline += ' '.repeat(gaps);
      }
    }
    timeline += '\n';

    // Legend
    timeline += '\nLegend: ';
    for (const [type, char] of Object.entries(typeColors)) {
      timeline += `${char}=${type} `;
    }
    timeline += '.=pending';

    return timeline;
  }

  /**
   * Jump to a specific step
   * @param {number} stepNumber - 1-indexed step number
   * @returns {object|null}
   */
  goToStep(stepNumber) {
    if (!this.session) {
      throw new Error('No session loaded. Call load() first.');
    }

    if (stepNumber < 1 || stepNumber > this.steps.length) {
      throw new Error(`Step ${stepNumber} out of range (1-${this.steps.length})`);
    }

    this.currentStep = stepNumber - 1;
    this.playbackState = 'paused';
    
    return this.getCurrentState();
  }

  /**
   * Get all step data
   * @returns {Array}
   */
  getAllSteps() {
    return [...this.steps];
  }

  /**
   * Get step count
   * @returns {number}
   */
  getStepCount() {
    return this.steps.length;
  }

  /**
   * Create a sample trajectory file for testing
   * @param {string} sessionId
   * @param {Array} messages - Optional custom messages
   * @returns {string} - Path to created file
   */
  static createSampleTrajectory(sessionId, messages = null) {
    const dir = path.join(process.env.HOME || '/home/opc', '.hermes', 'trajectories');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const sampleMessages = messages || [
      { role: 'user', content: 'Hello, can you help me write a function?' },
      { role: 'assistant', content: 'Sure! What kind of function would you like to write?' },
      { role: 'user', content: 'A Fibonacci function in JavaScript.' },
      { role: 'assistant', content: 'Here is a Fibonacci function in JavaScript:\n\n```javascript\nfunction fibonacci(n) {\n  if (n <= 1) return n;\n  return fibonacci(n - 1) + fibonacci(n - 2);\n}\n```' },
      { role: 'user', content: 'Can you optimize it?' },
      { role: 'assistant', content: 'Here is an optimized version using memoization:\n\n```javascript\nfunction fibonacci(n, memo = {}) {\n  if (n in memo) return memo[n];\n  if (n <= 1) return n;\n  memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo);\n  return memo[n];\n}\n```' }
    ];

    const trajectory = {
      id: sessionId,
      createdAt: Date.now(),
      model: 'hermes-3',
      messages: sampleMessages,
      metadata: {
        source: 'session-replayer-sample',
        tags: ['test', 'sample']
      }
    };

    const filePath = path.join(dir, `${sessionId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(trajectory, null, 2), 'utf-8');
    
    return filePath;
  }
}

module.exports = { SessionReplayer };
