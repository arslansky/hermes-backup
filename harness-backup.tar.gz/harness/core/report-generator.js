/**
 * Report Generator - 生成測試報告
 * 
 * 整合所有數據生成詳細的測試報告
 * 
 * 支持 Depth-First Debugging 風格的樹狀報告：
 * - Error Tree: 根本原因鏈
 * - 修復建議 vs 替代方案
 * - Capability 維度探索路徑
 */

const fs = require('fs').promises;
const path = require('path');

class ReportGenerator {
  constructor({ outputDir, logger, enableTreeReport = true } = {}) {
    this.outputDir = outputDir;
    this.logger = logger;
    this.enableTreeReport = enableTreeReport;
  }
  
  /**
   * 生成完整報告
   */
  async generate(data) {
    const {
      sessionId,
      testName,
      timestamp,
      errors,
      networkCalls,
      state
    } = data;
    
    // Calculate summary statistics
    const errorSummary = this._summarizeErrors(errors);
    const networkSummary = this._summarizeNetwork(networkCalls);
    
    // Build report
    const report = {
      meta: {
        sessionId,
        testName,
        generatedAt: new Date().toISOString(),
        harnessVersion: '2.0.0-dfs',  // DFS 版本標記
        duration: state?.timestamp ? Date.now() - new Date(state.timestamp).getTime() : null,
        analysisMode: this.enableTreeReport ? 'depth-first' : 'breadth-first'
      },
      summary: {
        totalErrors: errorSummary.total,
        blockingErrors: errorSummary.blocking,
        warningErrors: errorSummary.warning,
        totalNetworkCalls: networkSummary.total,
        failedNetworkCalls: networkSummary.failed,
        slowNetworkCalls: networkSummary.slow,
        avgResponseTime: networkSummary.avgDuration
      },
      
      // Depth-First 風格報告核心
      errorTree: this.enableTreeReport ? this._buildErrorTree(errors) : null,
      
      errors: errors || [],
      networkCalls: networkCalls || [],
      stateSnapshots: state?.snapshots || [],
      recommendations: this._generateRecommendations(errorSummary, networkSummary, errors)
    };
    
    // Save JSON report
    const reportPath = path.join(
      this.outputDir,
      `report-${sessionId}-${Date.now()}.json`
    );
    
    await fs.mkdir(this.outputDir, { recursive: true });
    await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
    
    // Generate markdown summary
    const mdPath = reportPath.replace('.json', '.md');
    await fs.writeFile(mdPath, this._generateMarkdown(report));
    
    // Generate HTML report
    const htmlPath = reportPath.replace('.json', '.html');
    await fs.writeFile(htmlPath, this._generateHtml(report));
    
    this.logger.info('Reports generated', { 
      json: reportPath, 
      md: mdPath, 
      html: htmlPath 
    });
    
    return {
      path: reportPath,
      json: reportPath,
      md: mdPath,
      html: htmlPath,
      report
    };
  }
  
  /**
   * 錯誤摘要
   */
  _summarizeErrors(errors) {
    const list = errors || [];
    return {
      total: list.length,
      blocking: list.filter(e => e.severity === '🔴 BLOCKING').length,
      warning: list.filter(e => e.severity === '🟡 WARNING').length,
      info: list.filter(e => e.severity === '⚪ INFO').length,
      bySource: this._groupBy(list, 'source')
    };
  }
  
  /**
   * 網絡請求摘要
   */
  _summarizeNetwork(calls) {
    const list = calls || [];
    const failed = list.filter(c => c.status === 'failed' || (c.status >= 400));
    const slow = list.filter(c => c.duration > 1000);
    const avgDuration = list.length > 0 
      ? Math.round(list.reduce((sum, c) => sum + (c.duration || 0), 0) / list.length)
      : 0;
    
    return {
      total: list.length,
      failed: failed.length,
      slow: slow.length,
      avgDuration,
      byStatus: this._groupBy(list.filter(c => c.status), 'status'),
      byDomain: this._groupBy(list, 'domain')
    };
  }
  
  /**
   * 按字段分組
   */
  _groupBy(list, field) {
    const grouped = {};
    list.forEach(item => {
      let key = item[field];
      if (field === 'domain' && item.url) {
        try {
          key = new URL(item.url).hostname;
        } catch (e) {
          key = 'unknown';
        }
      }
      grouped[key] = (grouped[key] || 0) + 1;
    });
    return grouped;
  }
  
  /**
   * 🌲 構建錯誤樹 (Depth-First 風格)
   * 
   * 將錯誤從淺到深組織成樹狀結構
   * 只顯示根本原因路徑，唔係所有獨立錯誤
   */
  _buildErrorTree(errors) {
    if (!errors || errors.length === 0) {
      return {
        hasErrors: false,
        tree: null,
        rootCauses: []
      };
    }
    
    const rootCauses = [];
    const tree = {
      id: 'error-tree-root',
      label: 'Error Tree (Depth-First)',
      type: 'tree',
      children: []
    };
    
    for (const error of errors) {
      // 如果錯誤有 diagnosis（DFS 分析結果），使用它
      if (error.diagnosis && error.diagnosis.rootCause) {
        const node = this._buildDiagnosisNode(error);
        tree.children.push(node);
        
        rootCauses.push({
          errorId: error.id,
          rootCause: error.diagnosis.rootCause,
          confidence: error.diagnosis.confidence,
          fixActions: error.diagnosis.fixActions
        });
      } else {
        // 沒有 DFS 分析，使用傳統分類
        const node = {
          id: error.id,
          label: `${error.severity} ${error.source}`,
          type: 'error',
          data: {
            message: error.text || error.message,
            type: error.type,
            timestamp: error.timestamp
          },
          children: []
        };
        tree.children.push(node);
        
        rootCauses.push({
          errorId: error.id,
          rootCause: {
            type: 'classified',
            label: `${error.source} ${error.severity}`,
            data: error
          },
          confidence: error.severity === '🔴 BLOCKING' ? 0.8 : 0.5,
          fixActions: []
        });
      }
    }
    
    return {
      hasErrors: true,
      tree,
      rootCauses,
      totalErrors: errors.length,
      analyzedErrors: errors.filter(e => e.diagnosis).length
    };
  }
  
  /**
   * 根據診斷結果構建節點
   */
  _buildDiagnosisNode(error) {
    const diag = error.diagnosis;
    
    // 根節點
    const node = {
      id: error.id,
      label: `${error.severity} ${error.source}: ${error.text || error.message}`,
      type: 'diagnosed-error',
      data: {
        errorType: error.type,
        severity: error.severity,
        source: error.source,
        timestamp: error.timestamp
      },
      children: []
    };
    
    // 添加根本原因節點
    if (diag.rootCause) {
      const rootCauseNode = {
        id: `${error.id}-root-cause`,
        label: `🔍 Root Cause: ${diag.rootCause.label}`,
        type: 'root-cause',
        data: {
          confidence: diag.confidence,
          rootCauseType: diag.rootCause.type
        },
        children: []
      };
      
      // 添加路徑（如果有的話）
      if (diag.rootCause.path && diag.rootCause.path.length > 0) {
        rootCauseNode.children = diag.rootCause.path.map((p, i) => ({
          id: `${error.id}-path-${i}`,
          label: `  └─ ${p.label || p.type}`,
          type: 'path-node',
          data: p,
          children: []
        }));
      }
      
      // 添加修復動作
      if (diag.fixActions && diag.fixActions.length > 0) {
        const fixNode = {
          id: `${error.id}-fix-actions`,
          label: '🛠️ Fix Actions',
          type: 'fix-actions',
          data: {},
          children: diag.fixActions.map((action, i) => ({
            id: `${error.id}-fix-${i}`,
            label: `  ${i + 1}. ${action.cmd || action.message || action}`,
            type: 'fix-action',
            data: action,
            children: []
          }))
        };
        rootCauseNode.children.push(fixNode);
      }
      
      // 添加替代方案
      if (diag.alternativePaths && diag.alternativePaths.length > 0) {
        const altNode = {
          id: `${error.id}-alternatives`,
          label: '🔄 Alternative Paths (if main fix fails)',
          type: 'alternatives',
          data: {},
          children: diag.alternativePaths.slice(0, 3).map((alt, i) => ({
            id: `${error.id}-alt-${i}`,
            label: `  ${i + 1}. ${alt.label || alt.dimensionName}`,
            type: 'alternative',
            data: alt,
            children: []
          }))
        };
        rootCauseNode.children.push(altNode);
      }
      
      node.children.push(rootCauseNode);
    }
    
    return node;
  }
  
  /**
   * 生成建議 (DFS 增強版)
   */
  _generateRecommendations(errorSummary, networkSummary, errors) {
    const recommendations = [];
    
    // 如果有 DFS 分析的錯誤，優先使用 DFS 建議
    const diagnosedErrors = (errors || []).filter(e => e.diagnosis && e.diagnosis.fixActions);
    
    if (diagnosedErrors.length > 0) {
      // 有 DFS 診斷結果，使用根本原因驅動的建議
      recommendations.push({
        priority: 'HIGH',
        category: 'Root Cause Analysis (DFS)',
        message: `Depth-First 分析發現 ${diagnosedErrors.length} 個錯誤的根本原因`,
        action: '優先執行 🛠️ Fix Actions 部分',
        dfsEnhanced: true
      });
      
      // 添加每個根本原因的建議
      for (const error of diagnosedErrors) {
        if (error.diagnosis.fixActions && error.diagnosis.fixActions.length > 0) {
          recommendations.push({
            priority: 'HIGH',
            category: `Fix: ${error.diagnosis.rootCause?.label || 'Unknown'}`,
            message: error.diagnosis.rootCause?.data?.message || error.text,
            action: error.diagnosis.fixActions[0].cmd || error.diagnosis.fixActions[0].message,
            confidence: error.diagnosis.confidence,
            alternativeActions: error.diagnosis.fixActions.slice(1).map(a => a.cmd || a.message)
          });
        }
      }
    } else {
      // 沒有 DFS，使用傳統建議
      if (errorSummary.blocking > 0) {
        recommendations.push({
          priority: 'HIGH',
          category: 'Error',
          message: `發現 ${errorSummary.blocking} 個阻塞性錯誤需要立即修復`,
          action: '檢查 🔴 BLOCKING 錯誤並優先處理'
        });
      }
      
      if (networkSummary.failed > 0) {
        recommendations.push({
          priority: 'HIGH',
          category: 'Network',
          message: `發現 ${networkSummary.failed} 個失敗的網絡請求`,
          action: '檢查 API endpoint 和 CORS 配置'
        });
      }
    }
    
    if (networkSummary.avgDuration > 2000) {
      recommendations.push({
        priority: 'MEDIUM',
        category: 'Performance',
        message: `平均響應時間過長 (${networkSummary.avgDuration}ms)`,
        action: '考慮添加緩存或優化 API'
      });
    }
    
    if (errorSummary.warning > 5) {
      recommendations.push({
        priority: 'LOW',
        category: 'Code Quality',
        message: `發現 ${errorSummary.warning} 個警告`,
        action: '清理代碼中的警告信息'
      });
    }
    
    if (recommendations.length === 0) {
      recommendations.push({
        priority: 'INFO',
        category: 'Status',
        message: '未發現重大問題',
        action: '繼續監控'
      });
    }
    
    return recommendations;
  }
  
  /**
   * 生成 Markdown 報告 (DFS 增強版)
   */
  _generateMarkdown(report) {
    const { meta, summary, errors, networkCalls, recommendations, errorTree } = report;
    
    const hasDFSTree = errorTree && errorTree.hasErrors;
    
    let markdown = `# 🔬 Debug Harness 測試報告 (Depth-First Analysis)

## 📊 摘要

| 指標 | 數值 |
|------|------|
| 測試名稱 | ${meta.testName} |
| Session ID | ${meta.sessionId} |
| 生成時間 | ${meta.generatedAt} |
| 分析模式 | ${meta.analysisMode === 'depth-first' ? '🌲 Depth-First (深度優先)' : '🌐 Breadth-First'} |
| 總錯誤數 | ${summary.totalErrors} |
| 阻塞錯誤 | ${summary.blockingErrors} |
| 警告錯誤 | ${summary.warningErrors} |
| 網絡請求 | ${summary.totalNetworkCalls} |
| 失敗請求 | ${summary.failedNetworkCalls} |
| 平均響應 | ${summary.avgResponseTime}ms |

`;
    
    // 🌲 Depth-First Error Tree Section
    if (hasDFSTree) {
      markdown += `## 🌲 錯誤樹 (Depth-First Root Cause Analysis)

> 🚨 分析了 ${errorTree.analyzedErrors}/${errorTree.totalErrors} 個錯誤

`;
      
      for (const rootCause of errorTree.rootCauses) {
        const error = errors.find(e => e.id === rootCause.errorId);
        if (!error) continue;
        
        markdown += `### ${error.severity} ${error.source}: ${(error.text || error.message).substring(0, 60)}...

**🔍 根本原因 (${Math.round(rootCause.confidence * 100)}% confidence):**
- Type: ${rootCause.rootCause?.type || 'unknown'}
- Label: ${rootCause.rootCause?.label || 'Unknown'}

`;
        
        if (rootCause.fixActions && rootCause.fixActions.length > 0) {
          markdown += `**🛠️ 修復動作:**

`;
          for (const action of rootCause.fixActions) {
            const cmd = action.cmd || action.message || JSON.stringify(action);
            markdown += `1. \`${cmd}\` ${action.type ? `(${action.type})` : ''}\n`;
          }
          markdown += '\n';
        }
        
        if (rootCause.rootCause?.data?.message) {
          markdown += `**📝 詳細信息:** ${rootCause.rootCause.data.message}\n\n`;
        }
      }
    } else {
      // 傳統錯誤列表
      markdown += `## 🚨 錯誤詳情

${errors.length === 0 ? '✅ 沒有錯誤' : errors.map(e => `
### ${e.severity} ${e.source}

- **類型**: ${e.type}
- **訊息**: ${e.text || e.message}
- **時間**: ${new Date(e.timestamp).toISOString()}
${e.stack ? `- **堆疊**: \`\`\`\n${e.stack}\n\`\`\`` : ''}
`).join('\n')}

`;
    }
    
    // 🌐 Network Section
    markdown += `## 🌐 網絡請求

${networkCalls.length === 0 ? '沒有網絡請求記錄' : `
| URL | 方法 | 狀態 | 耗時 |
|-----|------|------|------|
${networkCalls.slice(0, 20).map(c => `| ${c.url.substring(0, 50)}... | ${c.method} | ${c.status} | ${c.duration}ms |`).join('\n')}
`}

`;
    
    // 💡 Recommendations Section
    markdown += `## 💡 建議

${recommendations.map(r => `
### ${r.priority}: ${r.category}

**${r.message}**

${r.action ? `Action: ${r.action}` : ''}
${r.alternativeActions && r.alternativeActions.length > 0 ? `\nAlternatives:\n${r.alternativeActions.map(a => `- ${a}`).join('\n')}` : ''}
`).join('\n')}

`;
    
    markdown += `---
*報告由 Hermes Debug Harness v${meta.harnessVersion} 生成 (${meta.analysisMode} mode)*
`;
    
    return markdown;
  }
  
  /**
   * 生成 HTML 報告
   */
  _generateHtml(report) {
    const { meta, summary, errors, networkCalls, recommendations } = report;
    
    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Debug Harness Report - ${meta.testName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
    .card { background: #f5f5f5; border-radius: 8px; padding: 20px; margin: 10px 0; }
    .metric { display: inline-block; text-align: center; padding: 15px 25px; margin: 5px; background: white; border-radius: 8px; }
    .metric-value { font-size: 2em; font-weight: bold; }
    .error { padding: 10px; margin: 5px 0; border-left: 4px solid #dc3545; background: #fff3f3; }
    .warning { padding: 10px; margin: 5px 0; border-left: 4px solid #ffc107; background: #fffbf0; }
    .success { padding: 10px; margin: 5px 0; border-left: 4px solid #28a745; background: #f0fff4; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
    th { background: #f8f9fa; }
    .blocking { color: #dc3545; font-weight: bold; }
    .recommendation { background: #e7f3ff; border-radius: 8px; padding: 15px; margin: 10px 0; }
  </style>
</head>
<body>
  <h1>🔧 Debug Harness 測試報告</h1>
  <p><strong>測試:</strong> ${meta.testName} | <strong>Session:</strong> ${meta.sessionId} | <strong>時間:</strong> ${meta.generatedAt}</p>
  
  <div class="card">
    <h2>📊 摘要</h2>
    <div class="metric">
      <div class="metric-value">${summary.totalErrors}</div>
      <div>總錯誤</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.blockingErrors}</div>
      <div>阻塞</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.totalNetworkCalls}</div>
      <div>網絡請求</div>
    </div>
    <div class="metric">
      <div class="metric-value">${summary.avgResponseTime}ms</div>
      <div>平均響應</div>
    </div>
  </div>
  
  <div class="card">
    <h2>🚨 錯誤 (${errors.length})</h2>
    ${errors.length === 0 ? '<p class="success">✅ 沒有錯誤</p>' : errors.map(e => `
      <div class="${e.severity === '🔴 BLOCKING' ? 'error' : 'warning'}">
        <strong>${e.severity}</strong> ${e.source} - ${e.type}<br>
        <small>${e.text || e.message}</small>
      </div>
    `).join('')}
  </div>
  
  <div class="card">
    <h2>💡 建議</h2>
    ${recommendations.map(r => `
      <div class="recommendation">
        <strong>[${r.priority}]</strong> ${r.message}<br>
        <em>Action: ${r.action}</em>
      </div>
    `).join('')}
  </div>
  
  <footer style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd;">
    <small>Generated by Hermes Debug Harness v1.0.0</small>
  </footer>
</body>
</html>`;
  }
}

module.exports = ReportGenerator;
