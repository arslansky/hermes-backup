#!/usr/bin/env node
/**
 * Hermes Workflow Engine
 * 
 * A lightweight Graph/Pipeline-based workflow engine inspired by LangGraph.
 * Supports:
 * - Node types: LLM_CALL, TOOL_CALL, CONDITION, PARALLEL, MAP, SUB_WORKFLOW, HUMAN_INPUT
 * - Edges: direct, conditional, retry, fallback
 * - State passing between nodes
 * - Cycle detection
 * - YAML-defined workflows
 */

'use strict';

const fs = require('fs');
const path = require('path');
const util = require('util');

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

class WorkflowState {
  constructor(initial = {}) {
    this._data = { ...initial };
    this._history = [];
    this._errors = [];
    this._currentNode = null;
  }

  get(key) {
    const keys = key.split('.');
    let val = this._data;
    for (const k of keys) {
      if (val === null || val === undefined) return undefined;
      val = val[k];
    }
    return val;
  }

  set(key, value) {
    const keys = key.split('.');
    let cur = this._data;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!(keys[i] in cur) || typeof cur[keys[i]] !== 'object') {
        cur[keys[i]] = {};
      }
      cur = cur[keys[i]];
    }
    cur[keys[keys.length - 1]] = value;
  }

  push(key, value) {
    const arr = this.get(key) || [];
    arr.push(value);
    this.set(key, arr);
  }

  getAll() {
    return { ...this._data };
  }

  addHistory(entry) {
    this._history.push({ ...entry, timestamp: new Date().toISOString() });
  }

  getHistory() {
    return [...this._history];
  }

  addError(error) {
    this._errors.push(error);
  }

  getErrors() {
    return [...this._errors];
  }

  setCurrentNode(nodeId) {
    this._currentNode = nodeId;
  }

  getCurrentNode() {
    return this._currentNode;
  }

  has(key) {
    return this.get(key) !== undefined;
  }

  clone() {
    const s = new WorkflowState(this._data);
    s._history = [...this._history];
    s._errors = [...this._errors];
    s._currentNode = this._currentNode;
    return s;
  }
}

// ---------------------------------------------------------------------------
// Expression evaluator (safe eval for conditions)
// ---------------------------------------------------------------------------

class ExpressionEvaluator {
  static evaluate(expression, state) {
    try {
      // Only allow state.* access, basic operators, comparisons, and boolean logic
      const safeContext = {
        state: state.getAll(),
        len: (x) => (x ? (Array.isArray(x) ? x.length : typeof x === 'object' ? Object.keys(x).length : String(x).length) : 0),
        str: String,
        int: parseInt,
        float: parseFloat,
        bool: Boolean,
        not: (x) => !x,
        and: (a, b) => a && b,
        or: (a, b) => a || b,
      };
      
      const fn = new Function(...Object.keys(safeContext), `"use strict"; return (${expression});`);
      return fn(...Object.values(safeContext));
    } catch (err) {
      throw new Error(`Expression evaluation error: "${expression}" - ${err.message}`);
    }
  }
}

// ---------------------------------------------------------------------------
// Template resolver (fills {placeholders} from state)
// ---------------------------------------------------------------------------

function resolveTemplate(template, state) {
  if (typeof template !== 'string') return template;
  return template.replace(/\{([^}]+)\}/g, (match, key) => {
    const val = state.get(key.trim());
    return val !== undefined ? String(val) : match;
  });
}

// ---------------------------------------------------------------------------
// Node Runner
// ---------------------------------------------------------------------------

class NodeRunner {
  constructor(config = {}) {
    this.config = config;
    this._toolHandlers = {};
    this._llmHandlers = {};
    this._subWorkflows = {};
  }

  registerTool(name, handler) {
    this._toolHandlers[name] = handler;
  }

  registerLLM(name, handler) {
    this._llmHandlers[name] = handler;
  }

  registerSubWorkflow(name, engine) {
    this._subWorkflows[name] = engine;
  }

  async run(nodeDef, state) {
    const type = nodeDef.type;
    const resolvedNodeDef = this._resolveNodeDef(nodeDef, state);

    state.addHistory({ nodeId: nodeDef.id, type, status: 'started' });

    let result;
    switch (type) {
      case 'LLM_CALL':
        result = await this._runLLM(resolvedNodeDef, state);
        break;
      case 'TOOL_CALL':
        result = await this._runTool(resolvedNodeDef, state);
        break;
      case 'CONDITION':
        result = await this._runCondition(resolvedNodeDef, state);
        break;
      case 'PARALLEL':
        result = await this._runParallel(resolvedNodeDef, state);
        break;
      case 'MAP':
        result = await this._runMap(resolvedNodeDef, state);
        break;
      case 'SUB_WORKFLOW':
        result = await this._runSubWorkflow(resolvedNodeDef, state);
        break;
      case 'HUMAN_INPUT':
        result = await this._runHumanInput(resolvedNodeDef, state);
        break;
      case 'CODE':
        result = await this._runCode(resolvedNodeDef, state);
        break;
      case 'PASS':
        result = { status: 'passed' };
        break;
      default:
        throw new Error(`Unknown node type: ${type}`);
    }

    state.addHistory({ nodeId: nodeDef.id, type, status: 'completed', result: result.summary || '' });

    // Store output if output_key is defined
    if (nodeDef.output_key && result.value !== undefined) {
      state.set(nodeDef.output_key, result.value);
    }

    return result;
  }

  _resolveNodeDef(nodeDef, state) {
    // Clone and resolve template strings
    const resolved = JSON.parse(JSON.stringify(nodeDef));
    if (resolved.prompt) resolved.prompt = resolveTemplate(resolved.prompt, state);
    if (resolved.params) {
      for (const [k, v] of Object.entries(resolved.params)) {
        resolved.params[k] = resolveTemplate(v, state);
      }
    }
    if (resolved.condition) resolved.condition = resolveTemplate(resolved.condition, state);
    return resolved;
  }

  async _runLLM(nodeDef, state) {
    const handler = this._llmHandlers[nodeDef.llm || 'default'];
    if (!handler) {
      // Default: just return the prompt as-is (mock mode)
      return { value: `[LLM output for: ${(nodeDef.prompt || '').substring(0, 100)}]`, summary: 'llm_called' };
    }
    return handler(nodeDef, state);
  }

  async _runTool(nodeDef, state) {
    const { tool, params = {} } = nodeDef;
    const handler = this._toolHandlers[tool];
    if (!handler) {
      return { value: `[Tool ${tool} not registered]`, summary: `tool ${tool} not found` };
    }
    return handler(nodeDef, state);
  }

  async _runCondition(nodeDef, state) {
    const { condition } = nodeDef;
    const result = ExpressionEvaluator.evaluate(condition, state);
    return { value: result, summary: `condition: ${result}`, edge: result ? 'if' : 'else' };
  }

  async _runParallel(nodeDef, state) {
    const { for_each, node: childNodeId, max_concurrency = 3 } = nodeDef;
    const items = state.get(for_each);
    if (!items || !Array.isArray(items)) {
      return { value: [], summary: 'parallel: no items' };
    }

    const results = [];
    const chunks = [];
    for (let i = 0; i < items.length; i += max_concurrency) {
      chunks.push(items.slice(i, i + max_concurrency));
    }

    for (const chunk of chunks) {
      const promises = chunk.map(async (item, idx) => {
        const childState = state.clone();
        childState.set('item', item);
        childState.set('index', items.indexOf(item));
        return this._runChildNode(childNodeId, childState);
      });
      const chunkResults = await Promise.all(promises);
      results.push(...chunkResults);
    }

    // Store results array
    if (nodeDef.output_key) {
      state.set(nodeDef.output_key, results.map(r => r.value));
    }

    return { value: results.map(r => r.value), summary: `parallel: ${results.length} items` };
  }

  async _runMap(nodeDef, state) {
    const { for_each, node: childNodeId } = nodeDef;
    const items = state.get(for_each);
    if (!items || !Array.isArray(items)) {
      return { value: [], summary: 'map: no items' };
    }

    const results = [];
    for (const item of items) {
      const childState = state.clone();
      childState.set('item', item);
      childState.set('index', items.indexOf(item));
      const result = await this._runChildNode(childNodeId, childState);
      results.push(result);
    }

    if (nodeDef.output_key) {
      state.set(nodeDef.output_key, results.map(r => r.value));
    }

    return { value: results.map(r => r.value), summary: `map: ${results.length} items` };
  }

  async _runChildNode(nodeId, state) {
    const engine = this._subWorkflows['__self__'];
    if (!engine) return { value: null, summary: 'no engine for child node' };
    const nodeDef = engine.getNodeDef(nodeId);
    if (!nodeDef) return { value: null, summary: `node ${nodeId} not found` };
    return this.run(nodeDef, state);
  }

  async _runSubWorkflow(nodeDef, state) {
    const { workflow_id } = nodeDef;
    const engine = this._subWorkflows[workflow_id];
    if (!engine) return { value: null, summary: `sub-workflow ${workflow_id} not found` };
    const result = await engine.run(state);
    return { value: result, summary: `sub-workflow: ${workflow_id}` };
  }

  async _runHumanInput(nodeDef, state) {
    // In headless mode, return the default value
    const { prompt, default: defaultVal } = nodeDef;
    return { value: defaultVal || `[HUMAN_INPUT needed: ${prompt}]`, summary: `human_input: ${prompt}` };
  }

  async _runCode(nodeDef, state) {
    const { code } = nodeDef;
    try {
      const fn = new Function('state', `"use strict"; ${code}`);
      const result = fn(state);
      return { value: result, summary: 'code executed' };
    } catch (err) {
      throw new Error(`Code execution error: ${err.message}`);
    }
  }
}

// ---------------------------------------------------------------------------
// Workflow Engine
// ---------------------------------------------------------------------------

class WorkflowEngine {
  constructor(config = {}) {
    this._config = config;
    this._nodes = new Map();
    this._edges = [];
    this._metadata = {};
    this._nodeRunner = new NodeRunner(config);
    this._nodeRunner.registerSubWorkflow('__self__', this);
    this._loadToolHandlers();
  }

  _loadToolHandlers() {
    // Register a catch-all tool handler
    this._nodeRunner.registerTool('*', async (nodeDef, state) => {
      return { value: `[Tool ${nodeDef.tool}]`, summary: `tool ${nodeDef.tool}` };
    });
  }

  /**
   * Load a workflow from a YAML file path or parsed object
   */
  async load(source) {
    if (typeof source === 'string') {
      const yamlContent = fs.readFileSync(source, 'utf-8');
      return this._parseYaml(yamlContent);
    }
    return this._fromObject(source);
  }

  async loadYaml(yamlContent) {
    return this._parseYaml(yamlContent);
  }

  _parseYaml(yamlContent) {
    // Simple YAML parser (no external deps) - handles the subset we need
    const parsed = parseSimpleYaml(yamlContent);
    return this._fromObject(parsed);
  }

  _fromObject(obj) {
    const workflow = obj.workflow || obj;
    
    this._metadata = {
      id: workflow.id || 'unnamed',
      version: workflow.version || 1,
      description: workflow.description || '',
      config: workflow.config || {},
    };

    // Load nodes
    this._nodes.clear();
    if (workflow.nodes) {
      for (const [id, def] of Object.entries(workflow.nodes)) {
        this._nodes.set(id, { ...def, id });
      }
    }

    // Load edges
    this._edges = (workflow.edges || []).map(e => ({ ...e }));

    // Validate
    this._validate();

    // Check for cycles
    const cycle = this._detectCycle();
    if (cycle) {
      throw new Error(`Cycle detected in workflow: ${cycle.join(' -> ')}`);
    }

    return this;
  }

  _validate() {
    for (const edge of this._edges) {
      const fromBase = edge.from.split('.')[0];
      if (fromBase !== '__start__' && !this._nodes.has(fromBase)) {
        throw new Error(`Edge references unknown node: "${fromBase}" (from: ${edge.from})`);
      }
      const toBase = edge.to.split('.')[0];
      if (toBase !== '__end__' && !this._nodes.has(toBase)) {
        throw new Error(`Edge references unknown node: "${toBase}" (to: ${edge.to})`);
      }
    }

    // Check start node exists
    const startEdge = this._edges.find(e => e.from === '__start__');
    if (!startEdge) {
      throw new Error('No __start__ edge defined');
    }
  }

  _detectCycle() {
    const visited = new Set();
    const inStack = new Set();
    const parent = {};

    const dfs = (nodeId) => {
      visited.add(nodeId);
      inStack.add(nodeId);

      const nextNodes = this._getNextNodes(nodeId);
      for (const next of nextNodes) {
        if (next === '__end__') continue;
        if (!visited.has(next)) {
          parent[next] = nodeId;
          if (dfs(next)) return true;
        } else if (inStack.has(next)) {
          // Reconstruct cycle
          const cycle = [next, nodeId];
          let cur = nodeId;
          while (cur !== next && parent[cur]) {
            cur = parent[cur];
            cycle.push(cur);
          }
          cycle.reverse();
          return true;
        }
      }

      inStack.delete(nodeId);
      return false;
    };

    const startEdge = this._edges.find(e => e.from === '__start__');
    if (startEdge) {
      if (dfs(startEdge.to)) return true;
    }

    return false;
  }

  _getNextNodes(nodeId) {
    const next = [];
    for (const edge of this._edges) {
      const fromBase = edge.from.split('.')[0];
      if (fromBase === nodeId) {
        next.push(edge.to);
      }
    }
    return next;
  }

  /**
   * Get edges originating from a node, optionally filtered by edge label
   */
  _getEdgesFrom(nodeId, label) {
    return this._edges.filter(e => {
      const base = e.from.split('.')[0];
      if (base !== nodeId) return false;
      if (label && e.from.includes('.')) {
        return e.from.endsWith('.' + label);
      }
      return !e.from.includes('.') || !label;
    });
  }

  /**
   * Resolve which edge to follow based on condition result
   */
  _resolveEdge(nodeId, result) {
    const edges = this._edges.filter(e => {
      const base = e.from.split('.')[0];
      return base === nodeId;
    });

    // If only one edge, follow it
    if (edges.length === 1) return edges[0];

    // If condition result has an edge hint
    if (result && result.edge) {
      const match = edges.find(e => e.from.endsWith('.' + result.edge));
      if (match) return match;
    }

    // If no edge resolved, just take the last one
    return edges[edges.length - 1];
  }

  getNodeDef(nodeId) {
    return this._nodes.get(nodeId) || null;
  }

  getMetadata() {
    return { ...this._metadata };
  }

  getNodeIds() {
    return Array.from(this._nodes.keys());
  }

  getEdges() {
    return [...this._edges];
  }

  registerTool(name, handler) {
    this._nodeRunner.registerTool(name, handler);
  }

  registerLLM(name, handler) {
    this._nodeRunner.registerLLM(name, handler);
  }

  registerSubWorkflow(name, engine) {
    this._nodeRunner.registerSubWorkflow(name, engine);
  }

  /**
   * Main execution entry point
   */
  async run(initialState = {}) {
    const state = initialState instanceof WorkflowState ? initialState : new WorkflowState(initialState);
    const maxIterations = this._metadata.config?.max_iterations || 100;
    const timeout = this._metadata.config?.timeout || 300;
    
    let iterationCount = 0;
    const startTime = Date.now();

    // Find start edge
    const startEdge = this._edges.find(e => e.from === '__start__');
    if (!startEdge) throw new Error('No __start__ edge in workflow');

    let currentNodeId = startEdge.to;
    let lastResult = null;

    while (currentNodeId !== '__end__' && iterationCount < maxIterations) {
      // Check timeout
      if (Date.now() - startTime > timeout * 1000) {
        throw new Error(`Workflow timed out after ${timeout}s`);
      }

      iterationCount++;
      state.setCurrentNode(currentNodeId);

      const nodeDef = this._nodes.get(currentNodeId);
      if (!nodeDef) {
        throw new Error(`Node "${currentNodeId}" not found`);
      }

      try {
        // Check retry config
        const retryConfig = nodeDef.retry;
        let attempts = 1;
        const maxAttempts = retryConfig ? (retryConfig.max_attempts || 1) : 1;

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          try {
            lastResult = await this._nodeRunner.run(nodeDef, state);
            break; // success
          } catch (err) {
            if (attempt < maxAttempts) {
              const delay = retryConfig?.delay || 1;
              const backoff = retryConfig?.backoff || 1;
              const waitMs = delay * Math.pow(backoff, attempt - 1) * 1000;
              state.addHistory({ nodeId: currentNodeId, type: 'RETRY', status: `attempt ${attempt} failed: ${err.message}` });
              await new Promise(r => setTimeout(r, waitMs));
            } else {
              // Check for fallback
              const fallbackEdge = this._edges.find(e => 
                e.from === currentNodeId + '.fallback'
              );
              if (fallbackEdge) {
                state.addHistory({ nodeId: currentNodeId, type: 'FALLBACK', status: `failed after ${attempt} attempts, going to ${fallbackEdge.to}` });
                state.addError({ node: currentNodeId, error: err.message, attempt });
                currentNodeId = fallbackEdge.to;
                lastResult = { value: null, summary: `fallback to ${fallbackEdge.to}` };
                continue; // continue outer while loop
              }
              throw err;
            }
          }
        }

        // Resolve next edge
        const nextEdge = this._resolveEdge(currentNodeId, lastResult);
        currentNodeId = nextEdge.to;

      } catch (err) {
        state.addError({ node: currentNodeId, error: err.message, iteration: iterationCount });
        throw err;
      }
    }

    return {
      status: iterationCount >= maxIterations ? 'max_iterations' : 'completed',
      iterations: iterationCount,
      duration_ms: Date.now() - startTime,
      state: state.getAll(),
      history: state.getHistory(),
      errors: state.getErrors(),
    };
  }

  /**
   * Visualize the workflow as ASCII
   */
  visualize() {
    const lines = [];
    lines.push(`╔══════════════════════════════════════╗`);
    lines.push(`║ Workflow: ${this._metadata.id.padEnd(30)}║`);
    lines.push(`╚══════════════════════════════════════╝`);
    lines.push('');

    // Draw nodes and edges
    for (const edge of this._edges) {
      if (edge.from === '__start__') {
        lines.push(`  [START] ──→ ${edge.to}`);
      } else if (edge.to === '__end__') {
        if (edge.from.includes('.')) {
          const [node, label] = edge.from.split('.');
          lines.push(`  ${this._nodeSymbol(node)} ──(${label})→ [END]`);
        } else {
          lines.push(`  ${this._nodeSymbol(edge.from)} ──→ [END]`);
        }
      } else {
        if (edge.from.includes('.')) {
          const [node, label] = edge.from.split('.');
          lines.push(`  ${this._nodeSymbol(node)} ──(${label})→ ${edge.to}`);
        } else {
          lines.push(`  ${this._nodeSymbol(edge.from)} ──→ ${edge.to}`);
        }
      }
    }

    lines.push('');
    lines.push('Nodes:');
    for (const [id, def] of this._nodes) {
      const typeIcon = {
        'LLM_CALL': '🤖',
        'TOOL_CALL': '🔧',
        'CONDITION': '❓',
        'PARALLEL': '⚡',
        'MAP': '🔄',
        'SUB_WORKFLOW': '📦',
        'HUMAN_INPUT': '👤',
        'CODE': '💻',
        'PASS': '➡️',
      }[def.type] || '⬜';
      lines.push(`  ${typeIcon} ${id.padEnd(25)} ${def.type}`);
    }

    return lines.join('\n');
  }

  _nodeSymbol(nodeId) {
    const def = this._nodes.get(nodeId);
    if (!def) return nodeId;
    const icon = {
      'LLM_CALL': '🤖',
      'TOOL_CALL': '🔧',
      'CONDITION': '❓',
      'PARALLEL': '⚡',
      'MAP': '🔄',
      'SUB_WORKFLOW': '📦',
      'HUMAN_INPUT': '👤',
      'CODE': '💻',
      'PASS': '➡️',
    }[def.type] || '⬜';
    return `${icon} ${nodeId}`;
  }
}

// ---------------------------------------------------------------------------
// Simple YAML Parser (no external dependencies)
// ---------------------------------------------------------------------------

function parseSimpleYaml(content) {
  const lines = content.split('\n');

  // First pass: group lines into a tree structure
  // Each node is { indent, key, value, children: [] }
  function buildTree(lineData, startIdx, parentIndent) {
    const nodes = [];
    let i = startIdx;

    while (i < lineData.length) {
      const { indent, key, value, isArrayMarker } = lineData[i];
      
      // If we've gone back to parent level, stop
      if (indent <= parentIndent) break;

      // If this is an array marker (- key: value), it's an object item
      if (isArrayMarker) {
        const obj = { indent, isArrayItem: true, key, value, children: [] };
        
        // Look ahead - if next line has same indent but is NOT an array marker,
        // and starts where this line's properties would be
        if (i + 1 < lineData.length) {
          const next = lineData[i + 1];
          if (next.indent > indent) {
            obj.children = buildTree(lineData, i + 1, indent);
            // Skip past children
            let j = i + 1;
            while (j < lineData.length && lineData[j].indent > indent) j++;
            i = j;
          } else {
            // Inline value: - value
            obj.inlineValue = value;
            i++;
          }
        } else {
          obj.inlineValue = value;
          i++;
        }
        nodes.push(obj);
      } else {
        // Key-value pair
        const node = { indent, key, value, children: [] };
        if (value === '' || value === undefined) {
          // Has children or is an array
          if (i + 1 < lineData.length && lineData[i + 1].indent > indent) {
            node.children = buildTree(lineData, i + 1, indent);
            let j = i + 1;
            while (j < lineData.length && lineData[j].indent > indent) j++;
            i = j;
          }
        } else {
          i++;
        }
        nodes.push(node);
      }
    }
    
    return nodes;
  }

  // Parse lines into tokens
  const tokens = [];
  for (const rawLine of lines) {
    const trimmed = rawLine.trimEnd();
    if (trimmed.trim() === '' || trimmed.trim().startsWith('#')) continue;

    const indent = trimmed.search(/\S/);
    const line = trimmed.trim();

    if (line.startsWith('- ')) {
      const rest = line.substring(2).trim();
      const colonIdx = rest.indexOf(':');
      if (colonIdx !== -1 && colonIdx > 0) {
        // - key: value
        const key = rest.substring(0, colonIdx).trim();
        const value = rest.substring(colonIdx + 1).trim();
        tokens.push({ indent, key, value: value || '', isArrayMarker: true });
      } else {
        // - value (scalar array item)
        tokens.push({ indent, key: null, value: rest, isArrayMarker: true });
      }
    } else {
      const colonIdx = line.indexOf(':');
      if (colonIdx === -1) continue;
      const key = line.substring(0, colonIdx).trim();
      const value = line.substring(colonIdx + 1).trim();
      tokens.push({ indent, key, value, isArrayMarker: false });
    }
  }

  // Build tree from tokens
  const tree = buildTree(tokens, 0, -1);

  // Convert tree to plain JS object
  function treeToObj(nodes) {
    return _treeToObj(nodes);
  }

  return treeToObj(tree);
}

function _fillObjectFromTree(obj, node) {
  if (node.isArrayItem && node.key) {
    // First, set the node's own key/value
    if (node.value) {
      obj[node.key] = _parseScalar(node.value);
    }
    
    if (node.children.length > 0) {
      for (const child of node.children) {
        if (child.children.length > 0) {
          obj[child.key] = _treeToObj(child.children);
        } else {
          obj[child.key] = _parseScalar(child.value);
        }
      }
    }
  }
}

// Forward declaration for _treeToObj
function _treeToObj(nodes) {
  // Check if all nodes are array items without key (scalar array)
  if (nodes.length > 0 && nodes.every(n => n.isArrayItem && n.key === null)) {
    return nodes.map(n => _parseScalar(n.value));
  }

  const result = {};
  // Process non-array-item keys first
  const nonArrayNodes = nodes.filter(n => !n.isArrayItem);
  for (const node of nonArrayNodes) {
    if (node.children.length > 0) {
      const childResult = _treeToObj(node.children);
      // Check if children are all array items - if so, assign directly
      result[node.key] = childResult;
    } else if (node.value !== '') {
      result[node.key] = _parseScalar(node.value);
    }
  }

  // Process array items
  const arrayNodes = nodes.filter(n => n.isArrayItem);
  if (arrayNodes.length > 0) {
    const groupedItems = [];
    let currentObj = null;

    for (const node of arrayNodes) {
      if (node.children.length > 0) {
        // Complete object with sub-properties
        if (currentObj) { groupedItems.push(currentObj); currentObj = null; }
        const obj = {};
        _fillObjectFromTree(obj, node);
        groupedItems.push(obj);
      } else if (node.key === null) {
        // Scalar item
        if (currentObj) { groupedItems.push(currentObj); currentObj = null; }
        groupedItems.push(_parseScalar(node.value));
      } else {
        // Single key-value in array
        if (!currentObj) {
          currentObj = {};
        }
        currentObj[node.key] = _parseScalar(node.value);
      }
    }
    if (currentObj) {
      groupedItems.push(currentObj);
    }

    return groupedItems;
  }

  return result;
}

function _parseScalar(value) {
  if (value === 'true' || value === 'True') return true;
  if (value === 'false' || value === 'False') return false;
  if (value === 'null' || value === '~') return null;
  
  // Numbers
  const num = Number(value);
  if (!isNaN(num) && value !== '' && value.trim() === value) return num;

  // Quoted strings
  if ((value.startsWith("'") && value.endsWith("'")) ||
      (value.startsWith('"') && value.endsWith('"'))) {
    return value.slice(1, -1);
  }

  return value;
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

module.exports = {
  WorkflowEngine,
  WorkflowState,
  NodeRunner,
  ExpressionEvaluator,
  parseSimpleYaml,
};
