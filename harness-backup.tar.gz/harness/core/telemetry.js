'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * Generates a unique span ID.
 */
function generateId() {
  return crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * TelemetryTracer — a structured tracing system for tracking operations.
 * Supports parent-child span trees, events, metadata, and auto-flush to JSON files.
 */
class TelemetryTracer {
  /**
   * @param {Object} options
   * @param {string} options.serviceName - Name of the service/application.
   * @param {string} options.tracesDir - Directory to write trace log files.
   * @param {boolean} options.autoFlush - Automatically flush spans to disk.
   * @param {number} options.flushIntervalMs - Interval for auto-flush in ms (default: 5000).
   * @param {boolean} options.otelCompatible - Enable OpenTelemetry-compatible output format.
   */
  constructor(options = {}) {
    this.serviceName = options.serviceName || 'hermes-harness';
    this.tracesDir = options.tracesDir || path.join(__dirname, '..', 'traces');
    this.autoFlush = options.autoFlush !== false;
    this.flushIntervalMs = options.flushIntervalMs || 5000;
    this.otelCompatible = !!options.otelCompatible;

    // Span storage
    this._spans = new Map();      // id -> Span
    this._spanTree = new Map();   // id -> children ids
    this._roots = new Set();      // root span ids
    this._traceLog = [];          // ordered log of all spans (for flushing)

    // Trace session tracking
    this._traceId = generateId();
    this._startTime = Date.now();

    // Ensure traces directory exists
    this._ensureDir();

    // Auto-flush interval
    if (this.autoFlush) {
      this._flushTimer = setInterval(() => this.flush(), this.flushIntervalMs);
      // Allow process to exit cleanly even if timer is active
      if (this._flushTimer && this._flushTimer.unref) {
        this._flushTimer.unref();
      }
    }
  }

  /**
   * Ensure the traces directory exists.
   */
  _ensureDir() {
    try {
      if (!fs.existsSync(this.tracesDir)) {
        fs.mkdirSync(this.tracesDir, { recursive: true });
      }
    } catch (err) {
      console.error(`[TelemetryTracer] Failed to create traces directory: ${err.message}`);
    }
  }

  /**
   * Start a new span.
   * @param {string} name - Span name.
   * @param {Object} options
   * @param {string} options.parentId - Parent span ID (for nesting).
   * @param {string} options.type - Span type (e.g., 'llm_call', 'tool_execution', 'agent_step').
   * @param {Object} options.metadata - Arbitrary metadata to attach.
   * @param {string} options.id - Explicit span ID (auto-generated if omitted).
   * @returns {Object} The span object.
   */
  startSpan(name, options = {}) {
    const id = options.id || generateId();
    const parentId = options.parentId || null;
    const type = options.type || 'span';
    const metadata = options.metadata || {};

    const span = {
      id,
      parentId,
      traceId: this._traceId,
      name,
      type,
      startTime: Date.now(),
      endTime: null,
      duration: null,
      events: [],
      metadata: { ...metadata },
      status: 'running',
      serviceName: this.serviceName
    };

    this._spans.set(id, span);
    this._traceLog.push(span);

    // Manage tree structure
    if (parentId) {
      if (!this._spanTree.has(parentId)) {
        this._spanTree.set(parentId, []);
      }
      this._spanTree.get(parentId).push(id);
    } else {
      this._roots.add(id);
    }

    return span;
  }

  /**
   * End a span, setting its endTime, duration, and status.
   * @param {string} spanId - ID of the span to end.
   * @param {Object} options
   * @param {string} options.status - Final status ('ok', 'error', 'cancelled').
   * @param {Object} options.metadata - Additional metadata to merge.
   */
  endSpan(spanId, options = {}) {
    const span = this._spans.get(spanId);
    if (!span) {
      console.warn(`[TelemetryTracer] Attempted to end unknown span: ${spanId}`);
      return;
    }

    span.endTime = Date.now();
    span.duration = span.endTime - span.startTime;
    span.status = options.status || 'ok';

    if (options.metadata) {
      Object.assign(span.metadata, options.metadata);
    }
  }

  /**
   * Add an event to an existing span.
   * @param {string} spanId - ID of the span to add event to.
   * @param {string} name - Event name.
   * @param {Object} attributes - Event attributes/metadata.
   */
  addEvent(spanId, name, attributes = {}) {
    const span = this._spans.get(spanId);
    if (!span) {
      console.warn(`[TelemetryTracer] Attempted to add event to unknown span: ${spanId}`);
      return;
    }

    span.events.push({
      name,
      time: Date.now(),
      attributes: { ...attributes }
    });
  }

  /**
   * Get a span by ID.
   * @param {string} spanId
   * @returns {Object|undefined}
   */
  getSpan(spanId) {
    return this._spans.get(spanId);
  }

  /**
   * Get all active (not ended) spans.
   * @returns {Object[]}
   */
  getActiveSpans() {
    return Array.from(this._spans.values()).filter(s => s.status === 'running');
  }

  /**
   * Retrieve the full trace tree.
   * Returns an array of root spans, each with nested `children` arrays.
   * @returns {Object[]} Trace tree.
   */
  getTrace() {
    const buildTree = (spanId) => {
      const span = this._spans.get(spanId);
      if (!span) return null;

      const childrenIds = this._spanTree.get(spanId) || [];
      const children = childrenIds
        .map(id => buildTree(id))
        .filter(Boolean);

      return {
        ...span,
        children
      };
    };

    return Array.from(this._roots)
      .map(id => buildTree(id))
      .filter(Boolean);
  }

  /**
   * Flush all traces to a JSON log file.
   * Writes to {tracesDir}/trace-{traceId}-{timestamp}.json
   * @returns {string} Path to the written file.
   */
  flush() {
    try {
      this._ensureDir();

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `trace-${this._traceId}-${timestamp}.json`;

      // Build complete span data with tree
      const traceData = {
        traceId: this._traceId,
        serviceName: this.serviceName,
        sessionStartTime: new Date(this._startTime).toISOString(),
        exportTime: new Date().toISOString(),
        spans: this._getAllSpansWithFormat(),
        traceTree: this.getTrace()
      };

      const filePath = path.join(this.tracesDir, filename);
      fs.writeFileSync(filePath, JSON.stringify(traceData, null, 2), 'utf-8');
      return filePath;
    } catch (err) {
      console.error(`[TelemetryTracer] Flush failed: ${err.message}`);
      return null;
    }
  }

  /**
   * Get all spans in a flat array, with OpenTelemetry-compatible format if enabled.
   */
  _getAllSpansWithFormat() {
    if (!this.otelCompatible) {
      return Array.from(this._spans.values()).map(s => this._toPlainSpan(s));
    }

    // OpenTelemetry-compatible output format
    return Array.from(this._spans.values()).map(s => {
      const isEnded = s.status !== 'running';
      return {
        traceId: s.traceId,
        spanId: s.id,
        parentSpanId: s.parentId || undefined,
        name: s.name,
        kind: s.type === 'llm_call' ? 2 : s.type === 'tool_execution' ? 3 : 1, // SPAN_KIND
        startTime: new Date(s.startTime).toISOString(),
        endTime: s.endTime ? new Date(s.endTime).toISOString() : undefined,
        status: isEnded
          ? { code: s.status === 'error' ? 2 : 1, message: s.status }
          : undefined,
        attributes: {
          'service.name': this.serviceName,
          ...s.metadata
        },
        events: s.events.map(e => ({
          name: e.name,
          time: new Date(e.time).toISOString(),
          attributes: e.attributes
        })),
        duration: s.duration
      };
    });
  }

  /**
   * Convert a span to a plain object (removes internal methods, cleans up).
   */
  _toPlainSpan(span) {
    return {
      id: span.id,
      parentId: span.parentId,
      traceId: span.traceId,
      name: span.name,
      type: span.type,
      startTime: new Date(span.startTime).toISOString(),
      endTime: span.endTime ? new Date(span.endTime).toISOString() : null,
      duration: span.duration,
      events: span.events.map(e => ({
        name: e.name,
        time: new Date(e.time).toISOString(),
        attributes: e.attributes
      })),
      metadata: { ...span.metadata },
      status: span.status,
      serviceName: span.serviceName
    };
  }

  /**
   * Reset all tracked spans and start a new trace session.
   */
  reset() {
    // Flush any existing spans first
    if (this.autoFlush && this._spans.size > 0) {
      this.flush();
    }

    this._spans.clear();
    this._spanTree.clear();
    this._roots.clear();
    this._traceLog = [];
    this._traceId = generateId();
    this._startTime = Date.now();
  }

  /**
   * Dispose of the tracer, flushing any remaining data and clearing the timer.
   */
  dispose() {
    if (this._flushTimer) {
      clearInterval(this._flushTimer);
      this._flushTimer = null;
    }
    if (this._spans.size > 0) {
      this.flush();
    }
  }

  /**
   * Get the number of tracked spans.
   * @returns {number}
   */
  get spanCount() {
    return this._spans.size;
  }

  /**
   * Get the current trace ID.
   * @returns {string}
   */
  get currentTraceId() {
    return this._traceId;
  }
}

module.exports = {
  TelemetryTracer,
  generateId
};
