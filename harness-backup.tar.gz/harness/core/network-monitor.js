/**
 * Network Monitor - 監控 API 請求/回應
 * 
 * 追蹤所有網絡請求，記錄響應時間和狀態
 */

const { EventEmitter } = require('events');

class NetworkMonitor extends EventEmitter {
  constructor({ logger }) {
    super();
    this.logger = logger;
    this.page = null;
    this.calls = [];
    this.pending = new Map();
  }
  
  /**
   * 附加到頁面
   */
  attach(page) {
    this.page = page;
    this._setupListeners();
  }
  
  /**
   * 設置監聽器
   */
  _setupListeners() {
    // Request intercepted
    this.page.on('request', (request) => {
      const call = {
        id: `req-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        url: request.url(),
        method: request.method(),
        headers: request.headers(),
        postData: request.postData(),
        timestamp: Date.now(),
        status: 'pending',
        duration: null,
        response: null
      };
      
      this.calls.push(call);
      this.pending.set(request.url(), call);
      this.emit('networkEvent', { type: 'request', call });
    });
    
    // Response received
    this.page.on('response', async (response) => {
      const call = this.pending.get(response.url());
      if (call) {
        call.status = response.status();
        call.responseHeaders = response.headers();
        call.duration = Date.now() - call.timestamp;
        
        // Capture response body for failed requests
        if (response.status() >= 400) {
          try {
            call.responseBody = await response.text();
          } catch (e) {
            call.responseBody = '[Could not capture]';
          }
        }
        
        this.emit('networkEvent', { type: 'response', call });
      }
    });
    
    // Request failed
    this.page.on('requestfailed', (request) => {
      const failure = request.failure();
      const call = this.pending.get(request.url());
      if (call) {
        call.status = 'failed';
        call.error = failure?.errorText;
        call.duration = Date.now() - call.timestamp;
        this.emit('networkEvent', { type: 'requestfailed', call });
      }
    });
    
    // WebSocket events
    this.page.on('websocket', (ws) => {
      this.emit('networkEvent', {
        type: 'websocket',
        url: ws.url(),
        timestamp: Date.now()
      });
    });
    
    this.logger.info('NetworkMonitor listeners attached');
  }
  
  /**
   * 獲取所有網絡請求
   */
  getCalls() {
    return [...this.calls];
  }
  
  /**
   * 獲取失敗的請求
   */
  getFailedCalls() {
    return this.calls.filter(c => 
      c.status === 'failed' || 
      (typeof c.status === 'number' && c.status >= 400)
    );
  }
  
  /**
   * 獲取緩慢的請求 (超過閾值)
   */
  getSlowCalls(threshold = 1000) {
    return this.calls.filter(c => c.duration && c.duration > threshold);
  }
  
  /**
   * 按 URL 模式獲取請求
   */
  getCallsByPattern(pattern) {
    const regex = new RegExp(pattern);
    return this.calls.filter(c => regex.test(c.url));
  }
  
  /**
   * 獲取網絡摘要
   */
  getSummary() {
    const total = this.calls.length;
    const failed = this.getFailedCalls().length;
    const slow = this.getSlowCalls().length;
    const avgDuration = this.calls.reduce((sum, c) => sum + (c.duration || 0), 0) / total;
    
    // Group by domain
    const byDomain = {};
    this.calls.forEach(c => {
      try {
        const domain = new URL(c.url).hostname;
        byDomain[domain] = byDomain[domain] || [];
        byDomain[domain].push(c);
      } catch (e) {
        // ignore
      }
    });
    
    // Status code distribution
    const byStatus = {};
    this.calls.forEach(c => {
      const status = typeof c.status === 'number' ? c.status : c.status;
      byStatus[status] = (byStatus[status] || 0) + 1;
    });
    
    return {
      total,
      failed,
      slow,
      avgDuration: Math.round(avgDuration),
      byDomain,
      byStatus
    };
  }
  
  /**
   * 清除記錄
   */
  clear() {
    this.calls = [];
    this.pending.clear();
  }
}

module.exports = NetworkMonitor;
