'use strict';

const fs = require('fs');
const path = require('path');

/**
 * ToolMarketplace - Registry of installable MCP tools
 * Manages discovery, installation, and removal of tools
 */

const DEFAULT_TOOLS = [
  {
    name: 'web_search',
    description: 'Search the web for information and retrieve results',
    version: '1.0.0',
    author: 'Hermes',
    category: 'data',
    params: [
      { name: 'query', type: 'string', required: true, description: 'Search query' },
      { name: 'max_results', type: 'number', required: false, default: 5, description: 'Max results to return' }
    ],
    install_cmd: 'npm install @hermes/web-search'
  },
  {
    name: 'code_executor',
    description: 'Execute code in sandboxed environments (Python, Node.js, etc.)',
    version: '1.0.0',
    author: 'Hermes',
    category: 'development',
    params: [
      { name: 'code', type: 'string', required: true, description: 'Code to execute' },
      { name: 'language', type: 'string', required: false, default: 'javascript', description: 'Programming language' }
    ],
    install_cmd: 'npm install @hermes/code-executor'
  },
  {
    name: 'file_reader',
    description: 'Read and parse files in various formats',
    version: '1.2.0',
    author: 'Hermes',
    category: 'filesystem',
    params: [
      { name: 'path', type: 'string', required: true, description: 'File path to read' },
      { name: 'encoding', type: 'string', required: false, default: 'utf-8', description: 'File encoding' }
    ],
    install_cmd: 'npm install @hermes/file-reader'
  },
  {
    name: 'browser_automation',
    description: 'Automate browser interactions for web scraping and testing',
    version: '0.9.0',
    author: 'Hermes',
    category: 'automation',
    params: [
      { name: 'url', type: 'string', required: true, description: 'URL to navigate to' },
      { name: 'action', type: 'string', required: false, default: 'screenshot', description: 'Action to perform' }
    ],
    install_cmd: 'npm install @hermes/browser-automation'
  },
  {
    name: 'image_analyzer',
    description: 'Analyze images for objects, text, and patterns',
    version: '1.0.0',
    author: 'Hermes',
    category: 'vision',
    params: [
      { name: 'image_path', type: 'string', required: true, description: 'Path to image file' },
      { name: 'analysis_type', type: 'string', required: false, default: 'general', description: 'Type of analysis' }
    ],
    install_cmd: 'npm install @hermes/image-analyzer'
  },
  {
    name: 'data_visualizer',
    description: 'Create charts, graphs, and visualizations from data',
    version: '1.1.0',
    author: 'Hermes',
    category: 'data',
    params: [
      { name: 'data', type: 'object', required: true, description: 'Data to visualize' },
      { name: 'chart_type', type: 'string', required: false, default: 'bar', description: 'Type of chart' }
    ],
    install_cmd: 'npm install @hermes/data-visualizer'
  },
  {
    name: 'api_client',
    description: 'Make HTTP requests to external APIs',
    version: '2.0.0',
    author: 'Hermes',
    category: 'network',
    params: [
      { name: 'url', type: 'string', required: true, description: 'API endpoint URL' },
      { name: 'method', type: 'string', required: false, default: 'GET', description: 'HTTP method' },
      { name: 'headers', type: 'object', required: false, description: 'Request headers' },
      { name: 'body', type: 'object', required: false, description: 'Request body' }
    ],
    install_cmd: 'npm install @hermes/api-client'
  },
  {
    name: 'database_query',
    description: 'Execute queries against supported databases',
    version: '1.0.0',
    author: 'Hermes',
    category: 'data',
    params: [
      { name: 'connection_string', type: 'string', required: true, description: 'Database connection string' },
      { name: 'query', type: 'string', required: true, description: 'SQL query to execute' }
    ],
    install_cmd: 'npm install @hermes/database-query'
  }
];

class ToolMarketplace {
  constructor(options = {}) {
    this.toolsDir = options.toolsDir || path.join(process.env.HOME || '/home/opc', '.hermes', 'tools');
    this.registry = new Map();
    this.installed = new Set();

    // Register default mock tools
    for (const tool of DEFAULT_TOOLS) {
      this.registry.set(tool.name, { ...tool });
    }

    // Load currently installed tools
    this._loadInstalled();
  }

  /**
   * List all available tools
   * @param {object} options
   * @param {string} options.category - Filter by category
   * @param {boolean} options.installed - Only installed tools
   * @returns {Array}
   */
  list(options = {}) {
    let tools = [];
    
    for (const tool of this.registry.values()) {
      if (options.category && tool.category !== options.category) continue;
      if (options.installed && !this.installed.has(tool.name)) continue;
      
      tools.push({
        ...tool,
        installed: this.installed.has(tool.name)
      });
    }

    return tools;
  }

  /**
   * Search for tools by query string
   * @param {string} query - Search query
   * @returns {Array}
   */
  search(query) {
    if (!query || !query.trim()) return this.list();

    const lower = query.toLowerCase();
    const results = [];

    for (const tool of this.registry.values()) {
      if (
        tool.name.toLowerCase().includes(lower) ||
        tool.description.toLowerCase().includes(lower) ||
        tool.category.toLowerCase().includes(lower) ||
        tool.author.toLowerCase().includes(lower)
      ) {
        results.push({
          ...tool,
          installed: this.installed.has(tool.name)
        });
      }
    }

    return results;
  }

  /**
   * Install a tool
   * @param {string} toolName - Name of the tool to install
   * @returns {object} - Installation result
   */
  install(toolName) {
    const tool = this.registry.get(toolName);
    if (!tool) {
      throw new Error(`Tool "${toolName}" not found in marketplace`);
    }

    if (this.installed.has(toolName)) {
      return {
        success: true,
        message: `Tool "${toolName}" is already installed`,
        tool: { ...tool, installed: true }
      };
    }

    // Create stub file in tools directory
    const stubPath = path.join(this.toolsDir, `${toolName}.js`);
    const stubContent = this._generateStub(tool);

    try {
      if (!fs.existsSync(this.toolsDir)) {
        fs.mkdirSync(this.toolsDir, { recursive: true });
      }

      fs.writeFileSync(stubPath, stubContent, 'utf-8');
      this.installed.add(toolName);

      return {
        success: true,
        message: `Tool "${toolName}" installed successfully`,
        tool: { ...tool, installed: true, stubPath },
        installCommand: tool.install_cmd
      };
    } catch (err) {
      throw new Error(`Failed to install tool "${toolName}": ${err.message}`);
    }
  }

  /**
   * Uninstall a tool
   * @param {string} toolName - Name of the tool to uninstall
   * @returns {object}
   */
  uninstall(toolName) {
    const tool = this.registry.get(toolName);
    if (!tool) {
      throw new Error(`Tool "${toolName}" not found in marketplace`);
    }

    if (!this.installed.has(toolName)) {
      return {
        success: true,
        message: `Tool "${toolName}" is not installed`,
        tool: { ...tool, installed: false }
      };
    }

    const stubPath = path.join(this.toolsDir, `${toolName}.js`);

    try {
      if (fs.existsSync(stubPath)) {
        fs.unlinkSync(stubPath);
      }
      this.installed.delete(toolName);

      return {
        success: true,
        message: `Tool "${toolName}" uninstalled successfully`,
        tool: { ...tool, installed: false }
      };
    } catch (err) {
      throw new Error(`Failed to uninstall tool "${toolName}": ${err.message}`);
    }
  }

  /**
   * Get detailed info about a tool
   * @param {string} toolName
   * @returns {object|null}
   */
  getInfo(toolName) {
    const tool = this.registry.get(toolName);
    if (!tool) return null;

    return {
      ...tool,
      installed: this.installed.has(tool.name)
    };
  }

  /**
   * Check if a tool is installed
   * @param {string} toolName
   * @returns {boolean}
   */
  isInstalled(toolName) {
    return this.installed.has(toolName);
  }

  /**
   * Get all installed tools
   * @returns {Array}
   */
  getInstalled() {
    return this.list({ installed: true });
  }

  /**
   * Generate a stub file content for a tool
   */
  _generateStub(tool) {
    const paramsList = tool.params.map(p => 
      `  ${p.name}: ${p.required ? '(required)' : '(optional)'} - ${p.description}`
    ).join('\n');

    return `/**
 * ${tool.name} v${tool.version}
 * ${tool.description}
 * Author: ${tool.author}
 * Category: ${tool.category}
 * 
 * Parameters:
${paramsList}
 * 
 * This is a placeholder stub. Run '${tool.install_cmd}' for full installation.
 */

module.exports = {
  name: '${tool.name}',
  version: '${tool.version}',
  description: '${tool.description}',
  category: '${tool.category}',
  
  async execute(params = {}) {
    throw new Error('Tool "${tool.name}" stub: full implementation not installed. Run: ${tool.install_cmd}');
  },
  
  getInfo() {
    return {
      name: '${tool.name}',
      version: '${tool.version}',
      description: '${tool.description}',
      category: '${tool.category}',
      params: ${JSON.stringify(tool.params, null, 2)},
      stub: true
    };
  }
};
`;
  }

  /**
   * Load installed tools from filesystem
   */
  _loadInstalled() {
    try {
      if (fs.existsSync(this.toolsDir)) {
        const files = fs.readdirSync(this.toolsDir);
        for (const file of files) {
          if (file.endsWith('.js')) {
            const toolName = path.basename(file, '.js');
            this.installed.add(toolName);
          }
        }
      }
    } catch {
      // Directory doesn't exist yet
    }
  }

  /**
   * Get stats about the marketplace
   */
  getStats() {
    return {
      totalTools: this.registry.size,
      installed: this.installed.size,
      categories: Array.from(new Set(Array.from(this.registry.values()).map(t => t.category))),
      toolsDir: this.toolsDir
    };
  }
}

module.exports = { ToolMarketplace, DEFAULT_TOOLS };
