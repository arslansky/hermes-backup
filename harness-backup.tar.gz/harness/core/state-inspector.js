/**
 * State Inspector - 檢查前端狀態
 * 
 * 支援 Redux, Vuex, Zustand, React hooks 狀態追蹤
 */

const { EventEmitter } = require('events');

class StateInspector extends EventEmitter {
  constructor({ logger }) {
    super();
    this.logger = logger;
    this.page = null;
    this.snapshots = [];
    this.previousState = null;
  }
  
  /**
   * 附加到頁面
   */
  attach(page) {
    this.page = page;
    this._setupListeners();
  }
  
  /**
   * 設置監聽器
   */
  _setupListeners() {
    // Inject state tracking script
    this.page.evaluate(() => {
      // Initialize harness registry if not exists
      window.__hermes_harness__ = window.__hermes_harness__ || {};
      
      // Track Redux store if present
      if (window.__REDUX_DEVTOOLS_EXTENSION__) {
        window.__hermes_harness__.reduxStore = true;
      }
      
      // Track Vue devtools if present
      if (window.__VUE_DEVTOOLS_GLOBAL_HOOK__) {
        window.__hermes_harness__.vueStore = true;
      }
      
      // Initialize state registry
      window.__hermes_harness__.stateRegistry = {};
    });
    
    this.logger.info('StateInspector listeners attached');
  }
  
  /**
   * 獲取 Redux 狀態 (如果存在)
   */
  async getReduxState() {
    try {
      const state = await this.page.evaluate(() => {
        // Try common Redux patterns
        if (window.__REDUX_STORE__) {
          return window.__REDUX_STORE__.getState();
        }
        if (window.store?.getState) {
          return window.store.getState();
        }
        return null;
      });
      return state;
    } catch (e) {
      this.logger.warn('Could not get Redux state', { error: e.message });
      return null;
    }
  }
  
  /**
   * 獲取 Vuex 狀態 (如果存在)
   */
  async getVuexState() {
    try {
      const state = await this.page.evaluate(() => {
        if (window.__VUE_APP__) {
          return window.__VUE_APP__?.$store?.state;
        }
        return null;
      });
      return state;
    } catch (e) {
      this.logger.warn('Could not get Vuex state', { error: e.message });
      return null;
    }
  }
  
  /**
   * 獲取 Zustand 狀態 (如果存在)
   */
  async getZustandState() {
    try {
      const state = await this.page.evaluate(() => {
        // Zustand stores are typically attached to window
        const stores = Object.keys(window).filter(k => 
          k.includes('Store') || k.includes('store')
        );
        return stores.length > 0 ? stores : null;
      });
      return state;
    } catch (e) {
      return null;
    }
  }
  
  /**
   * 獲取 React Component Tree (if React DevTools available)
   */
  async getReactTree() {
    try {
      const tree = await this.page.evaluate(() => {
        if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
          return {
            hasReact: true,
            fibers: Object.keys(window.__REACT_DEVTOOLS_GLOBAL_HOOK__._renderers).length
          };
        }
        return { hasReact: false };
      });
      return tree;
    } catch (e) {
      return { hasReact: false, error: e.message };
    }
  }
  
  /**
   * 拍攝狀態快照
   */
  async takeSnapshot(label = 'manual') {
    const snapshot = {
      id: `snap-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      label,
      timestamp: new Date().toISOString(),
      redux: await this.getReduxState(),
      vuex: await this.getVuexState(),
      zustand: await this.getZustandState(),
      react: await this.getReactTree(),
      previousState: this.previousState
    };
    
    this.snapshots.push(snapshot);
    this.previousState = snapshot;
    this.emit('stateChange', snapshot);
    
    this.logger.info('State snapshot taken', { id: snapshot.id, label });
    return snapshot;
  }
  
  /**
   * 比較兩個快照
   */
  compareSnapshots(snap1Id, snap2Id) {
    const snap1 = this.snapshots.find(s => s.id === snap1Id);
    const snap2 = this.snapshots.find(s => s.id === snap2Id);
    
    if (!snap1 || !snap2) {
      return { error: 'Snapshot not found' };
    }
    
    return {
      snap1: snap1.timestamp,
      snap2: snap2.timestamp,
      diff: {
        redux: snap1.redux !== snap2.redux,
        vuex: snap1.vuex !== snap2.vuex
      }
    };
  }
  
  /**
   * 獲取所有快照
   */
  getSnapshots() {
    return [...this.snapshots];
  }
  
  /**
   * 獲取當前狀態
   */
  async getSnapshot() {
    return await this.takeSnapshot('current');
  }
  
  /**
   * 清除快照
   */
  clear() {
    this.snapshots = [];
    this.previousState = null;
  }
}

module.exports = StateInspector;
