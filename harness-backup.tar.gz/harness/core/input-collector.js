/**
 * Input Collector - 收集用戶操作序列
 * 
 * 捕獲點擊、鍵盤輸入、滾動等用戶操作
 */

class InputCollector {
  constructor({ page, logger }) {
    this.page = page;
    this.logger = logger;
    this.operations = [];
    this.startTime = null;
  }
  
  async setup() {
    this.startTime = Date.now();
    this.operations = [];
    
    // Initialize harness registry
    await this.page.evaluate(() => {
      window.__hermes_harness__ = window.__hermes_harness__ || {};
    });
    
    // 捕獲點擊事件
    await this.page.evaluate(() => {
      document.addEventListener('click', (e) => {
        window.__hermes_harness__ = window.__hermes_harness__ || {};
        window.__hermes_harness__.lastClick = {
          tagName: e.target.tagName,
          id: e.target.id,
          className: e.target.className,
          text: e.target.innerText?.substring(0, 50),
          x: e.clientX,
          y: e.clientY,
          timestamp: Date.now()
        };
      }, true);
    });
    
    // 捕獲鍵盤事件
    await this.page.evaluate(() => {
      document.addEventListener('keydown', (e) => {
        window.__hermes_harness__.lastKey = {
          key: e.key,
          code: e.code,
          ctrlKey: e.ctrlKey,
          shiftKey: e.shiftKey,
          timestamp: Date.now()
        };
      }, true);
    });
    
    // 捕獲滾動事件
    await this.page.evaluate(() => {
      window.__hermes_harness__.scrollEvents = [];
      window.addEventListener('scroll', (e) => {
        window.__hermes_harness__.scrollEvents.push({
          scrollX: window.scrollX,
          scrollY: window.scrollY,
          timestamp: Date.now()
        });
      }, { passive: true });
    });
    
    this.logger.info('InputCollector setup complete');
  }
  
  /**
   * 記錄操作
   */
  record(operation) {
    this.operations.push({
      ...operation,
      timestamp: Date.now(),
      elapsed: Date.now() - this.startTime
    });
  }
  
  /**
   * 獲取所有操作序列
   */
  getOperations() {
    return this.operations;
  }
  
  /**
   * 獲取最後一次點擊
   */
  getLastClick() {
    return this.page.evaluate(() => window.__hermes_harness__?.lastClick);
  }
  
  /**
   * 獲取最後一次鍵盤輸入
   */
  getLastKey() {
    return this.page.evaluate(() => window.__hermes_harness__?.lastKey);
  }
  
  /**
   * 獲取滾動事件序列
   */
  getScrollEvents() {
    return this.page.evaluate(() => window.__hermes_harness__?.scrollEvents || []);
  }
  
  /**
   * 清除記錄
   */
  clear() {
    this.operations = [];
  }
}

module.exports = InputCollector;
