'use strict';

/**
 * ModelRouter - Multi-Provider Fallback / Model Routing
 * Routes requests to best available provider/model with cost-aware selection
 */

class ModelRouter {
  /**
   * @param {object} options
   * @param {Array} options.providers - List of provider configs
   * @param {object} options.defaults - Default routing settings
   */
  constructor(options = {}) {
    this.providers = options.providers || [];
    this.defaults = {
      fallbackOrder: options.defaults?.fallbackOrder || ['cost', 'capability', 'weight'],
      maxRetries: options.defaults?.maxRetries || 3,
      ...options.defaults
    };
    this._validateProviders();
  }

  /**
   * Validate provider configurations
   */
  _validateProviders() {
    for (const p of this.providers) {
      if (!p.provider) throw new Error('Provider must have a name');
      if (!p.model) throw new Error(`Provider ${p.provider} must specify a model`);
      if (typeof p.cost_per_token !== 'number') {
        p.cost_per_token = p.cost_per_token || 0.001;
      }
      if (!p.capabilities) p.capabilities = [];
      if (typeof p.weights !== 'number') p.weights = 1.0;
    }
  }

  /**
   * Select the best model for a given query type and fallback order
   * @param {string} query_type - Type of query: 'coding', 'vision', 'reasoning', 'general'
   * @param {Array} fallback_order - Order of selection criteria
   * @returns {object} { provider, model, cost_per_token, capabilities }
   */
  select(query_type = 'general', fallback_order = null) {
    const order = fallback_order || this.defaults.fallbackOrder;
    
    // Filter providers that can handle this query type
    let candidates = this.providers.filter(p => {
      if (query_type === 'general') return true;
      return p.capabilities && p.capabilities.includes(query_type);
    });

    if (candidates.length === 0) {
      // Fallback to any provider if none match
      candidates = [...this.providers];
    }

    if (candidates.length === 0) {
      return null;
    }

    // Sort based on criteria
    const sorted = [...candidates].sort((a, b) => {
      for (const criterion of order) {
        let cmp = 0;
        switch (criterion) {
          case 'cost':
            cmp = (a.cost_per_token || 0) - (b.cost_per_token || 0);
            break;
          case 'weight':
            cmp = (b.weights || 0) - (a.weights || 0);
            break;
          case 'capability':
            const aCaps = (a.capabilities || []).length;
            const bCaps = (b.capabilities || []).length;
            cmp = bCaps - aCaps;
            break;
          default:
            cmp = 0;
        }
        if (cmp !== 0) return cmp;
      }
      return 0;
    });

    return {
      provider: sorted[0].provider,
      model: sorted[0].model,
      cost_per_token: sorted[0].cost_per_token,
      capabilities: sorted[0].capabilities || [],
      candidates: sorted.slice(0, 3) // Top 3 candidates
    };
  }

  /**
   * Execute with automatic fallback on error
   * @param {string} provider - Primary provider name
   * @param {string} model - Primary model name
   * @param {Function} fn - Function to execute, receives { provider, model }
   * @returns {Promise<any>}
   */
  async withFallback(provider, model, fn) {
    const primaryIndex = this.providers.findIndex(
      p => p.provider === provider && p.model === model
    );

    if (primaryIndex === -1) {
      throw new Error(`Provider ${provider}/${model} not found in router config`);
    }

    // Build fallback chain
    const fallbackChain = this._buildFallbackChain(primaryIndex);
    
    let lastError = null;
    
    for (let i = 0; i < fallbackChain.length; i++) {
      const entry = fallbackChain[i];
      try {
        const result = await fn({
          provider: entry.provider,
          model: entry.model,
          attempt: i + 1,
          isFallback: i > 0
        });
        return result;
      } catch (err) {
        lastError = err;
        
        // Check if error is retryable
        if (!this._isRetryableError(err)) {
          throw err;
        }

        // If it's the last entry, rethrow
        if (i === fallbackChain.length - 1) {
          throw new Error(
            `All providers exhausted. Last error: ${err.message}`
          );
        }
      }
    }

    throw lastError || new Error('Fallback chain exhausted');
  }

  /**
   * Build fallback chain starting from a provider index
   */
  _buildFallbackChain(startIndex) {
    const chain = [];
    const seen = new Set();

    // Add primary
    const primary = this.providers[startIndex];
    chain.push(primary);
    seen.add(`${primary.provider}:${primary.model}`);

    // Add remaining providers sorted by cost
    const remaining = this.providers
      .filter((p, i) => i !== startIndex)
      .sort((a, b) => (a.cost_per_token || 0) - (b.cost_per_token || 0));

    for (const p of remaining) {
      const key = `${p.provider}:${p.model}`;
      if (!seen.has(key)) {
        chain.push(p);
        seen.add(key);
      }
    }

    return chain;
  }

  /**
   * Check if an error is retryable (rate limit, timeout, etc.)
   */
  _isRetryableError(err) {
    const retryableMessages = [
      'rate limit',
      'too many requests',
      'timeout',
      'service unavailable',
      'internal server error',
      '429',
      '500',
      '502',
      '503',
      '504',
      'quota exceeded',
      'resource exhausted'
    ];

    const msg = (err.message || '').toLowerCase();
    const code = (err.code || '').toString();

    return retryableMessages.some(
      m => msg.includes(m) || code.includes(m)
    );
  }

  /**
   * Get the cheapest model that meets capability requirements
   * @param {Array} requiredCapabilities - ['coding', 'vision', 'reasoning']
   * @returns {object|null}
   */
  getCheapestWithCapabilities(requiredCapabilities = []) {
    const candidates = this.providers.filter(p => {
      const caps = p.capabilities || [];
      return requiredCapabilities.every(c => caps.includes(c));
    });

    if (candidates.length === 0) return null;

    candidates.sort((a, b) => (a.cost_per_token || 0) - (b.cost_per_token || 0));
    
    return {
      provider: candidates[0].provider,
      model: candidates[0].model,
      cost_per_token: candidates[0].cost_per_token,
      capabilities: candidates[0].capabilities || []
    };
  }

  /**
   * Add a provider to the router
   */
  addProvider(config) {
    this.providers.push(config);
    this._validateProviders();
  }

  /**
   * Remove a provider by name
   */
  removeProvider(providerName) {
    this.providers = this.providers.filter(p => p.provider !== providerName);
  }

  /**
   * Get router configuration
   */
  getConfig() {
    return {
      providers: [...this.providers],
      defaults: { ...this.defaults }
    };
  }
}

module.exports = { ModelRouter };
