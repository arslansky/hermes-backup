#!/usr/bin/env node
/**
 * Hermes MessageBus
 * 
 * Agent-to-Agent Communication Protocol enabling:
 * - publish/subscribe messaging between agents
 * - streaming conversations
 * - shared context across agents
 * - broadcast / direct messages
 * - message queuing with backpressure
 * - typed channels (chat, data, control)
 */

'use strict';

const { EventEmitter } = require('events');

// ---------------------------------------------------------------------------
// Message Types
// ---------------------------------------------------------------------------

const MessageType = Object.freeze({
  CHAT: 'chat',           // Conversational messages
  DATA: 'data',           // Data transfer (results, state)
  CONTROL: 'control',     // Control signals (pause, resume, cancel)
  ERROR: 'error',         // Error messages
  BROADCAST: 'broadcast', // Broadcast to all subscribers
  REQUEST: 'request',     // Request-response pattern
  RESPONSE: 'response',   // Response to a request
  HEARTBEAT: 'heartbeat', // Keep-alive
  LOG: 'log',             // Logging messages
});

const MessagePriority = Object.freeze({
  LOW: 0,
  NORMAL: 1,
  HIGH: 2,
  CRITICAL: 3,
});

// ---------------------------------------------------------------------------
// Message
// ---------------------------------------------------------------------------

let _messageCounter = 0;

class Message {
  constructor(type, payload, options = {}) {
    this.id = `msg_${Date.now()}_${++_messageCounter}`;
    this.type = type;
    this.payload = payload;
    this.sender = options.sender || 'unknown';
    this.recipient = options.recipient || null;     // null = broadcast
    this.correlationId = options.correlationId || null;  // For request/response
    this.replyTo = options.replyTo || null;          // For response routing
    this.priority = options.priority || MessagePriority.NORMAL;
    this.timestamp = Date.now();
    this.ttl = options.ttl || 30000;                 // 30s default TTL
    this.metadata = options.metadata || {};
    this._expired = false;
  }

  isExpired() {
    if (this._expired) return true;
    if (Date.now() - this.timestamp > this.ttl) {
      this._expired = true;
      return true;
    }
    return false;
  }

  static chat(text, options = {}) {
    return new Message(MessageType.CHAT, { text }, options);
  }

  static data(key, value, options = {}) {
    return new Message(MessageType.DATA, { key, value }, options);
  }

  static control(command, options = {}) {
    return new Message(MessageType.CONTROL, { command }, options);
  }

  static error(error, options = {}) {
    return new Message(MessageType.ERROR, { 
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
    }, { ...options, priority: MessagePriority.HIGH });
  }
}

// ---------------------------------------------------------------------------
// Subscription
// ---------------------------------------------------------------------------

class Subscription {
  constructor(channel, handler, options = {}) {
    this.id = `sub_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    this.channel = channel;
    this.handler = handler;
    this.filter = options.filter || null;           // (msg) => boolean
    this.oneShot = options.oneShot || false;
    this.priority = options.priority || MessagePriority.NORMAL;
    this.name = options.name || '';
    this.created = Date.now();
    this._active = true;
  }

  deactivate() {
    this._active = false;
  }

  isActive() {
    return this._active;
  }

  matches(message) {
    if (!this._active) return false;
    
    // Channel matching (support wildcards)
    if (this.channel === '*') return true;
    if (this.channel === message.channel) return true;
    
    // Wildcard: channel ending with *
    if (this.channel.endsWith('.*')) {
      const prefix = this.channel.slice(0, -2);
      return message.channel === prefix || message.channel.startsWith(prefix + '.');
    }
    
    return false;
  }
}

// ---------------------------------------------------------------------------
// Channel
// ---------------------------------------------------------------------------

class Channel {
  constructor(name, options = {}) {
    this.name = name;
    this.options = options;
    this._history = [];
    this._maxHistory = options.maxHistory || 100;
    this._subscribers = new Map();
  }

  addMessage(msg) {
    this._history.push(msg);
    if (this._history.length > this._maxHistory) {
      this._history.shift();
    }
  }

  getHistory(count = 10) {
    return this._history.slice(-count);
  }

  addSubscription(sub) {
    this._subscribers.set(sub.id, sub);
  }

  removeSubscription(subId) {
    this._subscribers.delete(subId);
  }

  getSubscribers() {
    return Array.from(this._subscribers.values());
  }
}

// ---------------------------------------------------------------------------
// MessageBus (main class)
// ---------------------------------------------------------------------------

class MessageBus extends EventEmitter {
  constructor(options = {}) {
    super();
    this._channels = new Map();
    this._agents = new Map();                 // agentId -> { name, capabilities, subscriptions }
    this._pendingMessages = [];               // Queue for backpressure
    this._processing = false;
    this._maxQueueSize = options.maxQueueSize || 1000;
    this._defaultChannelOptions = options.defaultChannelOptions || {};
    this._stats = {
      messagesSent: 0,
      messagesDelivered: 0,
      messagesExpired: 0,
      messagesQueued: 0,
    };
  }

  // -- Channel Management ---------------------------------------------------

  createChannel(name, options = {}) {
    if (this._channels.has(name)) {
      return this._channels.get(name);
    }
    const channel = new Channel(name, { ...this._defaultChannelOptions, ...options });
    this._channels.set(name, channel);
    this.emit('channel:created', { channel: name });
    return channel;
  }

  getChannel(name) {
    return this._channels.get(name) || null;
  }

  listChannels() {
    return Array.from(this._channels.keys());
  }

  deleteChannel(name) {
    const channel = this._channels.get(name);
    if (!channel) return false;
    this._channels.delete(name);
    this.emit('channel:deleted', { channel: name });
    return true;
  }

  // -- Agent Registration ---------------------------------------------------

  registerAgent(agentId, info = {}) {
    if (this._agents.has(agentId)) {
      this._agents.set(agentId, { ...this._agents.get(agentId), ...info });
      return;
    }
    this._agents.set(agentId, {
      id: agentId,
      name: info.name || agentId,
      capabilities: info.capabilities || [],
      subscriptions: [],
      metadata: info.metadata || {},
      registered: Date.now(),
      lastSeen: Date.now(),
    });
    this.emit('agent:registered', { agentId, info });
  }

  unregisterAgent(agentId) {
    const agent = this._agents.get(agentId);
    if (!agent) return false;
    
    // Remove all subscriptions for this agent
    for (const subId of agent.subscriptions) {
      for (const channel of this._channels.values()) {
        channel.removeSubscription(subId);
      }
    }
    
    this._agents.delete(agentId);
    this.emit('agent:unregistered', { agentId });
    return true;
  }

  getAgent(agentId) {
    return this._agents.get(agentId) || null;
  }

  listAgents() {
    return Array.from(this._agents.values());
  }

  updateAgentHeartbeat(agentId) {
    const agent = this._agents.get(agentId);
    if (agent) {
      agent.lastSeen = Date.now();
    }
  }

  // -- Subscription Management ----------------------------------------------

  subscribe(agentId, channelName, handler, options = {}) {
    const channel = this.createChannel(channelName);
    const sub = new Subscription(channelName, handler, options);
    
    channel.addSubscription(sub);
    
    // Auto-register agent if not exists
    if (!this._agents.has(agentId)) {
      this.registerAgent(agentId);
    }
    const agent = this._agents.get(agentId);
    if (agent) {
      agent.subscriptions.push(sub.id);
    }

    this.emit('subscription:created', { agentId, channel: channelName, subId: sub.id });
    return sub;
  }

  subscribeToChannel(agentId, channelName, handler, options = {}) {
    return this.subscribe(agentId, channelName, handler, options);
  }

  unsubscribe(subId) {
    for (const channel of this._channels.values()) {
      channel.removeSubscription(subId);
    }
    this.emit('subscription:removed', { subId });
  }

  unsubscribeAgent(agentId, channelName) {
    const agent = this._agents.get(agentId);
    if (!agent) return;

    const channel = this._channels.get(channelName);
    if (!channel) return;

    const remainingSubs = [];
    for (const subId of agent.subscriptions) {
      const sub = channel.getSubscribers().find(s => s.id === subId);
      if (sub && sub.channel === channelName) {
        channel.removeSubscription(subId);
      } else {
        remainingSubs.push(subId);
      }
    }
    agent.subscriptions = remainingSubs;
  }

  // -- Publishing -----------------------------------------------------------

  async publish(channelName, message) {
    const channel = this._channels.get(channelName);
    if (!channel) {
      // Auto-create channel if it doesn't exist
      return this.publishToChannel(channelName, message);
    }

    return this._deliver(channelName, message);
  }

  async publishToChannel(channelName, message) {
    if (!message) throw new Error('Message is required');
    if (typeof message === 'string') {
      message = Message.chat(message);
    }

    message.channel = channelName;
    this._stats.messagesSent++;

    // Check queue backpressure
    if (this._pendingMessages.length >= this._maxQueueSize) {
      this.emit('bus:backpressure', { channel: channelName, queueSize: this._pendingMessages.length });
      throw new Error(`MessageBus queue full (${this._maxQueueSize} messages)`);
    }

    return this._deliver(channelName, message);
  }

  async _deliver(channelName, message) {
    const channel = this._channels.get(channelName);
    if (!channel) {
      this._stats.messagesExpired++;
      return { delivered: 0, expired: true, reason: 'channel_not_found' };
    }

    // Check TTL
    if (message.isExpired()) {
      this._stats.messagesExpired++;
      return { delivered: 0, expired: true };
    }

    // Store in channel history
    channel.addMessage(message);
    this.emit('message', { channel: channelName, message });

    // Find matching subscribers
    const subscribers = channel.getSubscribers();
    let delivered = 0;
    const deliveryPromises = [];

    for (const sub of subscribers) {
      if (!sub.isActive()) continue;
      if (!sub.matches(message)) continue;
      if (sub.filter && !sub.filter(message)) continue;

      // Check recipient matching
      if (message.recipient) {
        // If message has specific recipient, only deliver to that agent
        const agent = this._agents.get(message.recipient);
        if (agent && !agent.subscriptions.includes(sub.id)) continue;
      }

      deliveryPromises.push(
        this._safeDeliver(sub, message).then(() => {
          delivered++;
          if (sub.oneShot) {
            sub.deactivate();
          }
        })
      );
    }

    await Promise.allSettled(deliveryPromises);
    this._stats.messagesDelivered += delivered;

    return { delivered, total: subscribers.length };
  }

  async _safeDeliver(sub, message) {
    try {
      await sub.handler(message);
    } catch (err) {
      this.emit('delivery:error', {
        subId: sub.id,
        channel: sub.channel,
        error: err.message,
        messageId: message.id,
      });
    }
  }

  // -- Request/Response ----------------------------------------------------

  async request(channelName, message, timeoutMs = 10000) {
    return new Promise((resolve, reject) => {
      const correlationId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
      const requestMsg = new Message(MessageType.REQUEST, message.payload || message, {
        ...message,
        correlationId,
        sender: message.sender || 'requestor',
      });
      requestMsg.channel = channelName;

      const timeout = setTimeout(() => {
        this.removeListener('message', responseHandler);
        reject(new Error(`Request timed out after ${timeoutMs}ms`));
      }, timeoutMs);

      const responseHandler = (event) => {
        const { message: responseMsg } = event;
        if (responseMsg.correlationId === correlationId && responseMsg.type === MessageType.RESPONSE) {
          clearTimeout(timeout);
          this.removeListener('message', responseHandler);
          resolve(responseMsg);
        }
      };

      this.on('message', responseHandler);
      this._deliver(channelName, requestMsg);
    });
  }

  async respond(correlationId, responsePayload) {
    const responseMsg = new Message(MessageType.RESPONSE, responsePayload, {
      correlationId,
    });
    this.emit('message', { channel: '__response__', message: responseMsg });
    return responseMsg;
  }

  // -- Query Methods -------------------------------------------------------

  getStats() {
    return { ...this._stats };
  }

  getChannelHistory(channelName, count = 10) {
    const channel = this._channels.get(channelName);
    return channel ? channel.getHistory(count) : [];
  }

  getActiveSubscriptions() {
    const subs = [];
    for (const channel of this._channels.values()) {
      for (const sub of channel.getSubscribers()) {
        if (sub.isActive()) {
          subs.push({ id: sub.id, channel: sub.channel, name: sub.name, created: sub.created });
        }
      }
    }
    return subs;
  }

  // -- Lifecycle -----------------------------------------------------------

  async shutdown() {
    this._pendingMessages = [];
    this._channels.clear();
    this._agents.clear();
    this.removeAllListeners();
    this.emit('bus:shutdown');
  }
}

// ---------------------------------------------------------------------------
// AgentBridge - Convenience wrapper for agents
// ---------------------------------------------------------------------------

class AgentBridge {
  constructor(agentId, messageBus, options = {}) {
    this.agentId = agentId;
    this.bus = messageBus;
    this._subscriptions = [];

    messageBus.registerAgent(agentId, options);
  }

  // Send a message to a channel
  async send(channel, payload, options = {}) {
    const msg = new Message(
      typeof payload === 'string' ? MessageType.CHAT : (options.type || MessageType.DATA),
      payload,
      { ...options, sender: this.agentId }
    );
    return this.bus.publishToChannel(channel, msg);
  }

  // Send a direct message to another agent
  async sendTo(recipientId, payload, options = {}) {
    const msg = new Message(
      typeof payload === 'string' ? MessageType.CHAT : (options.type || MessageType.DATA),
      payload,
      { ...options, sender: this.agentId, recipient: recipientId }
    );
    return this.bus.publishToChannel(`dm:${recipientId}`, msg);
  }

  // Request a response from a channel
  async request(channel, payload, timeoutMs = 10000) {
    const msg = new Message(MessageType.REQUEST, payload, { sender: this.agentId });
    return this.bus.request(channel, msg, timeoutMs);
  }

  // Broadcast to a channel
  async broadcast(channel, payload, options = {}) {
    const msg = new Message(MessageType.BROADCAST, payload, {
      ...options,
      sender: this.agentId,
    });
    return this.bus.publishToChannel(channel, msg);
  }

  // Listen on a channel
  on(channel, handler, options = {}) {
    const sub = this.bus.subscribe(this.agentId, channel, handler, {
      ...options,
      name: `${this.agentId}@${channel}`,
    });
    this._subscriptions.push(sub);
    return sub;
  }

  // Listen for a single message
  once(channel, handler, options = {}) {
    return this.on(channel, handler, { ...options, oneShot: true });
  }

  // Listen for direct messages
  onDirectMessage(handler, options = {}) {
    return this.on(`dm:${this.agentId}`, handler, options);
  }

  // Get channel history
  getHistory(channel, count = 10) {
    return this.bus.getChannelHistory(channel, count);
  }

  // List other agents
  listAgents() {
    return this.bus.listAgents().filter(a => a.id !== this.agentId);
  }

  // Update heartbeat
  heartbeat() {
    this.bus.updateAgentHeartbeat(this.agentId);
  }

  // Clean up
  disconnect() {
    for (const sub of this._subscriptions) {
      this.bus.unsubscribe(sub.id);
    }
    this._subscriptions = [];
    this.bus.unregisterAgent(this.agentId);
  }
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

module.exports = {
  MessageBus,
  AgentBridge,
  Message,
  MessageType,
  MessagePriority,
  Subscription,
  Channel,
};
