'use strict';

/**
 * HumanLoop - Interactive Human-in-the-Loop
 * Manages human handoff points for approvals, decisions, and input requests
 */

const HANDOFF_TYPES = {
  APPROVAL: 'APPROVAL',
  DECISION: 'DECISION',
  INPUT: 'INPUT',
  REVIEW: 'REVIEW',
  CLARIFICATION: 'CLARIFICATION'
};

class HumanLoop {
  constructor(options = {}) {
    this.pendingHandoffs = new Map();
    this.completedHandoffs = new Map();
    this.handoffCounter = 0;
    this.defaults = {
      timeout: options.timeout || 300000, // 5 minutes default
      defaultChoice: options.defaultChoice || null,
      autoApprove: options.autoApprove || false,
      onTimeout: options.onTimeout || 'default', // 'default', 'reject', 'approve'
      handlers: options.handlers || {} // Custom handler callbacks
    };
    this.history = [];
  }

  /**
   * Generate a unique handoff ID
   */
  _generateHandoffId() {
    this.handoffCounter++;
    return `handoff_${Date.now()}_${this.handoffCounter}_${Math.random().toString(36).slice(2, 6)}`;
  }

  /**
   * Request input from the human
   * @param {string} prompt - The question/prompt for the human
   * @param {Array} choices - Array of { value, label } choices (optional)
   * @param {object} options
   * @param {number} options.timeout - Timeout in ms
   * @param {string} options.type - Handoff type
   * @param {*} options.defaultValue - Default value on timeout
   * @returns {object} - Handoff object with id
   */
  requestInput(prompt, choices = [], options = {}) {
    const handoffId = this._generateHandoffId();
    const timeout = options.timeout || this.defaults.timeout;
    const handoffType = options.type || HANDOFF_TYPES.INPUT;

    const handoff = {
      id: handoffId,
      type: handoffType,
      prompt,
      choices: choices.map(c => typeof c === 'string' ? { value: c, label: c } : c),
      status: 'pending',
      createdAt: Date.now(),
      expiresAt: Date.now() + timeout,
      timeout,
      context: options.context || {},
      metadata: options.metadata || {},
      defaultValue: options.defaultValue !== undefined ? options.defaultValue : this.defaults.defaultChoice,
      result: null
    };

    this.pendingHandoffs.set(handoffId, handoff);
    this.history.push({ action: 'created', handoffId, type: handoffType, prompt, timestamp: Date.now() });

    // Set timeout
    if (timeout > 0) {
      handoff._timeout = setTimeout(() => {
        this._handleTimeout(handoffId);
      }, timeout);
    }

    return handoff;
  }

  /**
   * Request approval for an action
   * @param {string} action - Description of action needing approval
   * @param {object} context - Context about the action
   * @returns {object} - Handoff object
   */
  approve(action, context = {}) {
    return this.requestInput(
      `Approve the following action?\n\nAction: ${action}`,
      [
        { value: 'approved', label: 'Approve' },
        { value: 'rejected', label: 'Reject' },
        { value: 'modified', label: 'Modify' }
      ],
      {
        type: HANDOFF_TYPES.APPROVAL,
        context: { action, ...context },
        defaultValue: this.defaults.autoApprove ? 'approved' : 'rejected'
      }
    );
  }

  /**
   * Get a pending decision by handoff ID
   * @param {string} handoffId
   * @returns {object|null}
   */
  getDecision(handoffId) {
    // Check pending first
    if (this.pendingHandoffs.has(handoffId)) {
      return this.pendingHandoffs.get(handoffId);
    }
    // Check completed
    if (this.completedHandoffs.has(handoffId)) {
      return this.completedHandoffs.get(handoffId);
    }
    return null;
  }

  /**
   * Resolve a handoff with a decision
   * @param {string} handoffId
   * @param {*} value - The decision value
   * @param {object} options
   * @returns {object}
   */
  resolve(handoffId, value, options = {}) {
    const handoff = this.pendingHandoffs.get(handoffId);
    if (!handoff) {
      throw new Error(`Handoff "${handoffId}" not found or already resolved`);
    }

    // Clear timeout
    if (handoff._timeout) {
      clearTimeout(handoff._timeout);
      delete handoff._timeout;
    }

    handoff.status = 'resolved';
    handoff.result = {
      value,
      timestamp: Date.now(),
      notes: options.notes || '',
      resolvedBy: options.resolvedBy || 'system'
    };
    handoff.resolvedAt = Date.now();

    // Move from pending to completed
    this.pendingHandoffs.delete(handoffId);
    this.completedHandoffs.set(handoffId, handoff);
    
    this.history.push({ 
      action: 'resolved', 
      handoffId, 
      value, 
      timestamp: Date.now() 
    });

    return handoff;
  }

  /**
   * Handle timeout for a handoff
   */
  _handleTimeout(handoffId) {
    const handoff = this.pendingHandoffs.get(handoffId);
    if (!handoff) return;

    handoff.status = 'timed_out';
    
    let defaultValue = handoff.defaultValue;
    
    switch (this.defaults.onTimeout) {
      case 'approve':
        defaultValue = defaultValue || 'approved';
        break;
      case 'reject':
        defaultValue = defaultValue || 'rejected';
        break;
      case 'default':
      default:
        // Use the provided default or null
        break;
    }

    handoff.result = {
      value: defaultValue,
      timestamp: Date.now(),
      notes: 'Timeout - default value applied',
      resolvedBy: 'timeout'
    };
    handoff.resolvedAt = Date.now();

    this.pendingHandoffs.delete(handoffId);
    this.completedHandoffs.set(handoffId, handoff);
    
    this.history.push({ 
      action: 'timed_out', 
      handoffId, 
      defaultValue, 
      timestamp: Date.now() 
    });
  }

  /**
   * Get all pending handoffs
   * @returns {Array}
   */
  getPending() {
    return Array.from(this.pendingHandoffs.values());
  }

  /**
   * Get count of pending handoffs
   * @returns {number}
   */
  getPendingCount() {
    return this.pendingHandoffs.size;
  }

  /**
   * Check if there are pending handoffs
   * @returns {boolean}
   */
  hasPending() {
    return this.pendingHandoffs.size > 0;
  }

  /**
   * Wait for a specific handoff to be resolved
   * @param {string} handoffId
   * @param {number} timeout - Max wait time in ms
   * @returns {Promise<object>}
   */
  waitFor(handoffId, timeout = null) {
    return new Promise((resolve, reject) => {
      const handoff = this.getDecision(handoffId);
      
      // Already resolved
      if (handoff && handoff.status !== 'pending') {
        return resolve(handoff);
      }

      const checkInterval = 100; // check every 100ms
      const maxWait = timeout || (handoff ? handoff.timeout : 30000);
      const start = Date.now();

      const timer = setInterval(() => {
        const current = this.getDecision(handoffId);
        
        if (current && current.status !== 'pending') {
          clearInterval(timer);
          resolve(current);
        } else if (Date.now() - start > maxWait) {
          clearInterval(timer);
          reject(new Error(`Timeout waiting for handoff "${handoffId}"`));
        }
      }, checkInterval);
    });
  }

  /**
   * Cancel a pending handoff
   * @param {string} handoffId
   * @param {string} reason
   */
  cancel(handoffId, reason = 'Cancelled') {
    const handoff = this.pendingHandoffs.get(handoffId);
    if (!handoff) {
      throw new Error(`Handoff "${handoffId}" not found`);
    }

    if (handoff._timeout) {
      clearTimeout(handoff._timeout);
    }

    handoff.status = 'cancelled';
    handoff.result = {
      value: null,
      timestamp: Date.now(),
      notes: reason,
      resolvedBy: 'system'
    };
    handoff.resolvedAt = Date.now();

    this.pendingHandoffs.delete(handoffId);
    this.completedHandoffs.set(handoffId, handoff);
    
    this.history.push({ 
      action: 'cancelled', 
      handoffId, 
      reason, 
      timestamp: Date.now() 
    });
  }

  /**
   * Get all handoffs (both pending and completed)
   * @param {object} options
   * @returns {Array}
   */
  getAll(options = {}) {
    const all = new Map();
    
    for (const [id, h] of this.pendingHandoffs) {
      all.set(id, h);
    }
    for (const [id, h] of this.completedHandoffs) {
      all.set(id, h);
    }

    let results = Array.from(all.values());
    
    if (options.status) {
      results = results.filter(h => h.status === options.status);
    }
    if (options.type) {
      results = results.filter(h => h.type === options.type);
    }
    if (options.limit) {
      results = results.slice(-options.limit);
    }

    return results;
  }

  /**
   * Get loop statistics
   * @returns {object}
   */
  getStats() {
    const types = {};
    const statuses = {};
    
    for (const [id, h] of this.pendingHandoffs) {
      types[h.type] = (types[h.type] || 0) + 1;
      statuses[h.status] = (statuses[h.status] || 0) + 1;
    }
    for (const [id, h] of this.completedHandoffs) {
      types[h.type] = (types[h.type] || 0) + 1;
      statuses[h.status] = (statuses[h.status] || 0) + 1;
    }

    return {
      totalHandoffs: this.pendingHandoffs.size + this.completedHandoffs.size,
      pending: this.pendingHandoffs.size,
      completed: this.completedHandoffs.size,
      byType: types,
      byStatus: statuses,
      historyEntries: this.history.length
    };
  }

  /**
   * Review a piece of content (shorthand for creating a REVIEW handoff)
   * @param {string} content - Content to review
   * @param {object} context
   * @returns {object}
   */
  review(content, context = {}) {
    return this.requestInput(
      `Please review the following:\n\n${content}`,
      [
        { value: 'approved', label: 'Looks good' },
        { value: 'changes', label: 'Needs changes' },
        { value: 'reject', label: 'Reject' }
      ],
      {
        type: HANDOFF_TYPES.REVIEW,
        context: { content, ...context }
      }
    );
  }

  /**
   * Request clarification (shorthand for CLARIFICATION handoff)
   * @param {string} question
   * @param {Array} options
   * @returns {object}
   */
  clarify(question, options = []) {
    return this.requestInput(question, options, {
      type: HANDOFF_TYPES.CLARIFICATION
    });
  }
}

module.exports = { HumanLoop, HANDOFF_TYPES };
