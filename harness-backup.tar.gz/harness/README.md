# Hermes Debug Harness

Debug Harness System for Hermes Agent

## 結構

```
harness/
├── core/               # 核心模組
│   ├── index.js        # 主入口
│   ├── input-collector.js
│   ├── error-detector.js
│   ├── network-monitor.js
│   ├── state-inspector.js
│   ├── report-generator.js
│   └── initializers/
├── tests/              # 測試用例
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── reports/            # 報告輸出
├── scripts/            # 腳本工具
└── config/            # 配置文件
```

## 快速開始

```bash
cd /home/opc/.hermes/harness

# 運行所有測試
npm test

# 運行特定級別測試
npm run test:unit
npm run test:integration
npm run test:e2e

# 生成報告
npm run report:generate
```

## 核心功能

1. **Input Collector** - 收集用戶操作序列
2. **Error Detector** - 攔截並分類錯誤
3. **Network Monitor** - 監控 API 請求/回應
4. **State Inspector** - 檢查前端狀態
5. **Report Generator** - 生成多格式報告

## 狀態

🟢 已初始化 - 待使用
