'use strict';

const assert = require('assert');
const { ModelRouter } = require('../../core/model-router');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

console.log('\n=== ModelRouter Tests ===\n');

// Test providers config
const testProviders = [
  { provider: 'openai', model: 'gpt-4', weights: 10, cost_per_token: 0.03, capabilities: ['coding', 'reasoning'] },
  { provider: 'openai', model: 'gpt-3.5-turbo', weights: 8, cost_per_token: 0.002, capabilities: ['coding'] },
  { provider: 'anthropic', model: 'claude-3', weights: 9, cost_per_token: 0.015, capabilities: ['reasoning', 'coding'] },
  { provider: 'anthropic', model: 'claude-3-haiku', weights: 7, cost_per_token: 0.001, capabilities: ['coding'] },
  { provider: 'google', model: 'gemini-pro-vision', weights: 6, cost_per_token: 0.01, capabilities: ['vision', 'reasoning'] },
  { provider: 'local', model: 'hermes-3', weights: 5, cost_per_token: 0.0005, capabilities: ['coding', 'reasoning'] }
];

test('ModelRouter constructor with providers', () => {
  const router = new ModelRouter({ providers: testProviders });
  const config = router.getConfig();
  assert.strictEqual(config.providers.length, 6);
});

test('ModelRouter constructor validates providers', () => {
  assert.throws(() => {
    new ModelRouter({ providers: [{ model: 'test' }] });
  }, /must have a name/);
});

test('ModelRouter select - returns best model for coding', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.select('coding', ['cost', 'weight']);
  assert.ok(result);
  assert.ok(result.provider);
  assert.ok(result.model);
  assert.ok(result.candidates.length >= 1);
});

test('ModelRouter select - cheapest model for general query', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.select('general', ['cost']);
  // Cheapest should be local/hermes-3 at $0.0005
  assert.strictEqual(result.provider, 'local');
  assert.strictEqual(result.model, 'hermes-3');
});

test('ModelRouter select - coding query picks cheapest with coding capability', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.select('coding', ['cost']);
  // Cheapest with coding: anthropic claude-3-haiku ($0.001) or local hermes-3 ($0.0005)
  assert.ok(['hermes-3', 'claude-3-haiku', 'gpt-3.5-turbo'].includes(result.model));
});

test('ModelRouter select - vision query filters to vision-capable', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.select('vision', ['cost']);
  assert.ok(result);
  assert.strictEqual(result.provider, 'google');
  assert.strictEqual(result.model, 'gemini-pro-vision');
});

test('ModelRouter select - returns null for non-matching query with no fallback', () => {
  const router = new ModelRouter({ providers: [
    { provider: 'test', model: 'm1', cost_per_token: 0.01, capabilities: ['coding'] }
  ]});
  // Should fallback to available since no vision-capable exists
  const result = router.select('vision', ['cost']);
  assert.ok(result); // Falls back to coding provider
});

test('ModelRouter withFallback - primary succeeds', async () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = await router.withFallback('openai', 'gpt-4', async ({ provider, model }) => {
    return { success: true, provider, model };
  });
  assert.strictEqual(result.provider, 'openai');
  assert.strictEqual(result.model, 'gpt-4');
  assert.strictEqual(result.success, true);
});

test('ModelRouter withFallback - falls back on error', async () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = await router.withFallback('openai', 'gpt-4', async ({ provider, model, attempt, isFallback }) => {
    if (!isFallback && provider === 'openai') {
      const err = new Error('Rate limit exceeded');
      err.code = '429';
      throw err;
    }
    return { success: true, provider, model, isFallback };
  });
  assert.ok(result);
  assert.strictEqual(result.isFallback, true);
});

test('ModelRouter withFallback - throws on non-retryable error', async () => {
  const router = new ModelRouter({ providers: testProviders });
  try {
    await router.withFallback('openai', 'gpt-4', async () => {
      throw new Error('Invalid API key');
    });
    assert.fail('Should have thrown');
  } catch (err) {
    assert.ok(err.message.includes('Invalid API key'));
  }
});

test('ModelRouter withFallback - throws when all providers exhausted', async () => {
  const router = new ModelRouter({ providers: [
    { provider: 'p1', model: 'm1', cost_per_token: 0.01 },
    { provider: 'p2', model: 'm2', cost_per_token: 0.02 }
  ]});
  
  try {
    await router.withFallback('p1', 'm1', async ({ isFallback }) => {
      throw new Error('Rate limit hit');
    });
    assert.fail('Should have thrown');
  } catch (err) {
    assert.ok(err.message.includes('All providers exhausted'));
  }
});

test('ModelRouter getCheapestWithCapabilities - returns cheapest matching', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.getCheapestWithCapabilities(['coding', 'reasoning']);
  assert.ok(result);
  // local/hermes-3 ($0.0005) should be cheapest with both coding and reasoning
  assert.strictEqual(result.provider, 'local');
  assert.strictEqual(result.model, 'hermes-3');
});

test('ModelRouter getCheapestWithCapabilities - no match returns null', () => {
  const router = new ModelRouter({ providers: testProviders });
  const result = router.getCheapestWithCapabilities(['impossible_capability']);
  assert.strictEqual(result, null);
});

test('ModelRouter addProvider - adds and validates', () => {
  const router = new ModelRouter({ providers: [] });
  router.addProvider({ provider: 'new', model: 'm1', cost_per_token: 0.005, capabilities: ['vision'] });
  assert.strictEqual(router.getConfig().providers.length, 1);
});

test('ModelRouter removeProvider - removes by name', () => {
  const router = new ModelRouter({ providers: testProviders });
  router.removeProvider('google');
  const config = router.getConfig();
  assert.strictEqual(config.providers.filter(p => p.provider === 'google').length, 0);
});

test('ModelRouter - cost-aware selection picks cheapest', () => {
  const router = new ModelRouter({ providers: [
    { provider: 'a', model: 'expensive', cost_per_token: 1.0, capabilities: ['coding'] },
    { provider: 'b', model: 'cheap', cost_per_token: 0.001, capabilities: ['coding'] }
  ]});
  const result = router.select('coding', ['cost']);
  assert.strictEqual(result.model, 'cheap');
});

console.log(`\nModelRouter Tests: ${passed} passed, ${failed} failed\n`);

process.exit(failed > 0 ? 1 : 0);
