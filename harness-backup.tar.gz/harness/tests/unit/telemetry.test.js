'use strict';

const path = require('path');
const assert = require('assert');
const fs = require('fs');

const { TelemetryTracer } = require('../../core/telemetry.js');

const testTracesDir = path.resolve(__dirname, '..', '..', 'traces', 'test-' + Date.now());

function createTracer(options = {}) {
  return new TelemetryTracer({
    tracesDir: testTracesDir,
    autoFlush: false,
    ...options
  });
}

(async () => {
  let passed = 0;
  let failed = 0;
  const failures = [];

  function test(name, fn) {
    try {
      fn();
      passed++;
      console.log(`  ✅ ${name}`);
    } catch (err) {
      failed++;
      failures.push({ name, error: err.message, stack: err.stack });
      console.log(`  ❌ ${name}: ${err.message}`);
    }
  }

  async function testAsync(name, fn) {
    try {
      await fn();
      passed++;
      console.log(`  ✅ ${name}`);
    } catch (err) {
      failed++;
      failures.push({ name, error: err.message, stack: err.stack });
      console.log(`  ❌ ${name}: ${err.message}`);
    }
  }

  // ===== Span Creation & Lifecycle =====
  console.log('\n📋 Span Creation & Lifecycle');

  test('creates a span with auto-generated ID', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('test-span');
    assert.ok(span.id);
    assert.strictEqual(span.name, 'test-span');
    assert.strictEqual(span.status, 'running');
    assert.strictEqual(span.endTime, null);
    assert.strictEqual(span.duration, null);
    assert.deepStrictEqual(span.events, []);
    assert.strictEqual(span.parentId, null);
    tracer.dispose();
  });

  test('creates a span with explicit options', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('llm-call', {
      id: 'my-span-1', type: 'llm_call',
      metadata: { model: 'gpt-4', temperature: 0.7 }
    });
    assert.strictEqual(span.id, 'my-span-1');
    assert.strictEqual(span.type, 'llm_call');
    assert.strictEqual(span.metadata.model, 'gpt-4');
    tracer.dispose();
  });

  test('span count increases with each span', () => {
    const tracer = createTracer();
    assert.strictEqual(tracer.spanCount, 0);
    tracer.startSpan('s1');
    assert.strictEqual(tracer.spanCount, 1);
    tracer.startSpan('s2');
    assert.strictEqual(tracer.spanCount, 2);
    tracer.dispose();
  });

  // ===== Ending Spans =====
  console.log('\n📋 Ending Spans');

  test('endSpan sets endTime, duration, and status', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('quick-span');
    const start = Date.now();
    while (Date.now() - start < 5) { /* spin */ }
    tracer.endSpan(span.id);
    assert.ok(span.endTime > span.startTime);
    assert.ok(span.duration > 0);
    assert.strictEqual(span.status, 'ok');
    tracer.dispose();
  });

  test('endSpan with custom status', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('failing-span');
    tracer.endSpan(span.id, { status: 'error' });
    assert.strictEqual(span.status, 'error');
    tracer.dispose();
  });

  test('endSpan adds metadata', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('meta-span');
    tracer.endSpan(span.id, { metadata: { result: 'success', tokens: 150 } });
    assert.strictEqual(span.metadata.result, 'success');
    assert.strictEqual(span.metadata.tokens, 150);
    tracer.dispose();
  });

  test('endSpan warns on unknown span', () => {
    const tracer = createTracer();
    tracer.endSpan('non-existent-id');
    tracer.dispose();
  });

  // ===== Events =====
  console.log('\n📋 Events');

  test('addEvent adds event to span', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('event-span');
    tracer.addEvent(span.id, 'http.request', { url: 'https://api.example.com', method: 'GET' });
    assert.strictEqual(span.events.length, 1);
    assert.strictEqual(span.events[0].name, 'http.request');
    assert.strictEqual(span.events[0].attributes.url, 'https://api.example.com');
    tracer.dispose();
  });

  test('addEvent supports multiple events', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('multi-event');
    tracer.addEvent(span.id, 'start');
    tracer.addEvent(span.id, 'middle');
    tracer.addEvent(span.id, 'end');
    assert.strictEqual(span.events.length, 3);
    tracer.dispose();
  });

  test('addEvent warns on unknown span', () => {
    const tracer = createTracer();
    tracer.addEvent('bad-id', 'event');
    tracer.dispose();
  });

  // ===== Parent-Child Span Tree =====
  console.log('\n📋 Parent-Child Span Tree');

  test('nested spans create parent-child relationship', () => {
    const tracer = createTracer();
    const parent = tracer.startSpan('parent');
    const child = tracer.startSpan('child', { parentId: parent.id });
    assert.strictEqual(child.parentId, parent.id);
    tracer.dispose();
  });

  test('getTrace returns tree structure with children', () => {
    const tracer = createTracer();
    const root = tracer.startSpan('root');
    const child1 = tracer.startSpan('child1', { parentId: root.id });
    const child2 = tracer.startSpan('child2', { parentId: root.id });
    const grandchild = tracer.startSpan('grandchild', { parentId: child1.id });

    const trace = tracer.getTrace();
    assert.strictEqual(trace.length, 1);
    assert.strictEqual(trace[0].name, 'root');
    assert.strictEqual(trace[0].children.length, 2);
    assert.strictEqual(trace[0].children[0].children.length, 1);
    assert.strictEqual(trace[0].children[0].children[0].name, 'grandchild');
    tracer.dispose();
  });

  test('multiple root spans in trace', () => {
    const tracer = createTracer();
    tracer.startSpan('root1');
    tracer.startSpan('root2');
    tracer.startSpan('root3');
    const trace = tracer.getTrace();
    assert.strictEqual(trace.length, 3);
    tracer.dispose();
  });

  test('getTrace includes span data in tree nodes', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('data-span', { type: 'agent_step', metadata: { step: 1 } });
    tracer.addEvent(span.id, 'processing', { detail: 'step 1' });
    tracer.endSpan(span.id, { status: 'ok' });
    const trace = tracer.getTrace();
    assert.strictEqual(trace[0].name, 'data-span');
    assert.strictEqual(trace[0].type, 'agent_step');
    assert.strictEqual(trace[0].status, 'ok');
    assert.strictEqual(trace[0].events.length, 1);
    assert.ok(trace[0].duration >= 0);
    tracer.dispose();
  });

  // ===== Active Spans =====
  console.log('\n📋 Active Spans');

  test('getActiveSpans returns only non-ended spans', () => {
    const tracer = createTracer();
    const s1 = tracer.startSpan('active1');
    const s2 = tracer.startSpan('active2');
    tracer.endSpan(s1.id);
    const active = tracer.getActiveSpans();
    assert.strictEqual(active.length, 1);
    assert.strictEqual(active[0].id, s2.id);
    tracer.dispose();
  });

  // ===== Flush to Disk =====
  console.log('\n📋 Flush to Disk');

  test('flush writes a JSON file to traces dir', () => {
    const tracer = createTracer({ autoFlush: false });
    tracer.startSpan('flush-test');
    const filePath = tracer.flush();
    assert.ok(filePath, 'should return file path');
    assert.ok(fs.existsSync(filePath), 'file should exist');
    const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    assert.ok(content.traceId);
    assert.ok(content.spans);
    assert.ok(content.traceTree);
    assert.strictEqual(content.spans.length, 1);
    fs.unlinkSync(filePath);
    tracer.dispose();
  });

  test('flush writes complete trace tree', () => {
    const tracer = createTracer({ autoFlush: false });
    const root = tracer.startSpan('root');
    const child = tracer.startSpan('child', { parentId: root.id });
    tracer.endSpan(child.id);
    tracer.endSpan(root.id);
    const filePath = tracer.flush();
    const content = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    assert.strictEqual(content.spans.length, 2);
    assert.strictEqual(content.traceTree.length, 1);
    assert.strictEqual(content.traceTree[0].children.length, 1);
    fs.unlinkSync(filePath);
    tracer.dispose();
  });

  test('flush creates traces directory if missing', () => {
    const tempDir = path.resolve(__dirname, '..', '..', 'traces', 'new-dir-test');
    // Remove recursively if exists from prior runs
    if (fs.existsSync(tempDir)) {
      const entries = fs.readdirSync(tempDir);
      entries.forEach(f => {
        const fp = path.join(tempDir, f);
        if (fs.statSync(fp).isDirectory()) {
          const inner = fs.readdirSync(fp);
          inner.forEach(sf => fs.unlinkSync(path.join(fp, sf)));
          fs.rmdirSync(fp);
        } else {
          fs.unlinkSync(fp);
        }
      });
      fs.rmdirSync(tempDir);
    }
    const tracer = new TelemetryTracer({ tracesDir: tempDir, autoFlush: false });
    tracer.startSpan('new-dir-span');
    const filePath = tracer.flush();
    assert.ok(fs.existsSync(tempDir));
    assert.ok(fs.existsSync(filePath));
    fs.unlinkSync(filePath);
    fs.rmdirSync(tempDir);
    tracer.dispose();
  });

  // ===== Reset =====
  console.log('\n📋 Reset');

  test('reset clears all spans and starts new traceId', () => {
    const tracer = createTracer();
    tracer.startSpan('old-span');
    const oldTraceId = tracer.currentTraceId;
    tracer.reset();
    assert.strictEqual(tracer.spanCount, 0);
    assert.notStrictEqual(tracer.currentTraceId, oldTraceId);
    tracer.dispose();
  });

  // ===== OpenTelemetry =====
  console.log('\n📋 OpenTelemetry Compatibility');

  test('otelCompatible mode returns OTel-like span format', () => {
    const tracer = createTracer({ otelCompatible: true });
    const span = tracer.startSpan('otel-span', { type: 'llm_call' });
    tracer.endSpan(span.id);
    const spans = tracer._getAllSpansWithFormat();
    assert.ok(spans[0].spanId);
    assert.ok(spans[0].traceId);
    assert.ok(spans[0].startTime);
    assert.ok(spans[0].endTime);
    assert.strictEqual(spans[0].kind, 2);
    assert.strictEqual(spans[0].status.code, 1);
    tracer.dispose();
  });

  test('otelCompatible tool_execution span kind', () => {
    const tracer = createTracer({ otelCompatible: true });
    const span = tracer.startSpan('tool-call', { type: 'tool_execution' });
    tracer.endSpan(span.id);
    const spans = tracer._getAllSpansWithFormat();
    assert.strictEqual(spans[0].kind, 3);
    tracer.dispose();
  });

  test('otelCompatible default kind for unknown types', () => {
    const tracer = createTracer({ otelCompatible: true });
    const span = tracer.startSpan('custom', { type: 'custom_type' });
    tracer.endSpan(span.id);
    const spans = tracer._getAllSpansWithFormat();
    assert.strictEqual(spans[0].kind, 1);
    tracer.dispose();
  });

  // ===== Integration =====
  console.log('\n📋 Integration Tests');

  await testAsync('complex trace with nested spans, events, and flush', async () => {
    const tracer = createTracer({ autoFlush: false });
    const root = tracer.startSpan('agent-run', { type: 'session', metadata: { agent: 'hermes' } });
    const llmSpan = tracer.startSpan('llm-call-1', { parentId: root.id, type: 'llm_call', metadata: { model: 'deepseek-chat' } });
    tracer.addEvent(llmSpan.id, 'request.start', { prompt: 'What is 2+2?' });
    tracer.addEvent(llmSpan.id, 'response.received', { response: '4', latency_ms: 1234 });
    tracer.endSpan(llmSpan.id, { status: 'ok' });
    const toolSpan = tracer.startSpan('tool-execution', { parentId: root.id, type: 'tool_execution', metadata: { tool: 'calculator' } });
    tracer.addEvent(toolSpan.id, 'tool.start', {});
    tracer.addEvent(toolSpan.id, 'tool.result', { output: '4' });
    tracer.endSpan(toolSpan.id, { status: 'ok' });
    tracer.endSpan(root.id, { metadata: { total_duration_ms: 2345 } });

    const trace = tracer.getTrace();
    assert.strictEqual(trace.length, 1);
    assert.strictEqual(trace[0].children.length, 2);
    assert.strictEqual(trace[0].children[0].events.length, 2);
    assert.strictEqual(trace[0].children[1].events.length, 2);

    const filePath = tracer.flush();
    assert.ok(filePath);
    const fileContent = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    assert.strictEqual(fileContent.spans.length, 3);
    fs.unlinkSync(filePath);
    tracer.dispose();
  });

  // ===== Edge Cases =====
  console.log('\n📋 Edge Cases');

  test('getSpan returns undefined for unknown span', () => {
    const tracer = createTracer();
    assert.strictEqual(tracer.getSpan('non-existent'), undefined);
    tracer.dispose();
  });

  test('getTrace returns empty array with no spans', () => {
    const tracer = createTracer();
    assert.deepStrictEqual(tracer.getTrace(), []);
    tracer.dispose();
  });

  test('getActiveSpans returns empty array with no active spans', () => {
    const tracer = createTracer();
    const span = tracer.startSpan('done');
    tracer.endSpan(span.id);
    assert.deepStrictEqual(tracer.getActiveSpans(), []);
    tracer.dispose();
  });

  test('dispose flushes pending spans', () => {
    const beforeFiles = fs.existsSync(testTracesDir) ? fs.readdirSync(testTracesDir) : [];
    const tracer = createTracer({ autoFlush: false });
    tracer.startSpan('dispose-test');
    tracer.dispose();
    const afterFiles = fs.existsSync(testTracesDir) ? fs.readdirSync(testTracesDir) : [];
    assert.ok(afterFiles.length >= beforeFiles.length, 'dispose should flush');
    // Clean up the file created by dispose
    const newFiles = afterFiles.filter(f => !beforeFiles.includes(f));
    newFiles.forEach(f => fs.unlinkSync(path.join(testTracesDir, f)));
  });

  // ===== Cleanup =====
  console.log('\n📋 Cleanup');

  test('cleanup test traces directory', () => {
    if (fs.existsSync(testTracesDir)) {
      const files = fs.readdirSync(testTracesDir);
      files.forEach(f => fs.unlinkSync(path.join(testTracesDir, f)));
      fs.rmdirSync(testTracesDir);
    }
    assert.ok(!fs.existsSync(testTracesDir));
  });

  // ===== Summary =====
  console.log('\n');
  console.log('='.repeat(50));
  console.log(`Results: ${passed} passed, ${failed} failed, ${passed + failed} total`);
  if (failures.length > 0) {
    console.log('\nFailures:');
    failures.forEach(f => console.log(`  - ${f.name}: ${f.error}`));
  }
  console.log('='.repeat(50));
  process.exit(failed > 0 ? 1 : 0);
})();
