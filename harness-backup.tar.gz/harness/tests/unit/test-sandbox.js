'use strict';

const assert = require('assert');
const { Sandbox, SandboxManager } = require('../../core/sandbox');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

function assertApprox(actual, expected, tolerance, msg) {
  if (Math.abs(actual - expected) > tolerance) {
    throw new Error(msg || `Expected ~${expected}, got ${actual}`);
  }
}

console.log('\n=== Sandbox Tests ===\n');

// Sandbox class tests
test('Sandbox constructor with defaults', () => {
  const s = new Sandbox();
  assert.strictEqual(s.mode, 'standard');
  assert.ok(s.id);
  assert.ok(s.resourceLimits.maxMemory > 0);
});

test('Sandbox constructor with options', () => {
  const s = new Sandbox({ mode: 'strict', id: 'test-sandbox', maxMemory: 128 });
  assert.strictEqual(s.mode, 'strict');
  assert.strictEqual(s.id, 'test-sandbox');
  assert.strictEqual(s.resourceLimits.maxMemory, 128);
});

test('Sandbox exec - basic command', () => {
  const s = new Sandbox({ mode: 'permissive' });
  const result = s.exec('echo "hello world"');
  assert.strictEqual(result.exitCode, 0);
  assert.ok(result.stdout.includes('hello world') || result.stdout.trim() === 'hello world');
});

test('Sandbox exec - blocks rm -rf / in strict mode', () => {
  const s = new Sandbox({ mode: 'strict' });
  const result = s.exec('rm -rf /');
  assert.strictEqual(result.exitCode, 1);
  assert.ok(result.stderr.includes('SANDBOX_BLOCKED') || result.stderr.includes('blocked'));
});

test('Sandbox exec - blocks sudo in standard mode', () => {
  const s = new Sandbox({ mode: 'standard' });
  const result = s.exec('sudo rm file.txt');
  assert.strictEqual(result.exitCode, 1);
  assert.ok(result.stderr.includes('blocked'));
});

test('Sandbox exec - blocks chmod 777', () => {
  const s = new Sandbox({ mode: 'standard' });
  const result = s.exec('chmod 777 /etc/passwd');
  assert.strictEqual(result.exitCode, 1);
  assert.ok(result.stderr.includes('blocked'));
});

test('Sandbox exec - blocks eval(', () => {
  const s = new Sandbox({ mode: 'standard' });
  const result = s.exec('eval("dangerous code")');
  assert.strictEqual(result.exitCode, 1);
  assert.ok(result.stderr.includes('blocked'));
});

test('Sandbox exec - blocks exec(', () => {
  const s = new Sandbox({ mode: 'standard' });
  const result = s.exec('exec("malicious")');
  assert.strictEqual(result.exitCode, 1);
  assert.ok(result.stderr.includes('blocked'));
});

test('Sandbox exec - permissive mode allows everything', () => {
  const s = new Sandbox({ mode: 'permissive' });
  const result = s.exec('echo "permissive test"');
  assert.ok(result.stdout.trim() === 'permissive test' || result.exitCode === 0);
});

test('Sandbox exec - strict mode blocks network commands', () => {
  const s = new Sandbox({ mode: 'strict' });
  const result = s.exec('nc -l 4444');
  assert.strictEqual(result.exitCode, 1);
});

test('Sandbox exec - empty command returns error', () => {
  const s = new Sandbox();
  const result = s.exec('');
  assert.strictEqual(result.exitCode, 1);
});

test('Sandbox getHistory - tracks executed commands', () => {
  const s = new Sandbox({ mode: 'permissive' });
  s.exec('echo "first"');
  s.exec('echo "second"');
  const history = s.getHistory();
  assert.strictEqual(history.length, 2);
  assert.ok(history[0].command.includes('first'));
  assert.ok(history[1].command.includes('second'));
});

test('Sandbox getInfo - returns correct info', () => {
  const s = new Sandbox({ id: 'info-test', mode: 'strict' });
  const info = s.getInfo();
  assert.strictEqual(info.id, 'info-test');
  assert.strictEqual(info.mode, 'strict');
  assert.strictEqual(info.commandsExecuted, 0);
});

// SandboxManager class tests
test('SandboxManager constructor with defaults', () => {
  const sm = new SandboxManager();
  const status = sm.getStatus();
  assert.strictEqual(status.totalSandboxes, 0);
  assert.ok(status.globalLimits.maxSandboxes > 0);
});

test('SandboxManager createSandbox - creates sandbox', () => {
  const sm = new SandboxManager();
  const s = sm.createSandbox('test1', { mode: 'standard' });
  assert.strictEqual(s.id, 'test1');
  assert.strictEqual(s.mode, 'standard');
  assert.strictEqual(sm.listSandboxes().length, 1);
});

test('SandboxManager createSandbox - throws on duplicate', () => {
  const sm = new SandboxManager();
  sm.createSandbox('dup', { mode: 'standard' });
  assert.throws(() => sm.createSandbox('dup', { mode: 'standard' }), /already exists/);
});

test('SandboxManager createSandbox - respects max sandboxes', () => {
  const sm = new SandboxManager({ maxSandboxes: 2 });
  sm.createSandbox('a', { mode: 'standard' });
  sm.createSandbox('b', { mode: 'standard' });
  assert.throws(() => sm.createSandbox('c', { mode: 'standard' }), /Maximum number/);
});

test('SandboxManager destroySandbox - removes sandbox', () => {
  const sm = new SandboxManager();
  sm.createSandbox('remove-me', { mode: 'standard' });
  assert.strictEqual(sm.listSandboxes().length, 1);
  sm.destroySandbox('remove-me');
  assert.strictEqual(sm.listSandboxes().length, 0);
});

test('SandboxManager destroySandbox - throws on non-existent', () => {
  const sm = new SandboxManager();
  assert.throws(() => sm.destroySandbox('nonexistent'), /not found/);
});

test('SandboxManager listSandboxes - returns list of sandbox info', () => {
  const sm = new SandboxManager();
  sm.createSandbox('list-a', { mode: 'strict' });
  sm.createSandbox('list-b', { mode: 'permissive' });
  const list = sm.listSandboxes();
  assert.strictEqual(list.length, 2);
  assert.ok(list.some(s => s.id === 'list-a'));
  assert.ok(list.some(s => s.id === 'list-b'));
});

test('SandboxManager destroyAll - removes all sandboxes', () => {
  const sm = new SandboxManager();
  sm.createSandbox('x', { mode: 'standard' });
  sm.createSandbox('y', { mode: 'standard' });
  sm.createSandbox('z', { mode: 'standard' });
  assert.strictEqual(sm.listSandboxes().length, 3);
  sm.destroyAll();
  assert.strictEqual(sm.listSandboxes().length, 0);
});

test('SandboxManager getStatus - shows usage stats', () => {
  const sm = new SandboxManager({ totalMemory: 1024 });
  sm.createSandbox('stat', { maxMemory: 128 });
  const status = sm.getStatus();
  assert.strictEqual(status.totalSandboxes, 1);
  assert.ok(status.usage.totalMemoryUsed >= 128);
});

console.log(`\nSandbox Tests: ${passed} passed, ${failed} failed\n`);

// Return exit code
process.exit(failed > 0 ? 1 : 0);
