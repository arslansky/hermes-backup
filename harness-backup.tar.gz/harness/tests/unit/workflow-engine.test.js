#!/usr/bin/env node
/**
 * Workflow Engine - Comprehensive Tests
 * Tests all node types, edges, state management, and edge cases.
 */

'use strict';

const assert = require('assert');
const path = require('path');
const { WorkflowEngine, WorkflowState, ExpressionEvaluator, parseSimpleYaml } = require('../../core/workflow-engine');

const HARNESS_DIR = path.resolve(__dirname, '../..');

// ---------------------------------------------------------------------------
// Test counter
// ---------------------------------------------------------------------------
let passed = 0;
let failed = 0;
let errors = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    process.stdout.write('✓');
  } catch (err) {
    failed++;
    errors.push({ name, error: err.message, stack: err.stack });
    process.stdout.write('✗');
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    process.stdout.write('✓');
  } catch (err) {
    failed++;
    errors.push({ name, error: err.message, stack: err.stack });
    process.stdout.write('✗');
  }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

console.log('\n═══ WorkflowState Tests ═══\n');

test('WorkflowState: set/get single key', () => {
  const s = new WorkflowState();
  s.set('name', 'hermes');
  assert.strictEqual(s.get('name'), 'hermes');
});

test('WorkflowState: set/get nested key', () => {
  const s = new WorkflowState();
  s.set('results.count', 42);
  assert.strictEqual(s.get('results.count'), 42);
});

test('WorkflowState: set/get deep nested key', () => {
  const s = new WorkflowState();
  s.set('a.b.c.d', 'deep');
  assert.strictEqual(s.get('a.b.c.d'), 'deep');
});

test('WorkflowState: getAll returns all data', () => {
  const s = new WorkflowState({ x: 1, y: 2 });
  assert.deepStrictEqual(s.getAll(), { x: 1, y: 2 });
});

test('WorkflowState: push appends to array', () => {
  const s = new WorkflowState();
  s.push('items', 'a');
  s.push('items', 'b');
  assert.deepStrictEqual(s.get('items'), ['a', 'b']);
});

test('WorkflowState: has returns true/false', () => {
  const s = new WorkflowState({ a: 1 });
  assert.strictEqual(s.has('a'), true);
  assert.strictEqual(s.has('b'), false);
});

test('WorkflowState: get nonexistent key returns undefined', () => {
  const s = new WorkflowState();
  assert.strictEqual(s.get('nope'), undefined);
});

test('WorkflowState: history tracking', () => {
  const s = new WorkflowState();
  s.addHistory({ nodeId: 'n1', type: 'LLM_CALL', status: 'started' });
  s.addHistory({ nodeId: 'n1', type: 'LLM_CALL', status: 'completed' });
  assert.strictEqual(s.getHistory().length, 2);
});

test('WorkflowState: clone creates independent copy', () => {
  const s = new WorkflowState({ a: 1 });
  const c = s.clone();
  c.set('a', 2);
  assert.strictEqual(s.get('a'), 1);
  assert.strictEqual(c.get('a'), 2);
});

console.log('\n\n═══ ExpressionEvaluator Tests ═══\n');

test('ExpressionEvaluator: basic equality', () => {
  const s = new WorkflowState({ count: 5 });
  assert.strictEqual(ExpressionEvaluator.evaluate('state.count === 5', s), true);
  assert.strictEqual(ExpressionEvaluator.evaluate('state.count === 3', s), false);
});

test('ExpressionEvaluator: string comparison', () => {
  const s = new WorkflowState({ status: 'ok' });
  assert.strictEqual(ExpressionEvaluator.evaluate('state.status === "ok"', s), true);
});

test('ExpressionEvaluator: boolean logic', () => {
  const s = new WorkflowState({ x: true, y: false });
  assert.strictEqual(ExpressionEvaluator.evaluate('state.x && !state.y', s), true);
  assert.strictEqual(ExpressionEvaluator.evaluate('!state.x', s), false);
});

test('ExpressionEvaluator: len() function', () => {
  const s = new WorkflowState({ items: [1, 2, 3] });
  assert.strictEqual(ExpressionEvaluator.evaluate('len(state.items) > 0', s), true);
  assert.strictEqual(ExpressionEvaluator.evaluate('len(state.items) === 3', s), true);
});

test('ExpressionEvaluator: len() on string', () => {
  const s = new WorkflowState({ name: 'hello' });
  assert.strictEqual(ExpressionEvaluator.evaluate('len(state.name) === 5', s), true);
});

test('ExpressionEvaluator: len() on undefined', () => {
  const s = new WorkflowState({});
  assert.strictEqual(ExpressionEvaluator.evaluate('len(state.nonexistent) === 0', s), true);
});

test('ExpressionEvaluator: nested access', () => {
  const s = new WorkflowState({ config: { enabled: true } });
  assert.strictEqual(ExpressionEvaluator.evaluate('state.config.enabled', s), true);
});

console.log('\n\n═══ YAML Parser Tests ═══\n');

test('parseSimpleYaml: basic key-value', () => {
  const result = parseSimpleYaml('key: value');
  assert.deepStrictEqual(result, { key: 'value' });
});

test('parseSimpleYaml: nested object', () => {
  const yaml = `outer:
  inner: value`;
  const result = parseSimpleYaml(yaml);
  assert.deepStrictEqual(result, { outer: { inner: 'value' } });
});

test('parseSimpleYaml: numbers', () => {
  const yaml = 'count: 42\nratio: 3.14';
  const result = parseSimpleYaml(yaml);
  assert.strictEqual(result.count, 42);
  assert.strictEqual(result.ratio, 3.14);
});

test('parseSimpleYaml: booleans', () => {
  const result = parseSimpleYaml('enabled: true\nactive: false');
  assert.strictEqual(result.enabled, true);
  assert.strictEqual(result.active, false);
});

test('parseSimpleYaml: quoted strings', () => {
  const result = parseSimpleYaml("name: 'hello world'");
  assert.strictEqual(result.name, 'hello world');
});

test('parseSimpleYaml: list items', () => {
  const yaml = `items:
  - a
  - b
  - c`;
  const result = parseSimpleYaml(yaml);
  assert.deepStrictEqual(result, { items: ['a', 'b', 'c'] });
});

test('parseSimpleYaml: deep nesting', () => {
  const yaml = `a:
  b:
    c: deep`;
  const result = parseSimpleYaml(yaml);
  assert.strictEqual(result.a.b.c, 'deep');
});

test('parseSimpleYaml: comments are ignored', () => {
  const yaml = `key: value
# this is a comment`;
  const result = parseSimpleYaml(yaml);
  assert.deepStrictEqual(result, { key: 'value' });
});

console.log('\n\n═══ WorkflowEngine Tests ═══\n');

test('WorkflowEngine: load from object creates engine', () => {
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'test',
    nodes: {
      collect: { type: 'PASS' },
    },
    edges: [
      { from: '__start__', to: 'collect' },
      { from: 'collect', to: '__end__' },
    ],
  });
  assert.ok(engine.getNodeDef('collect'));
  assert.strictEqual(engine.getMetadata().id, 'test');
});

test('WorkflowEngine: simple pass-through workflow', async () => {
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'simple',
    nodes: {
      greet: { type: 'LLM_CALL', prompt: 'Hello!', output_key: 'greeting' },
    },
    edges: [
      { from: '__start__', to: 'greet' },
      { from: 'greet', to: '__end__' },
    ],
  });
  const result = await engine.run({});
  assert.strictEqual(result.status, 'completed');
  assert.strictEqual(result.iterations, 1);
});

test('WorkflowEngine: conditional branching (true path)', async () => {
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'conditional',
    nodes: {
      check: { type: 'CONDITION', condition: 'true' },
      true_branch: { type: 'LLM_CALL', prompt: 'True path', output_key: 'path' },
      false_branch: { type: 'LLM_CALL', prompt: 'False path', output_key: 'path' },
    },
    edges: [
      { from: '__start__', to: 'check' },
      { from: 'check.if', to: 'true_branch' },
      { from: 'check.else', to: 'false_branch' },
      { from: 'true_branch', to: '__end__' },
      { from: 'false_branch', to: '__end__' },
    ],
  });
  const result = await engine.run({});
  assert.strictEqual(result.status, 'completed');
  // Should have followed the 'if' path
  const visitedNodeIds = result.history.filter(h => h.status === 'started').map(h => h.nodeId);
  assert.ok(visitedNodeIds.includes('true_branch'), 'Should visit true_branch');
});

test('WorkflowEngine: conditional branching (false path)', async () => {
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'conditional-false',
    nodes: {
      check: { type: 'CONDITION', condition: 'state.x === 999', output_key: 'cond_result' },
      true_branch: { type: 'PASS' },
      false_branch: { type: 'PASS' },
    },
    edges: [
      { from: '__start__', to: 'check' },
      { from: 'check.if', to: 'true_branch' },
      { from: 'check.else', to: 'false_branch' },
      { from: 'true_branch', to: '__end__' },
      { from: 'false_branch', to: '__end__' },
    ],
  });
  const result = await engine.run({ x: 0 });
  assert.strictEqual(result.status, 'completed');
  const visitedNodeIds = result.history.filter(h => h.status === 'completed').map(h => h.nodeId);
  assert.ok(visitedNodeIds.includes('false_branch'), 'Should visit false_branch');
});

test('WorkflowEngine: state passed between nodes', async () => {
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'state-passing',
    nodes: {
      set_val: { type: 'LLM_CALL', prompt: 'set value', output_key: 'myval' },
    },
    edges: [
      { from: '__start__', to: 'set_val' },
      { from: 'set_val', to: '__end__' },
    ],
  });
  const result = await engine.run({});
  assert.strictEqual(result.state.myval, '[LLM output for: set value]');
});

test('WorkflowEngine: retry on failure with fallback', async () => {
  let failCount = 0;
  const engine = new WorkflowEngine();
  engine._fromObject({
    id: 'retry-test',
    nodes: {
      might_fail: {
        type: 'LLM_CALL',
        prompt: 'might fail',
        retry: { max_attempts: 3, delay: 0.1 },
      },
      fallback: { type: 'LLM_CALL', prompt: 'fallback run', output_key: 'fallback_done' },
    },
    edges: [
      { from: '__start__', to: 'might_fail' },
      { from: 'might_fail.fallback', to: 'fallback' },
      { from: 'fallback', to: '__end__' },
    ],
  });
  
  // Override LLM handler to fail twice
  let attempts = 0;
  engine.registerLLM('default', async (nodeDef) => {
    attempts++;
    if (attempts <= 2) throw new Error('Transient failure');
    return { value: 'success', summary: 'ok' };
  });
  
  const result = await engine.run({});
  assert.strictEqual(result.status, 'completed');
  assert.strictEqual(attempts, 3); // Should retry 3 times
});

console.log('\n\n═══ Demonstration: YAML Workflow ═══\n');

async function demoYamlLoad() {
  const engine = new WorkflowEngine();
  await engine.load(path.join(HARNESS_DIR, 'workflows/demo-research.yaml'));
  console.log(engine.visualize());
  
  // Run in mock mode
  const result = await engine.run({ query: 'AI agents' });
  console.log(`\nStatus: ${result.status}`);
  console.log(`Iterations: ${result.iterations}`);
  console.log(`Duration: ${result.duration_ms}ms`);
  console.log(`State keys: ${Object.keys(result.state).join(', ')}`);
  console.log(`History length: ${result.history.length}`);
}

// ---------------------------------------------------------------------------
// Run async tests
// ---------------------------------------------------------------------------

(async () => {
  console.log('\n═══ Async Tests ═══\n');
  
  await testAsync('WorkflowEngine: state-passing inline', async () => {
    const engine = new WorkflowEngine();
    engine._fromObject({
      id: 'inline',
      nodes: { n1: { type: 'LLM_CALL', prompt: 'hello', output_key: 'greeting' } },
      edges: [
        { from: '__start__', to: 'n1' },
        { from: 'n1', to: '__end__' },
      ],
    });
    const result = await engine.run({});
    assert.strictEqual(result.status, 'completed');
  });

  await testAsync('WorkflowEngine: test workflow YAML loads', async () => {
    const engine = new WorkflowEngine();
    await engine.load(path.join(HARNESS_DIR, 'workflows/demo-research.yaml'));
    assert.strictEqual(engine.getMetadata().id, 'demo-research');
    assert.strictEqual(engine.getNodeIds().length, 6);
    assert.strictEqual(engine.getEdges().length, 7);
  });

  await demoYamlLoad();

  // -------------------------------------------------------------------------
  // Summary
  // -------------------------------------------------------------------------
  console.log('\n\n═══════════════════════════════════════════');
  console.log(`  Passed: ${passed}  Failed: ${failed}  Total: ${passed + failed}`);
  console.log('═══════════════════════════════════════════\n');

  if (errors.length > 0) {
    console.log('FAILURES:');
    for (const e of errors) {
      console.log(`  - ${e.name}`);
      console.log(`    ${e.error}`);
    }
    process.exit(1);
  } else {
    console.log('All tests passed! ✓');
    process.exit(0);
  }
})().catch(err => {
  console.error('\nFatal:', err);
  process.exit(1);
});
