'use strict';

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { SessionReplayer } = require('../../core/session-replay');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

console.log('\n=== SessionReplayer Tests ===\n');

// Create a sample trajectory for testing
const testTrajectoryId = `test-session-${Date.now()}`;

test('SessionReplayer constructor with defaults', () => {
  const sr = new SessionReplayer();
  assert.ok(sr.trajectoriesDir.includes('.hermes/trajectories'));
  assert.strictEqual(sr.playbackState, 'stopped');
  assert.strictEqual(sr.currentStep, -1);
});

test('SessionReplayer createSampleTrajectory - creates sample file', () => {
  const filePath = SessionReplayer.createSampleTrajectory(testTrajectoryId);
  assert.strictEqual(fs.existsSync(filePath), true);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  assert.strictEqual(data.id, testTrajectoryId);
  assert.ok(data.messages);
  assert.strictEqual(data.messages.length, 6);
});

test('SessionReplayer load - loads trajectory by ID', () => {
  const sr = new SessionReplayer();
  const result = sr.load(testTrajectoryId);
  assert.strictEqual(result.loaded, true);
  assert.strictEqual(result.totalSteps, 6);
  assert.strictEqual(result.session.id, testTrajectoryId);
});

test('SessionReplayer load - loads trajectory by full path', () => {
  const sr = new SessionReplayer();
  const filePath = path.join(sr.trajectoriesDir, `${testTrajectoryId}.json`);
  const result = sr.load(filePath);
  assert.strictEqual(result.loaded, true);
});

test('SessionReplayer load - throws for non-existent session', () => {
  const sr = new SessionReplayer();
  assert.throws(() => sr.load('nonexistent-session-12345'), /not found/);
});

test('SessionReplayer step - advances to next step', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  const first = sr.step();
  assert.ok(first);
  assert.strictEqual(first.step.role, 'user');
  assert.strictEqual(first.progress.current, 1);
  assert.strictEqual(first.progress.total, 6);
  
  const second = sr.step();
  assert.strictEqual(second.progress.current, 2);
  assert.strictEqual(second.step.role, 'assistant');
});

test('SessionReplayer step - returns null at end', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  // Step through all 6
  for (let i = 0; i < 6; i++) {
    assert.ok(sr.step());
  }
  
  const beyond = sr.step();
  assert.strictEqual(beyond, null);
});

test('SessionReplayer stepBack - goes to previous step', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  sr.step(); // step 1
  sr.step(); // step 2
  
  const back = sr.stepBack();
  assert.ok(back);
  assert.strictEqual(back.progress.current, 1);
});

test('SessionReplayer stepBack - returns null at beginning', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  const back = sr.stepBack();
  assert.strictEqual(back, null);
});

test('SessionReplayer getCurrentState - returns state at current step', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  sr.step(); // step 1
  
  const state = sr.getCurrentState();
  assert.ok(state);
  assert.strictEqual(state.progress.current, 1);
  // 1/6 = 16.67%, rounded to 17
  assert.ok(state.progress.percentage === 17 || state.progress.percentage === 16);
  assert.ok(state.step);
  assert.ok(state.session);
});

test('SessionReplayer getCurrentState - returns null before first step', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  assert.strictEqual(sr.getCurrentState(), null);
});

test('SessionReplayer play - plays all remaining steps', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  const steps = sr.play();
  assert.strictEqual(steps.length, 6);
  assert.strictEqual(sr.playbackState, 'stopped');
});

test('SessionReplayer play - plays from middle', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  sr.step(); // step 1
  sr.step(); // step 2
  
  const steps = sr.play();
  assert.strictEqual(steps.length, 4); // remaining steps 3-6
});

test('SessionReplayer play - calls onStep callback', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  let callbackCount = 0;
  sr.play((step) => {
    callbackCount++;
  });
  assert.strictEqual(callbackCount, 6);
});

test('SessionReplayer getTimeline - returns ASCII visualization', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  sr.step();
  sr.step();
  
  const timeline = sr.getTimeline({ width: 40 });
  assert.ok(timeline.includes('Session:'));
  assert.ok(timeline.includes(testTrajectoryId));
  assert.ok(timeline.includes('Steps:'));
  assert.ok(timeline.includes('Legend:'));
  assert.ok(timeline.includes('U=user'));
});

test('SessionReplayer getTimeline - handles empty session', () => {
  const sr = new SessionReplayer();
  const timeline = sr.getTimeline();
  assert.ok(timeline.includes('No session loaded'));
});

test('SessionReplayer goToStep - jumps to specific step', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  const state = sr.goToStep(3);
  assert.ok(state);
  assert.strictEqual(state.progress.current, 3);
});

test('SessionReplayer goToStep - throws out of range', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  assert.throws(() => sr.goToStep(0), /out of range/);
  assert.throws(() => sr.goToStep(100), /out of range/);
});

test('SessionReplayer getAllSteps - returns all steps', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  
  const allSteps = sr.getAllSteps();
  assert.strictEqual(allSteps.length, 6);
});

test('SessionReplayer getStepCount - returns total steps', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  assert.strictEqual(sr.getStepCount(), 6);
});

test('SessionReplayer - step without load throws', () => {
  const sr = new SessionReplayer();
  assert.throws(() => sr.step(), /No session loaded/);
});

test('SessionReplayer - play without load throws', () => {
  const sr = new SessionReplayer();
  assert.throws(() => sr.play(), /No session loaded/);
});

test('SessionReplayer - loading updates state correctly', () => {
  const sr = new SessionReplayer();
  sr.load(testTrajectoryId);
  assert.strictEqual(sr.currentStep, -1);
  assert.strictEqual(sr.playbackState, 'stopped');
  assert.strictEqual(sr.steps.length, 6);
});

// Cleanup sample trajectory
try {
  const trajDir = path.join(os.homedir(), '.hermes', 'trajectories');
  const filePath = path.join(trajDir, `${testTrajectoryId}.json`);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
} catch {}

console.log(`\nSessionReplayer Tests: ${passed} passed, ${failed} failed\n`);

process.exit(failed > 0 ? 1 : 0);
