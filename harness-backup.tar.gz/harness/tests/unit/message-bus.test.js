#!/usr/bin/env node
/**
 * MessageBus Tests
 */

'use strict';

const assert = require('assert');
const { MessageBus, AgentBridge, Message, MessageType, MessagePriority } = require('../../core/message-bus');

let passed = 0;
let failed = 0;
const errors = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    process.stdout.write('✓');
  } catch (err) {
    failed++;
    errors.push({ name, error: err.message, stack: err.stack });
    process.stdout.write('✗');
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    process.stdout.write('✓');
  } catch (err) {
    failed++;
    errors.push({ name, error: err.message, stack: err.stack });
    process.stdout.write('✗');
  }
}

// ---------------------------------------------------------------------------
// Message Tests
// ---------------------------------------------------------------------------

console.log('\n═══ Message Tests ═══\n');

test('Message: create chat message', () => {
  const msg = Message.chat('hello');
  assert.strictEqual(msg.type, MessageType.CHAT);
  assert.strictEqual(msg.payload.text, 'hello');
});

test('Message: create data message', () => {
  const msg = Message.data('result', 42);
  assert.strictEqual(msg.type, MessageType.DATA);
  assert.strictEqual(msg.payload.key, 'result');
});

test('Message: create control message', () => {
  const msg = Message.control('pause');
  assert.strictEqual(msg.type, MessageType.CONTROL);
  assert.strictEqual(msg.payload.command, 'pause');
});

test('Message: create error message', () => {
  const msg = Message.error(new Error('test error'));
  assert.strictEqual(msg.type, MessageType.ERROR);
  assert.strictEqual(msg.payload.message, 'test error');
});

test('Message: sender and recipient', () => {
  const msg = Message.chat('hi', { sender: 'agent1', recipient: 'agent2' });
  assert.strictEqual(msg.sender, 'agent1');
  assert.strictEqual(msg.recipient, 'agent2');
});

test('Message: has unique IDs', () => {
  const m1 = Message.chat('a');
  const m2 = Message.chat('b');
  assert.notStrictEqual(m1.id, m2.id);
});

test('Message: TTL expiry', () => {
  const msg = Message.chat('old', { ttl: -1000 });
  assert.strictEqual(msg.isExpired(), true);
});

test('Message: priority levels', () => {
  const msg = Message.chat('critical', { priority: MessagePriority.CRITICAL });
  assert.strictEqual(msg.priority, MessagePriority.CRITICAL);
});

// ---------------------------------------------------------------------------
// MessageBus Tests
// ---------------------------------------------------------------------------

console.log('\n═══ MessageBus Tests ═══\n');

testAsync('MessageBus: publish and subscribe', async () => {
  const bus = new MessageBus();
  bus.createChannel('test');
  
  let received = null;
  bus.subscribe('agent1', 'test', (msg) => {
    received = msg;
  });
  
  await bus.publishToChannel('test', Message.chat('hello'));
  assert.ok(received);
  assert.strictEqual(received.payload.text, 'hello');
});

testAsync('MessageBus: no delivery to wrong channel', async () => {
  const bus = new MessageBus();
  bus.createChannel('ch1');
  bus.createChannel('ch2');
  
  let received = false;
  bus.subscribe('agent1', 'ch1', () => { received = true; });
  
  await bus.publishToChannel('ch2', Message.chat('hello'));
  assert.strictEqual(received, false);
});

testAsync('MessageBus: agent registration', async () => {
  const bus = new MessageBus();
  bus.registerAgent('agent1', { name: 'Research Agent', capabilities: ['web_search'] });
  
  const agent = bus.getAgent('agent1');
  assert.ok(agent);
  assert.strictEqual(agent.name, 'Research Agent');
  assert.deepStrictEqual(agent.capabilities, ['web_search']);
});

testAsync('MessageBus: auto-create channel on publish', async () => {
  const bus = new MessageBus();
  await bus.publishToChannel('auto-channel', Message.chat('hello'));
  assert.ok(bus.getChannel('auto-channel'));
});

testAsync('MessageBus: wildcard subscription', async () => {
  const bus = new MessageBus();
  bus.createChannel('agent.research');
  bus.createChannel('agent.coding');
  
  let count = 0;
  bus.subscribe('agent1', 'agent.*', () => { count++; });
  
  await bus.publishToChannel('agent.research', Message.chat('a'));
  await bus.publishToChannel('agent.coding', Message.chat('b'));
  assert.strictEqual(count, 2);
});

testAsync('MessageBus: channel history', async () => {
  const bus = new MessageBus();
  bus.createChannel('hist');
  
  await bus.publishToChannel('hist', Message.chat('msg1'));
  await bus.publishToChannel('hist', Message.chat('msg2'));
  
  const history = bus.getChannelHistory('hist', 2);
  assert.strictEqual(history.length, 2);
});

testAsync('MessageBus: one-shot subscription', async () => {
  const bus = new MessageBus();
  bus.createChannel('oneshot');
  
  let count = 0;
  bus.subscribe('agent1', 'oneshot', () => { count++; }, { oneShot: true });
  
  await bus.publishToChannel('oneshot', Message.chat('1'));
  await bus.publishToChannel('oneshot', Message.chat('2'));
  assert.strictEqual(count, 1);
});

testAsync('MessageBus: stats tracking', async () => {
  const bus = new MessageBus();
  bus.createChannel('stats');
  bus.subscribe('agent1', 'stats', () => {});
  
  await bus.publishToChannel('stats', Message.chat('1'));
  await bus.publishToChannel('stats', Message.chat('2'));
  
  const stats = bus.getStats();
  assert.strictEqual(stats.messagesSent, 2);
  assert.strictEqual(stats.messagesDelivered, 2);
});

testAsync('MessageBus: unregister agent cleans up subs', async () => {
  const bus = new MessageBus();
  bus.createChannel('cleanup');
  bus.subscribe('agent1', 'cleanup', () => {});
  bus.unregisterAgent('agent1');
  
  const subs = bus.getActiveSubscriptions();
  assert.strictEqual(subs.length, 0);
});

testAsync('MessageBus: list agents', async () => {
  const bus = new MessageBus();
  bus.registerAgent('a1');
  bus.registerAgent('a2', { name: 'Agent Two' });
  
  const agents = bus.listAgents();
  assert.strictEqual(agents.length, 2);
});

// ---------------------------------------------------------------------------
// AgentBridge Tests
// ---------------------------------------------------------------------------

console.log('\n═══ AgentBridge Tests ═══\n');

testAsync('AgentBridge: send and receive', async () => {
  const bus = new MessageBus();
  const bridge1 = new AgentBridge('alpha', bus, { name: 'Alpha' });
  const bridge2 = new AgentBridge('beta', bus, { name: 'Beta' });
  
  let received = null;
  bridge2.on('shared', (msg) => { received = msg; });
  
  await bridge1.send('shared', 'hello from alpha');
  assert.ok(received);
  assert.strictEqual(received.payload.text, 'hello from alpha');
});

testAsync('AgentBridge: direct messages', async () => {
  const bus = new MessageBus();
  const alpha = new AgentBridge('alpha', bus);
  const beta = new AgentBridge('beta', bus);
  
  let received = null;
  beta.onDirectMessage((msg) => { received = msg; });
  
  await alpha.sendTo('beta', 'secret message');
  assert.ok(received);
  assert.strictEqual(received.payload.text, 'secret message');
});

testAsync('AgentBridge: list other agents', async () => {
  const bus = new MessageBus();
  const alpha = new AgentBridge('alpha', bus);
  new AgentBridge('beta', bus);  // eslint-disable-line no-new
  
  const agents = alpha.listAgents();
  assert.strictEqual(agents.length, 1);
  assert.strictEqual(agents[0].id, 'beta');
});

testAsync('AgentBridge: disconnect cleanup', async () => {
  const bus = new MessageBus();
  const alpha = new AgentBridge('alpha', bus);
  alpha.disconnect();
  
  const agent = bus.getAgent('alpha');
  assert.strictEqual(agent, null);
});

// ---------------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------------

(async () => {
  // Run async tests
  console.log('\n\n═══ Async Tests (running) ═══\n');
  
  for (const [name, fn] of [
    ['publish subscribe', () => true],
  ]) {
    await testAsync(name, async () => {});
  }

  console.log('\n\n═══════════════════════════════════════════');
  console.log(`  Passed: ${passed}  Failed: ${failed}  Total: ${passed + failed}`);
  console.log('═══════════════════════════════════════════\n');

  if (errors.length > 0) {
    console.log('FAILURES:');
    for (const e of errors) {
      console.log(`  - ${e.name}`);
      console.log(`    ${e.error}`);
    }
    process.exit(1);
  } else {
    console.log('All tests passed! ✓');
    process.exit(0);
  }
})().catch(err => {
  console.error('\nFatal:', err);
  process.exit(1);
});
