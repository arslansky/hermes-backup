'use strict';

const path = require('path');
const assert = require('assert');
const fs = require('fs');

const {
  TestCase,
  BenchmarkDefinition,
  BenchmarkRunner,
  EvalResult,
  EvalReport,
  scorers
} = require('../../core/eval-framework.js');

const workDir = path.resolve(__dirname, '../../');

// ---------------------------------------------------------------------------
// Mock Agent
// ---------------------------------------------------------------------------
function createMockAgent(responses) {
  const responsesMap = new Map(Object.entries(responses || {}));
  return async ({ prompt, testCase }) => {
    if (testCase && testCase.id && responsesMap.has(testCase.id)) {
      return responsesMap.get(testCase.id);
    }
    if (responsesMap.has(prompt)) {
      return responsesMap.get(prompt);
    }
    return testCase ? testCase.expected : '';
  };
}

// ---------------------------------------------------------------------------
// Test Runner
// ---------------------------------------------------------------------------

(async () => {
  let passed = 0;
  let failed = 0;
  const failures = [];

  function test(name, fn) {
    try {
      fn();
      passed++;
      console.log(`  ✅ ${name}`);
    } catch (err) {
      failed++;
      failures.push({ name, error: err.message, stack: err.stack });
      console.log(`  ❌ ${name}: ${err.message}`);
    }
  }

  async function testAsync(name, fn) {
    try {
      await fn();
      passed++;
      console.log(`  ✅ ${name}`);
    } catch (err) {
      failed++;
      failures.push({ name, error: err.message, stack: err.stack });
      console.log(`  ❌ ${name}: ${err.message}`);
    }
  }

  // ===== TestCase Class =====
  console.log('\n📋 TestCase Class');

  test('creates TestCase with defaults', () => {
    const tc = new TestCase();
    assert.ok(tc.id, 'should auto-generate id');
    assert.strictEqual(tc.name, '');
    assert.strictEqual(tc.prompt, '');
    assert.strictEqual(tc.expected, '');
    assert.strictEqual(tc.evaluator_type, 'exact_match');
    assert.strictEqual(tc.rubric, '');
  });

  test('creates TestCase with provided values', () => {
    const tc = new TestCase({
      id: 'tc-1', name: 'Test One', prompt: 'What is 2+2?',
      expected: '4', evaluator_type: 'contains', rubric: 'Must mention the number 4'
    });
    assert.strictEqual(tc.id, 'tc-1');
    assert.strictEqual(tc.name, 'Test One');
    assert.strictEqual(tc.prompt, 'What is 2+2?');
    assert.strictEqual(tc.expected, '4');
    assert.strictEqual(tc.evaluator_type, 'contains');
    assert.strictEqual(tc.rubric, 'Must mention the number 4');
  });

  test('TestCase toJSON returns correct fields', () => {
    const tc = new TestCase({ id: 'tc-2', name: 'T2', prompt: 'P', expected: 'E' });
    const json = tc.toJSON();
    assert.strictEqual(json.id, 'tc-2');
    assert.strictEqual(json.name, 'T2');
    assert.strictEqual(json.prompt, 'P');
    assert.strictEqual(json.expected, 'E');
  });

  // ===== BenchmarkDefinition =====
  console.log('\n📋 BenchmarkDefinition Class');

  test('creates BenchmarkDefinition with defaults', () => {
    const bm = new BenchmarkDefinition();
    assert.ok(bm.id, 'should auto-generate id');
    assert.strictEqual(bm.testCount, 0);
    assert.deepStrictEqual(bm.test_cases, []);
  });

  test('creates BenchmarkDefinition with test cases from plain objects', () => {
    const bm = new BenchmarkDefinition({
      id: 'bm-1', name: 'Math Tests',
      test_cases: [
        { id: 't1', prompt: '2+2?', expected: '4', evaluator_type: 'exact_match' },
        { id: 't2', prompt: 'What color is sky?', expected: 'blue', evaluator_type: 'contains' }
      ]
    });
    assert.strictEqual(bm.testCount, 2);
    assert.ok(bm.test_cases[0] instanceof TestCase);
    assert.strictEqual(bm.test_cases[0].id, 't1');
  });

  test('BenchmarkDefinition wraps existing TestCase instances', () => {
    const tc = new TestCase({ id: 'tc-x', prompt: 'Hello', expected: 'World' });
    const bm = new BenchmarkDefinition({ test_cases: [tc] });
    assert.strictEqual(bm.test_cases[0], tc);
  });

  test('BenchmarkDefinition toJSON includes testCount', () => {
    const bm = new BenchmarkDefinition({ name: 'Test', test_cases: [{}] });
    const json = bm.toJSON();
    assert.strictEqual(json.testCount, 1);
    assert.strictEqual(json.test_cases.length, 1);
  });

  // ===== Scorers =====
  console.log('\n📋 Scorers');

  test('exact_match passes on exact match', () => {
    const r = scorers.exact_match('hello world', 'hello world');
    assert.strictEqual(r.passed, true);
    assert.strictEqual(r.score, 1);
  });

  test('exact_match fails on mismatch', () => {
    const r = scorers.exact_match('hello', 'world');
    assert.strictEqual(r.passed, false);
    assert.strictEqual(r.score, 0);
  });

  test('exact_match trims whitespace by default', () => {
    const r = scorers.exact_match('  hello  ', 'hello');
    assert.strictEqual(r.passed, true);
  });

  test('exact_match case sensitivity options', () => {
    const r1 = scorers.exact_match('Hello', 'hello', { caseSensitive: false });
    assert.strictEqual(r1.passed, true);
    const r2 = scorers.exact_match('Hello', 'hello', { caseSensitive: true });
    assert.strictEqual(r2.passed, false);
  });

  test('contains finds substring', () => {
    const r = scorers.contains('The sky is blue today', 'blue');
    assert.strictEqual(r.passed, true);
    assert.strictEqual(r.score, 1);
  });

  test('contains fails when not found', () => {
    const r = scorers.contains('The sky is blue today', 'red');
    assert.strictEqual(r.passed, false);
  });

  test('contains case insensitive option', () => {
    const r = scorers.contains('HELLO WORLD', 'hello', { caseSensitive: false });
    assert.strictEqual(r.passed, true);
  });

  test('regex matches pattern', () => {
    const r = scorers.regex('hello123', '[a-z]+\\d+');
    assert.strictEqual(r.passed, true);
  });

  test('regex fails on non-match', () => {
    const r = scorers.regex('hello', '^\\d+$');
    assert.strictEqual(r.passed, false);
  });

  test('regex with flags', () => {
    const r = scorers.regex('Hello World', 'hello', { flags: 'i' });
    assert.strictEqual(r.passed, true);
  });

  await testAsync('llm_judge with custom evaluator function', async () => {
    const evaluatorFn = async ({ actual, expected }) => {
      return { passed: actual === expected, score: actual === expected ? 1 : 0 };
    };
    const r = await scorers.llm_judge('correct', 'correct', { evaluatorFn });
    assert.strictEqual(r.passed, true);
    assert.strictEqual(r.score, 1);
  });

  await testAsync('llm_judge fallback uses contains with rubric', async () => {
    const r = await scorers.llm_judge('The answer is 42', '', { rubric: '42' });
    assert.strictEqual(r.passed, true);
  });

  await testAsync('code_execution with custom execute function', async () => {
    const executeFn = async ({ code }) => ({ output: code.trim() });
    const r = await scorers.code_execution('result = 42', 'result = 42', { executeFn });
    assert.strictEqual(r.passed, true);
  });

  await testAsync('code_execution fallback uses exact_match', async () => {
    const r = await scorers.code_execution('42', '42');
    assert.strictEqual(r.passed, true);
  });

  // ===== EvalResult =====
  console.log('\n📋 EvalResult');

  test('creates EvalResult with pass/fail', () => {
    const tc = new TestCase({ id: 't1', name: 'Test1' });
    const r = new EvalResult({ testCase: tc, actual: 'output', passed: true, score: 1 });
    assert.strictEqual(r.testCaseId, 't1');
    assert.strictEqual(r.testCaseName, 'Test1');
    assert.strictEqual(r.passed, true);
    assert.strictEqual(r.score, 1);
  });

  test('EvalResult stores error', () => {
    const r = new EvalResult({ testCase: {}, passed: false, score: 0, error: 'Something broke' });
    assert.strictEqual(r.error, 'Something broke');
  });

  // ===== EvalReport =====
  console.log('\n📋 EvalReport');

  test('EvalReport computes summary correctly', () => {
    const bm = new BenchmarkDefinition({ id: 'bm-r1', name: 'Report Test' });
    const results = [
      new EvalResult({ testCase: { id: 'a' }, passed: true, score: 1 }),
      new EvalResult({ testCase: { id: 'b' }, passed: true, score: 1 }),
      new EvalResult({ testCase: { id: 'c' }, passed: false, score: 0 }),
      new EvalResult({ testCase: { id: 'd' }, passed: true, score: 1 })
    ];
    const report = new EvalReport({ benchmark: bm, results });
    assert.strictEqual(report.total, 4);
    assert.strictEqual(report.passed, 3);
    assert.strictEqual(report.failed, 1);
    assert.strictEqual(report.passRate, 75);
    assert.strictEqual(report.totalScore, 3);
  });

  test('EvalReport generates markdown', () => {
    const bm = new BenchmarkDefinition({ id: 'md-bm', name: 'MD Test' });
    const results = [
      new EvalResult({ testCase: { id: 'x', name: 'Case X' }, passed: true, score: 1, actual: 'ok' }),
      new EvalResult({ testCase: { id: 'y', name: 'Case Y' }, passed: false, score: 0, error: 'fail' })
    ];
    const report = new EvalReport({ benchmark: bm, results });
    const md = report.toMarkdown();
    assert.ok(md.includes('MD Test'));
    assert.ok(md.includes('✅ PASS'));
    assert.ok(md.includes('❌ FAIL'));
    assert.ok(md.includes('50.00%'));
  });

  // ===== BenchmarkRunner =====
  console.log('\n📋 BenchmarkRunner');

  await testAsync('BenchmarkRunner.run() returns scores and pass_rate', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'run-test', name: 'Run Test',
      test_cases: [
        { id: 'rt1', prompt: 'Say hello', expected: 'hello', evaluator_type: 'exact_match' },
        { id: 'rt2', prompt: 'Say world', expected: 'world', evaluator_type: 'exact_match' }
      ]
    }));
    const agent = createMockAgent({ rt1: 'hello', rt2: 'world' });
    const result = await runner.run(agent);
    assert.strictEqual(result.pass_rate, 100);
    assert.ok(result.scores.rt1.passed);
    assert.ok(result.scores.rt2.passed);
    assert.strictEqual(result.reports.length, 1);
  });

  await testAsync('BenchmarkRunner.run() handles failures', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'fail-test', name: 'Fail Test',
      test_cases: [
        { id: 'ft1', prompt: 'Say hello', expected: 'hello', evaluator_type: 'exact_match' },
        { id: 'ft2', prompt: 'Say world', expected: 'nope', evaluator_type: 'exact_match' }
      ]
    }));
    const agent = createMockAgent({ ft1: 'hello', ft2: 'wrong answer' });
    const result = await runner.run(agent);
    assert.strictEqual(result.pass_rate, 50);
    assert.ok(result.scores.ft1.passed);
    assert.strictEqual(result.scores.ft2.passed, false);
  });

  await testAsync('BenchmarkRunner.run() handles agent errors gracefully', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      test_cases: [{ id: 'err1', prompt: 'Do something', expected: 'ok', evaluator_type: 'exact_match' }]
    }));
    const brokenAgent = async () => { throw new Error('Agent crashed'); };
    const result = await runner.run(brokenAgent);
    assert.strictEqual(result.pass_rate, 0);
    assert.ok(result.scores.err1.error);
    assert.strictEqual(result.scores.err1.passed, false);
  });

  await testAsync('BenchmarkRunner.runSingle() works', async () => {
    const runner = new BenchmarkRunner();
    const tc = new TestCase({ id: 'single', prompt: 'Hi', expected: 'Hello', evaluator_type: 'exact_match' });
    const result = await runner.runSingle(tc, async () => 'Hello');
    assert.strictEqual(result.passed, true);
    assert.strictEqual(result.score, 1);
  });

  await testAsync('BenchmarkRunner.runSingle() returns error on agent failure', async () => {
    const runner = new BenchmarkRunner();
    const tc = new TestCase({ id: 'single-fail', prompt: 'Hi', expected: 'Hello' });
    const result = await runner.runSingle(tc, async () => { throw new Error('fail'); });
    assert.strictEqual(result.passed, false);
    assert.ok(result.error);
  });

  test('BenchmarkRunner loads from JSON file', () => {
    const fixturePath = path.join(workDir, 'tests', 'fixtures');
    fs.mkdirSync(fixturePath, { recursive: true });
    const jsonPath = path.join(fixturePath, 'test-benchmark.json');
    fs.writeFileSync(jsonPath, JSON.stringify({
      id: 'json-bm', name: 'JSON Benchmark', description: 'From JSON file',
      test_cases: [
        { id: 'j1', prompt: 'What is 2+2?', expected: '4', evaluator_type: 'exact_match' },
        { id: 'j2', prompt: 'Say hi', expected: 'hi', evaluator_type: 'contains' }
      ]
    }));
    const runner = new BenchmarkRunner({ workDir });
    const bm = runner.loadBenchmark('tests/fixtures/test-benchmark.json');
    assert.strictEqual(bm.id, 'json-bm');
    assert.strictEqual(bm.testCount, 2);
    fs.unlinkSync(jsonPath);
    fs.rmdirSync(fixturePath);
  });

  test('BenchmarkRunner loads from YAML-like file', () => {
    const fixturePath = path.join(workDir, 'tests', 'fixtures');
    fs.mkdirSync(fixturePath, { recursive: true });
    const yamlPath = path.join(fixturePath, 'test-benchmark.yaml');
    fs.writeFileSync(yamlPath, `id: yaml-bm\nname: YAML Benchmark\ndescription: From YAML file\ntest_cases:\n  - id: y1\n    prompt: "What is 2+2?"\n    expected: "4"\n    evaluator_type: exact_match\n  - id: y2\n    prompt: "Say hi"\n    expected: "hi"\n    evaluator_type: contains\n`);
    const runner = new BenchmarkRunner({ workDir });
    const bm = runner.loadBenchmark('tests/fixtures/test-benchmark.yaml');
    assert.strictEqual(bm.id, 'yaml-bm');
    assert.strictEqual(bm.testCount, 2);
    fs.unlinkSync(yamlPath);
    fs.rmdirSync(fixturePath);
  });

  await testAsync('BenchmarkRunner supports custom scorers', async () => {
    const runner = new BenchmarkRunner();
    runner.addScorer('custom_check', (actual, expected) => {
      const passed = actual.length === expected.length;
      return { passed, score: passed ? 1 : 0, details: `length: ${actual.length}` };
    });
    runner.addBenchmark(new BenchmarkDefinition({
      test_cases: [{ id: 'c1', prompt: 'Test', expected: 'hello', evaluator_type: 'custom_check' }]
    }));
    const result = await runner.run(async () => 'world');
    assert.strictEqual(result.scores.c1.passed, true);
  });

  await testAsync('BenchmarkRunner generates JSON report', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'json-rpt', name: 'JSON Report',
      test_cases: [{ id: 'jr1', prompt: 'A', expected: 'a', evaluator_type: 'exact_match' }]
    }));
    await runner.run(async () => 'a');
    const json = runner.generateJSONReport();
    assert.ok(json.generatedAt);
    assert.strictEqual(json.reports.length, 1);
    assert.strictEqual(json.reports[0].summary.passed, 1);
  });

  await testAsync('BenchmarkRunner generates Markdown report', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'md-rpt', name: 'MD Report',
      test_cases: [{ id: 'mr1', prompt: 'A', expected: 'a', evaluator_type: 'exact_match' }]
    }));
    await runner.run(async () => 'a');
    const md = runner.generateMarkdownReport();
    assert.ok(md.includes('MD Report'));
    assert.ok(md.includes('✅ PASS'));
  });

  await testAsync('BenchmarkRunner runs specific benchmark by ID', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'bm-a', name: 'Benchmark A',
      test_cases: [{ id: 'a1', prompt: 'A', expected: 'a' }]
    }));
    runner.addBenchmark(new BenchmarkDefinition({
      id: 'bm-b', name: 'Benchmark B',
      test_cases: [{ id: 'b1', prompt: 'B', expected: 'b' }]
    }));
    const result = await runner.run(async (tc) => tc.testCase.expected, { benchmarkIds: ['bm-a'] });
    assert.strictEqual(result.reports.length, 1);
    assert.strictEqual(result.reports[0].benchmarkId, 'bm-a');
  });

  await testAsync('BenchmarkRunner throws if no agent provided', async () => {
    const runner = new BenchmarkRunner();
    runner.addBenchmark(new BenchmarkDefinition({ test_cases: [{}] }));
    try {
      await runner.run();
      assert.fail('Should have thrown');
    } catch (err) {
      assert.ok(err.message.includes('Agent function'));
    }
  });

  // ===== Full Integration =====
  console.log('\n📋 Integration Tests');

  await testAsync('Full integration: mixed scoring types', async () => {
    const runner = new BenchmarkRunner();
    const bm = new BenchmarkDefinition({
      id: 'integration', name: 'Integration Test',
      test_cases: [
        { id: 'i1', prompt: 'Say exactly hello', expected: 'hello', evaluator_type: 'exact_match' },
        { id: 'i2', prompt: 'Say something with hello', expected: 'hello', evaluator_type: 'contains' },
        { id: 'i3', prompt: 'Output a number', expected: '\\d+', evaluator_type: 'regex' },
        { id: 'i4', prompt: 'LLM test', expected: 'correct', evaluator_type: 'llm_judge' }
      ]
    });
    runner.addBenchmark(bm);

    const responses = { i1: 'hello', i2: 'say hello world', i3: '42', i4: 'correct' };
    const agent = async ({ testCase }) => responses[testCase.id] || '';
    const result = await runner.run(agent);
    assert.strictEqual(result.pass_rate, 100, 'All tests should pass');
    for (const [id, score] of Object.entries(result.scores)) {
      assert.strictEqual(score.passed, true, `${id} should pass`);
    }
  });

  // ===== Final Summary =====
  console.log('\n');
  console.log('='.repeat(50));
  console.log(`Results: ${passed} passed, ${failed} failed, ${passed + failed} total`);
  if (failures.length > 0) {
    console.log('\nFailures:');
    failures.forEach(f => {
      console.log(`  - ${f.name}: ${f.error}`);
    });
  }
  console.log('='.repeat(50));

  process.exit(failed > 0 ? 1 : 0);
})();
