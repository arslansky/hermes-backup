'use strict';

const assert = require('assert');
const { CostManager, TokenBucket } = require('../../core/cost-manager');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

console.log('\n=== CostManager Tests ===\n');

// TokenBucket tests
test('TokenBucket constructor with defaults', () => {
  const tb = new TokenBucket();
  const status = tb.getStatus();
  assert.strictEqual(status.capacity, status.fillRate);
  assert.ok(status.current > 0);
});

test('TokenBucket constructor with custom limits', () => {
  const tb = new TokenBucket({ tokensPerSecond: 100, burstCapacity: 500 });
  assert.strictEqual(tb.tokensPerSecond, 100);
  assert.strictEqual(tb.burstCapacity, 500);
  assert.strictEqual(tb.tokens, 500);
});

test('TokenBucket consume - reduces tokens', () => {
  const tb = new TokenBucket({ tokensPerSecond: 1000, burstCapacity: 100, initialTokens: 100 });
  assert.strictEqual(tb.consume(10), true);
  assert.strictEqual(tb.tokens, 90);
});

test('TokenBucket consume - fails when insufficient tokens', () => {
  const tb = new TokenBucket({ tokensPerSecond: 1, burstCapacity: 5, initialTokens: 3 });
  assert.strictEqual(tb.consume(10), false);
});

test('TokenBucket consume - returns true when tokens available', () => {
  const tb = new TokenBucket({ tokensPerSecond: 100, burstCapacity: 50, initialTokens: 50 });
  assert.strictEqual(tb.consume(25), true);
  assert.strictEqual(tb.tokens, 25);
});

test('TokenBucket refill - adds tokens over time', () => {
  const tb = new TokenBucket({ tokensPerSecond: 10, burstCapacity: 100, initialTokens: 0 });
  tb.tokens = 0;
  tb.lastRefill = Date.now() - 2000; // 2 seconds ago
  tb.refill();
  assert.ok(tb.tokens >= 20); // 2 * 10 = 20 tokens
});

test('TokenBucket refill - respects burst cap', () => {
  const tb = new TokenBucket({ tokensPerSecond: 100, burstCapacity: 50, initialTokens: 0 });
  tb.lastRefill = Date.now() - 10000; // 10 seconds ago, would add 1000 tokens
  tb.refill();
  assert.strictEqual(tb.tokens, 50); // capped at burstCapacity
});

test('TokenBucket getWaitTime - returns 0 when enough tokens', () => {
  const tb = new TokenBucket({ tokensPerSecond: 10, burstCapacity: 100, initialTokens: 50 });
  assert.strictEqual(tb.getWaitTime(10), 0);
});

test('TokenBucket getWaitTime - returns positive wait time', () => {
  const tb = new TokenBucket({ tokensPerSecond: 10, burstCapacity: 100, initialTokens: 5 });
  const waitTime = tb.getWaitTime(20); // Need 15 more tokens
  assert.ok(waitTime > 0);
  assert.ok(waitTime <= 60000); // Should be within maxWaitTime
});

test('TokenBucket getStatus - returns full status', () => {
  const tb = new TokenBucket({ tokensPerSecond: 50, burstCapacity: 200, initialTokens: 100 });
  const status = tb.getStatus();
  assert.strictEqual(status.current, 100);
  assert.strictEqual(status.capacity, 200);
  assert.strictEqual(status.fillRate, 50);
  assert.strictEqual(status.available, 100);
});

// CostManager tests
test('CostManager constructor with defaults', () => {
  const cm = new CostManager();
  assert.strictEqual(cm.defaultLimits.tokensPerSecond, 50);
  assert.strictEqual(cm.getTotalCost(), 0);
});

test('CostManager constructor with custom limits', () => {
  const cm = new CostManager({ tokensPerSecond: 100, burstCapacity: 500, maxCostPerSession: 200 });
  assert.strictEqual(cm.defaultLimits.tokensPerSecond, 100);
  assert.strictEqual(cm.defaultLimits.burstCapacity, 500);
  assert.strictEqual(cm.defaultLimits.maxCostPerSession, 200);
});

test('CostManager trackUsage - records token usage', () => {
  const cm = new CostManager({ tokensPerSecond: 1000, burstCapacity: 10000 });
  const result = cm.trackUsage('gpt-4', 100, 20);
  assert.strictEqual(result.success, true);
  assert.strictEqual(result.inputTokens, 100);
  assert.strictEqual(result.outputTokens, 20);
  assert.ok(result.cost > 0);
});

test('CostManager trackUsage - creates model entry', () => {
  const cm = new CostManager({ tokensPerSecond: 1000, burstCapacity: 10000 });
  cm.trackUsage('claude-3', 50, 10);
  const cost = cm.getCost('claude-3');
  assert.ok(cost);
  assert.strictEqual(cost.inputTokens, 50);
  assert.strictEqual(cost.outputTokens, 10);
  assert.strictEqual(cost.calls, 1);
});

test('CostManager getCost - returns null for unknown model', () => {
  const cm = new CostManager();
  assert.strictEqual(cm.getCost('unknown-model'), null);
});

test('CostManager getTotalCost - aggregates across models', () => {
  const cm = new CostManager({ tokensPerSecond: 10000, burstCapacity: 100000 });
  cm.trackUsage('model-a', 100, 20, { costPerToken: 0.001 });
  cm.trackUsage('model-b', 50, 10, { costPerToken: 0.002 });
  
  const total = cm.getTotalCost();
  // model-a: 120 * 0.001 = 0.12
  // model-b: 60 * 0.002 = 0.12
  // total: 0.24
  assert.ok(total > 0);
});

test('CostManager getUsageReport - returns comprehensive report', () => {
  const cm = new CostManager({ tokensPerSecond: 10000, burstCapacity: 100000 });
  cm.trackUsage('model-x', 200, 50, { costPerToken: 0.001 });
  
  const report = cm.getUsageReport();
  assert.strictEqual(report.totalCalls, 1);
  assert.strictEqual(report.totalInputTokens, 200);
  assert.strictEqual(report.totalOutputTokens, 50);
  assert.ok(report.withinBudget);
  assert.ok(report.models.length >= 1);
});

test('CostManager getUsageReport - multiple calls to same model', () => {
  const cm = new CostManager({ tokensPerSecond: 10000, burstCapacity: 100000 });
  cm.trackUsage('gpt-4', 100, 20);
  cm.trackUsage('gpt-4', 200, 40);
  
  const cost = cm.getCost('gpt-4');
  assert.strictEqual(cost.calls, 2);
  assert.strictEqual(cost.inputTokens, 300);
  assert.strictEqual(cost.outputTokens, 60);
});

test('CostManager setModelLimits - creates bucket for new model', () => {
  const cm = new CostManager();
  cm.setModelLimits('custom-model', { tokensPerSecond: 5, burstCapacity: 20 });
  const limit = cm.getModelRateLimit('custom-model');
  assert.ok(limit);
  assert.strictEqual(limit.fillRate, 5);
  assert.strictEqual(limit.capacity, 20);
});

test('CostManager setModelLimits - updates existing bucket', () => {
  const cm = new CostManager({ tokensPerSecond: 10, burstCapacity: 100 });
  cm.trackUsage('gpt-4', 10, 5);
  cm.setModelLimits('gpt-4', { tokensPerSecond: 50 });
  const limit = cm.getModelRateLimit('gpt-4');
  assert.strictEqual(limit.fillRate, 50);
});

test('CostManager getModelRateLimit - returns null for unknown', () => {
  const cm = new CostManager();
  assert.strictEqual(cm.getModelRateLimit('no-such-model'), null);
});

test('CostManager trackUsage - respects rate limits', () => {
  const cm = new CostManager({ tokensPerSecond: 1, burstCapacity: 1 });
  const first = cm.trackUsage('slow-model', 1, 0);
  assert.strictEqual(first.success, true);
  
  const second = cm.trackUsage('slow-model', 1, 0);
  assert.strictEqual(second.success, false);
  assert.ok(second.waitTime > 0);
});

test('CostManager reset - clears all data', () => {
  const cm = new CostManager({ tokensPerSecond: 10000, burstCapacity: 100000 });
  cm.trackUsage('gpt-4', 100, 20);
  cm.trackUsage('claude', 50, 10);
  assert.strictEqual(cm.getTotalCost() > 0, true);
  cm.reset();
  assert.strictEqual(cm.getTotalCost(), 0);
  assert.strictEqual(cm.getUsageReport().models.length, 0);
});

test('CostManager - custom cost per token', () => {
  const cm = new CostManager({ tokensPerSecond: 10000, burstCapacity: 100000 });
  cm.trackUsage('custom-cost', 1000, 500, { costPerToken: 0.0001 });
  const cost = cm.getCost('custom-cost');
  // 1500 * 0.0001 = 0.15
  assert.ok(cost.cost > 0);
});

console.log(`\nCostManager Tests: ${passed} passed, ${failed} failed\n`);

process.exit(failed > 0 ? 1 : 0);
