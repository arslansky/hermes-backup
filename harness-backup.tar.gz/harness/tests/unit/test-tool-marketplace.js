'use strict';

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { ToolMarketplace } = require('../../core/tool-marketplace');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

const testToolsDir = path.join(os.tmpdir(), `hermes-tools-test-${Date.now()}`);

// Each test gets its own temp dir to avoid cross-contamination
let testCounter = 0;

console.log('\n=== ToolMarketplace Tests ===\n');

// Setup - create test tools directory
try { fs.mkdirSync(testToolsDir, { recursive: true }); } catch {}

function createMarketplace() {
  testCounter++;
  const dir = path.join(testToolsDir, `instance-${testCounter}`);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return new ToolMarketplace({ toolsDir: dir });
}

test('ToolMarketplace constructor - loads default tools', () => {
  const tm = createMarketplace();
  const stats = tm.getStats();
  assert.strictEqual(stats.totalTools, 8);
});

test('ToolMarketplace list - returns all tools', () => {
  const tm = createMarketplace();
  const tools = tm.list();
  assert.strictEqual(tools.length, 8);
});

test('ToolMarketplace list - filters by category', () => {
  const tm = createMarketplace();
  const dataTools = tm.list({ category: 'data' });
  assert.ok(dataTools.length >= 2);
  assert.ok(dataTools.every(t => t.category === 'data'));
});

test('ToolMarketplace list - filters installed only', () => {
  const tm = createMarketplace();
  tm.install('web_search');
  const installed = tm.list({ installed: true });
  assert.strictEqual(installed.length, 1);
  assert.strictEqual(installed[0].name, 'web_search');
});

test('ToolMarketplace search - finds by name', () => {
  const tm = createMarketplace();
  const results = tm.search('web');
  assert.ok(results.some(t => t.name === 'web_search'));
});

test('ToolMarketplace search - finds by description', () => {
  const tm = createMarketplace();
  const results = tm.search('automate browser');
  assert.ok(results.some(t => t.name === 'browser_automation'));
});

test('ToolMarketplace search - finds by category', () => {
  const tm = createMarketplace();
  const results = tm.search('vision');
  assert.ok(results.some(t => t.name === 'image_analyzer'));
});

test('ToolMarketplace search - empty query returns all', () => {
  const tm = createMarketplace();
  const results = tm.search('');
  assert.strictEqual(results.length, 8);
});

test('ToolMarketplace search - no matches returns empty', () => {
  const tm = createMarketplace();
  const results = tm.search('xyznonexistenttool');
  assert.strictEqual(results.length, 0);
});

test('ToolMarketplace getInfo - returns tool details', () => {
  const tm = createMarketplace();
  const info = tm.getInfo('web_search');
  assert.ok(info);
  assert.strictEqual(info.name, 'web_search');
  assert.strictEqual(info.author, 'Hermes');
  assert.strictEqual(info.category, 'data');
  assert.ok(Array.isArray(info.params));
  assert.ok(info.params.length > 0);
});

test('ToolMarketplace getInfo - returns null for unknown', () => {
  const tm = createMarketplace();
  assert.strictEqual(tm.getInfo('nonexistent'), null);
});

test('ToolMarketplace install - installs a tool', () => {
  const tm = createMarketplace();
  const result = tm.install('web_search');
  assert.strictEqual(result.success, true);
  assert.strictEqual(result.tool.installed, true);
  assert.ok(result.tool.stubPath || result.stubPath);
});

test('ToolMarketplace install - creates stub file', () => {
  const tm = createMarketplace();
  const result = tm.install('code_executor');
  const stubPath = result.tool.stubPath || path.join(tm.toolsDir, 'code_executor.js');
  assert.strictEqual(fs.existsSync(stubPath), true);
  const content = fs.readFileSync(stubPath, 'utf-8');
  assert.ok(content.includes('code_executor'));
  assert.ok(content.includes('v1.0.0'));
});

test('ToolMarketplace install - no-op for already installed', () => {
  const tm = createMarketplace();
  tm.install('file_reader');
  const result = tm.install('file_reader');
  assert.strictEqual(result.success, true);
  assert.ok(result.message.includes('already installed'));
});

test('ToolMarketplace install - throws for unknown tool', () => {
  const tm = createMarketplace();
  assert.throws(() => tm.install('not_a_real_tool'), /not found/);
});

test('ToolMarketplace uninstall - removes tool', () => {
  const tm = createMarketplace();
  tm.install('browser_automation');
  assert.strictEqual(tm.isInstalled('browser_automation'), true);
  
  const result = tm.uninstall('browser_automation');
  assert.strictEqual(result.success, true);
  assert.strictEqual(tm.isInstalled('browser_automation'), false);
});

test('ToolMarketplace uninstall - removes stub file', () => {
  const tm = createMarketplace();
  const result = tm.install('image_analyzer');
  const stubPath = result.tool.stubPath || path.join(tm.toolsDir, 'image_analyzer.js');
  assert.strictEqual(fs.existsSync(stubPath), true);
  
  tm.uninstall('image_analyzer');
  assert.strictEqual(fs.existsSync(stubPath), false);
});

test('ToolMarketplace uninstall - no-op for not installed', () => {
  const tm = createMarketplace();
  const result = tm.uninstall('api_client');
  assert.strictEqual(result.success, true);
  assert.ok(result.message.includes('not installed'));
});

test('ToolMarketplace uninstall - throws for unknown tool', () => {
  const tm = createMarketplace();
  assert.throws(() => tm.uninstall('nonexistent_tool'), /not found/);
});

test('ToolMarketplace isInstalled - checks install state', () => {
  const tm = createMarketplace();
  assert.strictEqual(tm.isInstalled('database_query'), false);
  tm.install('database_query');
  assert.strictEqual(tm.isInstalled('database_query'), true);
});

test('ToolMarketplace getInstalled - returns only installed', () => {
  const tm = createMarketplace();
  tm.install('web_search');
  tm.install('api_client');
  const installed = tm.getInstalled();
  assert.strictEqual(installed.length, 2);
});

test('ToolMarketplace getStats - returns marketplace stats', () => {
  const tm = createMarketplace();
  tm.install('web_search');
  const stats = tm.getStats();
  assert.strictEqual(stats.totalTools, 8);
  assert.strictEqual(stats.installed, 1);
  assert.ok(Array.isArray(stats.categories));
  assert.ok(stats.categories.length > 0);
});

test('ToolMarketplace - all tools have required fields', () => {
  const tm = createMarketplace();
  const tools = tm.list();
  for (const tool of tools) {
    assert.ok(tool.name, 'Tool missing name');
    assert.ok(tool.description, `Tool ${tool.name} missing description`);
    assert.ok(tool.version, `Tool ${tool.name} missing version`);
    assert.ok(tool.author, `Tool ${tool.name} missing author`);
    assert.ok(tool.category, `Tool ${tool.name} missing category`);
    assert.ok(Array.isArray(tool.params), `Tool ${tool.name} missing params array`);
    assert.ok(tool.install_cmd, `Tool ${tool.name} missing install_cmd`);
  }
});

// Cleanup all test directories
try {
  function rmDirRecursive(dir) {
    if (fs.existsSync(dir)) {
      for (const f of fs.readdirSync(dir)) {
        const p = path.join(dir, f);
        if (fs.statSync(p).isDirectory()) rmDirRecursive(p);
        else fs.unlinkSync(p);
      }
      fs.rmdirSync(dir);
    }
  }
  rmDirRecursive(testToolsDir);
} catch {}

console.log(`\nToolMarketplace Tests: ${passed} passed, ${failed} failed\n`);

process.exit(failed > 0 ? 1 : 0);
