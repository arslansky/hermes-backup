'use strict';

const assert = require('assert');
const { HumanLoop, HANDOFF_TYPES } = require('../../core/human-loop');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  PASS: ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL: ${name} - ${err.message}`);
  }
}

console.log('\n=== HumanLoop Tests ===\n');

test('HumanLoop constructor with defaults', () => {
  const hl = new HumanLoop();
  assert.strictEqual(hl.getPendingCount(), 0);
  assert.strictEqual(hl.hasPending(), false);
});

test('HumanLoop constructor with custom options', () => {
  const hl = new HumanLoop({ timeout: 10000, autoApprove: true, onTimeout: 'approve' });
  assert.strictEqual(hl.defaults.timeout, 10000);
  assert.strictEqual(hl.defaults.autoApprove, true);
  assert.strictEqual(hl.defaults.onTimeout, 'approve');
});

test('HumanLoop requestInput - creates pending handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('What is your name?', [{ value: 'yes', label: 'Yes' }]);
  assert.ok(handoff.id);
  assert.strictEqual(handoff.type, HANDOFF_TYPES.INPUT);
  assert.strictEqual(handoff.status, 'pending');
  assert.strictEqual(handoff.prompt, 'What is your name?');
  assert.strictEqual(handoff.choices.length, 1);
  assert.strictEqual(hl.getPendingCount(), 1);
  assert.strictEqual(hl.hasPending(), true);
});

test('HumanLoop requestInput - with string choices', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Pick one', ['a', 'b', 'c']);
  assert.strictEqual(handoff.choices.length, 3);
  assert.strictEqual(handoff.choices[0].value, 'a');
  assert.strictEqual(handoff.choices[0].label, 'a');
});

test('HumanLoop requestInput - with custom type', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', [], { type: HANDOFF_TYPES.CLARIFICATION });
  assert.strictEqual(handoff.type, HANDOFF_TYPES.CLARIFICATION);
});

test('HumanLoop approve - creates APPROVAL handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.approve('Delete all files', { path: '/tmp/test' });
  assert.strictEqual(handoff.type, HANDOFF_TYPES.APPROVAL);
  assert.strictEqual(handoff.choices.length, 3);
  assert.ok(handoff.context.action);
  assert.ok(handoff.context.path);
});

test('HumanLoop approve - autoApprove default', () => {
  const hl = new HumanLoop({ autoApprove: true });
  const handoff = hl.approve('Test action');
  assert.strictEqual(handoff.defaultValue, 'approved');
});

test('HumanLoop getDecision - returns pending handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', []);
  const decision = hl.getDecision(handoff.id);
  assert.ok(decision);
  assert.strictEqual(decision.id, handoff.id);
  assert.strictEqual(decision.status, 'pending');
});

test('HumanLoop getDecision - returns null for unknown', () => {
  const hl = new HumanLoop();
  assert.strictEqual(hl.getDecision('nonexistent'), null);
});

test('HumanLoop resolve - resolves pending handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', []);
  
  const resolved = hl.resolve(handoff.id, 'my-answer', { notes: 'User said so' });
  assert.strictEqual(resolved.status, 'resolved');
  assert.strictEqual(resolved.result.value, 'my-answer');
  assert.strictEqual(resolved.result.notes, 'User said so');
  assert.strictEqual(hl.getPendingCount(), 0);
});

test('HumanLoop resolve - moves to completed', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', []);
  hl.resolve(handoff.id, 'done');
  
  const decision = hl.getDecision(handoff.id);
  assert.ok(decision);
  assert.strictEqual(decision.status, 'resolved');
});

test('HumanLoop resolve - throws for unknown handoff', () => {
  const hl = new HumanLoop();
  assert.throws(() => hl.resolve('nonexistent', 'value'), /not found/);
});

test('HumanLoop resolve - throws for already resolved', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', []);
  hl.resolve(handoff.id, 'first');
  assert.throws(() => hl.resolve(handoff.id, 'second'), /not found/);
});

test('HumanLoop getPending - returns all pending', () => {
  const hl = new HumanLoop();
  hl.requestInput('Q1', []);
  hl.requestInput('Q2', []);
  hl.requestInput('Q3', []);
  
  const pending = hl.getPending();
  assert.strictEqual(pending.length, 3);
});

test('HumanLoop cancel - cancels pending handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Test', []);
  hl.cancel(handoff.id, 'No longer needed');
  
  const decision = hl.getDecision(handoff.id);
  assert.strictEqual(decision.status, 'cancelled');
  assert.strictEqual(hl.getPendingCount(), 0);
});

test('HumanLoop cancel - throws for unknown', () => {
  const hl = new HumanLoop();
  assert.throws(() => hl.cancel('unknown'), /not found/);
});

test('HumanLoop getAll - returns all handoffs', () => {
  const hl = new HumanLoop();
  const h1 = hl.requestInput('Q1', []);
  const h2 = hl.requestInput('Q2', []);
  const h3 = hl.requestInput('Q3', []);
  hl.resolve(h1.id, 'done');
  hl.cancel(h3.id, 'cancelled');
  
  const all = hl.getAll();
  assert.strictEqual(all.length, 3);
});

test('HumanLoop getAll - filters by status', () => {
  const hl = new HumanLoop();
  const h1 = hl.requestInput('Q1', []);
  const h2 = hl.requestInput('Q2', []);
  hl.resolve(h1.id, 'done');
  
  const pending = hl.getAll({ status: 'pending' });
  assert.strictEqual(pending.length, 1);
  assert.strictEqual(pending[0].id, h2.id);
  
  const resolved = hl.getAll({ status: 'resolved' });
  assert.strictEqual(resolved.length, 1);
});

test('HumanLoop getAll - filters by type', () => {
  const hl = new HumanLoop();
  hl.requestInput('Q1', []);
  hl.approve('Approve this');
  
  const approvals = hl.getAll({ type: HANDOFF_TYPES.APPROVAL });
  assert.strictEqual(approvals.length, 1);
  assert.strictEqual(approvals[0].type, HANDOFF_TYPES.APPROVAL);
});

test('HumanLoop getStats - returns stats', () => {
  const hl = new HumanLoop();
  hl.requestInput('Q1', []);
  hl.requestInput('Q2', []);
  
  const stats = hl.getStats();
  assert.strictEqual(stats.totalHandoffs, 2);
  assert.strictEqual(stats.pending, 2);
  assert.strictEqual(stats.completed, 0);
  assert.ok(stats.byType.INPUT);
  assert.strictEqual(stats.byType.INPUT, 2);
});

test('HumanLoop review - creates REVIEW handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.review('Check this content', { source: 'test' });
  assert.strictEqual(handoff.type, HANDOFF_TYPES.REVIEW);
  assert.strictEqual(handoff.choices.length, 3);
  assert.strictEqual(handoff.context.content, 'Check this content');
});

test('HumanLoop clarify - creates CLARIFICATION handoff', () => {
  const hl = new HumanLoop();
  const handoff = hl.clarify('What do you mean?', ['Option A', 'Option B']);
  assert.strictEqual(handoff.type, HANDOFF_TYPES.CLARIFICATION);
  assert.strictEqual(handoff.choices.length, 2);
});

test('HumanLoop waitFor - resolves when handoff resolved', async () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Wait test', []);
  
  // Resolve after a short delay
  setTimeout(() => {
    hl.resolve(handoff.id, 'finally done');
  }, 50);
  
  const result = await hl.waitFor(handoff.id, 5000);
  assert.strictEqual(result.status, 'resolved');
  assert.strictEqual(result.result.value, 'finally done');
});

test('HumanLoop waitFor - rejects on timeout', async () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('Timeout test', [], { timeout: 60000 });
  
  try {
    await hl.waitFor(handoff.id, 50);
    assert.fail('Should have rejected');
  } catch (err) {
    assert.ok(err.message.includes('Timeout'));
  }
});

test('HumanLoop timeout handling - applies default value', (done) => {
  const hl = new HumanLoop({ timeout: 50, onTimeout: 'default' });
  
  const handoff = hl.requestInput('Timeout test', [], { defaultValue: 'fallback' });
  
  setTimeout(() => {
    const decision = hl.getDecision(handoff.id);
    assert.strictEqual(decision.status, 'timed_out');
    assert.strictEqual(decision.result.value, 'fallback');
    assert.strictEqual(decision.result.resolvedBy, 'timeout');
    done();
  }, 150);
});

test('HumanLoop - HANDOFF_TYPES are frozen', () => {
  assert.strictEqual(HANDOFF_TYPES.APPROVAL, 'APPROVAL');
  assert.strictEqual(HANDOFF_TYPES.DECISION, 'DECISION');
  assert.strictEqual(HANDOFF_TYPES.INPUT, 'INPUT');
  assert.strictEqual(HANDOFF_TYPES.REVIEW, 'REVIEW');
  assert.strictEqual(HANDOFF_TYPES.CLARIFICATION, 'CLARIFICATION');
});

test('HumanLoop - history tracking', () => {
  const hl = new HumanLoop();
  const handoff = hl.requestInput('History test', []);
  hl.resolve(handoff.id, 'resolved value');
  
  assert.strictEqual(hl.history.length, 2);
  assert.strictEqual(hl.history[0].action, 'created');
  assert.strictEqual(hl.history[1].action, 'resolved');
  assert.strictEqual(hl.history[1].value, 'resolved value');
});

console.log(`\nHumanLoop Tests: ${passed} passed, ${failed} failed\n`);

process.exit(failed > 0 ? 1 : 0);
