/**
 * TC-DFS-002: DepthFirstDebugger 診斷網絡錯誤
 */

const DepthFirstDebugger = require('../../core/depth-first-debugger');

module.exports = {
  id: 'TC-DFS-002',
  name: 'DepthFirstDebugger 診斷連接錯誤',
  execute: async (harness) => {
    const debugger_ = new DepthFirstDebugger({ logger: console });
    
    const error = {
      type: 'console',
      text: 'net::ERR_CONNECTION_REFUSED',
      source: 'NETWORK',
      timestamp: Date.now()
    };
    
    const context = {
      network: {
        url: 'https://api.example.com/data',
        status: 'failed',
        error: 'Connection refused'
      }
    };
    
    const result = await debugger_.diagnose(error, context);
    
    if (!result) throw new Error('Diagnosis returned null');
    if (!result.rootCause) throw new Error('Missing root cause');
    if (typeof result.confidence !== 'number') throw new Error('Missing confidence');
    if (result.exploredNodes < 1) throw new Error('Should explore at least 1 node');
    
    console.log('TC-DFS-002: Root cause -', result.rootCause.label);
  },
  assert: async (harness) => {
    // If we got here without throwing, test passed
  }
};
