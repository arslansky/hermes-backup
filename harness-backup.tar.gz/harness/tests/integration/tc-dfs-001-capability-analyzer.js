/**
 * TC-DFS-001: CapabilityAnalyzer 網絡錯誤分析
 */

const CapabilityAnalyzer = require('../../core/capability-analyzer');

module.exports = {
  id: 'TC-DFS-001',
  name: 'CapabilityAnalyzer 分析 401 網絡錯誤',
  execute: async (harness) => {
    const analyzer = new CapabilityAnalyzer({ logger: console });
    
    const error = {
      type: 'console',
      text: 'Failed to fetch: 401 Unauthorized',
      source: 'NETWORK',
      timestamp: Date.now()
    };
    
    const result = analyzer.analyze(error, {});
    
    if (!result) throw new Error('Analysis returned null');
    if (!result.tree) throw new Error('Missing analysis tree');
    if (!result.recommendation) throw new Error('Missing recommendation');
    
    console.log('TC-DFS-001: Analysis result -', JSON.stringify(result.recommendation, null, 2));
  },
  assert: async (harness) => {
    // If we got here without throwing, test passed
  }
};
