/**
 * TC-DFS-003: ReportGenerator 生成 DFS 樹狀報告
 */

const ReportGenerator = require('../../core/report-generator');

module.exports = {
  id: 'TC-DFS-003',
  name: 'ReportGenerator 生成樹狀錯誤報告',
  execute: async (harness) => {
    const reportGen = new ReportGenerator({ 
      outputDir: '/tmp/harness-test',
      logger: console,
      enableTreeReport: true
    });
    
    const errors = [
      {
        id: 'err-001',
        type: 'console',
        text: 'Failed to fetch: 401 Unauthorized',
        source: 'NETWORK',
        severity: '🔴 BLOCKING',
        timestamp: Date.now(),
        diagnosis: {
          rootCause: {
            type: 'network_failure',
            label: 'authentication',
            data: { message: 'Bearer token expired' }
          },
          confidence: 0.85,
          fixActions: [
            { cmd: 'openclaw auth refresh', type: 'fix', message: 'Refresh authentication' }
          ],
          alternativePaths: [
            { label: 'rate_limit', dimensionName: 'network.rate_limit' }
          ]
        }
      }
    ];
    
    const report = await reportGen.generate({
      sessionId: 'test-dfs-003',
      testName: 'DFS Tree Report Test',
      timestamp: new Date().toISOString(),
      errors,
      networkCalls: [],
      state: { timestamp: new Date().toISOString() }
    });
    
    if (!report) throw new Error('Report generation returned null');
    if (!report.report) throw new Error('Missing report object');
    if (report.report.meta.analysisMode !== 'depth-first') throw new Error('Should be depth-first mode');
    if (!report.report.errorTree) throw new Error('Missing error tree');
    if (!report.report.errorTree.hasErrors) throw new Error('Should have errors');
    if (report.report.errorTree.rootCauses.length !== 1) throw new Error('Should have 1 root cause');
    
    console.log('TC-DFS-003: Report generated with', report.report.errorTree.rootCauses.length, 'root causes');
  },
  assert: async (harness) => {
    // If we got here without throwing, test passed
  }
};
