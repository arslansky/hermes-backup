/**
 * Semantic Scholar Research Integration
 * 
 * 整合 Semantic Scholar API 學術論文搜索
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const API_BASE = 'https://api.semanticscholar.org/graph/v1';
const REPORTS_DIR = '/home/opc/.hermes/harness/reports';

class SemanticScholarResearch {
  constructor(apiKey = null) {
    this.apiKey = apiKey;
    this.rateLimit = 100; // requests per minute
  }

  /**
   * Search papers by query
   */
  async searchPapers(query, options = {}) {
    const params = new URLSearchParams({
      query: query,
      fields: 'title,abstract,authors,year,citationCount,influentialCitationCount,venue,tags,externalIds',
      limit: options.limit || 10,
      offset: options.offset || 0
    });

    return await this._get(`/paper/search?${params}`);
  }

  /**
   * Get paper by ID
   */
  async getPaper(paperId) {
    const fields = 'title,abstract,authors,year,citationCount,influentialCitationCount,venue,tags,externalIds,references.title,references.authors';
    const params = new URLSearchParams({ fields });
    return await this._get(`/paper/${paperId}?${params}`);
  }

  /**
   * Get author by ID
   */
  async getAuthor(authorId) {
    const fields = 'name,papers.title,papers.year,papers.citationCount,hIndex';
    const params = new URLSearchParams({ fields });
    return await this._get(`/author/${authorId}?${params}`);
  }

  /**
   * Get recommended papers for a paper
   */
  async getRecommendations(paperId, limit = 5) {
    const params = new URLSearchParams({ limit: limit.toString() });
    return await this._get(`/paper/${paperId}/recommendations?${params}`);
  }

  /**
   * Get multiple papers by IDs
   */
  async getPapers(paperIds) {
    const papers = [];
    // Process in batches of 50 (API limit)
    for (let i = 0; i < paperIds.length; i += 50) {
      const batch = paperIds.slice(i, i + 50);
      const ids = batch.join(',');
      const result = await this._get(`/paper/batch?ids=${ids}&fields=title,abstract,authors,year,citationCount`);
      if (result) {
        papers.push(...(Array.isArray(result) ? result : [result]));
      }
    }
    return papers;
  }

  async _get(endpoint, retries = 5, baseDelay = 5000) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        return await this._doGet(endpoint);
      } catch (error) {
        // Check if it's a rate limit error
        const isRateLimit = error.message.includes('429') || 
                           error.message.includes('rate') ||
                           error.message.includes('Too Many Requests');
        
        if (isRateLimit && attempt < retries) {
          // Exponential backoff with jitter: baseDelay * 2^(attempt-1) + random(0-1s)
          const delay = baseDelay * Math.pow(2, attempt - 1) + (Math.random() * 1000);
          console.log(`   Rate limited, retrying in ${Math.ceil(delay/1000)}s... (${attempt}/${retries})`);
          await new Promise(r => setTimeout(r, delay));
          continue;
        }
        throw error;
      }
    }
  }

  _doGet(endpoint) {
    return new Promise((resolve, reject) => {
      const url = new URL(endpoint, API_BASE);
      
      const options = {
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0 (compatible; HermesResearch/1.0)'
        }
      };

      if (this.apiKey) {
        options.headers['x-api-key'] = this.apiKey;
      }

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              resolve(JSON.parse(data));
            } catch (e) {
              reject(e);
            }
          } else if (res.statusCode === 429) {
            reject(new Error('429 Rate limit'));
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  /**
   * Format paper for display
   */
  formatPaper(paper, index) {
    const authors = (paper.authors || []).slice(0, 3).map(a => a.name).join(', ');
    const moreAuthors = (paper.authors || []).length > 3 ? ` +${paper.authors.length - 3} more` : '';
    const year = paper.year || 'N/A';
    const citations = paper.citationCount || 0;
    const influential = paper.influentialCitationCount || 0;

    return `
${index}. **${paper.title || 'Untitled'}**

   👥 Authors: ${authors}${moreAuthors}
   📅 Year: ${year}
   📰 Venue: ${paper.venue || 'N/A'}
   📚 Citations: ${citations} ${influential > 0 ? `(${influential} influential)` : ''}
   🏷️ Tags: ${(paper.tags || []).slice(0, 5).join(', ') || 'None'}
   ${paper.abstract ? `📝 Abstract: ${paper.abstract.substring(0, 200)}...` : ''}
`;
  }

  /**
   * Format paper for markdown
   */
  formatPaperMarkdown(paper) {
    const authors = (paper.authors || []).map(a => a.name).join(', ');
    return `- **${paper.title}**
  - Authors: ${authors}
  - Year: ${paper.year || 'N/A'}
  - Citations: ${paper.citationCount || 0}
  - Venue: ${paper.venue || 'N/A'}
  - URL: https://www.semanticscholar.org/paper/${paper.paperId || paper.externalIds?.DOI || ''}
`;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const query = args[0] || 'AI agent';
  const limit = parseInt(args.find(a => a.startsWith('--limit='))?.split('=')[1] || '10');

  console.log('📚 Hermes Harness - Semantic Scholar Research\n');
  console.log(`Searching for: "${query}" (max ${limit} results)\n`);

  const ss = new SemanticScholarResearch();
  
  try {
    const result = await ss.searchPapers(query, { limit });
    
    const papers = result.data || [];
    console.log(`✅ Found ${papers.length} papers\n`);

    // Display papers
    console.log('========================================');
    console.log('📚 Research Papers');
    console.log('========================================\n');

    papers.forEach((paper, i) => {
      console.log(ss.formatPaper(paper, i + 1));
    });

    // Generate markdown report
    let mdReport = `# Semantic Scholar Research Report: "${query}"

> Generated: ${new Date().toISOString()}
> Total papers: ${papers.length}
> Query: "${query}"

---

## 📚 Papers

`;
    papers.forEach((paper, i) => {
      mdReport += `### ${i + 1}. ${paper.title || 'Untitled'}

**Authors:** ${(paper.authors || []).map(a => a.name).join(', ') || 'Unknown'}
**Year:** ${paper.year || 'N/A'}
**Venue:** ${paper.venue || 'N/A'}
**Citations:** ${paper.citationCount || 0} (${paper.influentialCitationCount || 0} influential)
**Tags:** ${(paper.tags || []).join(', ') || 'None'}

**Abstract:**
${paper.abstract || 'No abstract available'}

**External IDs:** ${JSON.stringify(paper.externalIds || {})}

---
`;
    });

    // Summary stats
    const totalCitations = papers.reduce((sum, p) => sum + (p.citationCount || 0), 0);
    const avgCitations = papers.length > 0 ? Math.round(totalCitations / papers.length) : 0;
    const years = papers.map(p => p.year).filter(Boolean);
    const yearRange = years.length > 0 ? `${Math.min(...years)} - ${Math.max(...years)}` : 'N/A';

    mdReport += `
## 📊 Summary

| Metric | Value |
|--------|-------|
| Total Papers | ${papers.length} |
| Total Citations | ${totalCitations} |
| Average Citations | ${avgCitations} |
| Year Range | ${yearRange} |
| Generated | ${new Date().toISOString()} |

---

*Generated by Hermes Harness - Semantic Scholar Integration*
`;

    // Save report
    const timestamp = Date.now();
    const mdPath = path.join(REPORTS_DIR, `semantic-${timestamp}.md`);
    fs.mkdirSync(REPORTS_DIR, { recursive: true });
    fs.writeFileSync(mdPath, mdReport);

    // Save JSON
    const jsonPath = path.join(REPORTS_DIR, `semantic-${timestamp}.json`);
    fs.writeFileSync(jsonPath, JSON.stringify({
      meta: { query, generatedAt: new Date().toISOString(), count: papers.length },
      papers: papers.map((p, i) => ({
        index: i + 1,
        title: p.title,
        authors: p.authors?.map(a => a.name),
        year: p.year,
        venue: p.venue,
        citations: p.citationCount,
        influentialCitations: p.influentialCitationCount,
        tags: p.tags,
        abstract: p.abstract?.substring(0, 500),
        externalIds: p.externalIds,
        url: `https://www.semanticscholar.org/paper/${p.paperId || ''}`
      })),
      summary: { totalCitations, avgCitations, yearRange }
    }, null, 2));

    console.log('\n========================================');
    console.log(`📄 Reports saved:`);
    console.log(`   MD: ${mdPath}`);
    console.log(`   JSON: ${jsonPath}`);
    console.log('========================================\n');

  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    console.log('\nNote: Semantic Scholar API has rate limits. Try again later.');
  }
}

if (require.main === module) {
  main();
}

module.exports = { SemanticScholarResearch };
