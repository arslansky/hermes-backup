/**
 * Test Runner - 測試用例執行器
 * 
 * 運行不同級別的測試用例
 */

const path = require('path');
const fs = require('fs').promises;

const TestRunner = class {
  constructor(harness) {
    this.harness = harness;
    this.results = [];
  }

  async run(testCase) {
    const result = {
      id: testCase.id,
      name: testCase.name,
      status: 'PASS',
      errors: [],
      startTime: Date.now()
    };

    try {
      await testCase.execute(this.harness);
      await testCase.assert(this.harness);
    } catch (error) {
      result.status = 'FAIL';
      result.errors.push(error.message);
    }

    result.duration = Date.now() - result.startTime;
    this.results.push(result);
    return result;
  }

  async runAll(testCases) {
    console.log(`\n========================================`);
    console.log(`Running ${testCases.length} test cases...`);
    console.log(`========================================\n`);
    
    for (const tc of testCases) {
      const result = await this.run(tc);
      const icon = result.status === 'PASS' ? '✅' : '❌';
      console.log(`${icon} ${tc.id}: ${result.status} (${result.duration}ms)`);
      if (result.errors.length > 0) {
        console.log(`   Error: ${result.errors[0]}`);
      }
    }

    return this.generateSummary();
  }

  generateSummary() {
    const passed = this.results.filter(r => r.status === 'PASS').length;
    const failed = this.results.filter(r => r.status === 'FAIL').length;
    const total = this.results.length;
    
    return {
      total,
      passed,
      failed,
      passRate: `${((passed / total) * 100).toFixed(1)}%`,
      results: this.results
    };
  }
};

// CLI entry point
async function main() {
  const args = process.argv.slice(2);
  const level = args.includes('--level') 
    ? args[args.indexOf('--level') + 1] 
    : 'all';

  console.log('🔧 Hermes Debug Harness - Test Runner');
  console.log(`Testing level: ${level}\n`);

  // Load test cases based on level
  const testDir = path.join(__dirname, '..', 'tests');
  const testCases = [];

  try {
    if (level === 'all' || level === 'unit') {
      const unitTests = await loadTests(path.join(testDir, 'unit'));
      testCases.push(...unitTests);
    }
    if (level === 'all' || level === 'integration') {
      const intTests = await loadTests(path.join(testDir, 'integration'));
      testCases.push(...intTests);
    }
    if (level === 'all' || level === 'e2e') {
      const e2eTests = await loadTests(path.join(testDir, 'e2e'));
      testCases.push(...e2eTests);
    }
  } catch (e) {
    console.log('No test files found, running demo...');
  }

  // Initialize harness
  const DebugHarness = require('../core/index');
  const harness = new DebugHarness({ headless: true });
  await harness.init();
  await harness.launchBrowser();

  // Run tests
  const runner = new TestRunner(harness);
  
  if (testCases.length > 0) {
    const summary = await runner.runAll(testCases);
    console.log('\n========================================');
    console.log('📊 Test Summary');
    console.log('========================================');
    console.log(`Total: ${summary.total}`);
    console.log(`Passed: ${summary.passed}`);
    console.log(`Failed: ${summary.failed}`);
    console.log(`Pass Rate: ${summary.passRate}`);
  } else {
    // Run demo test
    console.log('Running demo test...');
    await harness.page.goto('https://example.com');
    const title = await harness.page.title();
    console.log(`✅ Demo test passed - Page title: ${title}`);
  }

  // Generate report
  const report = await harness.generateReport(`test-run-${level}`);
  console.log(`\n📄 Report generated: ${report.md}`);

  await harness.cleanup();
  process.exit(0);
}

async function loadTests(dir) {
  const tests = [];
  try {
    const files = await fs.readdir(dir);
    for (const file of files) {
      if (file.endsWith('.js')) {
        const testCase = require(path.join(dir, file));
        tests.push(testCase);
      }
    }
  } catch (e) {
    // Directory doesn't exist
  }
  return tests;
}

if (require.main === module) {
  main().catch(e => {
    console.error('Test runner error:', e);
    process.exit(1);
  });
}

module.exports = TestRunner;
