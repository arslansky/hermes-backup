/**
 * Upload Report Script - 上傳報告到 GDrive
 * 
 * 自動將測試報告上傳到 Google Drive
 */

const { execSync } = require('child_process');
const fs = require('fs').promises;
const path = require('path');

const HARNESS_DIR = '/home/opc/.hermes/harness';
const REPORTS_DIR = '/home/opc/.hermes/harness/reports';
const BACKUP_DIR = 'gdrive:/OpenClaw_Backups/Harness-Reports';

async function getLatestReport() {
  try {
    const files = await fs.readdir(REPORTS_DIR);
    const reports = files
      .filter(f => f.endsWith('.json') && f.startsWith('report-'))
      .map(f => ({
        name: f,
        path: path.join(REPORTS_DIR, f),
        time: (require('fs').statSync(path.join(REPORTS_DIR, f)).mtimeMs)
      }))
      .sort((a, b) => b.time - a.time);
    
    return reports[0];
  } catch (e) {
    return null;
  }
}

async function uploadToGDrive(localPath, remotePath) {
  try {
    console.log(`📤 Uploading to GDrive: ${remotePath}`);
    execSync(`rclone copyto "${localPath}" "${remotePath}"`, { stdio: 'inherit' });
    console.log('✅ Upload complete');
    return true;
  } catch (e) {
    console.error('❌ Upload failed:', e.message);
    return false;
  }
}

async function main() {
  console.log('🔧 Hermes Harness - Report Uploader\n');
  
  // Find latest report
  const latestReport = await getLatestReport();
  
  if (!latestReport) {
    console.log('❌ No report found to upload');
    process.exit(1);
  }
  
  console.log(`📄 Latest report: ${latestReport.name}`);
  
  // Upload JSON report
  const jsonDest = `${BACKUP_DIR}/${latestReport.name}`;
  await uploadToGDrive(latestReport.path, jsonDest);
  
  // Upload corresponding MD report
  const mdFile = latestReport.name.replace('.json', '.md');
  const mdPath = path.join(REPORTS_DIR, mdFile);
  try {
    await fs.access(mdPath);
    const mdDest = `${BACKUP_DIR}/${mdFile}`;
    await uploadToGDrive(mdPath, mdDest);
  } catch (e) {
    console.log('⚠️ No MD report found');
  }
  
  // Upload HTML report
  const htmlFile = latestReport.name.replace('.json', '.html');
  const htmlPath = path.join(REPORTS_DIR, htmlFile);
  try {
    await fs.access(htmlPath);
    const htmlDest = `${BACKUP_DIR}/${htmlFile}`;
    await uploadToGDrive(htmlPath, htmlDest);
  } catch (e) {
    console.log('⚠️ No HTML report found');
  }
  
  console.log('\n========================================');
  console.log('✅ All reports uploaded to GDrive');
  console.log(`📁 Remote: ${BACKUP_DIR}`);
  console.log('========================================\n');
}

main().catch(e => {
  console.error('Upload script error:', e);
  process.exit(1);
});
