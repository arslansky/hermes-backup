/**
 * Research Integration - OpenAlex API
 * 
 * 整合 OpenAlex 學術論文搜索到 Harness 系統
 * API 完全免費，無需 key，每分鐘可請求多次
 */

const https = require('https');
const fs = require('fs').promises;
const path = require('path');

const API_BASE = 'https://api.openalex.org';
const REPORTS_DIR = '/home/opc/.hermes/harness/reports';

/**
 * OpenAlex API wrapper - 完全免費，無 rate limit
 */
class OpenAlexResearch {
  constructor(options = {}) {
    this.maxResults = options.maxResults || 10;
  }

  /**
   * Search papers by keyword
   */
  async search(keyword, options = {}) {
    const limit = options.limit || this.maxResults;
    const sortBy = options.sortBy || 'relevance';
    
    // Build filter - URLSearchParams will handle encoding
    let filter = `title.search:${keyword}`;
    
    // Add date filter if specified
    if (options.fromYear) {
      filter += `,publication_year:>${options.fromYear}`;
    }
    
    // Build sort parameter
    let sort = 'relevance_score:desc';
    if (sortBy === 'cited') sort = 'cited_by_count:desc';
    if (sortBy === 'date') sort = 'publication_date:desc';
    
    const params = new URLSearchParams();
    params.append('filter', filter);
    params.append('sort', sort);
    params.append('per_page', limit.toString());
    params.append('cursor', options.cursor || '*');
    
    return await this._get(`/works?${params}`);
  }

  /**
   * Get paper by OpenAlex ID
   */
  async getPaper(id) {
    return await this._get(`/works/${id}`);
  }

  async _get(endpoint) {
    return new Promise((resolve, reject) => {
      const url = new URL(endpoint, API_BASE);
      
      const options = {
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0 (compatible; HermesHarness/1.0)'
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              resolve(JSON.parse(data));
            } catch (e) {
              reject(e);
            }
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${data.substring(0, 200)}`));
          }
        });
      });

      req.on('error', reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  /**
   * Parse OpenAlex response to papers
   */
  parseResults(response) {
    const papers = (response.results || []).map(work => ({
      id: work.id,
      openalexId: work.id,
      doi: work.doi,
      title: work.display_name,
      summary: work.abstract_inverted_index ? this._reconstructAbstract(work.abstract_inverted_index) : '',
      published: work.publication_date,
      year: work.publication_year,
      authors: (work.authorships || []).map(a => a.author?.display_name || 'Unknown').slice(0, 5),
      citationCount: work.cited_by_count || 0,
      citationPercentile: work.citation_normalized_percentile?.value,
      venue: work.primary_location?.source?.display_name || '',
      openAccess: work.open_access?.is_oa || false,
      pdfUrl: work.best_oa_location?.pdf_url || '',
      topics: (work.topics || []).slice(0, 5).map(t => t.display_name),
      keywords: (work.keywords || []).slice(0, 10).map(k => k.display_name),
      relevanceScore: work.relevance_score
    }));

    return {
      count: papers.length,
      total: response.meta?.count || papers.length,
      papers,
      nextCursor: response.meta?.next_cursor
    };
  }

  /**
   * Reconstruct abstract from inverted index
   */
  _reconstructAbstract(invertedIndex) {
    const words = Object.keys(invertedIndex);
    const wordPositions = {};
    
    for (const word of words) {
      for (const pos of invertedIndex[word]) {
        wordPositions[pos] = word;
      }
    }
    
    const sortedPositions = Object.keys(wordPositions).map(Number).sort((a, b) => a - b);
    return sortedPositions.map(pos => wordPositions[pos]).join(' ').substring(0, 1000);
  }

  /**
   * Format paper for display
   */
  formatPaper(paper, index) {
    const shortId = paper.openalexId?.split('/').pop() || 'N/A';
    const authors = paper.authors?.slice(0, 3).join(', ') || 'Unknown';
    const extraAuthors = (paper.authors?.length || 0) > 3 ? ` +${paper.authors.length - 3} more` : '';
    const citations = paper.citationCount > 0 ? `📊 Citations: ${paper.citationCount}` : '';
    const oa = paper.openAccess ? '🔓 OA' : '';
    
    return `
${index}. **${paper.title}**

   📄 ID: \`${shortId}\`
   📅 Year: ${paper.year || 'N/A'}
   👥 Authors: ${authors}${extraAuthors}
   📰 Venue: ${paper.venue || 'N/A'}
   ${citations} ${oa}
   🏷️ Topics: ${(paper.topics || []).slice(0, 3).join(', ') || 'N/A'}
   
   ${paper.summary ? paper.summary.substring(0, 200) + '...' : 'No abstract available'}
`;
  }
}

/**
 * Generate research report
 */
async function generateResearchReport(keyword, options = {}) {
  console.log(`🔍 Searching OpenAlex for: "${keyword}"\n`);
  
  const openalex = new OpenAlexResearch({ maxResults: options.maxResults || 10 });
  
  try {
    const response = await openalex.search(keyword, {
      limit: options.maxResults || 10,
      sortBy: options.sortBy || 'relevance'
    });
    
    const results = openalex.parseResults(response);
    
    console.log(`✅ Found ${results.total} papers (showing ${results.count})\n`);
    
    // Create report
    const report = {
      meta: {
        keyword,
        generatedAt: new Date().toISOString(),
        source: 'OpenAlex API',
        count: results.count,
        totalMatches: results.total
      },
      papers: results.papers,
      recommendations: generateRecommendations(results.papers)
    };
    
    // Save JSON report
    const timestamp = Date.now();
    const jsonPath = path.join(REPORTS_DIR, `openalex-${timestamp}.json`);
    await fs.mkdir(REPORTS_DIR, { recursive: true });
    await fs.writeFile(jsonPath, JSON.stringify(report, null, 2));
    
    // Save MD report
    const mdContent = generateMarkdownReport(keyword, results.papers, results.total);
    const mdPath = path.join(REPORTS_DIR, `openalex-${timestamp}.md`);
    await fs.writeFile(mdPath, mdContent);
    
    console.log(`📄 Reports saved:`);
    console.log(`   JSON: ${jsonPath}`);
    console.log(`   MD: ${mdPath}`);
    
    return { report, jsonPath, mdPath };
    
  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    throw error;
  }
}

/**
 * Generate recommendations based on papers
 */
function generateRecommendations(papers) {
  const recommendations = [];
  
  // Analyze topics
  const topics = papers.flatMap(p => p.topics || []);
  const topTopics = [...new Set(topics)]
    .map(t => ({ topic: t, count: topics.filter(tp => tp === t).length }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  
  if (topTopics.length > 0) {
    recommendations.push({
      type: 'trending_topics',
      message: `Most common topics: ${topTopics.map(t => `${t.topic} (${t.count})`).join(', ')}`
    });
  }
  
  // Find highly cited papers
  const highlyCited = papers.filter(p => (p.citationCount || 0) > 50);
  if (highlyCited.length > 0) {
    recommendations.push({
      type: 'influential_papers',
      message: `${highlyCited.length} paper(s) with 50+ citations`
    });
  }
  
  // Find recent papers (2024+)
  const recentCount = papers.filter(p => (p.year || 0) >= 2024).length;
  if (recentCount > 0) {
    recommendations.push({
      type: 'recent_papers',
      message: `${recentCount} paper(s) published in 2024+`
    });
  }
  
  // Find open access papers
  const oaCount = papers.filter(p => p.openAccess).length;
  if (oaCount > 0) {
    recommendations.push({
      type: 'open_access',
      message: `${oaCount} open access paper(s) available`
    });
  }
  
  return recommendations;
}

/**
 * Generate markdown report
 */
function generateMarkdownReport(keyword, papers, total) {
  let md = `# OpenAlex Research Report: "${keyword}"

> Generated: ${new Date().toISOString()}
> Total matches: ${total} | Showing: ${papers.length} papers

---

## 📚 Papers

`;
  
  papers.forEach((paper, i) => {
    const shortId = paper.openalexId?.split('/').pop() || 'N/A';
    const authors = paper.authors?.join(', ') || 'Unknown';
    md += `### ${i + 1}. ${paper.title || 'Untitled'}

**OpenAlex ID:** \`${shortId}\`  
**Year:** ${paper.year || 'N/A'}  
**Authors:** ${authors}  
**Venue:** ${paper.venue || 'N/A'}  
**Citations:** ${paper.citationCount || 0}  
**Topics:** ${(paper.topics || []).join(', ') || 'None'}
${paper.openAccess ? `**Open Access:** Yes ([PDF](${paper.pdfUrl || paper.openalexId}))\n` : ''}

**Abstract:**
${paper.summary ? paper.summary.substring(0, 500) : 'No abstract available'}...

---

`;
  });
  
  md += `
## 📊 Summary

- Total matches: ${total}
- Papers shown: ${papers.length}
- Generated: ${new Date().toISOString()}
- Source: OpenAlex API

---

*Generated by Hermes Harness - OpenAlex Research Integration*
`;
  
  return md;
}

// CLI usage
async function main() {
  const args = process.argv.slice(2);
  const keyword = args[0] || 'AI agent';
  const maxResults = parseInt(args.find(a => a.startsWith('--max='))?.split('=')[1] || '10');
  
  console.log('🔬 Hermes Harness - OpenAlex Research\n');
  console.log(`Searching for: "${keyword}" (max ${maxResults} results)\n`);
  
  await generateResearchReport(keyword, { maxResults });
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = { OpenAlexResearch, generateResearchReport };