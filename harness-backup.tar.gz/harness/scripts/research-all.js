#!/usr/bin/env node
/**
 * Unified Research Report Generator
 * 
 * 整合 OpenAlex + Polymarket + Blogwatcher + ArXiv (backup)
 * 生成完整嘅每日研究報告
 * 
 * Feature Flags 控制：
 *   - research-openalex: OpenAlex 論文源
 *   - research-arxiv: ArXiv 論文源  
 *   - research-polymarket: Polymarket 預測市場
 *   - research-blogwatcher: Blogwatcher 業界文章
 *   - research-semantic: Semantic Scholar（需要 API key）
 */

const path = require('path');
const fs = require('fs');

// Import integrations
const { OpenAlexResearch } = require('./research-openalex');
const { ArXivResearch } = require('./research-arxiv');
const { PolymarketResearch } = require('./research-polymarket');
const { Blogwatcher, DEFAULT_FEEDS } = require('./research-blogwatcher');
const { SemanticScholarResearch } = require('./research-semantic');
const { getFeatureFlags } = require('../lib/feature-flags');

const REPORTS_DIR = '/home/opc/.hermes/harness/reports';
const STATE_DIR = '/home/opc/.hermes/harness/state';

class UnifiedResearchReport {
  constructor(options = {}) {
    this.topic = options.topic || 'AI agent';
    this.maxResults = options.maxResults || 10;
    
    // Feature flags
    this.flags = getFeatureFlags();
    
    // Primary: OpenAlex (free, no rate limit)
    this.openalex = new OpenAlexResearch({ maxResults: this.maxResults });
    // Backup: ArXiv (may be rate limited)
    this.arxiv = new ArXivResearch({ maxResults: this.maxResults });
    this.polymarket = new PolymarketResearch();
    this.semantic = new SemanticScholarResearch();
    this.blogwatcher = new Blogwatcher();
  }

  async generate() {
    console.log('🔬 Hermes Harness - Unified Research Report\n');
    console.log(`Topic: "${this.topic}"\n`);
    
    // Show active flags
    const activeFlags = this.flags.getActiveFlags();
    if (activeFlags.length > 0) {
      console.log('📋 Active Flags:', activeFlags.join(', '), '\n');
    }
    
    const results = {
      meta: {
        topic: this.topic,
        generatedAt: new Date().toISOString(),
        maxResults: this.maxResults,
        activeFlags: activeFlags
      },
      openalex: null,
      arxiv: null,
      polymarket: null,
      semantic: null,
      blogwatcher: null,
      errors: []
    };

    // 1. OpenAlex Research (PRIMARY - no rate limit)
    console.log('📚 [1/5] Fetching OpenAlex papers (primary)...');
    if (this.flags.isEnabled('research-openalex')) {
      try {
        const oaResponse = await this.openalex.search(this.topic, { limit: this.maxResults });
        const oaResults = this.openalex.parseResults(oaResponse);
        results.openalex = { count: oaResults.count, papers: oaResults.papers };
        console.log(`   ✅ Found ${oaResults.total} papers (showing ${oaResults.count})`);
      } catch (error) {
        console.log(`   ❌ OpenAlex error: ${error.message}`);
        results.errors.push({ source: 'openalex', error: error.message });
      }
    } else {
      console.log('   ⏭️  Disabled via feature flag');
    }

    // 2. ArXiv Research (BACKUP - may be rate limited)
    console.log('📚 [2/5] Fetching ArXiv papers (backup)...');
    if (this.flags.isEnabled('research-arxiv')) {
      try {
        const arxivResult = await this.arxiv.search(this.topic, { maxResults: this.maxResults });
        results.arxiv = arxivResult;
        console.log(`   ✅ Found ${arxivResult.count} papers`);
      } catch (error) {
        console.log(`   ⚠️ ArXiv error: ${error.message} (OpenAlex used as primary)`);
        results.errors.push({ source: 'arxiv', error: error.message });
      }
    } else {
      console.log('   ⏭️  Disabled via feature flag');
    }

    // 3. Polymarket Predictions
    console.log('🔮 [3/5] Fetching Polymarket predictions...');
    if (this.flags.isEnabled('research-polymarket')) {
      try {
        const polyMarkets = await this.polymarket.getMarkets(this.topic, { limit: this.maxResults });
        results.polymarket = { count: polyMarkets.length, markets: polyMarkets };
        console.log(`   ✅ Found ${polyMarkets.length} markets`);
      } catch (error) {
        console.log(`   ❌ Polymarket error: ${error.message}`);
        results.errors.push({ source: 'polymarket', error: error.message });
      }
    } else {
      console.log('   ⏭️  Disabled via feature flag');
    }

    // 4. Semantic Scholar
    console.log('📖 [4/5] Fetching Semantic Scholar papers...');
    if (this.flags.isEnabled('research-semantic')) {
      try {
        const ssResult = await this.semantic.searchPapers(this.topic, { limit: this.maxResults });
        results.semantic = ssResult;
        console.log(`   ✅ Found ${(ssResult.data || []).length} papers`);
      } catch (error) {
        console.log(`   ❌ Semantic Scholar error: ${error.message}`);
        results.errors.push({ source: 'semantic', error: error.message });
      }
    } else {
      console.log('   ⏭️  Disabled via feature flag (no API key)');
    }

    // 5. Blogwatcher
    console.log('📰 [5/5] Fetching blog updates...');
    if (this.flags.isEnabled('research-blogwatcher')) {
      await this.blogwatcher._loadFeeds();
      
      // Add default feeds if none
      if (this.blogwatcher.feeds.size === 0) {
        for (const feed of DEFAULT_FEEDS) {
          await this.blogwatcher.addFeed(feed.name, feed.url);
        }
      }
      
      const fetchResults = await this.blogwatcher.fetchAll();
      const allArticles = [];
      
      for (const result of fetchResults) {
        if (!result.error) {
          allArticles.push(...result.articles.map(a => ({ ...a, feedName: result.feed })));
        }
      }
      
      allArticles.sort((a, b) => new Date(b.published) - new Date(a.published));
      results.blogwatcher = { count: allArticles.length, articles: allArticles.slice(0, 10) };
      console.log(`   ✅ Found ${allArticles.length} articles`);
    } else {
      console.log('   ⏭️  Disabled via feature flag');
    }

    // Generate report
    const report = this.generateReport(results);
    
    // Save reports
    const timestamp = Date.now();
    const baseName = `unified-research-${timestamp}`;
    
    fs.mkdirSync(REPORTS_DIR, { recursive: true });
    
    const mdPath = path.join(REPORTS_DIR, `${baseName}.md`);
    fs.writeFileSync(mdPath, report.markdown);
    
    const jsonPath = path.join(REPORTS_DIR, `${baseName}.json`);
    fs.writeFileSync(jsonPath, JSON.stringify(report.json, null, 2));
    
    const htmlPath = path.join(REPORTS_DIR, `${baseName}.html`);
    fs.writeFileSync(htmlPath, report.html);

    console.log('\n========================================');
    console.log('✅ Report generated successfully!');
    console.log('========================================');
    console.log(`📄 Markdown: ${path.basename(mdPath)}`);
    console.log(`📊 JSON:     ${path.basename(jsonPath)}`);
    console.log(`🌐 HTML:     ${path.basename(htmlPath)}`);
    console.log(`\nFull path: ${REPORTS_DIR}`);

    return { report, mdPath, jsonPath, htmlPath };
  }

  generateReport(results) {
    const { meta, openalex, arxiv, polymarket, semantic, blogwatcher, errors } = results;

    // Markdown Report
    let md = `# 🔬 Unified Research Report: "${meta.topic}"

> **Generated:** ${meta.generatedAt}
> **Topic:** ${meta.topic}
> **Errors:** ${errors.length > 0 ? errors.map(e => `${e.source}: ${e.error}`).join('; ') : 'None'}

---

## 📚 OpenAlex Papers (${openalex?.count || 0}) [PRIMARY]

`;
    if (openalex?.papers?.length > 0) {
      openalex.papers.forEach((paper, i) => {
        md += `### ${i + 1}. ${paper.title}

- **Authors:** ${(paper.authors || []).slice(0, 3).join(', ')}${(paper.authors || []).length > 3 ? ' +more' : ''}
- **Published:** ${paper.published || 'N/A'}
- **DOI:** ${paper.doi || 'N/A'}
- **Citations:** ${paper.citations || 0}
- **Open Access:** ${paper.openAccess ? '✅ Yes' : '❌ No'}

${paper.abstract ? `${paper.abstract.substring(0, 200)}...` : ''}

---
`;
      });
    } else {
      md += '*No papers found (may need to wait for ArXiv fallback)*\n\n---\n\n';
    }

    md += `

## 📚 ArXiv Papers (${arxiv?.count || 0}) [BACKUP]

`;
    if (arxiv?.papers?.length > 0) {
      arxiv.papers.forEach((paper, i) => {
        md += `### ${i + 1}. ${paper.title}

- **ID:** \`${paper.id?.split('/').pop() || 'N/A'}\`
- **Published:** ${paper.published?.split('T')[0] || 'N/A'}
- **Authors:** ${paper.authors?.slice(0, 5).join(', ') || 'Unknown'}
- **PDF:** ${paper.pdf || 'N/A'}

${paper.summary?.substring(0, 300)}...

---
`;
      });
    } else {
      md += '*No papers found*\n';
    }

    md += `
---

## 🔮 Polymarket Predictions (${polymarket?.count || 0})

`;
    if (polymarket?.markets?.length > 0) {
      polymarket.markets.forEach((market, i) => {
        const prob = market.outcomePrices?.Yes 
          ? (parseFloat(market.outcomePrices.Yes) * 100).toFixed(1) 
          : 'N/A';
        md += `### ${i + 1}. ${market.question}

- **Probability:** ${prob}%
- **Category:** ${(market.tags || []).join(', ') || 'General'}
${market.volume ? `- **Volume:** $${(market.volume / 1000).toFixed(1)}K` : ''}

---
`;
      });
    } else {
      md += '*No markets found*\n';
    }

    md += `
---

## 📖 Semantic Scholar Papers (${semantic?.data?.length || 0})

`;
    if (semantic?.data?.length > 0) {
      semantic.data.forEach((paper, i) => {
        md += `### ${i + 1}. ${paper.title}

- **Authors:** ${(paper.authors || []).slice(0, 3).map(a => a.name).join(', ')}${(paper.authors || []).length > 3 ? ' +more' : ''}
- **Year:** ${paper.year || 'N/A'}
- **Venue:** ${paper.venue || 'N/A'}
- **Citations:** ${paper.citationCount || 0} (${paper.influentialCitationCount || 0} influential)
- **Tags:** ${(paper.tags || []).slice(0, 5).join(', ') || 'None'}

${paper.abstract ? `${paper.abstract.substring(0, 200)}...` : ''}

---
`;
      });
    } else {
      md += '*No papers found*\n';
    }

    md += `
---

## 📰 Blog Updates (${blogwatcher?.count || 0})

`;
    if (blogwatcher?.articles?.length > 0) {
      blogwatcher.articles.slice(0, 10).forEach((article, i) => {
        const date = new Date(article.published).toLocaleDateString();
        md += `### ${i + 1}. ${article.title}

- **Source:** ${article.feedName || article.feed}
- **Date:** ${date}
- **Link:** ${article.link || 'N/A'}

${article.description?.substring(0, 150)}...

---
`;
      });
    } else {
      md += '*No new articles*\n';
    }

    md += `
---

## 📊 Summary

| Source | Count |
|--------|-------|
| ArXiv | ${arxiv?.count || 0} |
| Polymarket | ${polymarket?.count || 0} |
| Semantic Scholar | ${semantic?.data?.length || 0} |
| Blogwatcher | ${blogwatcher?.count || 0} |

**Errors:** ${results.errors.length > 0 ? results.errors.map(e => e.source).join(', ') : 'None'}

---

*Generated by Hermes Harness - Unified Research Report*
*Date: ${meta.generatedAt}*
`;

    // JSON Report
    const json = {
      meta,
      sources: {
        arxiv: arxiv?.papers?.map(p => ({
          title: p.title,
          id: p.id,
          published: p.published,
          authors: p.authors,
          pdf: p.pdf
        })) || [],
        polymarket: polymarket?.markets?.map(m => ({
          question: m.question,
          probability: m.outcomePrices?.Yes 
            ? `${(parseFloat(m.outcomePrices.Yes) * 100).toFixed(1)}%` 
            : 'N/A',
          tags: m.tags,
          volume: m.volume
        })) || [],
        semantic: semantic?.data?.map(p => ({
          title: p.title,
          authors: p.authors?.map(a => a.name),
          year: p.year,
          citations: p.citationCount,
          venue: p.venue
        })) || [],
        blogwatcher: blogwatcher?.articles?.slice(0, 10).map(a => ({
          title: a.title,
          feed: a.feedName || a.feed,
          date: a.published,
          link: a.link
        })) || []
      },
      errors: results.errors
    };

    // HTML Report
    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Research Report: ${meta.topic}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 20px; }
    .card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .section-title { color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; margin-bottom: 15px; }
    .paper { padding: 15px; border-left: 4px solid #667eea; background: #f8f9fa; margin-bottom: 15px; border-radius: 5px; }
    .market { padding: 15px; border-left: 4px solid #f56565; background: #fff5f5; margin-bottom: 15px; border-radius: 5px; }
    .article { padding: 15px; border-left: 4px solid #48bb78; background: #f0fff4; margin-bottom: 15px; border-radius: 5px; }
    .badge { display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 12px; background: #e2e8f0; margin-right: 5px; }
    .meta { display: flex; gap: 20px; margin-top: 10px; }
    .meta-item { background: rgba(255,255,255,0.2); padding: 5px 15px; border-radius: 5px; }
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
    th { background: #f8f9fa; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🔬 Research Report</h1>
    <h2>Topic: "${meta.topic}"</h2>
    <div class="meta">
      <div class="meta-item">📅 ${meta.generatedAt}</div>
      <div class="meta-item">📚 ArXiv: ${arxiv?.count || 0}</div>
      <div class="meta-item">🔮 Polymarket: ${polymarket?.count || 0}</div>
      <div class="meta-item">📖 S.Scholar: ${semantic?.data?.length || 0}</div>
      <div class="meta-item">📰 Blogs: ${blogwatcher?.count || 0}</div>
    </div>
  </div>

  <div class="card">
    <h2 class="section-title">📚 ArXiv Papers</h2>
    ${arxiv?.papers?.map((p, i) => `
      <div class="paper">
        <h3>${i + 1}. ${p.title}</h3>
        <p><strong>ID:</strong> ${p.id?.split('/').pop() || 'N/A'} | <strong>Published:</strong> ${p.published?.split('T')[0] || 'N/A'}</p>
        <p><strong>Authors:</strong> ${p.authors?.slice(0, 5).join(', ') || 'Unknown'}</p>
        <p>${p.summary?.substring(0, 200)}...</p>
      </div>
    `).join('') || '<p>No papers found</p>'}
  </div>

  <div class="card">
    <h2 class="section-title">🔮 Polymarket Predictions</h2>
    ${polymarket?.markets?.map((m, i) => `
      <div class="market">
        <h3>${i + 1}. ${m.question}</h3>
        <p><strong>Probability:</strong> ${m.outcomePrices?.Yes ? (parseFloat(m.outcomePrices.Yes) * 100).toFixed(1) : 'N/A'}%</p>
        <p><strong>Tags:</strong> ${(m.tags || []).map(t => `<span class="badge">${t}</span>`).join('')}</p>
      </div>
    `).join('') || '<p>No markets found</p>'}
  </div>

  <div class="card">
    <h2 class="section-title">📖 Semantic Scholar</h2>
    ${semantic?.data?.map((p, i) => `
      <div class="paper">
        <h3>${i + 1}. ${p.title}</h3>
        <p><strong>Authors:</strong> ${(p.authors || []).map(a => a.name).join(', ')} | <strong>Year:</strong> ${p.year || 'N/A'}</p>
        <p><strong>Citations:</strong> ${p.citationCount || 0} | <strong>Venue:</strong> ${p.venue || 'N/A'}</p>
        <p>${p.abstract?.substring(0, 200)}...</p>
      </div>
    `).join('') || '<p>No papers found</p>'}
  </div>

  <div class="card">
    <h2 class="section-title">📰 Blog Updates</h2>
    ${blogwatcher?.articles?.slice(0, 10).map((a, i) => `
      <div class="article">
        <h3>${i + 1}. ${a.title}</h3>
        <p><strong>Source:</strong> ${a.feedName || a.feed} | <strong>Date:</strong> ${new Date(a.published).toLocaleDateString()}</p>
        <p>${a.description?.substring(0, 150)}...</p>
      </div>
    `).join('') || '<p>No articles found</p>'}
  </div>

  <footer style="text-align: center; padding: 20px; color: #666;">
    Generated by Hermes Harness - ${meta.generatedAt}
  </footer>
</body>
</html>`;

    return { markdown: md, json, html };
  }
}

async function main() {
  const args = process.argv.slice(2);
  const topic = args[0] || 'AI agent';
  const maxResults = parseInt(args.find(a => a.startsWith('--max='))?.split('=')[1] || '10');

  console.log('========================================');
  console.log('🔬 Unified Research Report Generator');
  console.log('========================================\n');

  const report = new UnifiedResearchReport({ topic, maxResults });
  await report.generate();
}

if (require.main === module) {
  main();
}

module.exports = { UnifiedResearchReport };
