/**
 * Research Integration - ArXiv API
 * 
 * 整合 ArXiv 學術論文搜索到 Harness 系統
 */

const https = require('https');
const fs = require('fs').promises;
const path = require('path');

const HARNESS_DIR = '/home/opc/.hermes/harness';
const REPORTS_DIR = '/home/opc/.hermes/harness/reports';

/**
 * ArXiv API wrapper
 */
class ArXivResearch {
  constructor(options = {}) {
    this.baseUrl = 'export.arxiv.org';
    this.maxResults = options.maxResults || 10;
  }

  /**
   * Search papers by keyword
   */
  async search(keyword, options = {}) {
    const maxResults = options.maxResults || this.maxResults;
    const sortBy = options.sortBy || 'submittedDate';
    const sortOrder = options.sortOrder || 'descending';
    
    const query = encodeURIComponent(keyword);
    const path = `/api/query?search_query=all:${query}&max_results=${maxResults}&sortBy=${sortBy}&sortOrder=${sortOrder}`;
    
    return await this._request(path);
  }

  /**
   * Get paper by ID
   */
  async getPaper(id) {
    const path = `/api/query?id_list=${id}`;
    return await this._request(path);
  }

  /**
   * Get multiple papers by IDs
   */
  async getPapers(ids) {
    const path = `/api/query?id_list=${ids.join(',')}`;
    return await this._request(path);
  }

  /**
   * Make HTTP request with retry with exponential backoff and jitter
   */
  async _request(path, retries = 5, baseDelay = 3000) {
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        const data = await this._doRequest(path);
        return this._parseXML(data);
      } catch (error) {
        if (error.message.includes('429') && attempt < retries) {
          // Exponential backoff: baseDelay * 2^(attempt-1) + random jitter (0-1s)
          const delay = baseDelay * Math.pow(2, attempt - 1) + (Math.random() * 1000);
          const retryAfter = error.retryAfter || Math.ceil(delay / 1000);
          console.log(`   Rate limited, retrying in ${retryAfter}s... (${attempt}/${retries})`);
          await new Promise(r => setTimeout(r, delay));
          continue;
        }
        throw error;
      }
    }
  }

  _doRequest(path) {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: this.baseUrl,
        path: path,
        method: 'GET',
        headers: {
          'Accept': 'application/atom+xml',
          'User-Agent': 'Mozilla/5.0 (compatible; HermesResearch/1.0)'
        }
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            resolve(data);
          } else if (res.statusCode === 429) {
            reject(new Error('429'));
          } else {
            reject(new Error(`HTTP ${res.statusCode}`));
          }
        });
      });

      req.on('error', reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  /**
   * Parse ArXiv Atom XML response
   */
  _parseXML(xml) {
    const papers = [];
    const entries = xml.split('<entry>');
    
    for (let i = 1; i < entries.length; i++) {
      const entry = entries[i];
      papers.push({
        id: this._extract(entry, 'id'),
        title: this._extract(entry, 'title').replace(/\s+/g, ' ').trim(),
        summary: this._extract(entry, 'summary').replace(/\s+/g, ' ').trim(),
        published: this._extract(entry, 'published'),
        updated: this._extract(entry, 'updated'),
        authors: this._extractAll(entry, 'author', 'name'),
        categories: this._extractAll(entry, 'category', 'term'),
        pdf: this._extract(entry, 'link[rel="related"][type="application/pdf"]', 'href') || 
             this._extract(entry, 'link[type="application/pdf"]', 'href'),
        abs: this._extract(entry, 'link[rel="alternate"][type="text/html"]', 'href')
      });
    }
    
    return {
      count: papers.length,
      papers
    };
  }

  _extract(xml, tag, attr) {
    if (attr) {
      const regex = new RegExp(`<${tag}[^>]*${attr}="([^"]*)"`, 'i');
      const match = xml.match(regex);
      return match ? match[1] : null;
    }
    const regex = new RegExp(`<${tag}>([^<]*)</${tag}>`, 'i');
    const match = xml.match(regex);
    return match ? match[1] : null;
  }

  _extractAll(xml, tag, innerTag) {
    const regex = new RegExp(`<${tag}[^>]*>([^<]*<${innerTag}[^>]*>[^<]*</${innerTag}>[^<]*</${tag}>|)`, 'gi');
    const matches = xml.match(regex) || [];
    return matches.map(m => {
      const inner = this._extract(m, innerTag);
      return inner;
    }).filter(Boolean);
  }
}

/**
 * Format paper for display
 */
function formatPaper(paper, index) {
  const shortId = paper.id.split('/').pop();
  return `
${index}. **${paper.title}**

   📄 ID: \`${shortId}\`
   📅 Published: ${paper.published?.split('T')[0] || 'N/A'}
   👥 Authors: ${paper.authors.slice(0, 3).join(', ')}${paper.authors.length > 3 ? '...' : ''}
   🏷️ Categories: ${paper.categories.slice(0, 3).join(', ')}
   📎 PDF: ${paper.pdf || 'N/A'}
   
   ${paper.summary?.substring(0, 200)}...
`;
}

/**
 * Generate research report
 */
async function generateResearchReport(keyword, options = {}) {
  console.log(`🔍 Searching ArXiv for: "${keyword}"\n`);
  
  const arxiv = new ArXivResearch({ maxResults: options.maxResults || 10 });
  
  try {
    const results = await arxiv.search(keyword, options);
    
    console.log(`✅ Found ${results.count} papers\n`);
    
    // Create report
    const report = {
      meta: {
        keyword,
        generatedAt: new Date().toISOString(),
        source: 'ArXiv API',
        count: results.count
      },
      papers: results.papers.map((p, i) => ({
        index: i + 1,
        id: p.id,
        title: p.title,
        summary: p.summary?.substring(0, 500),
        published: p.published,
        authors: p.authors,
        categories: p.categories,
        pdf: p.pdf
      })),
      recommendations: generateRecommendations(results.papers)
    };
    
    // Save JSON report
    const timestamp = Date.now();
    const jsonPath = path.join(REPORTS_DIR, `research-${timestamp}.json`);
    await fs.mkdir(REPORTS_DIR, { recursive: true });
    await fs.writeFile(jsonPath, JSON.stringify(report, null, 2));
    
    // Save MD report
    const mdContent = generateMarkdownReport(keyword, results.papers);
    const mdPath = path.join(REPORTS_DIR, `research-${timestamp}.md`);
    await fs.writeFile(mdPath, mdContent);
    
    console.log(`📄 Reports saved:`);
    console.log(`   JSON: ${jsonPath}`);
    console.log(`   MD: ${mdPath}`);
    
    return { report, jsonPath, mdPath };
    
  } catch (error) {
    console.error(`❌ Error: ${error.message}`);
    throw error;
  }
}

/**
 * Generate recommendations based on papers
 */
function generateRecommendations(papers) {
  const recommendations = [];
  
  // Analyze categories
  const categories = papers.flatMap(p => p.categories || []);
  const topCategories = [...new Set(categories)]
    .map(c => ({ category: c, count: categories.filter(cat => cat === c).length }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  
  if (topCategories.length > 0) {
    recommendations.push({
      type: 'trending_topics',
      message: `Most common categories: ${topCategories.map(c => `${c.category} (${c.count})`).join(', ')}`
    });
  }
  
  // Find recent papers
  const recentCount = papers.filter(p => {
    const date = new Date(p.published);
    const monthAgo = new Date();
    monthAgo.setMonth(monthAgo.getMonth() - 1);
    return date > monthAgo;
  }).length;
  
  if (recentCount > 0) {
    recommendations.push({
      type: 'recent_papers',
      message: `${recentCount} paper(s) published in the last month`
    });
  }
  
  return recommendations;
}

/**
 * Generate markdown report
 */
function generateMarkdownReport(keyword, papers) {
  let md = `# ArXiv Research Report: "${keyword}"

> Generated: ${new Date().toISOString()}
> Total papers: ${papers.length}

---

## 📚 Papers

`;
  
  papers.forEach((paper, i) => {
    const shortId = paper.id?.split('/').pop() || 'N/A';
    md += `### ${i + 1}. ${paper.title || 'Untitled'}

**ID:** \`${shortId}\`  
**Published:** ${paper.published?.split('T')[0] || 'N/A'}  
**Authors:** ${paper.authors?.join(', ') || 'Unknown'}  
**Categories:** ${paper.categories?.join(', ') || 'None'}

**Abstract:**
${paper.summary?.substring(0, 500) || 'No abstract available'}...

**PDF:** ${paper.pdf || 'N/A'}

---
`;
  });
  
  md += `
## 📊 Summary

- Total papers: ${papers.length}
- Generated: ${new Date().toISOString()}
- Source: ArXiv API

---
*Generated by Hermes Harness - ArXiv Research Integration*
`;
  
  return md;
}

// CLI usage
async function main() {
  const args = process.argv.slice(2);
  const keyword = args[0] || 'AI agent';
  const maxResults = parseInt(args.find(a => a.startsWith('--max='))?.split('=')[1] || '10');
  
  console.log('🔬 Hermes Harness - ArXiv Research\n');
  console.log(`Searching for: "${keyword}" (max ${maxResults} results)\n`);
  
  await generateResearchReport(keyword, { maxResults });
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = { ArXivResearch, generateResearchReport };
