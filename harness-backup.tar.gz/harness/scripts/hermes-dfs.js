#!/usr/bin/env node
/**
 * Hermes DFS CLI - Depth-First 錯誤分析工具
 * 
 * 用法:
 *   node hermes-dfs.js "你的錯誤信息" [source]
 *   node hermes-dfs.js --file /path/to/error.log
 *   node hermes-dfs.js --interactive
 * 
 * 示例:
 *   node hermes-dfs.js "TypeError: Cannot read property of undefined" RUNTIME
 *   node hermes-dfs.js --file ./error.log
 */

const fs = require('fs');
const path = require('path');

// Add core to module path
const corePath = path.join(__dirname, '..', 'core');
require('module').globalPaths.push(corePath);

const CapabilityAnalyzer = require(path.join(corePath, 'capability-analyzer'));
const DepthFirstDebugger = require(path.join(corePath, 'depth-first-debugger'));

class HermesDFSCLI {
  constructor() {
    this.analyzer = new CapabilityAnalyzer();
    this.debugger = new DepthFirstDebugger();
    
    this.colors = {
      reset: '\x1b[0m',
      bright: '\x1b[1m',
      dim: '\x1b[2m',
      red: '\x1b[31m',
      yellow: '\x1b[33m',
      green: '\x1b[32m',
      blue: '\x1b[34m',
      cyan: '\x1b[36m'
    };
  }
  
  /**
   * 解析命令列參數
   */
  parseArgs(args) {
    if (args.includes('--help') || args.includes('-h')) {
      return { mode: 'help' };
    }
    if (args.includes('--interactive') || args.includes('-i')) {
      return { mode: 'interactive' };
    }
    if (args.includes('--file') || args.includes('-f')) {
      const idx = args.indexOf('--file') !== -1 ? args.indexOf('--file') : args.indexOf('-f');
      return { mode: 'file', path: args[idx + 1] };
    }
    
    // Default: analyze error text directly
    const errorText = args[0] || '';
    const source = args[1] || this.guessSource(errorText);
    
    return { mode: 'direct', errorText, source };
  }
  
  /**
   * 猜測錯誤 source
   */
  guessSource(text) {
    const lower = text.toLowerCase();
    if (lower.includes('net::') || lower.includes('fetch') || lower.includes('http') || lower.includes('connection')) {
      return 'NETWORK';
    }
    if (lower.includes('401') || lower.includes('403') || lower.includes('unauthorized') || lower.includes('auth') || lower.includes('token')) {
      return 'AUTH';
    }
    if (lower.includes('redux') || lower.includes('state') || lower.includes('store')) {
      return 'STATE';
    }
    if (lower.includes('render') || lower.includes('dom') || lower.includes('css')) {
      return 'RENDER';
    }
    return 'RUNTIME';
  }
  
  /**
   * 從文件讀取錯誤
   */
  readErrorFromFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      // Try to extract last error from log
      const lines = content.split('\n').filter(l => l.trim());
      const lastLines = lines.slice(-20).join('\n');
      return lastLines;
    } catch (e) {
      throw new Error(`Cannot read file: ${filePath}`);
    }
  }
  
  /**
   * 打印幫助
   */
  printHelp() {
    console.log(`
${this.colors.cyan}${this.colors.bright}Hermes DFS - Depth-First 錯誤分析 CLI${this.colors.reset}

${this.colors.green}用法:${this.colors.reset}
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} "<錯誤信息>" [SOURCE]
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} --file <日誌文件>
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} --interactive

${this.colors.green}參數:${this.colors.reset}
  <錯誤信息>    錯誤文字或消息
  SOURCE        錯誤來源: NETWORK, RUNTIME, STATE, RENDER, AUTH
               (默認自動檢測)

${this.colors.green}示例:${this.colors.reset}
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} "TypeError: Cannot read property of undefined"
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} "Failed to fetch: 401" AUTH
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} --file ./error.log
  ${this.colors.yellow}node hermes-dfs.js${this.colors.reset} -i

${this.colors.green}源代碼整合:${this.colors.reset}
  在你的代碼中加入:
  const { analyzeError } = require('hermes-dfs');
  try {
    await myFunction();
  } catch (e) {
    analyzeError(e, { context: 'myModule' });
  }
`);
  }
  
  /**
   * 執行 DFS 分析
   */
  async analyze(errorText, source = 'RUNTIME') {
    console.log(`\n${this.colors.cyan}🔍 分析錯誤...${this.colors.reset}\n`);
    
    const error = {
      type: 'cli',
      text: errorText,
      source: source,
      timestamp: Date.now()
    };
    
    // 執行 DFS 分析
    const diagResult = await this.debugger.diagnose(error, {});
    
    // 打印結果
    this.printResult(errorText, source, diagResult);
    
    return diagResult;
  }
  
  /**
   * 打印分析結果
   */
  printResult(errorText, source, result) {
    const { rootCause, confidence, fixActions } = result;
    
    console.log(`${this.colors.red}╔════════════════════════════════════════════════════════════╗${this.colors.reset}`);
    console.log(`${this.colors.red}║${this.colors.reset}  ${this.colors.bright}🌲 Hermes DFS 分析結果${this.colors.reset}`.padEnd(63) + `${this.colors.red}║${this.colors.reset}`);
    console.log(`${this.colors.red}╚════════════════════════════════════════════════════════════╝${this.colors.reset}`);
    
    console.log(`\n${this.colors.yellow}📌 錯誤:${this.colors.reset} ${errorText}`);
    console.log(`${this.colors.yellow}📂 Source:${this.colors.reset} ${source}\n`);
    
    console.log(`${this.colors.cyan}🔍 根本原因:${this.colors.reset}`);
    console.log(`   ${this.colors.bright}${rootCause?.label || 'Unknown'}${this.colors.reset}`);
    console.log(`   Confidence: ${this.colors.green}${Math.round(confidence * 100)}%${this.colors.reset}\n`);
    
    if (fixActions && fixActions.length > 0) {
      console.log(`${this.colors.green}🛠️  建議修復:${this.colors.reset}`);
      fixActions.forEach((action, i) => {
        const cmd = action.cmd || action.message || (typeof action === 'string' ? action : JSON.stringify(action));
        if (cmd && cmd !== 'undefined') {
          console.log(`   ${this.colors.yellow}${i + 1}.${this.colors.reset} ${cmd}`);
          if (action.type) {
            console.log(`      ${this.colors.dim}[${action.type}]${this.colors.reset}`);
          }
        }
      });
    }
    
    console.log(`\n${this.colors.dim}Analysis ID: ${result.diagnosticTree?.id || 'N/A'}${this.colors.reset}`);
  }
  
  /**
   * 互動模式
   */
  async interactive() {
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    
    const question = (q) => new Promise(resolve => rl.question(q, resolve));
    
    console.log(`\n${this.colors.cyan}${this.colors.bright}Hermes DFS 互動模式${this.colors.reset}`);
    console.log('輸入錯誤信息進行分析，輸入 q 退出\n');
    
    while (true) {
      const input = await question(`${this.colors.yellow}錯誤信息 > ${this.colors.reset}`);
      
      if (input.toLowerCase() === 'q' || input.toLowerCase() === 'quit') {
        console.log('Bye!');
        break;
      }
      
      if (!input.trim()) continue;
      
      const source = await question(`${this.colors.yellow}Source (NETWORK/RUNTIME/STATE/RENDER/AUTH) [auto]: ${this.colors.reset}`);
      const detectedSource = source.trim() || this.guessSource(input);
      
      await this.analyze(input, detectedSource);
    }
    
    rl.close();
  }
  
  /**
   * 主入口
   */
  async main() {
    const args = process.argv.slice(2);
    const opts = this.parseArgs(args);
    
    try {
      switch (opts.mode) {
        case 'help':
          this.printHelp();
          break;
        case 'interactive':
          await this.interactive();
          break;
        case 'file':
          const content = this.readErrorFromFile(opts.path);
          await this.analyze(content, this.guessSource(content));
          break;
        case 'direct':
        default:
          await this.analyze(opts.errorText, opts.source);
      }
    } catch (e) {
      console.error(`${this.colors.red}Error: ${e.message}${this.colors.reset}`);
      if (args.includes('--debug')) {
        console.error(e.stack);
      }
      process.exit(1);
    }
  }
}

// 導出模組介面（供其他模組調用）
function analyzeError(error, options = {}) {
  const debugger_ = new DepthFirstDebugger();
  
  const errorObj = {
    type: 'integrated',
    text: error.message || String(error),
    source: options.source || 'RUNTIME',
    timestamp: Date.now(),
    stack: error.stack
  };
  
  return debugger_.diagnose(errorObj, options.context || {});
}

// 獨立運行
if (require.main === module) {
  const cli = new HermesDFSCLI();
  cli.main();
}

module.exports = { HermesDFSCLI, analyzeError };
