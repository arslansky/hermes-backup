/**
 * Blogwatcher Integration - RSS/Atom Feed 監控 (v2)
 */

const https = require('https');
const http = require('http');
const { URL } = require('url');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');

const STATE_DIR = '/home/opc/.hermes/harness/state';
const FEEDS_FILE = path.join(STATE_DIR, 'blogwatcher-feeds.json');

class Blogwatcher {
  constructor() {
    this.feeds = new Map();
  }

  /**
   * Add a feed to monitor
   */
  async addFeed(name, url) {
    this.feeds.set(name, {
      url,
      name,
      addedAt: new Date().toISOString(),
      lastFetched: null,
      articles: []
    });
    await this._saveFeeds();
    console.log(`✅ Added feed: ${name} (${url})`);
  }

  /**
   * Remove a feed
   */
  async removeFeed(name) {
    if (this.feeds.delete(name)) {
      await this._saveFeeds();
      console.log(`✅ Removed feed: ${name}`);
    }
  }

  /**
   * Fetch all feeds
   */
  async fetchAll() {
    console.log(`\n🔍 Checking ${this.feeds.size} feeds...\n`);
    
    const results = [];
    
    for (const [name, feed] of this.feeds) {
      try {
        const articles = await this._fetchFeed(feed);
        results.push({
          feed: name,
          url: feed.url,
          count: articles.length,
          articles
        });
        feed.lastFetched = new Date().toISOString();
        feed.articles = articles;
      } catch (error) {
        console.log(`❌ Error fetching ${name}: ${error.message}`);
        results.push({
          feed: name,
          url: feed.url,
          error: error.message,
          articles: []
        });
      }
    }
    
    await this._saveFeeds();
    
    return results;
  }

  /**
   * Get new articles since last check
   */
  async getNewArticles() {
    const results = await this.fetchAll();
    const newArticles = [];
    
    for (const result of results) {
      if (result.error) continue;
      for (const article of result.articles) {
        if (!article.read) {
          newArticles.push({
            ...article,
            feedName: result.feed,
            feedUrl: result.url
          });
        }
      }
    }
    
    return newArticles;
  }

  /**
   * Fetch a single feed
   */
  async _fetchFeed(feed) {
    const content = await this._httpGet(feed.url);
    return this._parseFeed(content, feed.url);
  }

  /**
   * Parse RSS or Atom feed
   */
  _parseFeed(content, baseUrl) {
    const articles = [];
    
    // Detect feed type
    if (content.includes('<rss') || content.includes('<channel>')) {
      // RSS 2.0
      const items = content.split('<item>').slice(1);
      for (const item of items) {
        const endIndex = item.indexOf('</item>');
        const itemContent = item.substring(0, endIndex);
        const article = this._parseRSSItem(itemContent, baseUrl);
        if (article) articles.push(article);
      }
    } else if (content.includes('<feed') || content.includes('<entry>')) {
      // Atom
      const entries = content.split('<entry>').slice(1);
      for (const entry of entries) {
        const endIndex = entry.indexOf('</entry>');
        const entryContent = entry.substring(0, endIndex);
        const article = this._parseAtomEntry(entryContent, baseUrl);
        if (article) articles.push(article);
      }
    }
    
    return articles;
  }

  /**
   * Extract CDATA or text content from tag
   */
  _extract(item, tag) {
    // Try CDATA first
    const cdataRegex = new RegExp(`<${tag}[^>]*>\\s*<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>\\s*<\\/${tag}>`, 'i');
    const cdataMatch = item.match(cdataRegex);
    if (cdataMatch) return cdataMatch[1].trim();
    
    // Try simple text
    const textRegex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i');
    const textMatch = item.match(textRegex);
    return textMatch ? textMatch[1].trim() : '';
  }

  /**
   * Extract attribute from tag
   */
  _extractAttr(item, tag, attr) {
    const regex = new RegExp(`${tag}[^>]*${attr}="([^"]*)"`, 'i');
    const match = item.match(regex);
    return match ? match[1] : '';
  }

  /**
   * Clean HTML entities and tags
   */
  _cleanHTML(text) {
    return text
      .replace(/<[^>]*>/g, '')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  _parseRSSItem(item, baseUrl) {
    const title = this._cleanHTML(this._extract(item, 'title'));
    const link = this._extract(item, 'link');
    const description = this._cleanHTML(this._extract(item, 'description'));
    const pubDate = this._extract(item, 'pubDate') || this._extract(item, 'dc:date');
    const guid = this._extract(item, 'guid') || link;

    if (!title) return null;

    return {
      id: crypto.createHash('md5').update(guid).digest('hex').substring(0, 16),
      title,
      link: link || baseUrl,
      description: description.substring(0, 300),
      published: pubDate ? new Date(pubDate).toISOString() : new Date().toISOString(),
      feed: baseUrl,
      read: false
    };
  }

  _parseAtomEntry(entry, baseUrl) {
    const title = this._cleanHTML(this._extract(entry, 'title'));
    const link = this._extractAttr(entry, 'link', 'href');
    const summary = this._cleanHTML(this._extract(entry, 'summary') || this._extract(entry, 'content'));
    const published = this._extract(entry, 'published') || this._extract(entry, 'updated');
    const id = this._extract(entry, 'id') || link;

    if (!title) return null;

    return {
      id: crypto.createHash('md5').update(id).digest('hex').substring(0, 16),
      title,
      link: link || baseUrl,
      description: summary.substring(0, 300),
      published: published ? new Date(published).toISOString() : new Date().toISOString(),
      feed: baseUrl,
      read: false
    };
  }

  _httpGet(url) {
    return new Promise((resolve, reject) => {
      const parsed = new URL(url);
      const options = {
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: 'GET',
        headers: {
          'User-Agent': 'Hermes Blogwatcher/1.0',
          'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*'
        }
      };

      const req = (parsed.protocol === 'https:' ? https : http).request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve(data));
      });

      req.on('error', reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      req.end();
    });
  }

  async _saveFeeds() {
    const data = Object.fromEntries(this.feeds);
    await fs.mkdir(STATE_DIR, { recursive: true });
    await fs.writeFile(FEEDS_FILE, JSON.stringify(data, null, 2));
  }

  async _loadFeeds() {
    try {
      const data = JSON.parse(await fs.readFile(FEEDS_FILE, 'utf8'));
      for (const [name, feed] of Object.entries(data)) {
        this.feeds.set(name, feed);
      }
    } catch (e) {
      // No feeds saved yet
    }
  }

  formatArticle(article, index) {
    const date = new Date(article.published).toLocaleDateString('zh-TW', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });

    return `
${index}. **${article.title}**

   📰 ${article.feedName || article.feed}
   📅 ${date}
   🔗 ${article.link}
   
   ${article.description ? article.description.substring(0, 150) + '...' : ''}
`;
  }
}

// Default feeds for AI/tech news
const DEFAULT_FEEDS = [
  { name: 'TechCrunch', url: 'https://techcrunch.com/feed/' },
  { name: 'The Verge', url: 'https://www.theverge.com/rss/index.xml' },
  { name: 'ArXiv CS.AI', url: 'https://arxiv.org/rss/cs.AI' },
  { name: 'Hacker News', url: 'https://hnrss.org/frontpage' }
];

async function main() {
  const watcher = new Blogwatcher();
  await watcher._loadFeeds();

  console.log('📰 Hermes Harness - Blogwatcher\n');

  // Add default feeds if none exist
  if (watcher.feeds.size === 0) {
    console.log('📋 Adding default AI/tech feeds...\n');
    for (const feed of DEFAULT_FEEDS) {
      await watcher.addFeed(feed.name, feed.url);
    }
  }

  // Fetch all feeds
  const results = await watcher.fetchAll();
  const allArticles = [];

  for (const result of results) {
    if (result.error) {
      console.log(`❌ ${result.feed}: ${result.error}`);
    } else {
      console.log(`✅ ${result.feed}: ${result.count} articles`);
      allArticles.push(...result.articles.map(a => ({ ...a, feedName: result.feed })));
    }
  }

  // Sort by date
  allArticles.sort((a, b) => new Date(b.published) - new Date(a.published));

  // Display latest
  console.log('\n========================================');
  console.log(`📰 Latest ${Math.min(10, allArticles.length)} Articles`);
  console.log('========================================\n');

  allArticles.slice(0, 10).forEach((article, i) => {
    console.log(watcher.formatArticle(article, i + 1));
  });

  // Save state
  const stateFile = path.join(STATE_DIR, 'blogwatcher-state.json');
  await fs.writeFile(stateFile, JSON.stringify({
    lastCheck: new Date().toISOString(),
    totalArticles: allArticles.length
  }, null, 2));

  console.log(`\n✅ Blogwatcher check complete: ${allArticles.length} articles from ${results.length} feeds`);
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = { Blogwatcher, DEFAULT_FEEDS };
