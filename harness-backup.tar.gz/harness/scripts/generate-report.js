/**
 * Generate Report Script - 生成測試報告
 * 
 * 快速生成測試報告
 */

const DebugHarness = require('../core/index');

async function main() {
  console.log('🔧 Hermes Harness - Report Generator\n');
  
  // Initialize harness
  const harness = new DebugHarness({ headless: true });
  await harness.init();
  await harness.launchBrowser();
  
  // Navigate to test page
  console.log('🌐 Opening test page...');
  await harness.page.goto('https://example.com');
  
  // Collect some basic data
  const title = await harness.page.title();
  console.log(`✅ Page loaded: ${title}`);
  
  // Generate report
  console.log('\n📄 Generating report...');
  const report = await harness.generateReport(`quick-test-${Date.now()}`);
  
  console.log('\n========================================');
  console.log('✅ Report generated successfully!');
  console.log('========================================');
  console.log(`📁 JSON: ${report.json}`);
  console.log(`📝 MD: ${report.md}`);
  console.log(`🌐 HTML: ${report.html}`);
  console.log('\n');
  
  await harness.cleanup();
}

main().catch(e => {
  console.error('Report generation error:', e);
  process.exit(1);
});
