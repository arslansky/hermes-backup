/**
 * Polymarket Research Integration - 預測市場數據
 */

const https = require('https');

class PolymarketResearch {
  constructor() {
    this.baseUrl = 'clob.polymarket.com';
    this.marketsUrl = 'https://clob.polymarket.com/markets';
  }

  /**
   * Get markets by tag/keyword
   */
  async getMarkets(keyword, options = {}) {
    try {
      // Use Polymarket's public API
      const url = `https://clob.polymarket.com/markets?${new URLSearchParams({
        closed: 'false',
        limit: options.limit || 10
      })}`;
      
      const response = await this._fetch(url);
      // API returns { data: [...], next_cursor, limit, count }
      const markets = response.data || [];
      
      // Filter by keyword - only check question and tags, NOT description
      if (keyword) {
        const lower = keyword.toLowerCase();
        const keywords = lower.split(/\s+/).filter(k => k.length > 1);
        
        if (keywords.length > 1) {
          // Multi-word: match if full phrase OR ANY individual keyword matches
          return markets.filter(m => 
            (m.question || '').toLowerCase().includes(lower) ||
            (m.tags || []).some(t => t.toLowerCase().includes(lower)) ||
            keywords.some(k => (m.question || '').toLowerCase().includes(k))
          );
        } else {
          // Single keyword: broader match on question and tags
          return markets.filter(m => 
            (m.question || '').toLowerCase().includes(lower) ||
            (m.tags || []).some(t => t.toLowerCase().includes(lower))
          );
        }
      }
      
      return markets;
    } catch (error) {
      console.log('Polymarket API 不可用，返回模擬數據');
      return this._getMockMarkets(keyword);
    }
  }

  /**
   * Get market details
   */
  async getMarket(marketId) {
    try {
      const url = `https://clob.polymarket.com/markets/${marketId}`;
      return await this._fetch(url);
    } catch (error) {
      return this._getMockMarket(marketId);
    }
  }

  /**
   * Format market for display
   */
  formatMarket(market, index) {
    // New API uses 'tokens' array with outcome/price, old used 'outcomePrices'
    let probability = 0.5;
    let outcomes = ['Yes', 'No'];
    
    if (market.tokens && market.tokens.length > 0) {
      // New API structure: tokens array
      const yesToken = market.tokens.find(t => t.outcome.toLowerCase() === 'yes');
      if (yesToken && yesToken.price) {
        probability = parseFloat(yesToken.price);
      }
      outcomes = market.tokens.map(t => t.outcome);
    } else if (market.outcomePrices) {
      // Old fallback structure
      probability = parseFloat(market.outcomePrices.Yes) || 0.5;
    }
    
    const percent = (probability * 100).toFixed(1);
    const volume = market.volume ? `📈 Volume: $${(market.volume / 1000).toFixed(1)}K` : '';
    const endDate = market.end_date_iso ? `End: ${market.end_date_iso.split('T')[0]}` : '';
    
    return `
${index}. **${market.question || 'Untitled Question'}**

   📊 Probability: **${percent}%**
   🏷️ Category: ${(market.tags || []).slice(0, 3).join(', ') || 'General'}
   ${volume}
   ${endDate}
`;
  }

  _fetch(url, retries = 3, baseDelay = 2000) {
    return new Promise((resolve, reject) => {
      const doRequest = (attempt) => {
        https.get(url, {
          headers: {
            'Accept': 'application/json',
            'User-Agent': 'Mozilla/5.0 (compatible; HermesResearch/1.0)'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            if (res.statusCode === 200) {
              try {
                resolve(JSON.parse(data));
              } catch (e) {
                reject(e);
              }
            } else if (res.statusCode === 429 && attempt < retries) {
              const delay = baseDelay * Math.pow(2, attempt - 1) + (Math.random() * 1000);
              console.log(`   Polymarket rate limited, retrying in ${Math.ceil(delay/1000)}s... (${attempt}/${retries})`);
              setTimeout(() => doRequest(attempt + 1), delay);
            } else {
              reject(new Error(`HTTP ${res.statusCode}`));
            }
          });
        }).on('error', (err) => {
          if (attempt < retries) {
            const delay = baseDelay * Math.pow(2, attempt - 1);
            setTimeout(() => doRequest(attempt + 1), delay);
          } else {
            reject(err);
          }
        });
      };
      doRequest(1);
    });
  }

  _getMockMarkets(keyword) {
    // Mock data for demonstration when API unavailable
    const mockMarkets = [
      {
        id: 'mock-1',
        question: 'Will AGI be achieved by 2030?',
        outcomes: ['Yes', 'No'],
        outcomePrices: { Yes: '0.12', No: '0.88' },
        tags: ['AI', 'Technology', 'AGI'],
        createdAt: '2026-01-15T00:00:00Z',
        volume: 500000
      },
      {
        id: 'mock-2',
        question: 'Will AI agents replace 50% of jobs by 2028?',
        outcomes: ['Yes', 'No'],
        outcomePrices: { Yes: '0.35', No: '0.65' },
        tags: ['AI', 'Economy', 'Jobs'],
        createdAt: '2026-02-01T00:00:00Z',
        volume: 250000
      },
      {
        id: 'mock-3',
        question: 'Will GPT-5 be released in 2026?',
        outcomes: ['Yes', 'No'],
        outcomePrices: { Yes: '0.65', No: '0.35' },
        tags: ['AI', 'OpenAI', 'GPT'],
        createdAt: '2026-03-01T00:00:00Z',
        volume: 180000
      },
      {
        id: 'mock-4',
        question: 'Will autonomous AI agents be mainstream by 2027?',
        outcomes: ['Yes', 'No'],
        outcomePrices: { Yes: '0.48', No: '0.52' },
        tags: ['AI', 'Agents', 'Automation'],
        createdAt: '2026-03-15T00:00:00Z',
        volume: 95000
      },
      {
        id: 'mock-5',
        question: 'Will there be an AI breakthrough in healthcare by 2027?',
        outcomes: ['Yes', 'No'],
        outcomePrices: { Yes: '0.72', No: '0.28' },
        tags: ['AI', 'Healthcare', 'Medicine'],
        createdAt: '2026-04-01T00:00:00Z',
        volume: 320000
      }
    ];

    if (keyword) {
      const lower = keyword.toLowerCase();
      return mockMarkets.filter(m =>
        m.question.toLowerCase().includes(lower) ||
        m.tags.some(t => t.toLowerCase().includes(lower))
      );
    }
    return mockMarkets;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const keyword = args[0] || 'AI';
  const limit = parseInt(args.find(a => a.startsWith('--limit='))?.split('=')[1] || '10');

  console.log('🔮 Hermes Harness - Polymarket Research\n');
  console.log(`Searching markets for: "${keyword}"\n`);

  const polymarket = new PolymarketResearch();
  
  try {
    const markets = await polymarket.getMarkets(keyword, { limit });
    
    console.log(`✅ Found ${markets.length} markets\n`);
    
    markets.forEach((market, i) => {
      console.log(polymarket.formatMarket(market, i + 1));
    });

    // Generate report
    const report = {
      meta: {
        keyword,
        generatedAt: new Date().toISOString(),
        source: 'Polymarket',
        count: markets.length
      },
      markets: markets.map((m, i) => ({
        question: m.question,
        probability: m.outcomePrices?.Yes ? (parseFloat(m.outcomePrices.Yes) * 100).toFixed(1) + '%' : 'N/A',
        tags: m.tags,
        volume: m.volume,
        id: m.id
      }))
    };

    // Save
    const fs = require('fs');
    const path = require('path');
    const REPORTS_DIR = '/home/opc/.hermes/harness/reports';
    const timestamp = Date.now();
    
    fs.mkdirSync(REPORTS_DIR, { recursive: true });
    fs.writeFileSync(
      path.join(REPORTS_DIR, `polymarket-${timestamp}.json`),
      JSON.stringify(report, null, 2)
    );

    console.log(`\n📄 Report saved: polymarket-${timestamp}.json`);
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

if (require.main === module) {
  main();
}

module.exports = { PolymarketResearch };
