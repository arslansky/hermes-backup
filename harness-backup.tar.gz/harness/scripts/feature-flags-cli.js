#!/usr/bin/env node
/**
 * Feature Flag Management CLI
 * 
 * 用於管理 Harness 研究功能的開關
 * 
 * 使用方式：
 *   node feature-flags-cli.js list
 *   node feature-flags-cli.js status <flag-name>
 *   node feature-flags-cli.js enable <flag-name>
 *   node feature-flags-cli.js disable <flag-name>
 *   node feature-flags-cli.js toggle <flag-name>
 *   node feature-flags-cli.js reset <flag-name>
 *   node feature-flags-cli.js active
 *   node feature-flags-cli.js emergency
 *   node feature-flags-cli.js summary
 */

const { getFeatureFlags } = require('../lib/feature-flags');

const args = process.argv.slice(2);
const command = args[0];
const flagName = args[1];
const reason = args[2] || 'cli';

const flags = getFeatureFlags();

function printUsage() {
  console.log(`
Feature Flag Management CLI

Usage:
  node feature-flags-cli.js list                      列出所有 flags
  node feature-flags-cli.js status <flag-name>        查看單個 flag 狀態
  node feature-flags-cli.js enable <flag-name> [reason]  啟用 flag
  node feature-flags-cli.js disable <flag-name> [reason] 停用 flag
  node feature-flags-cli.js toggle <flag-name> [reason]   切換 flag
  node feature-flags-cli.js reset <flag-name> [reason]    重置為預設
  node feature-flags-cli.js active                     列出所有已啟用的 flags
  node feature-flags-cli.js emergency                 緊急模式：停用所有研究功能
  node feature-flags-cli.js exit-emergency            退出緊急模式
  node feature-flags-cli.js summary                   顯示 flags 概覽

Examples:
  node feature-flags-cli.js list
  node feature-flags-cli.js enable research-openalex
  node feature-flags-cli.js disable research-polymarket "第三方API故障"
  node feature-flags-cli.js emergency
`);
}

switch (command) {
  case 'list': {
    const all = flags.getAll();
    console.log('\n========================================');
    console.log('  Feature Flags - All');
    console.log('========================================\n');
    
    // Group by type
    const groups = { release: [], ops: [], experiment: [], kill: [] };
    for (const name in all) {
      const flag = all[name];
      groups[flag.type].push({ name, ...flag });
    }
    
    for (const type of ['release', 'ops', 'experiment', 'kill']) {
      if (groups[type].length === 0) continue;
      console.log(`[${type.toUpperCase()}]`);
      groups[type].forEach(f => {
        const status = f.enabled ? '✅' : '❌';
        const override = f.override !== null ? ' (override)' : '';
        console.log(`  ${status} ${f.name}${override}`);
        console.log(`       ${f.description}`);
      });
      console.log('');
    }
    break;
  }

  case 'status': {
    if (!flagName) {
      console.error('❌ Error: flag-name required');
      printUsage();
      process.exit(1);
    }
    const all = flags.getAll();
    if (!all[flagName]) {
      console.error(`❌ Flag "${flagName}" not found`);
      process.exit(1);
    }
    const f = all[flagName];
    console.log(`\nFlag: ${flagName}`);
    console.log('========================================');
    console.log(`Description: ${f.description}`);
    console.log(`Type: ${f.type}`);
    console.log(`Enabled: ${f.enabled ? '✅ YES' : '❌ NO'}`);
    console.log(`Default: ${typeof f.default === 'object' ? JSON.stringify(f.default) : f.default}`);
    console.log(`Override: ${f.override !== null ? f.override : '(none)'}`);
    console.log('');
    break;
  }

  case 'enable': {
    if (!flagName) {
      console.error('❌ Error: flag-name required');
      process.exit(1);
    }
    flags.enable(flagName, reason);
    console.log(`✅ Enabled: ${flagName}`);
    break;
  }

  case 'disable': {
    if (!flagName) {
      console.error('❌ Error: flag-name required');
      process.exit(1);
    }
    flags.disable(flagName, reason);
    console.log(`❌ Disabled: ${flagName}`);
    break;
  }

  case 'toggle': {
    if (!flagName) {
      console.error('❌ Error: flag-name required');
      process.exit(1);
    }
    const wasEnabled = flags.isEnabled(flagName);
    flags.toggle(flagName, reason);
    console.log(`🔄 Toggled: ${flagName} (was ${wasEnabled ? 'enabled' : 'disabled'})`);
    break;
  }

  case 'reset': {
    if (!flagName) {
      console.error('❌ Error: flag-name required');
      process.exit(1);
    }
    flags.reset(flagName, reason);
    console.log(`↩️  Reset: ${flagName} (back to default)`);
    break;
  }

  case 'active': {
    const active = flags.getActiveFlags();
    console.log('\n========================================');
    console.log('  Active Flags');
    console.log('========================================\n');
    if (active.length === 0) {
      console.log('No flags active');
    } else {
      active.forEach(name => {
        const f = flags.getAll()[name];
        console.log(`✅ ${name} - ${f.description}`);
      });
    }
    console.log('');
    break;
  }

  case 'emergency': {
    flags.emergencyMode();
    console.log('🚨 EMERGENCY MODE ACTIVATED');
    console.log('All research features have been disabled.');
    console.log('Run "node feature-flags-cli.js exit-emergency" to restore.');
    break;
  }

  case 'exit-emergency': {
    flags.exitEmergencyMode();
    console.log('✅ Emergency mode deactivated');
    break;
  }

  case 'summary': {
    const s = flags.getSummary();
    console.log('\n========================================');
    console.log('  Feature Flags Summary');
    console.log('========================================\n');
    console.log(`Total flags:    ${s.total}`);
    console.log(`Active:         ${s.active} ✅`);
    console.log(`Inactive:       ${s.inactive} ❌`);
    console.log(`Overrides:      ${s.overrides}`);
    console.log(`Emergency:      ${s.emergencyMode ? '🚨 ACTIVE' : '✅ Normal'}`);
    console.log('');
    break;
  }

  default: {
    printUsage();
    break;
  }
}