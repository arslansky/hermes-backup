# 🚀 Debug Harness 快速參考卡

## 常用命令

```bash
# 進入目錄
cd /home/opc/.hermes/harness

# 研究工具
node scripts/research-arxiv.js "關鍵詞" --max=5
node scripts/research-polymarket.js "關鍵詞"
node scripts/research-blogwatcher.js
node scripts/research-semantic.js "關鍵詞" --max=5
node scripts/research-all.js "關鍵詞" --max=5  # ← 推薦

# 上傳報告
node scripts/upload-report.js

# Debug Harness
node scripts/generate-report.js
node scripts/run-tests.js
```

## 目錄結構

```
harness/
├── scripts/
│   ├── research-arxiv.js      # 學術論文 (ArXiv)
│   ├── research-polymarket.js # 預測市場
│   ├── research-blogwatcher.js # RSS 監控
│   ├── research-semantic.js  # 論文搜索 (Semantic)
│   └── research-all.js       # 統一報告 ← 最常用
├── reports/                   # 報告輸出目錄
└── state/                    # 狀態緩存
```

## Cron 任務

| 時間 | 任務 |
|------|------|
| 00 08 * * * | 每日研究報告 |
| 0 9 * * * | 每日新聞 |
| 0 */6 * * * | OpenClaw 健康檢查 |

## 查看報告

```bash
# 最新統一報告
ls -lt reports/unified-research-*.md | head -1

# 查看內容
cat reports/unified-research-*.md | head -50

# GDrive
# gdrive:/OpenClaw_Backups/Harness-Reports/
```

## 測試 API

```bash
# ArXiv
curl "https://export.arxiv.org/api/query?search_query=all:test&max_results=1"

# Semantic Scholar
curl "https://api.semanticscholar.org/graph/v1/paper/search?query=AI&limit=1&fields=title"
```

## 添加自定義 RSS

```javascript
const { Blogwatcher } = require('./scripts/research-blogwatcher');
const w = new Blogwatcher();
w._loadFeeds().then(() => {
  w.addFeed('My Blog', 'https://myblog.com/feed.xml');
});
```

## 停止自動化

```bash
crontab -e
# 刪除對應行
```

---

📌 完整文檔：`/home/opc/.hermes/harness/HARNESS-GUIDE.md`
