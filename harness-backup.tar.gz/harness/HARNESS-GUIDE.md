# 🔧 Hermes Debug Harness 使用指南

## 📋 目錄

1. [系統概覽](#系統概覽)
2. [快速開始](#快速開始)
3. [研究工具](#研究工具)
4. [自動化設置](#自動化設置)
5. [報告查看](#報告查看)
6. [常見問題](#常見問題)

---

## 🏠 系統概覽

```
┌─────────────────────────────────────────────────────────────┐
│                   Hermes Debug Harness                      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   ArXiv      │  │ Polymarket  │  │  Semantic    │     │
│  │  論文搜索    │  │  預測市場    │  │  Scholar     │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐                        │
│  │ Blogwatcher  │  │ Debug Harness│                        │
│  │  RSS 監控    │  │  測試框架    │                        │
│  └──────────────┘  └──────────────┘                        │
│                                                             │
│                         ↓                                   │
│              ┌──────────────────┐                          │
│              │   統一報告生成    │                          │
│              │   (JSON/MD/HTML)  │                          │
│              └──────────────────┘                          │
│                         ↓                                   │
│              ┌──────────────────┐                          │
│              │   Google Drive   │                          │
│              │    (rclone)      │                          │
│              └──────────────────┘                          │
└─────────────────────────────────────────────────────────────┘
```

### 文件位置

```
/home/opc/.hermes/harness/
├── core/                    # 核心框架
│   ├── index.js            # 主入口
│   ├── error-detector.js   # 錯誤檢測
│   ├── network-monitor.js   # 網絡監控
│   ├── state-inspector.js  # 狀態檢查
│   └── report-generator.js  # 報告生成
├── scripts/                 # 研究腳本
│   ├── research-arxiv.js   # ArXiv 論文
│   ├── research-polymarket.js # Polymarket 預測
│   ├── research-blogwatcher.js # RSS 監控
│   ├── research-semantic.js # Semantic Scholar
│   └── research-all.js     # 統一報告
├── reports/                # 報告輸出
└── state/                  # 狀態緩存
```

---

## 🚀 快速開始

### 基本命令

```bash
# 進入目錄
cd /home/opc/.hermes/harness

# 生成測試報告
node scripts/generate-report.js

# 查看所有報告
ls -la reports/
```

---

## 📚 研究工具

### 1. ArXiv 論文搜索

**功能：** 搜索學術論文，專注於 AI、ML、CS 領域

```bash
# 基本搜索
node scripts/research-arxiv.js "AI agent"

# 指定結果數量
node scripts/research-arxiv.js "machine learning" --max=10

# 搜索特定類別
node scripts/research-arxiv.js "neural network" --max=5
```

**輸出範例：**
```
🔬 Hermes Harness - ArXiv Research

Searching for: "AI agent" (max 5 results)

✅ Found 5 papers

1. LongSeeker: Elastic Context Orchestration for Long-Horizon Search Agents
   ID: 2605.05191v1
   Date: 2026-05-06
```

**報告位置：** `reports/research-*.md` / `reports/research-*.json`

---

### 2. Polymarket 預測市場

**功能：** 查看區塊鏈預測市場對事件發生概率的評估

```bash
# 搜索相關預測
node scripts/research-polymarket.js "AI"

# 查看更多結果
node scripts/research-polymarket.js "technology" --limit=10
```

**輸出範例：**
```
🔮 Hermes Harness - Polymarket Research

✅ Found 5 markets

1. Will AGI be achieved by 2030?
   Probability: 12.0%
   Category: AI, Technology, AGI
```

**用途：**
- 了解市場對 AI 發展的預期
- 追蹤趨勢變化
- 發現熱門話題

---

### 3. Blogwatcher RSS 監控

**功能：** 監控你關注的博客、新聞網站的最新更新

```bash
# 查看所有關注源的最新文章
node scripts/research-blogwatcher.js

# 添加新的 RSS 源
node -e "
const { Blogwatcher } = require('./scripts/research-blogwatcher');
const w = new Blogwatcher();
w._loadFeeds().then(() => {
  w.addFeed('My Blog', 'https://myblog.com/feed.xml');
});
"
```

**默認關注源：**
| 名稱 | URL |
|------|-----|
| TechCrunch | https://techcrunch.com/feed/ |
| The Verge | https://www.theverge.com/rss/index.xml |
| ArXiv CS.AI | https://arxiv.org/rss/cs.AI |
| Hacker News | https://hnrss.org/frontpage |

**狀態文件：** `state/blogwatcher-feeds.json`

---

### 4. Semantic Scholar

**功能：** 搜索學術論文，帶引用分析和作者信息

```bash
# 基本搜索
node scripts/research-semantic.js "AI agent"

# 指定結果數量
node scripts/research-semantic.js "deep learning" --max=10
```

**輸出包含：**
- 論文標題和作者
- 發表年份和會議/期刊
- 引用次數
- 影響力指標
- 摘要

**注意：** 有 rate limit (100次/小時)，腳本會自動重試

---

### 5. 統一研究報告 (推薦)

**功能：** 一次過生成包含所有數據源的完整研究報告

```bash
# 生成統一報告
node scripts/research-all.js "AI agent"

# 指定結果數量
node scripts/research-all.js "machine learning" --max=10
```

**輸出：**
```
📄 Markdown: unified-research-*.md
📊 JSON:     unified-research-*.json
🌐 HTML:     unified-research-*.html
```

**報告包含：**
- ArXiv 論文列表
- Polymarket 預測市場
- Semantic Scholar 論文
- Blogwatcher 最新文章
- 摘要統計

---

## ⏰ 自動化設置

### 查看當前 Cron 任務

```bash
crontab -l
```

### 每日自動生成研究報告

系統已設置每日 08:00 自動運行：

```
0 8 * * * /home/opc/daily_research.sh >> /home/opc/logs/research_cron.log 2>&1
```

### 自定義自動化

編輯 crontab：

```bash
crontab -e
```

**常用時間格式：**

| 格式 | 說明 |
|------|------|
| `0 8 * * *` | 每天 08:00 |
| `0 */6 * * *` | 每 6 小時 |
| `0 8 * * 1` | 每周一 08:00 |
| `0 8 1 * *` | 每月1日 08:00 |

**範例 - 每天 9 點和 21 點生成報告：**

```bash
0 9,21 * * * cd /home/opc/.hermes/harness && node scripts/research-all.js "AI agent" --max=5 >> /home/opc/logs/research.log 2>&1
```

---

## 📂 報告查看

### 本地查看

```bash
# 查看最新報告
ls -lt reports/ | head

# 查看 Markdown 報告
cat reports/unified-research-*.md | head -100

# 格式化查看 JSON
cat reports/unified-research-*.json | python3 -m json.tool | head -50
```

### 上傳到 Google Drive

```bash
# 手動上傳最新報告
node scripts/upload-report.js

# 自動上傳 (已在 daily_research.sh 集成)
```

**GDrive 位置：**
```
gdrive:/OpenClaw_Backups/Harness-Reports/
```

### 通過瀏覽器查看 HTML 報告

```bash
# 在本地開啟簡單 HTTP 服務器
cd /home/opc/.hermes/harness/reports
python3 -m http.server 8080
```

然後瀏覽器打開：`http://your-vm-ip:8080`

---

## 📊 Debug Harness (測試框架)

### 基本使用

```bash
# 運行測試
node scripts/run-tests.js

# 生成測試報告
node scripts/generate-report.js
```

### 整合到代碼

```javascript
const DebugHarness = require('./core/index');

async function myTest() {
  const harness = new DebugHarness({ headless: true });
  await harness.init();
  await harness.launchBrowser();
  
  await harness.page.goto('https://example.com');
  
  // 你的測試代碼...
  
  const report = await harness.generateReport('my-test');
  console.log('Report:', report.path);
  
  await harness.cleanup();
}
```

---

## ❓ 常見問題

### Q: ArXiv 返回 429 錯誤？

**A:** 這是 rate limit，腳本會自動重試 3 次。等几分鐘後再試。

### Q: Semantic Scholar 找不到論文？

**A:** 可能 rate limit，會自動重試。或嘗試更通用的關鍵詞。

### Q: 如何添加自定義 RSS 源？

```javascript
const { Blogwatcher } = require('./scripts/research-blogwatcher');

async function add() {
  const w = new Blogwatcher();
  await w._loadFeeds();
  await w.addFeed('網站名', 'https://example.com/feed.xml');
}

add();
```

### Q: 報告存儲在哪裡？

**A:** 
- 本地：`/home/opc/.hermes/harness/reports/`
- Gdrive：`gdrive:/OpenClaw_Backups/Harness-Reports/`

### Q: 如何查看自動化任務的日誌？

```bash
cat /home/opc/logs/research_cron.log
tail -f /home/opc/logs/research_cron.log
```

### Q: 如何停止自動化？

```bash
crontab -e
# 刪除對應的行
```

---

## 🔗 相關文件

| 文件 | 說明 |
|------|------|
| `/home/opc/.hermes/harness/README.md` | 技術文檔 |
| `/home/opc/daily_research.sh` | 每日自動化腳本 |
| `/home/opc/logs/research_cron.log` | Cron 日誌 |

---

## 📞 獲取幫助

```bash
# 查看所有可用腳本
ls -la /home/opc/.hermes/harness/scripts/

# 測試網絡連接
curl -s https://export.arxiv.org/api/query?search_query=all:test\&max_results=1 | head
```

---

*最後更新：2026-05-08*
