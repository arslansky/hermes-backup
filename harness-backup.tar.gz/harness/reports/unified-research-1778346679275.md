# 🔬 Unified Research Report: "AI testing"

> **Generated:** 2026-05-09T17:10:59.287Z
> **Topic:** AI testing

---

## 📚 ArXiv Papers (5)

### 1. UniPool: A Globally Shared Expert Pool for Mixture-of-Experts

- **ID:** `2605.06665v1`
- **Published:** 2026-05-07
- **Authors:** Minbin Huang, Han Shi, Chuanyang Zheng, Yimeng Wu, Guoxuan Chen
- **PDF:** N/A

Modern Mixture-of-Experts (MoE) architectures allocate expert capacity through a rigid per-layer rule: each transformer layer owns a separate expert set. This convention couples depth scaling with linear expert-parameter growth and assumes that every layer needs isolated expert capacity. However, re...

---
### 2. The Pulsar Radial Acceleration Relation

- **ID:** `2605.06659v1`
- **Published:** 2026-05-07
- **Authors:** Tariq Yasin, Harry Desmond
- **PDF:** N/A

The radial acceleration relation (RAR) links observed and baryonic accelerations, and is best established in rotation curves of late-type galaxies. Pulsar timing, which measures line-of-sight (LOS) differential accelerations between the Sun and pulsars, provides a novel probe of this relation, inclu...

---
### 3. AI Co-Mathematician: Accelerating Mathematicians with Agentic AI

- **ID:** `2605.06651v1`
- **Published:** 2026-05-07
- **Authors:** Daniel Zheng, Ingrid von Glehn, Yori Zwols, Iuliya Beloshapka, Lars Buesing
- **PDF:** N/A

We introduce the AI co-mathematician, a workbench for mathematicians to interactively leverage AI agents to pursue open-ended research. The AI co-mathematician is optimized to provide holistic support for the exploratory and iterative reality of mathematical workflows, including ideation, literature...

---
### 4. GlazyBench: A Benchmark for Ceramic Glaze Property Prediction and Image Generation

- **ID:** `2605.06641v1`
- **Published:** 2026-05-07
- **Authors:** Ziyu Zhai, Siyou Li, Juexi Shao, Juntao Yu
- **PDF:** N/A

Developing ceramic glazes is a costly, time-consuming process of trial and error due to complex chemistry, placing a significant burden on independent artists. While recent advances in multimodal AI offer a modern solution, the field lacks the large-scale datasets required to train these models. We ...

---
### 5. libwignernj: a reusable C/C++/Fortran/Python library for exact Wigner symbols and related coefficients

- **ID:** `2605.06634v1`
- **Published:** 2026-05-07
- **Authors:** Susi Lehtola
- **PDF:** N/A

We describe libwignernj, a freely available, BSD-licensed library that evaluates Wigner 3j, 6j, and 9j symbols, Clebsch--Gordan, Racah $W$, and Fano $X$ coefficients, and Gaunt coefficients over both complex and real spherical harmonics in standards-compliant C99. libwignernj represents factorials b...

---

---

## 🔮 Polymarket Predictions (0)

*No markets found*

---

## 📖 Semantic Scholar Papers (0)

*No papers found*

---

## 📰 Blog Updates (20)

### 1. Introduction to Beaver Triples

- **Source:** HN
- **Date:** 5/10/2026
- **Link:** https://stoffelmpc.com/stoffel-blog/beaver-triples-tuples

Article URL: https://stoffelmpc.com/stoffel-blog/beaver-triples-tuples Comments URL: https://news.ycombinator.com/item?id=48076009 Points: 3 # Comment...

---
### 2. The context window has been shattered: Subquadratic debuts a 12M token window

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://thenewstack.io/subquadratic-12-million-context-window/

Article URL: https://thenewstack.io/subquadratic-12-million-context-window/ Comments URL: https://news.ycombinator.com/item?id=48075645 Points: 20 # C...

---
### 3. PipeDream on the Acorn Archimedes

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://stonetools.ghost.io/pipedream-archimedes/

Article URL: https://stonetools.ghost.io/pipedream-archimedes/ Comments URL: https://news.ycombinator.com/item?id=48075528 Points: 37 # Comments: 12...

---
### 4. GrapheneOS fixes Android VPN leak Google refused to patch

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://cyberinsider.com/grapheneos-fixes-android-vpn-leak-google-refused-to-patch/

Article URL: https://cyberinsider.com/grapheneos-fixes-android-vpn-leak-google-refused-to-patch/ Comments URL: https://news.ycombinator.com/item?id=48...

---
### 5. Show HN: Mochi.js: bun-native high-fidelity browser automation library

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://mochijs.com/

Hi HN,I’m sharing mochi.js (https://github.com/0xchasercat/mochi), a Bun-native, raw-CDP browser automation framework. It's designed to make programma...

---
### 6. The Intolerable Hypocrisy of Cyberlibertarianism

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://matduggan.com/the-intolerable-hypocrisy-of-cyberlibertarianism/

Article URL: https://matduggan.com/the-intolerable-hypocrisy-of-cyberlibertarianism/ Comments URL: https://news.ycombinator.com/item?id=48074952 Point...

---
### 7. Read Programming as Theory Building

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://codeutopia.net/blog/2026/05/09/you-should-read-programming-as-theory-building/

Article URL: https://codeutopia.net/blog/2026/05/09/you-should-read-programming-as-theory-building/ Comments URL: https://news.ycombinator.com/item?id...

---
### 8. Internet Archive Switzerland

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://internetarchive.ch/

Article URL: https://internetarchive.ch/ Comments URL: https://news.ycombinator.com/item?id=48074265 Points: 288 # Comments: 36...

---
### 9. Forking the Web

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://dillo-browser.org/lab/web-fork/

Article URL: https://dillo-browser.org/lab/web-fork/ Comments URL: https://news.ycombinator.com/item?id=48074087 Points: 81 # Comments: 70...

---
### 10. Killswitch: Per-function short-circuit mitigation primitive

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://lwn.net/ml/all/20260507070547.2268452-1-sashal@kernel.org/

Article URL: https://lwn.net/ml/all/20260507070547.2268452-1-sashal@kernel.org/ Comments URL: https://news.ycombinator.com/item?id=48073394 Points: 59...

---

---

## 📊 Summary

| Source | Count |
|--------|-------|
| ArXiv | 5 |
| Polymarket | 0 |
| Semantic Scholar | 0 |
| Blogwatcher | 20 |

**Errors:** semantic

---

*Generated by Hermes Harness - Unified Research Report*
*Date: 2026-05-09T17:10:59.287Z*
