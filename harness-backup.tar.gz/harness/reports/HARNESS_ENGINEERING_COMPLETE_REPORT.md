# 🔧 Harness Engineering 完整研究報告

> **生成時間:** 2026-05-08  
> **來源:** ArXiv 學術論文 + 中文深度解析 PDF + OpenAI/Anthropic 官方文章

---

## 📊 資源總覽

| 來源 | 數量 | 狀態 |
|------|------|------|
| ArXiv 論文 | 50+ | ✅ 已獲取 |
| 中文深度 PDF | 1 (9頁) | ✅ 已提取 |
| OpenAI 官方文章 | 1 | ✅ 已分析 |
| Anthropic 官方文章 | 2 | ✅ 已分析 |
| Martin Fowler 網站文章 | 1 | ✅ 已分析 |

---

## 🎯 核心定義

### 公式：Harness = Agent − Model

```
一個完整 Agent 減去入面的大模型，剩下所有嘢都係 Harness
```

**例子 (Claude Code)：**
- CLAUDE.md 入面嘅規則 → Harness
- 可用工具 (Tools) → Harness
- 定時調度機制 → Harness
- 驗證框架 (Linters, Tests) → Harness
- 總之：唔係模型嘅嘢，都係 Harness

---

## 📐 三層進化框架

| 層次 | 研究範圍 | 核心問題 |
|------|---------|---------|
| **Prompt Engineering** | 點樣問 | 如何組織 Prompt，把發給模型的話說得更清楚 |
| **Context Engineering** | 點樣俾信息 | 如何在最合適嘅時機，把最合適的內容放到 Model Context |
| **Harness Engineering** | 點樣搭建系統 | 如何圍繞大模型搭建完整可靠的 Agent |

> **進化邏輯：** 關注問題越來越大 — 從「問得好」→「俾得啱」→「成個系統穩陣」

---

## 🚀 實際成果 (OpenAI 案例)

| 指標 | 數值 |
|------|------|
| 5個月 | 從零到有實際用戶的產品 |
| ~100萬行 | 全部代碼由 Codex 生成 |
| ~1,500 個 PR | 合併 |
| 3 → 7 人 engineers | 初期只需要3個工程師驅動 Codex |
| 3.5 PRs/工程師/日 | 平均吞吐量 |
| 1/10 時間 | 相比人手寫 code |

---

## 🔬 OpenAI 三大優化方向

### 1️⃣ 上下文管理 (Context Management)

**目標：** 讓 Agent 獲取充足信息

**問題：**
- 一開始嘗試用肥 AGENTS.md file，但失敗：
  - 信息太多 → 模型效果變差 (如同新人入職即管你一本厚員工手冊)
  - 文件會即時腐化，冇人更新，變成廢物

**解決方案：**
- 把 AGENTS.md 壓縮到 ~100 行 (唔係 encyclopedia，要係 map)
- 所有重要決策同約定，全部搬入代碼倉庫
- 倉庫成為唯一事實來源 (Single Source of Truth)

**檔案系統佈局：**
```
repo/
├── AGENTS.md              # ~100行，Map
├── docs/                  # 所有文檔分門別類
│   ├── index.md
│   ├── design/
│   ├── architecture/
│   └── plans/
└── [代碼]
```

### 2️⃣ 驗證與反饋 (Validation & Feedback)

**目標：** Agent 寫完代碼後，能夠驗證成果係咪正確

**實現方式：**

| 能力 | 工具/方法 |
|------|----------|
| UI 驗證 | Chrome DevTools Protocol → Agent 可以截圖、睇 DOM、模擬操作 |
| 可觀測性 | 完整 logging + metrics stack → Agent 可以讀 logs、追蹤鏈路 |
| 性能調優 | 可量化目標，例如「服務啟動時間必須 <800ms」|
| 架構合規 | Linter + 測試 → 不合規即報錯 → Agent 自動修復 → 閉環 |

**自動閉環流程：**
```
Agent 生成代碼 → Linter/測試檢測 → 不合規 → 報錯回傳 Agent → Agent 修復 → 再次檢測 → 通過
```

### 3️⃣ 技術債清理 (Technical Debt Cleanup)

**問題：** Agent 大規模生成代碼，會引入糟糕的 design patterns

**解決方案：垃圾回收機制**

| 清理對象 | 做法 |
|---------|------|
| 代碼 | 設置後台 Codex 任務，定期 scan 全碼庫，偏離規範自動修改並提交 |
| 文檔 | 同樣定期 scan 文檔庫，過時/對不上代碼的文檔自動修復 |

---

## 🏛️ Anthropic 三 Agent 架構

### Full Harness 方案 (對比 Solo 方案)

```
┌─────────────────────────────────────────────────────────────┐
│                      Full Harness 架構                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌──────────┐                                             │
│   │ Planner  │ ←── 用戶需求 (模糊)                          │
│   └──┬───────┘                                             │
│      │ 拆解為功能列表                                       │
│      ▼                                                     │
│   ┌──────────┐                                             │
│   │Generator │ ←── 功能列表                                 │
│   └──┬───────┘                                             │
│      │ 討論交付標準                                         │
│      ▼                                                     │
│   ┌──────────┐                                             │
│   │Evaluator │ ←── 評估質量 (獨立第三方)                    │
│   └──┬───────┘                                             │
│      │ 反饋                                                │
│      ▼                                                     │
│   ┌──────────┐                                             │
│   │Generator │ ←── 修改代碼                                 │
│   └──┬───────┘                                             │
│      │ 評估通過                                            │
│      ▼                                                     │
│   ✅ 完成功能點 → 下一個功能點                              │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Solo vs Full Harness 對比

| 指標 | Solo 方案 | Full Harness 方案 |
|------|----------|------------------|
| 耗時 | 20 分鐘 | 6 小時 |
| 花費 | $9 | $200 |
| 質量 | 多問題，唔可用 | 明显改善，達到可用水準 |

---

## 📚 ArXiv 論文精選

### 相關論文 (2026年5月最新)

1. **Design Conductor 2.0** - Agent 構建 TurboQuant 推理加速器 (80小時)
   - 展示了 multi-agent harness 的實際應用
   - 用了 April 2026 frontier models

2. **LongSeeker: Elastic Context Orchestration** - 長距離搜索代理
   - 研究上下文管理優化

3. **PhysForge** - 物理基礎 3D 資產生成
   - 展示 Agent 在複雜任務中的應用

---

## ⚡ 爭議與討論

### 批評者話：
- 只係換湯不換藥
- 所謂的 Harness Engineering 唔過係舊嘢重新包裝
- 門檻低，任何人都可以話自己係做呢樣嘢
- 所有技術沒有一個係新的

### 支持者話：
- OpenAI 5個月100萬行係實際成果
- Anthropic、Martin Fowler 等大咖都喺度討論
- 代表真正的範式轉移
- 工程領域真正進步在於統一的框架組織零散能力

### 爭議時間線：
```
2025-02-05  Mitchell Hashimoto 首次提出 "Harness Engineering"
2025-02-11  OpenAI 發表 Harness Engineering 文章 (引爆點)
2025-02-17  Martin Fowler 網站發表文章討論
2025-03-10  LangChain 發表 "The Anatomy of an Agent Harness"
2025-03-24  Anthropic 發表 Planner/Generator/Evaluator 架構
```

---

## 🔮 未來趨勢

### 模型越強，Harness 越少？

**事實：**
- Opus 4.5 → 上下文焦慮問題大幅緩解
- Opus 4.6 → 全域統籌能力夠強，可以一次過處理所有功能點

**推測：**
- 隨著模型能力繼續增強，今天用來約束模型、糾正模型的系統設計可能會被逐步吸收
- 但短期內 (2-3年)，Harness Engineering 仍然係最重要嘅過渡期技術

---

## 📝 實用工具棧

| 工具 | 用途 |
|------|------|
| Codex CLI / Codex | 主力 coding agent |
| `gh` | GitHub CLI，用於 pull/push/merge |
| Git worktree | 每個 change 隔離 bootable instance |
| Chrome DevTools Protocol | Agent 驅動瀏覽器 |
| LogQL / PromQL | Agent query logs/metrics |
| Custom linters | 架構 + taste enforcement |
| OpenTelemetry | Instrumentation |

---

## 📖 延伸閱讀

- [Harness Engineering 原文章 (OpenAI)](https://openai.com/index/harness-engineering/)
- [Symphony - Agent Orchestration Spec](https://github.com/openai/symphony)
- [Execution Plans (Cookbook)](https://cookbook.openai.com/articles/codex_exec_plans)
- [AGENTS.md 概念](https://agents.md/)
- [Architecture.md 模板](https://matklad.github.io/2021/02/06/ARCHITECTURE.md.html)
- [Effective Harnesses for Long-Running Agents (Anthropic)](https://www.anthropic.com/research)
- [Harness Design for Long-Running Application Development (Anthropic)](https://www.anthropic.com/research)

---

## 🛠️ 本地資源

| 文件 | 位置 |
|------|------|
| 完整中文 PDF | `/home/opc/.openclaw/media/inbound/Default_Harness_Engineering_到底是什么_概念_实战与争议_一次全部讲---549f16e4-904b-4d6e-a7cc-cdcfe9a81e28.pdf` |
| Harness Engineering 指南 | `/home/opc/.openclaw/workspace/guides/HARNESS_ENGINEERING_GUIDE.md` |
| Hermes Debug Harness | `/home/opc/.hermes/harness/` |

---

*Generated by Hermes Harness - Unified Research Report*


---

## 🧩 Harness 9 大核心組件 (技術詳解)

> 來源: "Agent Harness vs Everything Else" 英文詳解 (PDF 6頁)

### 組件總覽

| # | 組件 | 功能描述 |
|---|------|---------|
| 1 | **Iteration Loop** | 主控制迴圈，調用工具、餵回結果、重複直到完成 |
| 2 | **Context Management** | 上下文管理 — 決定保留、總結或拋棄哪些內容 |
| 3 | **Skills & Tools** | 工具原語 (讀文件、寫文件、運行 bash) + 技能層 (團隊特定知識) |
| 4 | **Sub-agent Management** | 子 Agent 管理 — 任務太大時創建隔離的子會話 |
| 5 | **Built-in Skills** | 內建技能 — 開箱即用的基本能力 |
| 6 | **Session Persistence** | 會話持久化 — 崩潰後可以從中斷處恢復 |
| 7 | **System Prompt Assembly** | 動態系統提示組裝 — 從目錄動態加載文件 |
| 8 | **Lifecycle Hooks** | 生命週期鉤子 — 在工具運行前後注入自定義邏輯 |
| 9 | **Permissions** | 權限控制 — 聲明工具所需最小權限，運行時強制執行 |

---

### 詳細解釋

#### 1️⃣ Iteration Loop (主控制迴圈)

```
用戶 Prompt → 讀取系統提示 → 決定調用哪個工具 → 運行工具 → 結果餵回上下文 → 迴圈重複
```

**核心邏輯：**
- while 迴圈係整個引擎
- 每次迭代決定：調用工具、壓縮上下文、創建子代理
- 需要設置最大迭代次數 cap，防止無限循環

#### 2️⃣ Context Management (上下文管理)

**問題：** 對話歷史增長 → 觸及 LLM 的上下文限制

**解決方案：** 
- 當使用到 80-90% 時觸發 "compaction"
- 最新消息保持完整
- 舊消息進行總結

**例子：** Cloud Code 從 200K tokens → 增加到 100 萬 tokens (Opus)

#### 3️⃣ Skills & Tools (工具與技能)

**Tools (工具原語)：**
- 通用能力：讀文件、寫文件、編輯文件、運行 bash、搜索代碼
- 這些係 "non-negotiable" — 如果連文件都讀寫唔到，就唔算係 coding agent

**Skills (技能)：**
- 組織知識的封裝
- 團隊/工作流特定
- 通常在 model files 入面

**Registry (註冊表)：**
- 記錄可用工具
- 記錄每個工具需要什麼權限
- 負責調度分發

#### 4️⃣ Sub-agent Management (子代理管理)

**時機：** 任務太大或需要並行處理

**實現方式：**
- 每個子代理獲得獨立會話
- 獲得受限的工具集
- 獲得專注的系統提示 ("你正在處理這個特定任務")

**模式：** span → restrict → collect

#### 5️⃣ Built-in Skills (內建技能)

**Baseline set:**
- 文件操作 (讀、寫、編輯、搜索)
- 代碼執行
- 代碼導航

**High-level skills:**
- 如何做 Git commit
- 如何開 Pull Request
- 如何運行測試

#### 6️⃣ Session Persistence (會話持久化)

**問題：** 長會話係 stateful，進程崩潰會丟失一切

**解決方案：**
- append-only JSON files (或 Markdown)
- 每條消息、每個工具結果、每次壓縮事件都係一行
- 崩潰後可以精確恢復到中斷點

**設計優雅之處：**
- 兩個 harness 實例可以共享同一個日誌而唔會互相踩踏
- 如果 harness 死左，文件仲係響度

#### 7️⃣ System Prompt Assembly (系統提示組裝)

**關鍵洞察：** 系統提示唔係靜態字符串，而係一個管道

**實現方式：**
- 動態掃描 ancestor directories
- 搵到 cloud.md 或 agents.md 就注入到系統提示
- 可以動態加載 memory files

**⚠️ 注意：** 動態引入組件會破壞 prompt caching，要小心處理

#### 8️⃣ Lifecycle Hooks (生命週期鉤子)

**兩種類型：**

| 類型 | 時機 | 功能 |
|------|------|------|
| **Pre-tool Hook** | 工具運行前 | 可以 allow/deny/modify 調用 |
| **Post-tool Hook** | 工具運行後 | 可以審計結果，用於 logging 和可觀測性 |

**企業採用方式：** 通過 hooks 將自定義邏輯注入 harness 本身

#### 9️⃣ Permissions (權限控制)

**靜態權限聲明：**
- `read` — 只讀
- `workspace` — 工作區訪問
- `full` — 完全訪問

**動態分類：**
- 同樣的工具可以根據命令動態判定安全或危險
- 例如：`ls` → read-only，`rm` → full access

**Interactive Approvals：**
- Agent 可以暫停並問用戶：「我應該運行呢個嗎？」
- 危險操作前的安全層

---

## 🔧 Framework vs Harness 區別

| 特性 | Framework | Harness |
|------|-----------|---------|
| 目標用戶 | 人類組裝 agent | Agent 自己執行任務 |
| 核心概念 | 抽象層 (state crafts, chains, memory) | 現成的 agent |
| 組裝方式 | 用戶自己 wire 組件 | 已經全部連接好 |
| 例子 | LangChain, LangGraph, AutoGen, CrewAI | Codex, Cursor, Claude Code |

> **Framework 係為人類組裝 agent；Harness 係為 Agent 自己執行任務**

---

## 📚 為何 ArXiv 搜索結果較少？

**原因：**
1. 呢個概念太新 (2025 年 2 月先開始流行)
2. 主要係 industry 實踐，學術研究落後於行業
3. 類似概念可能分散響 "agent architecture", "LLM agent framework" 等術語下

**建議搜索關鍵詞：**
- `agent framework architecture`
- `autonomous AI agent`
- `multi-agent LLM`
- `LLM software engineering`

---

*最後更新: 2026-05-08*
*報告包含: OpenAI 案例 + Anthropic 三 Agent 架構 + 9 組件詳解 + ArXiv 論文*
