# 🔬 Unified Research Report: "AI agent"

> **Generated:** 2026-05-09T17:38:00.488Z
> **Topic:** AI agent
> **Errors:** semantic: HTTP 404: {"error":"Not found"}


---

## 📚 OpenAlex Papers (10) [PRIMARY]

### 1. Modelling social action for AI agents

- **Authors:** Cristiano Castelfranchi
- **Published:** 1998-08-01
- **DOI:** https://doi.org/10.1016/s0004-3702(98)00056-3
- **Citations:** 0
- **Open Access:** ❌ No



---
### 2. Empowering biomedical discovery with AI agents

- **Authors:** Shanghua Gao, Ada Fang, Yepeng Huang +more
- **Published:** 2024-10-01
- **DOI:** https://doi.org/10.1016/j.cell.2024.09.022
- **Citations:** 0
- **Open Access:** ✅ Yes



---
### 3. Bots with Feelings: Should AI Agents Express Positive Emotion in Customer Service?

- **Authors:** Elizabeth Han, Dezhi Yin, Han Zhang
- **Published:** 2022-12-02
- **DOI:** https://doi.org/10.1287/isre.2022.1179
- **Citations:** 0
- **Open Access:** ❌ No



---
### 4. Mental Models of AI Agents in a Cooperative Game Setting

- **Authors:** Katy Ilonka Gero, Zahra Ashktorab, Casey Dugan +more
- **Published:** 2020-04-21
- **DOI:** https://doi.org/10.1145/3313831.3376316
- **Citations:** 0
- **Open Access:** ❌ No



---
### 5. AI Agents as Team Members: Effects on Satisfaction, Conflict, Trustworthiness, and Willingness to Work With

- **Authors:** Alan R. Dennis, Akshat Lakhiwal, Agrim Sachdeva
- **Published:** 2023-04-03
- **DOI:** https://doi.org/10.1080/07421222.2023.2196773
- **Citations:** 0
- **Open Access:** ❌ No



---
### 6. AI Agents vs. Agentic AI: A Conceptual Taxonomy, Applications and Challenges

- **Authors:** Ranjan Sapkota, Konstantinos I. Roumeliotis, Manoj Karkee
- **Published:** 2025-07-20
- **DOI:** https://doi.org/10.70777/si.v2i3.15161
- **Citations:** 0
- **Open Access:** ✅ Yes



---
### 7. AI Agents and Agentic Systems: A Multi-Expert Analysis

- **Authors:** Laurie Hughes, Yogesh K. Dwivedi, Tegwen Malik +more
- **Published:** 2025-04-24
- **DOI:** https://doi.org/10.1080/08874417.2025.2483832
- **Citations:** 0
- **Open Access:** ✅ Yes



---
### 8. AI Agents Under Threat: A Survey of Key Security Challenges and Future Pathways

- **Authors:** Zehang Deng, Yongjian Guo, Changzhou Han +more
- **Published:** 2025-02-07
- **DOI:** https://doi.org/10.1145/3716628
- **Citations:** 0
- **Open Access:** ❌ No



---
### 9. AI Agents vs. Agentic AI: A Conceptual taxonomy, applications and challenges

- **Authors:** Ranjan Sapkota, Konstantinos I. Roumeliotis, Manoj Karkee
- **Published:** 2025-08-22
- **DOI:** https://doi.org/10.1016/j.inffus.2025.103599
- **Citations:** 0
- **Open Access:** ✅ Yes



---
### 10. Generative AI Agents With Large Language Model for Satellite Networks via a Mixture of Experts Transmission

- **Authors:** Ruichen Zhang, Hongyang Du, Yinqiu Liu +more
- **Published:** 2024-09-12
- **DOI:** https://doi.org/10.1109/jsac.2024.3459037
- **Citations:** 0
- **Open Access:** ❌ No



---


## 📚 ArXiv Papers (10) [BACKUP]

### 1. BAMI: Training-Free Bias Mitigation in GUI Grounding

- **ID:** `2605.06664v1`
- **Published:** 2026-05-07
- **Authors:** Borui Zhang, Bo Zhang, Bo Wang, Wenzhao Zheng, Yuhao Cheng
- **PDF:** N/A

GUI grounding is a critical capability for enabling GUI agents to execute tasks such as clicking and dragging. However, in complex scenarios like the ScreenSpot-Pro benchmark, existing models often suffer from suboptimal performance. Utilizing the proposed \textbf{Masked Prediction Distribution (MPD...

---
### 2. AI Co-Mathematician: Accelerating Mathematicians with Agentic AI

- **ID:** `2605.06651v1`
- **Published:** 2026-05-07
- **Authors:** Daniel Zheng, Ingrid von Glehn, Yori Zwols, Iuliya Beloshapka, Lars Buesing
- **PDF:** N/A

We introduce the AI co-mathematician, a workbench for mathematicians to interactively leverage AI agents to pursue open-ended research. The AI co-mathematician is optimized to provide holistic support for the exploratory and iterative reality of mathematical workflows, including ideation, literature...

---
### 3. Superintelligent Retrieval Agent: The Next Frontier of Information Retrieval

- **ID:** `2605.06647v1`
- **Published:** 2026-05-07
- **Authors:** Zeyu Yang, Qi Ma, Jason Chen, Anshumali Shrivastava
- **PDF:** N/A

Retrieval-augmented agents are increasingly the interface to large organizational knowledge bases, yet most still treat retrieval as a black box: they issue exploratory queries, inspect returned snippets, and iteratively reformulate until useful evidence emerges. This approach resembles how a newcom...

---
### 4. StraTA: Incentivizing Agentic Reinforcement Learning with Strategic Trajectory Abstraction

- **ID:** `2605.06642v1`
- **Published:** 2026-05-07
- **Authors:** Xiangyuan Xue, Yifan Zhou, Zidong Wang, Shengji Tang, Philip Torr
- **PDF:** N/A

Large language models (LLMs) are increasingly used as interactive agents, but optimizing them for long-horizon decision making remains difficult because current methods are largely purely reactive, which weakens both exploration and credit assignment over extended trajectories. In this work, we pres...

---
### 5. GlazyBench: A Benchmark for Ceramic Glaze Property Prediction and Image Generation

- **ID:** `2605.06641v1`
- **Published:** 2026-05-07
- **Authors:** Ziyu Zhai, Siyou Li, Juexi Shao, Juntao Yu
- **PDF:** N/A

Developing ceramic glazes is a costly, time-consuming process of trial and error due to complex chemistry, placing a significant burden on independent artists. While recent advances in multimodal AI offer a modern solution, the field lacks the large-scale datasets required to train these models. We ...

---
### 6. Recursive Agent Optimization

- **ID:** `2605.06639v1`
- **Published:** 2026-05-07
- **Authors:** Apurva Gandhi, Satyaki Chakraborty, Xiangjun Wang, Aviral Kumar, Graham Neubig
- **PDF:** N/A

We introduce Recursive Agent Optimization (RAO), a reinforcement learning approach for training recursive agents: agents that can spawn and delegate sub-tasks to new instantiations of themselves recursively. Recursive agents implement an inference-time scaling algorithm that naturally allows agents ...

---
### 7. Cited but Not Verified: Parsing and Evaluating Source Attribution in LLM Deep Research Agents

- **ID:** `2605.06635v1`
- **Published:** 2026-05-07
- **Authors:** Hailey Onweller, Elias Lumer, Austin Huber, Pia Ramchandani, Vamse Kumar Subbiah
- **PDF:** N/A

Large language models (LLMs) power deep research agents that synthesize information from hundreds of web sources into cited reports, yet these citations cannot be reliably verified. Current approaches either trust models to self-cite accurately, risking bias, or employ retrieval-augmented generation...

---
### 8. Quantifying Trade-Offs Between Stability and Goal-Obfuscation

- **ID:** `2605.06630v1`
- **Published:** 2026-05-07
- **Authors:** Yixuan Wang, Dan Guralnik, Warren Dixon
- **PDF:** N/A

Safety-critical autonomy in adversarial settings demands more than Lyapunov stability of tracking error signals. An agent executing a goal-directed trajectory is intrinsically legible to a passive observer running online Bayesian inference, because the contractive dynamics of any Lyapunov basin of a...

---
### 9. MASPO: Joint Prompt Optimization for LLM-based Multi-Agent Systems

- **ID:** `2605.06623v1`
- **Published:** 2026-05-07
- **Authors:** Zhexuan Wang, Xuebo Liu, Li Wang, Zifei Shan, Yutong Wang
- **PDF:** N/A

Large language model (LLM)-based Multi-agent systems (MAS) have shown promise in tackling complex collaborative tasks, where agents are typically orchestrated via role-specific prompts. While the quality of these prompts is pivotal, jointly optimizing them across interacting agents remains a non-tri...

---
### 10. SkillOS: Learning Skill Curation for Self-Evolving Agents

- **ID:** `2605.06614v1`
- **Published:** 2026-05-07
- **Authors:** Siru Ouyang, Jun Yan, Yanfei Chen, Rujun Han, Zifeng Wang
- **PDF:** N/A

LLM-based agents are increasingly deployed to handle streaming tasks, yet they often remain one-off problem solvers that fail to learn from past interactions. Reusable skills distilled from experience provide a natural substrate for self-evolution, where high-quality skill curation serves as the key...

---

---

## 🔮 Polymarket Predictions (71)

### 1. Super Bowl LVII Coin Toss: Heads or Tails?

- **Probability:** N/A%
- **Category:** All


---
### 2. UFC 285: Will there be at least 4 finishes on the main card?

- **Probability:** N/A%
- **Category:** All


---
### 3. Will Bank of America fail by March 17?

- **Probability:** N/A%
- **Category:** All


---
### 4. Did Changpeng Zhao (CZ) bail out SBF?

- **Probability:** N/A%
- **Category:** All


---
### 5. zkSync airdrop by June 1?

- **Probability:** N/A%
- **Category:** All


---
### 6. Will Western Alliance Bancorp fail by March 17?

- **Probability:** N/A%
- **Category:** All


---
### 7. Will 'Cocaine Bear' gross more than $16 million domestically on opening weekend?

- **Probability:** N/A%
- **Category:** All


---
### 8. NBA: Boston Celtics vs. Portland Trail Blazers 2023-03-08

- **Probability:** N/A%
- **Category:** All


---
### 9. Will a third US bank fail by March 31?

- **Probability:** N/A%
- **Category:** All


---
### 10. NBA: Portland Trail Blazers vs. LA Clippers 2023-03-19

- **Probability:** N/A%
- **Category:** All


---
### 11. Daytona 500: Will Denny Hamlin or Ryan Blaney claim the pole position?

- **Probability:** N/A%
- **Category:** All


---
### 12. Formula 1: Will Red Bull collect the most points of any constructor at the 2023 Bahrain Grand Prix?

- **Probability:** N/A%
- **Category:** All


---
### 13. NBA: New Orleans Pelicans vs. Portland Trail Blazers 2023-03-12

- **Probability:** N/A%
- **Category:** All


---
### 14. NBA: Portland Trail Blazers vs. New Orleans Pelicans 2023-03-01

- **Probability:** N/A%
- **Category:** All


---
### 15. NBA: Atlanta Hawks vs. Portland Trail Blazers 2023-03-03

- **Probability:** N/A%
- **Category:** All


---
### 16. Will Vladimir Putin remain President of Russia through June 30, 2023?

- **Probability:** N/A%
- **Category:** All


---
### 17. Will 'Cocaine Bear' gross more than $20 million domestically on opening weekend?

- **Probability:** N/A%
- **Category:** All


---
### 18. Will Ukraine win Eurovision 2023?

- **Probability:** N/A%
- **Category:** All


---
### 19. NBA: Detroit Pistons vs. Portland Trail Blazers 2023-03-06

- **Probability:** N/A%
- **Category:** All


---
### 20. Will Benjamin Netanyahu remain prime minister of Israel through June 30, 2021?

- **Probability:** N/A%
- **Category:** All


---
### 21. NBA: Lakers vs. Trail Blazers (02/13/2023)

- **Probability:** N/A%
- **Category:** All


---
### 22. NFL Preseason: Who will win Minnesota Vikings v. Las Vegas Raiders, scheduled for August 14, 4:25 PM ET?

- **Probability:** N/A%
- **Category:** All


---
### 23. Tails Never Fails Parlay

- **Probability:** N/A%
- **Category:** All


---
### 24. NBA: Orlando Magic vs. Portland Trail Blazers 2023-03-05

- **Probability:** N/A%
- **Category:** All


---
### 25. NFL Preseason: Who will win Jacksonville Jaguars v. Las Vegas Raiders, scheduled for August 4, 8:00 PM ET?

- **Probability:** N/A%
- **Category:** All


---
### 26. Will Metamask airdrop a native token before 2023?

- **Probability:** N/A%
- **Category:** All


---
### 27. NBA: Portland Trail Blazers vs. New York Knicks 2023-03-14

- **Probability:** N/A%
- **Category:** All


---
### 28. UFC 286: Who will win - Maia or O'Neill?

- **Probability:** N/A%
- **Category:** All


---
### 29. Will 'Cocaine Bear' gross more than $12 million domestically on opening weekend?

- **Probability:** N/A%
- **Category:** All


---
### 30. Will Biden mention "AI" during his SOTU?

- **Probability:** N/A%
- **Category:** All


---
### 31. Formula 1: Will Max Verstappen win the 2023 Bahrain Grand Prix?

- **Probability:** N/A%
- **Category:** All


---
### 32. Will Credit Suisse fail by March 31?

- **Probability:** N/A%
- **Category:** All


---
### 33. NFL Saturday: Chiefs vs. Raiders

- **Probability:** N/A%
- **Category:** All


---
### 34. Will Amazon debut its NFT marketplace with any collections on the AVAX chain?

- **Probability:** N/A%
- **Category:** All


---
### 35. Will First Republic Bank fail by March 17?

- **Probability:** N/A%
- **Category:** All


---
### 36. NCAAB: Texas Longhorns vs. Colgate Raiders 2023-03-16

- **Probability:** N/A%
- **Category:** All


---
### 37. Formula 1: Will 17 or more drivers complete the 2023 Bahrain Grand Prix?

- **Probability:** N/A%
- **Category:** All


---
### 38. Will ChatGPT remain free through April 30?

- **Probability:** N/A%
- **Category:** All


---
### 39. NBA: Wizards vs. Trail Blazers (02/14/2023)

- **Probability:** N/A%
- **Category:** All


---
### 40. Will Bing suspend its AI chatbot by February 28?

- **Probability:** N/A%
- **Category:** All


---
### 41. NBA: Portland Trail Blazers vs. Houston Rockets 2023-02-26

- **Probability:** N/A%
- **Category:** All


---
### 42. NFL Saturday: Raiders vs. Steelers

- **Probability:** N/A%
- **Category:** All


---
### 43. NBA: Philadelphia 76ers vs. Portland Trail Blazers 2023-03-10

- **Probability:** N/A%
- **Category:** All


---
### 44. NCAAB: Purdue Boilermakers vs. Fairleigh Dickinson Knights 2023-03-17

- **Probability:** N/A%
- **Category:** All


---
### 45. Will George Santos remain in Congress through March 31?

- **Probability:** N/A%
- **Category:** All


---
### 46. Will Ali Khamenei remain Supreme Leader of Iran through June 30, 2023?

- **Probability:** N/A%
- **Category:** All


---
### 47. NBA: Bucks vs. Trail Blazers (02/06/2023)

- **Probability:** N/A%
- **Category:** All


---
### 48. NCAAB: Texas Southern Tigers vs. Fairleigh Dickinson Knights 2023-03-15

- **Probability:** N/A%
- **Category:** All


---
### 49. Arbitrum airdrop by March 31st?

- **Probability:** N/A%
- **Category:** All


---
### 50. Did Justin Sun bail out SBF?

- **Probability:** N/A%
- **Category:** All


---
### 51. Did Dustin Moskovitz bail out SBF?

- **Probability:** N/A%
- **Category:** All


---
### 52. Will Base mainnet launch by June 30?

- **Probability:** N/A%
- **Category:** All


---
### 53. Did Jaan Tallinn bail out SBF?

- **Probability:** N/A%
- **Category:** All


---
### 54. Will SVB fail?

- **Probability:** N/A%
- **Category:** All


---
### 55. NCAAB: Maryland Terrapins vs. West Virginia Mountaineers 2023-03-16

- **Probability:** N/A%
- **Category:** All


---
### 56. Will OpenAI release GPT-4 by May 31?

- **Probability:** N/A%
- **Category:** All


---
### 57. Will a third US bank fail by March 17?

- **Probability:** N/A%
- **Category:** All


---
### 58. NBA: Thunder vs. Trail Blazers (02/10/2023)

- **Probability:** N/A%
- **Category:** All


---
### 59. Will Schwab fail by March 17?

- **Probability:** N/A%
- **Category:** All


---
### 60. NBA: Sacramento Kings vs. Portland Trail Blazers 2023-02-23

- **Probability:** N/A%
- **Category:** All


---
### 61. Will Ronna McDaniel be reelected as RNC Chair?

- **Probability:** N/A%
- **Category:** All


---
### 62. NBA: Golden State Warriors vs. Portland Trail Blazers 2023-02-28

- **Probability:** N/A%
- **Category:** All


---
### 63. NBA: Portland Trail Blazers vs. Boston Celtics 2023-03-17

- **Probability:** N/A%
- **Category:** All


---
### 64. Will another US bank fail in March?

- **Probability:** N/A%
- **Category:** All


---
### 65. NBA: Warriors vs. Trail Blazers (02/08/2023)

- **Probability:** N/A%
- **Category:** All


---
### 66. Did Kevin O'Leary bail out SBF?

- **Probability:** N/A%
- **Category:** All


---
### 67. NCAAB: Florida Atlantic Owls vs. Fairleigh Dickinson Knights 2023-03-19

- **Probability:** N/A%
- **Category:** All


---
### 68. Will Coinbase staking be available in the US through March 31?

- **Probability:** N/A%
- **Category:** All


---
### 69. Ethereum Shanghai Upgrade by April 15?

- **Probability:** N/A%
- **Category:** All


---
### 70. NBA: Hawks vs. Trail Blazers (01/30/2023)

- **Probability:** N/A%
- **Category:** All


---
### 71. Will Magnus Carlsen win the Airthings Masters 2023?

- **Probability:** N/A%
- **Category:** All


---

---

## 📖 Semantic Scholar Papers (0)

*No papers found*

---

## 📰 Blog Updates (20)

### 1. Introduction to Beaver Triples

- **Source:** HN
- **Date:** 5/10/2026
- **Link:** https://stoffelmpc.com/stoffel-blog/beaver-triples-tuples

Article URL: https://stoffelmpc.com/stoffel-blog/beaver-triples-tuples Comments URL: https://news.ycombinator.com/item?id=48076009 Points: 6 # Comment...

---
### 2. The context window has been shattered: Subquadratic debuts a 12M token window

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://thenewstack.io/subquadratic-12-million-context-window/

Article URL: https://thenewstack.io/subquadratic-12-million-context-window/ Comments URL: https://news.ycombinator.com/item?id=48075645 Points: 27 # C...

---
### 3. PipeDream on the Acorn Archimedes

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://stonetools.ghost.io/pipedream-archimedes/

Article URL: https://stonetools.ghost.io/pipedream-archimedes/ Comments URL: https://news.ycombinator.com/item?id=48075528 Points: 42 # Comments: 13...

---
### 4. GrapheneOS fixes Android VPN leak Google refused to patch

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://cyberinsider.com/grapheneos-fixes-android-vpn-leak-google-refused-to-patch/

Article URL: https://cyberinsider.com/grapheneos-fixes-android-vpn-leak-google-refused-to-patch/ Comments URL: https://news.ycombinator.com/item?id=48...

---
### 5. Show HN: Mochi.js: bun-native high-fidelity browser automation library

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://mochijs.com/

Hi HN,I’m sharing mochi.js (https://github.com/0xchasercat/mochi), a Bun-native, raw-CDP browser automation framework. It's designed to make programma...

---
### 6. The Intolerable Hypocrisy of Cyberlibertarianism

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://matduggan.com/the-intolerable-hypocrisy-of-cyberlibertarianism/

Article URL: https://matduggan.com/the-intolerable-hypocrisy-of-cyberlibertarianism/ Comments URL: https://news.ycombinator.com/item?id=48074952 Point...

---
### 7. Read Programming as Theory Building

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://codeutopia.net/blog/2026/05/09/you-should-read-programming-as-theory-building/

Article URL: https://codeutopia.net/blog/2026/05/09/you-should-read-programming-as-theory-building/ Comments URL: https://news.ycombinator.com/item?id...

---
### 8. Internet Archive Switzerland

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://internetarchive.ch/

Article URL: https://internetarchive.ch/ Comments URL: https://news.ycombinator.com/item?id=48074265 Points: 312 # Comments: 41...

---
### 9. Killswitch: Per-function short-circuit mitigation primitive

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://lwn.net/ml/all/20260507070547.2268452-1-sashal@kernel.org/

Article URL: https://lwn.net/ml/all/20260507070547.2268452-1-sashal@kernel.org/ Comments URL: https://news.ycombinator.com/item?id=48073394 Points: 61...

---
### 10. LLMs Corrupt Your Documents When You Delegate

- **Source:** HN
- **Date:** 5/9/2026
- **Link:** https://arxiv.org/abs/2604.15597

Article URL: https://arxiv.org/abs/2604.15597 Comments URL: https://news.ycombinator.com/item?id=48073246 Points: 198 # Comments: 66...

---

---

## 📊 Summary

| Source | Count |
|--------|-------|
| ArXiv | 10 |
| Polymarket | 71 |
| Semantic Scholar | 0 |
| Blogwatcher | 20 |

**Errors:** semantic

---

*Generated by Hermes Harness - Unified Research Report*
*Date: 2026-05-09T17:38:00.488Z*
