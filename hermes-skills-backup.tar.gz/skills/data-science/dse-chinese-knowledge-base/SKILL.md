---
name: dse-chinese-knowledge-base
description: Multi-phase pipeline for building a DSE Chinese subject knowledge base — crawl sources → structure → AI refine → SQLite deploy. Use when: DSE Chinese, Chinese knowledge base, 中文, 文言文, Chinese exam
---

# DSE Chinese Knowledge Base Pipeline

A complete multi-phase workflow to gather, structure, and refine DSE Chinese (香港中學文憑考試中國語文科) study materials across 10+ years.

## Architecture

```
Zeabur 🟡 → Crawl public websites (8+ concurrent, I/O bound)
Oracle 🔵 → Crawl anti-scrape sites + PDF OCR + AI refinement + TaskForge dispatcher
Big VM 🟢 → SQLite database host + API server (orchestrator runs here OR on Oracle)
```

### Concurrency Strategy (May 2026 experiential finding)

**You don't need multiple VMs for concurrency.** Single VM can handle 20-30 concurrent I/O-bound tasks. The real value of multi-VM setup is:

1. **Fault isolation** — one crash doesn't kill the bot
2. **Resilience** — if Zeabur goes down, Oracle picks up
3. **Not** for raw compute — your tasks are 90% I/O bound (waiting for network/API), not CPU bound

**Current VM efficiency (assessed May 2026):**
- Big VM (3.7GB): Uses ~512MB actual → 86% waste. Could drop to 1-2GB plan.
- Oracle VM (15GB): Uses ~2-4GB actual → 73% waste (but possibly Oracle free tier)
- Zeabur (1.9GB): Uses ~512MB actual → 73% waste

**Recommendation:** Single 4-8GB VM can handle all concurrent needs for this project size. Multi-VM only justified when: (a) need true fault isolation, (b) single VM insufficient RAM (>16GB workload), (c) geographic distribution needed.

## Multi-Subject Expansion (May 2026 — Experiential)

The DSE knowledge base pattern has been expanded to 3 additional subjects:

| Subject | Project Dir | Crawled | DB | Notes | 
|---------|-------------|---------|-----|-------|
| Geography | `data/dse-geography/` | 5 DSE00 articles | 6 tables + FTS5 | 27.7KB |
| Economics | `data/dse-economics/` | 1 DSE00 article | 6 tables + FTS5 | 30.6KB |
| English | `data/dse-english/` | 0 (no sites found) | Schema only | 22KB AI gen |

### Subject-Specific Schema Design

Each subject needs DIFFERENT tables — **DON'T** reuse the Chinese tables as-is:

| Subject | DB Name | Subject-Specific Tables |
|---------|---------|------------------------|
| Geography | `dse_geography.db` | `sources`, `past_papers`, `articles`, **`topics`**, **`map_skills`**, **`case_studies`** |
| Economics | `dse_economics.db` | `sources`, `past_papers`, `articles`, **`topics`** (with formulas), **`key_terms`**, **`diagrams`** |
| English | `dse_english.db` | `sources`, `past_papers`, `articles`, **`writing_topics`**, **`grammar_notes`**, **`vocabulary`** |
| Chinese | `dse_chinese.db` | `sources`, `past_papers`, `articles`, `writing_topics`, `classical_texts`, `classical_vocab` |

Common tables across all: `sources`, `past_papers`, `articles` (with FTS5). All get FTS5 on articles.

### Migration Script Pitfall: INSERT OR IGNORE + RETURNING id

**DO NOT** use this pattern in Python sqlite3:
```python
# BROKEN — returns None when row already exists due to INSERT OR IGNORE
src_id = c.execute("INSERT OR IGNORE INTO sources (name) VALUES (?) RETURNING id", (s,)).fetchone()[0]
```

**Use try/except instead:**
```python
# FIXED — works every time
try:
    c.execute("INSERT INTO sources (name,type) VALUES (?,?)", (source, 'blog'))
except sqlite3.IntegrityError:
    pass
c.execute("SELECT id FROM sources WHERE name=?", (source,))
src_id = c.fetchone()[0]
```

This applies to ALL DB migration scripts when sources might already exist.

### DSE00 English: NO Articles Found

All English-related labels on DSE00 return zero articles:
- `/search/label/English` → 0 results
- `/search/label/Eng` → 0 results
- `/search/label/English%20Language` → 0 results
- `/search/label/English%20Grammar` → 0 results
- `/search/label/writing` → 0 results

The DSE00 blog comment section is active but contains no educational article content — only student chat/spam.

**Other English DSE sites tested:**
- `hkdseenglish.com` → DNS dead (ERR_NAME_NOT_RESOLVED)
- `afterclass.hk/dse/eng` → DNS dead

**Conclusion:** No public websites with reusable English DSE content have been found. English notes must be 100% AI-generated from curriculum knowledge.

### DSE00 Blog Content Extraction (Browser Tool Pattern)

When scraping DSE00 articles, use the browser tool directly (NOT a subagent — subagents lack browser tools):
1. `browser_navigate(url)` — loads the article
2. `browser_console(expression="document.querySelector('.post-body').innerText")` — extracts full content
3. Save as JSON to `raw/` directory
4. Each article = separate browser_navigate call (sequential, not parallel)

### Direct Python DB Init (Simpler than Shell Scripts)

For new subjects, skip the shell migration script for first-time setup and use direct Python:
```bash
python3 /tmp/init-{subject}-db.py
```
Then save the Python as the migration script afterward. This avoids shell escaping issues with multiline Python strings.

## Phase 1 — Crawling

### ⚠️ CRITICAL: Many DSE websites are DEAD (May 2026)

| Source | Method | Status |
|--------|--------|--------|
| dse-chinese.com | HTTP / Browser (Oracle VM) | ❌ DNS dead — site no longer exists. `ERR_NAME_NOT_RESOLVED` from both HTTP and browser. |
| afterclass.hk | HTTP / Browser (Oracle VM) | ❌ DNS dead — `ERR_NAME_NOT_RESOLVED`. No workaround. |
| dse-tips.com | HTTP / Browser (Oracle VM) | ❌ DNS dead — `ERR_NAME_NOT_RESOLVED`. |
| dsepp.com | HTTP → Browser fallback | ✅ Site alive, has 80 PDF links (2012-2017) + SP/PP |
| dse00.blogspot.com | HTTP + Browser | ✅ Site alive, 21 Chinese articles |
| hkeaa.edu.hk | HTTP | ✅ Accessible (but only URL listing, no content) |
| hk01.com | HTTP | ⚠️ Low content (0 articles via generic scrape) |
| edu-kingdom.com | HTTP | ⚠️ 0 posts found |

**Strategy:**
1. **First pass — HTTP scrape on Zeabur** (8 concurrent, quick titles/links)
2. **Second pass — Browser tool fallback** on Oracle VM for high-value sites that HTTP failed

### TaskForge Dispatch Fix (May 2026)

**Original problem:** TaskForge's `_dispatchViaSSH()` used `execSync()` (blocking) for local tasks, and SSH dispatch for remote workers. DSE crawls dispatched to Zeabur failed with `agent.js not found` or script path errors.

**Root causes fixed:**
1. **`_dispatchViaSSH` was synchronous** → Changed to async Promise-based `spawn()` for local (localhost) tasks. This enables concurrent task execution on the same VM without blocking the orchestrator.
2. **`~` path not resolved** → Local spawn used `~/hermes-worker/agent.js` but `spawn()` doesn't expand tilde. Fixed to use `path.join(process.env.HOME, 'hermes-worker/agent.js')`
3. **Script path hardcoded to Oracle VM** → DSE crawl scripts lived at `/home/opc/hermes-pricepulse/scripts/` on Oracle, but were dispatched to Zeabur where they don't exist. **Fix:** Upload scripts to Zeabur's `~/hermes-worker/scripts/` first, then dispatch with Zeabur-local path.
4. **Zeabur missing Python deps** → `pip3 install --break-system-packages beautifulsoup4 requests` required before any DSE crawls run.

**Health verification:** After fix, all 3 workers (oracle-vm1, big-vm, zeabur) ping successfully. DSE crawls dispatch and complete with OK status.

**Lesson:** Always verify script dependencies on target workers before dispatching. The orchestrator itself was fine — the issue was deployment hygiene.

### Zeabur Tasks (public websites, 8 concurrent)

**Step 1:** Upload scrape scripts to Zeabur first:
```bash
# Upload scripts to Zeabur's hermes-worker directory
scp -i ~/.ssh/zeabur_devbox.pem scripts/dse-crawl-zeabur.sh ubuntu@43.156.247.30:~/hermes-worker/scripts/dse-crawl.sh
scp -i ~/.ssh/zeabur_devbox.pem scripts/dse-writing-crawl.sh ubuntu@43.156.247.30:~/hermes-worker/scripts/dse-writing.sh
ssh -i ~/.ssh/zeabur_devbox.pem ubuntu@43.156.247.30 "chmod +x ~/hermes-worker/scripts/*.sh"
```

**Step 2:** Ensure Python dependencies:
```bash
ssh -i ~/.ssh/zeabur_devbox.pem ubuntu@43.156.247.30 \
  "pip3 install --break-system-packages beautifulsoup4 requests"
```

**Step 3:** Execute scripts directly on Zeabur (NOT via TaskForge dispatcher — scripts use local paths):
```bash
ssh -i ~/.ssh/zeabur_devbox.pem ubuntu@43.156.247.30 "
cd ~/hermes-worker/scripts
# Run in parallel batches of 3-4
bash dse-crawl.sh afterclass https://afterclass.hk &
PID1=\$!
bash dse-crawl.sh dse00 https://dse00.blogspot.com &
PID2=\$!
bash dse-crawl.sh dsepp https://dsepp.com &
PID3=\$!
wait \$PID1; wait \$PID2; wait \$PID3
echo 'Done'
"
```

**Step 4:** Pull data back to Oracle VM:
```bash
scp -i ~/.ssh/zeabur_devbox.pem ubuntu@43.156.247.30:/tmp/dse-cache/*.json \
  /home/opc/hermes-pricepulse/data/dse-chinese/raw/
```

**Note:** `hkeaa` crawl succeeds because it uses inline Python (no external script dependency). All other crawls need explicit script upload because `dse-crawl-zeabur.sh` references `/home/opc/...` paths that don't exist on Zeabur.

### Browser Fallback (Oracle VM — for HTTP-failed sites)

When HTTP scrape fails (DNS dead, 429 rate limit, connection refused), use Hermes browser tool:

```python
# 1. Navigate to the site
browser_navigate(url="https://target-site.com/resource_centre/chinese")

# 2. Explore page structure
browser_snapshot(full=True)  # get all interactive elements

# 3. Extract data with JavaScript via browser_console
browser_console(expression="""
(() => {
  const links = Array.from(document.querySelectorAll('a[href*=".pdf"]'));
  return JSON.stringify(links.map(a => ({
    name: a.textContent.trim(),
    url: a.href
  })), null, 2);
})()
""")
```

**Key findings from browser fallback:**
- **dsepp.com** (`/resource_centre/chinese`): Has **80 PDF links** (2012-2017 + sample/practice papers across卷一至五). Write JSON output in format: `{"source":"dsepp","type":"past_papers","total_pdfs":N,"papers":{"2017":[...], ...}}` and save to `raw/dsepp-pdfs.json`
- **dse00.com** (`/search/label/中文`): Has 21 Chinese DSE articles covering: 作文背文方法, 修辭手法, 扣題技巧, 白話文答題公式, 綜合拓展技巧, 文言文翻譯技巧, 說理文評分準則, 5**心得 etc. Save full article content (extract post-body div with JS).
- **dse-chinese.com, afterclass.hk, dse-tips.com**: DNS completely unresolvable even via browser — these sites no longer exist

### YouTube Transcripts (separate pipeline)
Search keywords: 文言文技巧, 作文技巧, 閱讀理解, 綜合卷, 聆聽, 12篇範文
Fetch with `yt-dlp --skip-download --write-auto-sub`
2. HK01 / am730 / 明報 — education articles
3. YouTube video metadata (if Zeabur has issues)
4. PDF download + OCR of HKEAA past papers (~39 PDFs)
```

## Phase 2 — Structuring (Oracle VM)

Run after all crawls complete.

### Database Location
`/home/opc/hermes-pricepulse/data/dse-chinese/db/dse_chinese.db`

### Schema (6 tables + FTS5)

| Table | Content |
|-------|---------|
| `sources` | 資料來源 metadata (name, type, url, description) |
| `past_papers` | 歷屆試題 PDF links (80 entries for dsepp.com) |
| `articles` | 學習文章 full content with FTS5 |
| `writing_topics` | 作文題目 by year (2012-2024) with FTS5 |
| `classical_texts` | 12篇範文 titles + analysis |
| `classical_vocab` | 文言文字詞庫 (char, meaning, examples) |

### Quick Start

```bash
# Initialize DB from all raw JSON files
bash scripts/dse-db-migrate.sh --init

# Add new data later
bash scripts/dse-db-migrate.sh /path/to/new-data.json
```

### Migration Script Location
`/home/opc/hermes-pricepulse/scripts/dse-db-migrate.sh`

Supports these input formats:
- `articles[]` — blog articles (auto-categorize by title keywords: 作文/閱讀/說話/綜合)
- `papers{}` — past paper PDF links (keyed by year, sample, practice)
- `years[]` — writing topics (by year)
- `chars[]` — classical vocabulary (insert or ignore duplicates)

### DB Features
- **FTS5 full-text search**: `SELECT title FROM articles_fts WHERE articles_fts MATCH '修辭'`
- **Auto-sync triggers**: INSERT on `articles` auto-indexes FTS, INSERT on `writing_topics` auto-indexes FTS
- **WAL mode**: concurrent reads during future migration
- **Idempotent**: INSERT OR IGNORE for resume-safe re-import

## Phase 3 — AI Refinement (Oracle VM)

Use LLM to generate structured study notes from database content. No additional API cost if using same model as agent.

### ⚠️ Large File Translation Pitfalls (May 2026)

When translating large DSE notes (30KB+/700+ lines) from English to Chinese, avoid these issues:

**Problem 1: `read_file()` caches results.**
- If you read a file, then another tool writes to it, `read_file()` may return "File unchanged since last read" (154 chars) instead of the actual file content.
- **Fix:** Use `terminal()` with `python3 -c "open('/path').read()"` or `subprocess.run(['cat', '/path'], capture_output=True, text=True)` to read files directly. The `execute_code()` tool's `from hermes_tools import read_file` has the same cache issue.

**Problem 2: `delegate_task` output limit causes truncation for large files.**
- Subagents writing >30KB of content hit "Response truncated due to output length limit" errors.
- Even if you tell the subagent to `write_file()` directly instead of returning content, it may still exhaust max_iterations reading the file in chunks.
- **Fix 1:** Do the translation yourself (in the main agent) using `terminal()` with an inline `python3 << 'PYEOF'` heredoc. Process the file line-by-line with a translation dict map.
- **Fix 2:** For very large files (>500 lines), avoid dict-based word-by-word translation (too many entries needed). Instead:
  1. Section-split the file using `====` or `---` delimiters
  2. Translate section headers with a map
  3. For body content, use AI per-section via `delegate_task` with small chunks (each <200 lines)

**Problem 3: Dict-based exact-match translation misses variations.**
- A line like `'- 2 hours 15 minutes'` won't match if there's trailing whitespace
- **Fix:** `strip()` each line before lookup, preserve original indentation

**Problem 4: Use `terminal()` inline Python for bulk processing.**
```bash
python3 << 'PYEOF'
# Read file directly
with open('/path/to/file.txt') as f:
    lines = f.readlines()

# Process with translation map
trans = {'exact line': '翻譯文本'}
for i, line in enumerate(lines):
    s = line.strip()
    if s in trans:
        lines[i] = line[:len(line)-len(line.lstrip())] + trans[s]

with open('/path/to/output.txt', 'w') as f:
    f.write('\n'.join(lines))
print("Done")
PYEOF
```

**Best practice for notes translation:**
1. Read via `terminal()` with Python `open().read()`
2. Use a translation dict for structural elements (headers, section names, common phrases)
3. For full content translation, use `delegate_task` with small chunks (<200 lines each)
4. Write output directly to file, don't try to return it through the subagent's response

### Deliverable Format
Write to `data/dse-chinese/notes/dse-chinese-notes.txt` (plain text, ~30KB, ~700 lines).

### Sections Generated (May 2026)
1. **作文技巧** — 背文方法 + 21種修辭手法（15基本+6進階）附例子和考試用法
2. **文言文必背字詞** — 20個高頻虛詞（之其而以為於與則也者所乎焉哉矣乃因故遂既）— 每字附詞性、DSE用法、例句、答題口訣
3. **12篇範文分析** — 完全覆蓋：論仁論孝論君子、魚我所欲也、逍遙遊、勸學、廉頗藺相如列傳、出師表、師說、岳陽樓記、六國論、始得西山宴遊記、唐詩三首、詞三首。每篇：作者朝代、核心思想、DSE常見考法、必背金句、K.O.錦囊
4. **歷屆試題攻略** — 2012-2024年題型分析、時間管理
5. **答題框架** — 閱讀/寫作/說話/綜合卷具體模板
6. **溫習計劃建議** — 每日時間分配、past paper進度規劃

### How to Generate
1. Read all data from SQLite DB (articles, classical_vocab, classical_texts, writing_topics, past_papers)
2. Write structured TXT with `write_file()` — each section ~300-800 words
3. For 12篇範文: database only has titles, so use AI's own knowledge of DSE Chinese curriculum to generate full analysis. Mark as "AI-generated from curriculum knowledge" in disclaimer.
4. Include practical DSE exam tips, not just factual content

### Cost
~30KB of text generation = negligible (<$0.01 for most models)

### Notes on Data Quality
- **Sites that worked**: dsepp.com (80 PDF links 2012-2017), dse00 blog (2 full articles)
- **Sites dead**: dse-chinese.com, afterclass.hk, dse-tips.com (DNS unresolvable)
- **Partial data**: writing-topics has year labels only (2012-2024), no actual question text
- The notes supplement missing data with AI curriculum knowledge (e.g., 12篇範文, 文言字詞分析)

## Phase 3b — Future Data Supplementation

New data can be added anytime:
1. Crawl → raw JSON → `data/dse-chinese/raw/`
2. Run: `bash scripts/dse-db-migrate.sh data/dse-chinese/raw/new-file.json`
3. Regenerate notes with updated DB content

## Phase 4 — Deploy (Big VM)

```
Big VM: SQLite + API server (PM2)
- Schema: questions, articles, notes tables with FTS5
- API: /search, /questions, /notes, /tips
- Nginx reverse proxy
```

## Worker Paths

| VM | Agent Path | User | SSH Key |
|----|-----------|------|---------|
| Oracle VM | ~/hermes-worker/agent.js | opc | ~/.ssh/id_rsa |
| Zeabur | ~/hermes-worker/agent.js | ubuntu | ~/.ssh/zeabur_devbox.pem |
| Big VM | /root/hermes-worker/agent.js | root | ~/.ssh/oracle_to_bigvm |

## Scrape Scripts Location

Upload to `/tmp/taskforge_scrape/` on each worker. Each script writes JSON results to `/tmp/dse_crawl_{source}_{timestamp}.json`.

## Worker Routing Rules

| Task Type | Worker | Reason |
|-----------|--------|--------|
| Public website crawl | Zeabur 🟡 | I/O bound, 8 concurrent, 1.9GB RAM enough |
| Anti-scrape / browser | Oracle 🔵 | Docker for selenium, 15GB RAM |
| PDF OCR | Oracle 🔵 | Heavy processing |
| AI refinement | Oracle 🔵 | LLM calls |
| Database + API serve | Big VM 🟢 | ~50MB RAM, always online for bot |

## Project Status Tracking (Session Reset Countermeasure)

**Problem:** Hermes session resets daily at 04:00 (`session_reset.at_hour: 4, mode: both`). User asking "what did we do?" 3 hours later may find the agent has no recollection of the previous session's work. `session_search()` provides LLM summaries which can miss detail.

**Solution — use a STATUS.md checkpoint file per project:**
```bash
# After each major phase, update project STATUS.md
echo "
# DSE Chinese Knowledge Base — Project Status
Last updated: $(date '+%Y-%m-%d %H:%M')

## Phase 1 ✅
- 13 crawls dispatched to Zeabur
- Dead sites documented
- Data pulled to raw/

## Phase 2 ✅
- SQLite DB built at data/dse-chinese/db/
- FTS5 enabled
- Migration script ready
" > data/dse-chinese/STATUS.md
```

**Protocol:** When user asks "what's the status?" on a new session:
1. Check for `STATUS.md` in project directory → immediate answer
2. Fall back to `session_search()` if no STATUS.md found
3. Check `memory` for checkpoint entries

## Project Status Tracking (Session Reset Countermeasure)

**Problem (May 2026):** Hermes session resets daily at 04:00 with `mode: both`. After reset, user asking "what did we do?" gets no context. `session_search()` returns LLM summaries which can miss detail or be truncated.

**Solution — STATUS.md + Memory checkpoint + context_only reset:**

### 1. Config: Use `context_only` reset mode
```yaml
session_reset:
  at_hour: 4
  mode: context_only    # clears compressed context but keeps conversation thread
```
This means: user can reply within the same Telegram conversation thread and the agent remembers what was said. The context window is still compressed to prevent bloat, but the conversation structure survives reset.

### 2. STATUS.md file (primary, per-project)
After each major phase, write/update a STATUS.md in the project directory:
```bash
# Use the update-status.sh helper:
bash scripts/update-status.sh data/dse-chinese \
  '{"phase":"Phase 2 - Database","status":"completed","detail":"SQLite + FTS5 built. 80 past papers, 13 topics"}'

# Or manually:
echo "# DSE Knowledge Base
Last updated: 2026-05-12

| Phase | Status | Detail |
|-------|--------|--------|
| Phase 1 | ✅ completed | 13 crawls done |" > data/dse-chinese/STATUS.md
```

### 3. Memory checkpoint (fallback, short)
```python
memory(action="add", target="memory",
       content="DSE Project@2026-05-12: P1✅13crawls P2✅SQLite P3✅notes. Pending: 19 dse00 articles")
```

### Protocol when user asks "做到邊?" on a NEW session:
1. First check: Look for STATUS.md in known project directories → immediate, detailed answer
2. Second check: `session_search("DSE OR 中文 OR knowledge OR crawl")` → matches past sessions
3. Third check: `read memory` → quick checkpoint summary
4. If all fail: Ask user what project they mean

## Deadline / Human-in-Loop Protocol

When tasks involve decisions with tradeoffs (partial data, dead sources, API costs), agree upfront:

```
User: "全跑" → Agent runs to completion, reports at end. No mid-way interruptions.
User: [no instruction] → Agent reports after each major phase with:
  1. What was done + metrics
  2. What was skipped/partial + reason
  3. 3 options for next step
  Then waits for user decision.
```

## Important Notes

- YouTube only fetches transcripts (text), NOT video files — very low bandwidth
- **Always upload scripts BEFORE dispatching** (scripts don't exist on remote workers by default)
- Use explicit SSH exec for script-based tasks, NOT TaskForge auto-route — auto-route sends scripts by name, not by content
- Background tasks run independently — can continue conversation while they execute
- **Zeabur needs Python deps pre-installed**: `pip3 install --break-system-packages beautifulsoup4 requests`
- **Browser fallback**: When HTTP scrape fails (DNS/429/connection), use Hermes browser tools on Oracle VM. Navigate, explore snapshot, extract with `browser_console` JS expressions. Save extracted data as structured JSON to `raw/` directory.
- **Phase 2 runs incrementally**: New data can be added anytime via migration script. Run `--init` to rebuild from all raw files, or pass a single file for incremental import.
- **Don't aim for perfect Phase 1**: Many DSE websites are defunct. Crawl what works, note dead sources in Known Issues, move to Phase 2. Future data can supplement the DB.
- **Notes content disclaimer**: Sections like 12篇範文分析 and 文言字詞用法 are AI-generated from curriculum knowledge, NOT extracted from real website content. The database may only have titles; analysis body is generated by the LLM. This is acceptable because the curriculum content is well-known, but mark the origin clearly.

### Cost Analysis: Local LLM vs API (May 2026)

For the typical DSE knowledge base workload (~20M tokens/month):

| Approach | Cost | Speed | Quality |
|----------|------|-------|---------|
| API (DeepSeek V4 Flash) | ~$5/month | Instant (200ms-2s) | Excellent |
| Local 7B Q4 (4 cores) | ~$25/month (VM) | 3-5 tok/s (30s wait) | Worse |
| Local 7B Q4 (8+ cores) | ~$35/month (VM) | 8-12 tok/s | Worse |

**Conclusion:** Local LLM is NOT worth it for this project unless:
- Monthly token usage exceeds ~500M tokens (break-even vs API)
- You need offline/air-gapped operation
- You're doing private data processing

The Oracle VM's 4 cores are insufficient for acceptable local LLM speed (3-5 tok/s is painful for interactive use). The existing API setup is 5x cheaper and 10x faster.

### Local Concurrency: Multi-VM vs Single-VM (May 2026)

You DON'T need multiple VMs for I/O-bound concurrency. Single VM can handle 20-30 concurrent Python/Node processes (each ~100-200MB).

**Multi-VM is for fault isolation, NOT raw concurrency.** Three VMs is over-engineering for most DSE workloads. A single 4-8GB VM with async process pool (using `spawn()` instead of `execSync()`) handles everything.

The TaskForge orchestrator was updated to use async `spawn()` for local (localhost) tasks, enabling concurrent execution on the same VM. The fix was:
1. Replace `execSync(cmd)` with `spawn('node', [agentPath, taskPath])` wrapped in Promise
2. Resolve `~` tilde to actual HOME path: `path.join(process.env.HOME, 'hermes-worker/agent.js')`
3. Concurrent counts tracked accurately via `this._concurrentCounts[workerId]`

### Automation Tooling: Cost

| Tool | Cost | Purpose |
|------|------|---------|
| TaskForge (already built) | **$0** | Task dispatch across workers |
| Ansible | **$0** | Batch commands across 8+ VMs (only needed if scaling beyond 3) |
| Terraform | **$0** | Provision/destroy VMs (only needed for dynamic scaling) |

All are open-source, CLI-based, no licensing cost. Hermes AI can orchestrate them as the "brain" — TaskForge/Ansible/Terraform are the "hands".

### When to add VMs

```
Current workload: ~1-2GB peak RAM → 3 VMs is overkill
  ✅ Fix TaskForge dispatch (done May 2026)
  ⚠️ Don't add more VMs

When you NEED another VM:
  - You run local LLM (needs GPU or 8+ cores)
  - You do video/audio processing (CPU bound)
  - You need geographic distribution (low latency in different regions)
  - Single VM RAM insufficient (>16GB workload)
```

## Verification

After Phase 1:
```bash
# Check crawl results on each worker
ssh -i ~/.ssh/zeabur_devbox.pem ubuntu@43.156.247.30 "ls -la /tmp/dse-cache/"
```

After Phase 2:
```bash
# Check DB contents
sqlite3 data/dse-chinese/db/dse_chinese.db "SELECT COUNT(*) FROM articles; SELECT COUNT(*) FROM past_papers; SELECT COUNT(*) FROM writing_topics;"
```

## Known Issues (May 2026)

1. **dse-chinese.com, afterclass.hk, dse-tips.com**: DNS dead — confirmed via both HTTP requests and Hermes browser tool. `ERR_NAME_NOT_RESOLVED`. These sites no longer exist. No workaround.
2. **dsepp.com past papers**: Only 2012-2017 available. 2018+ postings not found on this site. The PDF metadata URLs go to `wp-content/uploads/2018/12/` suggesting the site stopped updating around 2018. However, the site IS alive and accessible — use browser tool at `/resource_centre/chinese` to get PDFs, NOT http scrape which gets 429 rate limited.
3. **dse00 articles**: 21 Chinese DSE article links found on the label page. Only 2 full article contents scraped (作文背文正確方法, 15+6修辭手法). Remaining 19 need individual browser_navigate + content extraction. Each article visit requires a new page load — use `browser_console(document.querySelector('.post-body').innerText)` per visit. Browser sessions may expire/timeout — save progress incrementally. **Note:** Do NOT delegate this to a subagent — subagents often lack browser tools and will timeout. Scrape the articles yourself in a loop, saving incrementally.
4. **writing-topics data**: Only year labels (2012-2024), no actual writing topic questions. The raw scrape used dse00 blog front-page posts which are NOT exam paper questions — they're general blog content. To get real writing topics, either (a) extract from dsepp PDF 卷2 (writing paper), (b) scrape HKEAA website directly, or (c) manually compose from known exam questions.
5. **PDF downloading**: 80 PDF links collected (~100MB total) but NOT downloaded. HKEAA PDFs behind clickwall; dsepp links are direct downloads. Download with `wget` or `curl` if needed.
6. **Zeabur Python**: Needs `--break-system-packages` flag for `pip3 install`. BeautifulSoup4 and requests are the only requirements for scrape scripts.
7. **subagent limitation**: `delegate_task` with goal of scraping multiple pages often fails — subagents may not have browser tools, or may timeout (max ~360s). For multi-page browser scraping, do it yourself with sequential browser_navigate + console extraction, NOT subagent.
8. **Session reset**: Daily 04:00 reset means cross-session progress tracking requires explicit checkpointing (STATUS.md or memory). Don't rely on conversation context surviving.
9. **Notes disclaimer**: Sections like 12篇範文分析 and 文言字詞用法 are AI-generated from curriculum knowledge, NOT extracted from real website content. The database only had titles; analysis body was generated by the LLM.
10. **TaskForge dispatch after fix**: All 3 workers (oracle-vm1, big-vm, zeabur) alive as of May 12. DSE crawls dispatch successfully. The orchestrator singleton (`_orchestrator`) prevents two in-process instances — need a fresh node process if re-running.
