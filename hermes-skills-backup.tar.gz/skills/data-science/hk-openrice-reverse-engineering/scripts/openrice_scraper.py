#!/usr/bin/env python3.9
"""
OpenRice HK Restaurant Scraper
Fetches restaurant data from OpenRice's internal API.

Usage:
    python3.9 openrice_scraper.py                    # Default: top restaurants
    python3.9 openrice_scraper.py --district 2010    # 旺角 restaurants
    python3.9 openrice_scraper.py --search tandoor    # Search by name
    python3.9 openrice_scraper.py --cuisine 2004      # Thai restaurants
"""

import urllib.request
import urllib.parse
import json
import ssl
import argparse
from typing import Optional, List, Dict, Any


def fetch_openrice_restaurants(
    districtId: Optional[int] = None,
    cuisineId: Optional[int] = None,
    rows: int = 20,
    startAt: int = 0,
    search_term: Optional[str] = None,
    priceRangeId: Optional[int] = None,
) -> Dict[str, Any]:
    """Fetch restaurants from OpenRice internal API."""
    ctx = ssl.create_default_context()
    params = {
        "sortBy": "ORScoreDesc",
        "apiEntryPoint": "PoiSR1",
        "regionId": "0",
        "uiLang": "zh",
        "uiCity": "hongkong",
        "rows": str(min(rows, 250)),
        "startAt": str(startAt),
    }
    if districtId:
        params["districtId"] = str(districtId)
    if cuisineId:
        params["cuisineId"] = str(cuisineId)
    if search_term:
        params["searchTerm"] = search_term
    if priceRangeId:
        params["priceRangeId"] = str(priceRangeId)

    url = f"https://www.openrice.com/api/v2/search?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.openrice.com/zh/hongkong/restaurants",
        },
    )
    resp = urllib.request.urlopen(req, context=ctx, timeout=15)
    return json.loads(resp.read())


def get_districts() -> List[Dict]:
    """Fetch all HK districts from OpenRice metadata API."""
    ctx = ssl.create_default_context()
    url = "https://www.openrice.com/api/v2/metadata/region/all?uiLang=zh&uiCity=hongkong"
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    resp = urllib.request.urlopen(req, context=ctx, timeout=15)
    data = json.loads(resp.read())
    return data.get("districts", [])


PRICE_LABELS = {1: "$50以下", 2: "$51-100", 3: "$101-200", 4: "$201-400", 5: "$401-800", 6: "$800以上"}


def print_restaurants(results: List[Dict], start: int = 0):
    """Pretty print restaurant results."""
    for i, r in enumerate(results, start + 1):
        cuisines = [c["name"] for c in r.get("categories", []) if c.get("categoryTypeId") == 1]
        price = PRICE_LABELS.get(r.get("priceRangeId", 0), "未知")
        open_status = "營業中" if r.get("openNow") else "休息"
        print(f"{i}. {r['name']}")
        print(f"   地址: {r['address']}")
        print(f"   地區: {r.get('district', {}).get('name', 'N/A')} | 評分: {r.get('scoreOverall', 'N/A'):.2f}")
        print(f"   價錢: {price} | 狀態: {open_status}")
        print(f"   菜式: {', '.join(cuisines) if cuisines else 'N/A'}")
        print(f"   相片: {r.get('photoCount', 0):,} | 食評: {r.get('reviewCount', 0):,} | 收藏: {r.get('bookmarkedUserCount', 0):,}")
        if r.get("phones"):
            print(f"   電話: {', '.join(r['phones'])}")
        print()


def main():
    parser = argparse.ArgumentParser(description="OpenRice HK Restaurant Scraper")
    parser.add_argument("--district", type=int, help="District ID (e.g. 2010=旺角, 2008=尖沙咀)")
    parser.add_argument("--cuisine", type=int, help="Cuisine ID (e.g. 2004=泰國菜)")
    parser.add_argument("--search", type=str, help="Search term (restaurant name)")
    parser.add_argument("--price", type=int, choices=[1, 2, 3, 4, 5, 6], help="Price range 1-6")
    parser.add_argument("--rows", type=int, default=10, help="Number of results (max 250)")
    parser.add_argument("--start", type=int, default=0, help="Pagination offset")
    parser.add_argument("--list-districts", action="store_true", help="List all available districts")
    args = parser.parse_args()

    if args.list_districts:
        districts = get_districts()
        print(f"Total districts: {len(districts)}\n")
        for d in districts:
            names = d.get("nameLangDict", {})
            print(f"  {d['districtId']}: {names.get('tc', 'N/A')} ({names.get('en', 'N/A')})")
        return

    print(f"Fetching up to {args.rows} restaurants...\n")
    result = fetch_openrice_restaurants(
        districtId=args.district,
        cuisineId=args.cuisine,
        search_term=args.search,
        priceRangeId=args.price,
        rows=args.rows,
        startAt=args.start,
    )

    total = result.get("paginationResult", {}).get("count", 0)
    results = result.get("paginationResult", {}).get("results", [])
    print(f"Total matching restaurants: {total:,}\n")
    if results:
        print_restaurants(results, start=args.start)
        print(f"(Showing {len(results)} of {total:,})")
    else:
        print("No results found.")


if __name__ == "__main__":
    main()
