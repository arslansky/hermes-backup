---
name: hk-openrice-reverse-engineering
description: Reverse engineer OpenRice's internal API to fetch HK restaurant data without an official public API. Includes Playwright network interception discovery method and working endpoint parameters.. Use when: OpenRice, reverse engineering, restaurant API, 香港餐廳
category: data-science
---

# HK OpenRice API Reverse Engineering

## Task
Programmatically fetch Hong Kong restaurant data from OpenRice (`openrice.com`) without an official public API.

## Key Findings

### 1. OpenRice Internal API (Working)

**Base URL:** `https://www.openrice.com/api/v2/search`

**Minimal working curl:**
```bash
curl -s "https://www.openrice.com/api/v2/search?sortBy=ORScoreDesc&apiEntryPoint=PoiSR1&regionId=0&uiLang=zh&uiCity=hongkong&rows=20&startAt=0" \
  -H "Accept: application/json" \
  -H "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" \
  -H "Referer: https://www.openrice.com/zh/hongkong/restaurants"
```

**Required headers:**
- `Accept: application/json`
- `User-Agent: Mozilla/5.0 ...` (Chrome browser UA)
- `Referer: https://www.openrice.com/zh/hongkong/restaurants` (or any openrice page)

**Query parameters:**
| Parameter | Value | Notes |
|-----------|-------|-------|
| `apiEntryPoint` | `PoiSR1` | POI Search Result — fixed value |
| `sortBy` | `ReviewCountDesc` | Sort by review count (descending) |

**Important:** `sortBy=ORScoreDesc` returns high-rated restaurants (often Japanese/Korean), while `sortBy=ReviewCountDesc` returns the most popular/shoppy restaurants (e.g. 九記牛腩, 澳洲牛奶公司). Use the right sort for the task.
| `regionId` | `0` | Hong Kong region |
| `uiLang` | `zh` | Traditional Chinese |
| `uiCity` | `hongkong` | City = Hong Kong |
| `rows` | `1-250` | Results per page (max 250) |
| `startAt` | `0, 250, 500...` | Pagination offset |
| `districtId` | e.g. `2010` (旺角), `2008` (尖沙咀) | Filter by district |
| `cuisineId` | e.g. `2004` (泰國菜) | Filter by cuisine |
| `searchTerm` | e.g. `tandoor` | Text search |
| `priceRangeId` | `1-6` | Price range filter |
| `poiType` | `1` | Restaurant type |

**Districts:** 87 total, retrieved from:
```
https://www.openrice.com/api/v2/metadata/region/all?uiLang=zh&uiCity=hongkong
```

**Known district IDs:**
- 旺角: `2010`
- 尖沙咀: `2008`
- 銅鑼灣: `1019`
- 中環: `1003`
- 觀塘: `2026`
- 九龍塘: `2002`

### 2. What Failed

| Method | Result |
|--------|--------|
| Old `api.openrice.com` endpoints | BytePlus WAF JS challenge blocking |
| `jeffffc/openriceapi` Python library | Defunct (endpoints gone) |
| Direct `/api/v2/search/count/nofacet` | Returns only metadata, no restaurant data |
| `/api/v2/search/poi` | 404 |
| RSS feeds | 404 |
| Brave Search API | 403 forbidden from this server |
| Firecrawl SDK | No API key found in environment |
| **Global `startAt` pagination (`startAt >= 10000`)** | **HTTP 500 — server-side bug, not rate limit. Root cause: OpenRice's server physically cannot handle deep pagination. Verified: `startAt=0` works, `startAt=5000` works, `startAt=10000` returns 500. MUST use per-district fetching instead.** |

**Never try to bypass 500 from `startAt >= 10000` with retries** — it's a server bug, not rate limiting. The background process (`openrice_sync.py`) stuck at `startAt=10000` demonstrates this. It will retry forever and never succeed. Kill it and use district-based scraping instead.

### 3. Discovery Method (Playwright Network Interception)

When the website works but curl doesn't, use Playwright to find hidden API calls:

```python
import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
        page = await context.new_page()

        async def on_request(req):
            if '/api/' in req.url:
                print(f"REQ: {req.method} {req.url}")

        async def on_response(resp):
            try:
                body = await resp.text()
                url = resp.url
                if '/api/' in url and body.startswith('{') and len(body) > 1000:
                    print(f"RESP: {resp.status} {url}")
            except:
                pass

        page.on('request', on_request)
        page.on('response', on_response)

        await page.goto('https://www.openrice.com/zh/hongkong/restaurants?districtId=2010',
                       wait_until='domcontentloaded', timeout=15000)
        await page.wait_for_timeout(8000)
        await browser.close()

asyncio.run(main())
```

**Key insight:** The `/api/v2/search/count/nofacet` endpoint returns metadata (facet counts), but the **actual restaurant data** comes from `/api/v2/search` with the same parameters minus `/count/nofacet`.

### 4. Response Data Structure

```python
{
  "paginationResult": {
    "count": 32982,        # Total matching restaurants
    "totalReturnCount": 250,
    "results": [           # Array of restaurant objects
      {
        "poiId": 588815,
        "name": "Milu Thai มิลู่ไทย (百樂中心)",
        "address": "耀華街3號百樂中心2樓",
        "scoreOverall": 4.38,
        "priceRangeId": 3,   # 1=最平, 6=最貴
        "district": {"districtId": 1019, "name": "銅鑼灣"},
        "categories": [     # cuisine and dish types
          {"categoryTypeId": 1, "name": "泰國菜"}
        ],
        "photoCount": 14946,
        "reviewCount": 1685,
        "bookmarkedUserCount": 158947,
        "phones": ["28850060"],
        "openNow": True,
        "mapLatitude": 22.2776,
        "mapLongitude": 114.1821
      }
    ]
  }
}
```

### 5. Go Scraper Template

**IMPORTANT — Use `url.Values` for encoding, NOT string concatenation!**

```go
import (
    "crypto/tls"
    "encoding/json"
    "net/http"
    "net/url"
    "sort"
)

func fetch(urlParams map[string]string) (*SearchResult, error) {
    v := url.Values{}
    keys := make([]string, 0, len(urlParams))
    for k := range urlParams {
        keys = append(keys, k)
    }
    sort.Strings(keys) // deterministic order
    for _, k := range keys {
        v.Add(k, urlParams[k])
    }

    urlStr := "https://www.openrice.com/api/v2/search?" + v.Encode()

    ctx := &http.Client{Transport: &http.Transport{
        TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12},
    }}

    req, _ := http.NewRequest("GET", urlStr, nil)
    req.Header.Set("Accept", "application/json")
    req.Header.Set("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
    req.Header.Set("Referer", "https://www.openrice.com/zh/hongkong/restaurants")

    resp, err := ctx.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    body, _ := io.ReadAll(resp.Body)
    var result SearchResult
    if err := json.Unmarshal(body, &result); err != nil {
        return nil, err
    }
    return &result, nil
}
```

**Why `url.Values` and not `k+"="+v`?** OpenRice's API returns 400 Bad Request for non-ASCII characters (e.g. Chinese search terms) when encoded naively. `url.Values.Add()` applies proper `url.QueryEscape()` to each value. Parameter ordering also appears to matter for some API endpoints — sorting keys ensures consistent requests.

### 6. Python Scraper Template

```python
import urllib.request, urllib.parse, json, ssl

def fetch_openrice_restaurants(districtId=None, cuisineId=None,
                                rows=20, startAt=0, search_term=None):
    ctx = ssl.create_default_context()
    params = {
        'sortBy': 'ORScoreDesc',
        'apiEntryPoint': 'PoiSR1',
        'regionId': '0',
        'uiLang': 'zh',
        'uiCity': 'hongkong',
        'rows': str(min(rows, 250)),
        'startAt': str(startAt)
    }
    if districtId:
        params['districtId'] = str(districtId)
    if cuisineId:
        params['cuisineId'] = str(cuisineId)
    if search_term:
        params['name'] = search_term  # NOTE: 'name', NOT 'searchTerm'

    url = f"https://www.openrice.com/api/v2/search?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'Referer': 'https://www.openrice.com/zh/hongkong/restaurants'
    })
    resp = urllib.request.urlopen(req, context=ctx, timeout=15)
    return json.loads(resp.read())
```

### 7. Rate Limiting — Full Progression (Discovered 2025-05-09, Updated 2026-05-10)

OpenRice's blocking has **three stages**:

| Stage | Trigger | HTTP Code | Behavior |
|-------|---------|-----------|----------|
| 1. Normal | 0-10,000 requests | 200 | Working fine |
| 2. **Server-side pagination bug** | `startAt >= 10000` | **500 Internal Server Error** | BUG: OpenRice server cannot handle deep pagination regardless of IP or request count |
| 3. IP block | After prolonged abuse | **403 Forbidden** | Complete block, ALL endpoints return 403 |

**Stage 1 → 2 root cause — CRITICAL FINDING (2026-05-10):**
`startAt >= 10000` returns HTTP 500 on OpenRice's server for **any** IP address — this is a server-side pagination bug or deliberate limitation, NOT a rate limit you can retry through. Verified across multiple IPs:
```
startAt=0:     ✅ 5 results
startAt=5000:  ✅ 5 results  
startAt=10000: ❌ HTTP 500 Internal Server Error
startAt=15000: ❌ HTTP 500 Internal Server Error
startAt=20000: ❌ HTTP 500 Internal Server Error
startAt=25000: ❌ HTTP 500 Internal Server Error
```
**Stage 2 → 3 transition:** Continued scraping eventually results in **403 Forbidden** on ALL OpenRice API endpoints, including the metadata endpoint (`/api/v2/metadata/region/all`). This appears to be a permanent IP-level block.

**Stage 3 also manifests as HTML responses** — OpenRice's bot detection sometimes returns an HTML challenge page instead of JSON. When you see `b'<html>'` instead of `b'{'`, you've been flagged. The API still technically "responds" (HTTP 200) but with HTML content. Check with:
```python
raw = resp.read()
if not raw.startswith(b'{'):
    print("Bot detection — received HTML challenge page")
```

**Stage 2 → 3 bot detection workaround:** Adding delays (20-30s between batches) and small batch sizes reduce the rate of bot detection triggering. However, once 403 is returned, no workaround exists except waiting.

**District-based workaround — THE ONLY WORKING METHOD (Verified 2026-05-10):**
Per-district `districtId` scraping bypasses BOTH the pagination bug AND reduces rate limit pressure:

| District | Server Count | Verified Pagination Limit |
|----------|-------------|--------------------------|
| 尖沙咀 (2008) | 2,112 | startAt=0 → 2100 works, 2200+ returns 0 |
| 中環 (1003) | 1,589 | startAt=0 → 1500 works, 2000+ returns 0 |
| 旺角 (2010) | 1,358 | startAt=0 → 1350 works, 1400+ returns 0 |
| 銅鑼灣 (1019) | 1,292 | similar pattern |
| 荃灣 (3018) | 1,418 | similar pattern |
| 元朗 (3003) | 1,489 | similar pattern |

Each district has its OWN ~2000 record limit via `startAt`, independent of the global pagination. The server metadata `count` reflects actual available restaurants per district.

**District scraper script (working — 2026-05-10):**
```bash
# Run district-based scraper (bypasses 10,000 global limit)
python3 /home/opc/.openrice_district_scraper.py                    # Start/resume
python3 /home/opc/.openrice_district_scraper.py --status           # Show progress
python3 /home/opc/.openrice_district_scraper.py --reset            # Reset and restart

# Background operation (use nohup for true background)
nohup python3 /home/opc/.openrice_district_scraper.py > /tmp/openrice_district_scraper.out 2>&1 &

# Check progress
tail -f /tmp/openrice_district_scraper.out
python3 -c "import sqlite3; c=sqlite3.connect('/home/opc/.openrice-hk.db').cursor(); print(c.execute('SELECT COUNT(*) FROM restaurants').fetchone()[0])"
```

**Scraper script location: `/home/opc/.openrice_district_scraper.py`** (not in ~/.hermes/scripts — user's copy lives at homedir)

**Key features of the district scraper:**
- 99 districts from `/api/v2/metadata/region/all`
- `districtId` parameter for each district (positive integer IDs, some negatives for special zones)
- Batch size: 250, delay: 20s between batches (reduces bot detection trigger rate)
- Checkpoint after every district: `/home/opc/.openrice_checkpoint.json`
- 99 districts × ~2000 max each = ~198,000 potential capacity (server says ~32,982 real restaurants)
- Verified: 10,000 → 10,800 in 15 minutes, growing. District 1 (Hong Kong Island) alone collected 3,750+ restaurants.

**Why district scraping avoids rate limiting:**
- Each batch of 250 requests only advances `startAt` within one district (max ~2000)
- Different districts = different result sets = lower perceived abuse pattern
- 20s delay between batches spreads load over time
- No single `startAt` value gets hammered repeatedly

**Critical findings from trial (2026-05-10):**
1. `startAt >= 10000` is a SERVER-SIDE bug (verified: same error from different IPs)
2. Background process `openrice_sync.py` stuck at startAt=10000 — KILL IT and use district scraper
3. Bot detection returns HTML not JSON (check with `raw[:5] == b'<html>'`)
4. Server metadata endpoint works for district list even during 403 on search API
5. Adding `districtId` filter to `startAt=0` returns DIFFERENT restaurants than global `startAt=0` — the global query over-returns popular restaurants across all HK, while district queries return restaurants sorted within that district

**Database path:** `/home/opc/.openrice-hk.db` (SQLite, 3MB, 10,000+ restaurants)
**Checkpoint path:** `/home/opc/.openrice_checkpoint.json`
**Output log:** `/tmp/openrice_district_scraper.out`
**Old log (from broken global pagination sync):** `/tmp/openrice_sync.log`

**Quick sanity check after running scraper:**
```bash
# The DB count should ALWAYS increase. If it stays flat while scraper is running:
# 1. Check if scraper is actually making progress (tail -5 /tmp/openrice_district_scraper.out)
# 2. Check if API returned HTML (bot detection): grep -c '<html>' /tmp/openrice_district_scraper.out
# 3. If DB count temporarily drops in --status output, it's because checkpoint hasn't been saved yet
#    (DB has new data but checkpoint file is stale — scraper is working, just hasn't checkpointed)
```

**Existing datasets:**
- `/home/opc/.openrice-hk.db` — SQLite with 10,000 restaurants (synced via global `startAt` pagination — stuck at 10000 due to server bug, NOT rate limited)
- `/home/opc/.hermes/scripts/.openrice_checkpoint.json` — checkpoint for district-based scraper
- `/home/opc/.openrice_sync.log` — sync log

### 8. If Blocked by 403 — Options

**Option A: Wait and retry (low success probability)**
- 403 may lift after hours/days if OpenRice rotates IPs or relaxes the block
- Check by running: `curl -s -o /dev/null -w "%{http_code}" "https://www.openrice.com/api/v2/search?sortBy=ORScoreDesc&apiEntryPoint=PoiSR1&regionId=0&uiLang=zh&uiCity=hongkong&rows=1&startAt=0"`
- If it returns 200, resume with `--resume` flag

**Option B: Foodpanda HK (recommended — no blocking)**
```bash
/home/opc/go/bin/foodpanda-hk --help
# Sitemap crawl: fully available, no rate limiting
# Coverage: ~18,377 restaurants, different IP range so no OpenRice block correlation
```

**Option C: Use existing 31,540 restaurants (already 95% complete)**
- Core areas: 尖沙咀(2112), 中環(1589), 元朗(1489), 荃灣(1418), 屯門(1390), 旺角(1358), 觀塘(1305), 銅鑼灣(1292), 灣仔(1281)
- Missing: 蒲苔島(+8), 南丫島(+?), 坪洲(+?), 長洲(+) and other small islands
- SQLite schema: `poi_id, name, name_other, address, address_other, score, review_count, price_range, photo_count, district_id, district_name, cuisine, open_now, map_lat, map_lon, phone, open_since`

### 9. Resuming After Rate Limit

```bash
cd ~/.hermes/scripts
python3.9 openrice_district_scraper.py --resume   # Check checkpoint
python3.9 openrice_district_scraper.py --run      # Resume (if 403 has lifted)
python3.9 openrice_district_scraper.py --stats    # Show current DB stats
```

### 9. Notes & Caveats

- **`startAt >= 10000` is a server bug, not a rate limit** — the background sync process `openrice_sync.py` will get stuck retrying forever at `startAt=10000`. If you see this pattern, kill the process and switch to district-based scraping.
- **Rate limiting:** Not tested — add delays between requests if scraping large amounts
- **No auth required** — this is an internal API used by the website itself
- **Max rows:** 250 per request (pagination via `startAt`)
- **Working Python:** Use `python3.9` (not system `python3` or venv) for Playwright
- **Old API (`api.openrice.com`):** Dead since at least 2024, blocked by BytePlus WAF
- **Brave Search API:** Returns 403 when called from this server environment
- **Firecrawl:** Installed (`firecrawl-py v4.23.0`) but no API key found in env
- **`name` param NOT `searchTerm`:** The search parameter is `name`, not `searchTerm`. `searchTerm` returns the same top results regardless of input — confirmed by testing. The OpenRice website uses `name` for search.
