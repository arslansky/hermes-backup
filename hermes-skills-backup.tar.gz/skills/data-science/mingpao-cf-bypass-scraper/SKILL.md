---
name: mingpao-cf-bypass-scraper
description: "Scrape Ming Pao Daily News (明報) — bypass Cloudflare on news.mingpao.com subdomain, full article content extraction, concurrent pipeline for 264+ articles. Use when: 明報, Ming Pao, Cloudflare bypass, news scrape, CF bypass"
---

# 明報 CF Bypass Scraper

Complete pipeline for scraping Ming Pao Daily News articles — bypassing Cloudflare protection, extracting full article content, and producing AI-summarized daily digests.

## Cron Job Setup

Cron job: `mingpao-daily-digest` (job_id: 6941cf1d2213)
- Schedule: `15 6 * * *` (06:15 HKT daily)
- Model: MiniMax-M2.7
- Deliver: `telegram:-1003654034759:1907` (EXPLICIT — do NOT use "origin")
- Scraper script: `/home/opc/.hermes/scripts/mingpao_scraper.py`
- Temporary data: `/tmp/mingpao_today.json`
- Official output: `~/.hermes/cron/output/mingpao_digest_YYYYMMDD.txt`
- Delivery method: cron auto-delivers final response; txt file is saved and system handles file upload

The cron prompt calls the scraper script via terminal(), then uses delegate_task batches summarization via MiniMax.

## Proxy Credentials (2026-06-05 VERIFIED WORKING)

**Proxy:** `http://prs:gru@c9.hk2.yfip.top:30426`
- Exit IP: `124.155.247.14` (住宅 IP)
- Oracle VM 可以直連，curl + proxy 可成功連接

### Two-Phase Approach (2026-06-08 VERIFIED)

**Phase 1 — Section pages: CloakBrowser (JS rendering required)**
```python
from cloakbrowser import launch
browser = launch(headless=True)  # NO proxy needed — CloakBrowser bypasses CF on its own
page = browser.new_page()
page.goto(url, timeout=25000)
import time; time.sleep(2)
html = page.content()
browser.close()
```

**Phase 2 — Article content: requests + proxy (pure HTML, no JS needed)**
```python
PROXIES = {
    'http': 'http://prs:gru@c9.hk2.yfip.top:30426',
    'https': 'http://prs:gru@c9.hk2.yfip.top:30426',
}
r = requests.get(url, headers=HEADERS, proxies=PROXIES, timeout=20)
```

### ⚠️ Critical: CloakBrowser Must Be Sequential
- CloakBrowser uses Playwright Sync API which conflicts with asyncio/ThreadPoolExecutor
- **Never** call CloakBrowser inside a thread or async context
- Run CloakBrowser section fetching sequentially in the main thread
- Phase 2 (article content scraping) CAN use ThreadPoolExecutor (it's just requests)

### Important: Proxy URL Format
Proxy URL MUST include credentials as `http://user:pass@host:port`.
- With credentials → works
- Without credentials → `407 Proxy Authentication Required`

### Alternative: Browserbase with Scale Plan

Set `BROWSERBASE_KEY` in `~/.hermes/.env` for residential proxy.

## Phase 1: Get All Article URLs (13 Section Pages — Sequential CloakBrowser)

Scrape all PNS (每日明報/print edition) and INS (即時新聞/breaking) sections **sequentially** (CloakBrowser asyncio conflict with threads):

```python
from urllib.parse import urljoin, unquote

BASE = "https://news.mingpao.com"
sections = [
    ("要聞", "https://news.mingpao.com/pns/要聞/section/latest/s00001"),
    ("港聞", "https://news.mingpao.com/pns/港聞/section/latest/s00002"),
    ("經濟", "https://news.mingpao.com/pns/經濟/section/latest/s00004"),
    ("娛樂", "https://news.mingpao.com/pns/娛樂/section/latest/s00016"),
    ("副刊", "https://news.mingpao.com/pns/副刊/section/latest/s00005"),
    ("社評", "https://news.mingpao.com/pns/社評/section/latest/s00003"),
    ("觀點", "https://news.mingpao.com/pns/觀點/section/latest/s00012"),
    ("中國", "https://news.mingpao.com/pns/中國/section/latest/s00013"),
    ("國際", "https://news.mingpao.com/pns/國際/section/latest/s00014"),
    ("即時港聞", "https://news.mingpao.com/ins/港聞/section/latest/s00001"),
    ("即時熱點", "https://news.mingpao.com/ins/熱點/section/latest/s00024"),
    ("即時兩岸", "https://news.mingpao.com/ins/兩岸/section/latest/s00004"),
    ("即時國際", "https://news.mingpao.com/ins/國際/section/latest/s00005"),
]

def fetch_section(name, url):
    browser = launch(headless=True)
    page = browser.new_page()
    page.goto(url, timeout=25000)
    import time; time.sleep(2)
    html = page.content()
    browser.close()

    # Section pages return both relative (../) and absolute (https://) URLs
    links_rel = re.findall(r'href=\"(\.\./(?:ins|pns)/[^\"]*?article[^\"]+)\"', html)
    links_abs = re.findall(r'href=\"(https://news\.mingpao\.com/(?:ins|pns)/[^\"]*?article[^\"]+)\"', html)
    all_links = links_rel + links_abs

    articles = []
    for l in all_links:
        abs_url = l if l.startswith('https://') else urljoin(BASE, l.lstrip('../'))
        slug = abs_url.split('/')[-1]
        title = unquote(re.sub(r'-[^-]+$', '', slug)).replace('-', '，')
        articles.append((abs_url, title, name))
    return name, articles

# Run sequentially (MUST be sequential — CloakBrowser asyncio conflict)
section_articles = {}
for name, url in sections:
    name, articles = fetch_section(name, url)
    section_articles[name] = articles  # ~150-200 articles total
```

**Expected output:** ~150-200 articles across 13 sections (requires ~3-4 min due to sequential nature)

**⚠️ Network instability:** Some sections may timeout. Implement retry once for failed sections.

## Phase 2: Scrape Full Article Content

Each article page uses standard HTML structure:
- **Title:** `<h1>` tag
- **Summary:** `<meta property="og:description">`
- **Body:** `<p>` tags with content >20 characters (filter out browser upgrade warnings)

**PNS articles** sometimes have only 1-2 paragraphs of content in the OG description alone. Use both.

**Run concurrent requests** for speed (max_workers=10):
- ~55KB HTML per article (includes nav, ads, etc.)
- ~2KB pure text content per article
- 264 articles: ~14MB raw HTML, ~565KB extracted text

**Performance:**
- Sequential: ~53s
- Concurrent (10 workers): ~5-8s

## Phase 3: AI Summary Pipeline

Feed extracted articles to subagent for summarization. Output format:

```
## 📰 要聞（<篇數>篇）

【標題】（時間）
📝 3-5句重點摘要

---
```

**Note: Use MiniMax-M2.7 model for summarization, not DeepSeek.**

**Token cost breakdown (DeepSeek pricing):**
- Phase 2 scraping: ~1.87M input / ~28K output = ~$0.52
- Phase 3 AI summary: ~1.34M input / ~14K output = ~$0.38
- Total full pipeline: ~$0.95 USD (~HK$7.40)

## Multi-Worker Parallel Dispatch (Subagent Mode)

For maximum speed, dispatch scraping + summary to subagents via `delegate_task()`:

### Strategy: Shard by section pages
Split the 13 sections evenly across N subagents. Each subagent receives a list of section URLs, scrapes them independently, and returns the extracted data.

### Performance: 6 subagents (3 concurrent) + summary
```
Phase 1 (headlines):    0.6s    →  concurrent requests in agent loop
Phase 2 (full text):   60-114s  →  6 subagents × 44 articles each (max_conc=3)
Phase 3 (AI summary):  ~157s    →  1 subagent, 565KB input → 16KB output
Total wall time:       ~4.5min
Total input tokens:    ~3.3M (all deepseek-chat)
Total cost:            ~$0.95 USD (~HK$7.40)
```

### Key bottleneck observations
1. **Phase 2 bottleneck**: `max_concurrent_children=3` means only 3 subagents run at once. Batch 0-1 each took ~94-114s (large input due to `read_file` + write + debug iterations). Batches 2-5 at 30-63s.
   - **Fix**: Set `max_concurrent_children=6` for faster dispatch
   - Alternative: Use direct `terminal()` Python scripts instead of subagents for pure scraping (no AI logic needed)

2. **Phase 3 bottleneck**: Single subagent processing 565KB of text → 157s.
   - **Fix**: Split the 264 articles into 2-3 batches, each sent to a separate subagent for summary, then merge results in agent loop

3. **Subagent approach is overkill for scraping-only tasks**: If no AI summarization is needed per-section, use `concurrent.futures.ThreadPoolExecutor` with raw `requests` inside a single `terminal()` Python script — much faster (~5-8s for all 264 articles) and cheaper (no LLM token cost).

### Hybrid recommended setup
- **Phase 1**: `concurrent.futures` in agent loop → 0.6s
- **Phase 2**: `concurrent.futures` with `requests` in a single `terminal()` Python script → 5-8s, $0
- **Phase 3**: Split articles into 2-3 batches by section, dispatch to 2-3 subagents in parallel for AI summary → ~80s, ~$0.38

## Architecture: v2 Scraper (2026-06-13)

**Dual-track approach:**
- Phase 1: CloakBrowser via ProcessPoolExecutor (max_workers=4, each worker processes 3-4 sections sequentially)
- Phase 2: ThreadPoolExecutor requests (max_workers=10)
- Phase 3: MiniMax API for AI summary

**Performance (2026-06-13 test):**
- Phase 1: ~65s (4 workers, 13 sections total)
- Phase 2: ~12s (262 articles, 10 workers)
- Phase 3: ~2s (MiniMax-M2.7)
- Total: ~79s wall time, 262 articles

**Key improvements over v1:**
- ProcessPoolExecutor bypasses Playwright asyncio conflict
- MiniMax key auto-loaded from .env
- AI summary generated inline

## Architecture Options

### Option A: Headline-only cron job (~1s, <$0.01)
Scrape section pages → extract titles → short AI summary → deliver

### Option B: Headline + top 20 articles (~5s, ~$0.05)
Phase 1 + select important articles → Phase 2 for selected → summary

### Option C: Full 264 articles (~8s scrape, ~$0.95 total)
Use this skill's full pipeline

### Performance comparison table

| Phase | Sequential CloakBrowser | Concurrent (requests only) | Notes |
|-------|------------------------|---------------------------|-------|
| Phase 1: Section URLs | ~3-4 min (13 sections) | N/A (CloakBrowser must be sequential) | ~150-200 articles |
| Phase 2: Article content | ~53s | **5-8s** (10 workers) | ~55KB HTML per article |
| Phase 3: AI summary | ~157s | ~157s (single) | Split into 2-3 batches for speed |
| **Total wall** | ~4-5 min | ~3-4 min | Phase 1 is the bottleneck |
| **Total cost** | ~$0.95 | ~$0.95 | Same LLM cost for summary |

## Known Pitfalls
## Script Fixes Log (2026-06-10)

### Bug fix: CloakBrowser must NOT use proxy
**Problem (0610 failure):** `fetch_section()` passed `proxy=PROXY_URL` to CloakBrowser, causing `ERR_TUNNEL_CONNECTION_FAILED` on ALL section pages. 要聞/港聞/中國/國際全部fail。

**Root cause:** CloakBrowser is a stealth browser that bypasses Cloudflare on its own — proxy is NOT needed and causes tunnel errors.

**Fix:** Removed `proxy=PROXY_URL` from `launch()` call. CloakBrowser bypasses CF directly without proxy.

### Bug fix: CloakBrowser must run SEQUENTIALLY
**Problem (0610 failure):** Phase 1 used `ThreadPoolExecutor(max_workers=13)` to fetch all 13 section pages in parallel. Playwright Sync API conflicts with asyncio → some sections fail silently.

**Fix:** Changed Phase 1 to a simple sequential `for` loop — no ThreadPoolExecutor for CloakBrowser.

### Bug fix: Add retry for failed sections
**Problem:** Network instability causes some sections to timeout without recovery.

**Fix:** Added Phase 1b — retry failed sections once before proceeding to Phase 2.

### CRITICAL FINDING: Proxy is COMPLETELY USELESS for Cloudflare
**Discovery (2026-06-10):** Testing confirmed that proxy does NOT help bypass Cloudflare AT ALL.

| Page Type | Direct | +Proxy | Result |
|----------|--------|-------|--------|
| Section page (`/pns/要聞/section/...`) | 403 CF | 403 CF | Both blocked |
| Article page (`/pns/要聞/article/...`) | 200 OK | 200 OK | Both work |

**Why:** Cloudflare detects bots by browser fingerprint (JS execution, DOM features, timing patterns), NOT by IP address. Proxy only changes your exit IP — it doesn't fake a real browser. Both `curl` and `requests.get()` get403 CF regardless of proxy.

**Conclusion:** The ENTIRE scraper needs ZERO proxies:
- Phase 1 (section pages): CloakBrowser bypasses CF directly — no proxy needed
- Phase 2 (article pages): Article pages have NO Cloudflare block — `requests.get()` works fine without proxy

Proxy was historically added because someone assumed CF blocks by IP. This is wrong. The proxy buying was unnecessary.

---

## Manual Summary Regeneration (When Phase 3 AI Fails)

If `mingpao_scraper.py` completes Phase 1 & 2 but Phase 3 AI summary fails (timeout, API error), you can regenerate the summary manually:

**Step 1: Locate the raw data**
```bash
# The scraper saves raw data to /tmp/ with YYYYMMDD format (NOT the --date input format)
ls -la /tmp/mingpao_20260612.json  # This exists even if --date 2026-06-12 was passed
```

**Step 2: Regenerate summary via MiniMax API**
```python
import json, os, urllib.request

d = json.load(open('/tmp/mingpao_20260612.json'))
arts = d['articles']

# Build prompt
section_articles = {}
for a in arts:
    sec = a.get('section', '其他')
    if sec not in section_articles:
        section_articles[sec] = []
    body = a.get('body', '') or a.get('summary', '')
    if body:
        section_articles[sec].append({'title': a['title'], 'body': body[:300]})

prompt = "你係香港明報編輯，幫我將今日新聞做一個簡潔摘要。請用廣東話，每個版塊最多3句重點。\n\n"
for sec, articles in section_articles.items():
    prompt += f"\n【{sec}】\n"
    for art in articles[:5]:
        prompt += f"【{art['title']}】{art['body']}\n"

prompt += "\n\n請用廣東話輸出，格式：\n[版塊名稱]\n• 重點1\n• 重點2\n• 重點3\n..."

api_key = os.environ.get('MINIMAX_API_KEY', '')
url = 'https://api.minimax.io/v1/chat/completions'
headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
data = {
    'model': 'MiniMax-M2.7',
    'messages': [{'role': 'user', 'content': prompt}],
    'max_tokens': 3000,
    'temperature': 0.3
}
req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method='POST')
with urllib.request.urlopen(req, timeout=120) as resp:
    result = json.loads(resp.read())
    summary = result['choices'][0]['message']['content']

# Save to output file
output_path = f"/home/opc/.hermes/cron/output/mingpao_digest_20260612.txt"
with open(output_path, 'w') as f:
    f.write(f"明報每日摘要 2026-06-12\n=== Scraped: {len(arts)} articles ===\n\n")
    f.write(summary)
print(f"Saved to {output_path}")
```

**⚠️ MiniMax API pitfalls discovered (2026-06-12):**
- Wrong endpoint: `/v1/text/chatcompletion_v2` → CORRECT: `/v1/chat/completions`
- Wrong model: `MiniMax-Text-01` → CORRECT: `MiniMax-M2.7`
- The `MINIMAX_BASE_URL` env var points to `https://api.minimax.io/anthropic` (Anthropic-compatible), but for direct API calls use `https://api.minimax.io/v1/chat/completions`

---

## Known Pitfalls

### ⚠️ Telegram delivery: NEVER use `deliver=origin` with `TELEGRAM_HOME_CHANNEL=chat_id:thread_id`
**Problem (2026-06-12):** `deliver=origin` + `TELEGRAM_HOME_CHANNEL=-1003654034759:1907` causes:
```
invalid literal for int() with base 10: '-1003654034759:1907'
```
**Root cause:** When job has no `origin`, scheduler falls back to `TELEGRAM_HOME_CHANNEL` env var, which is the combined string `-1003654034759:1907`. The Telegram adapter's `send()` method tries to call `int(chat_id)` directly on this combined string before any parsing happens.

**Fix:** Always use explicit delivery target: `deliver: "telegram:-1003654034759:1907"` (chat_id and thread_id are parsed by scheduler before reaching the adapter). The scheduler's `_resolve_delivery_target()` correctly splits `telegram:-1003654034759:1907` into `chat_id=-1003654034759, thread_id=1907`.

**Why `origin` fails:** Jobs created via API/script have no `origin` field. Scheduler tries to use `TELEGRAM_HOME_CHANNEL` env var as fallback, but the combined `chat_id:thread_id` format bypasses the adapter's parsing logic.

1. **⚠️ Proxy intermittent from Oracle VM** — `ERR_TUNNEL_CONNECTION_FAILED` happens randomly. CloakBrowser works fine WITHOUT proxy (stealth browser bypasses CF directly). Use proxy only for article content scraping.

2. **⚠️ Cookie consent button not needed** — clicking "接受" times out and content renders fine without it. The "暫沒有內容" issue was caused by missing JS rendering, not cookie consent.

3. **Section pages return mixed URL formats** — both relative (`../pns/...`) and absolute (`https://news.mingpao.com/pns/...`) article links. Use both regex patterns.

4. **URL-encoded titles** — title extracted from URL slug must be decoded with `unquote()`. Example: `%e9%86%ab%e5%a7%94%e6%8c%87%E7%96%8f` → `醫委指疏忽即失當`

5. **CloakBrowser must be sequential** — Playwright Sync API conflicts with asyncio/ThreadPoolExecutor. Running CloakBrowser inside a thread causes `"It looks like you are using Playwright Sync API inside the asyncio loop"` error. Always run in main thread sequentially.

6. **Some section pages timeout** — network instability causes 25-30s timeouts. Implement retry once for failed sections.

7. **PNS article pages** sometimes have minimal content (<p> tags mostly navigation). Fall back to OG description: `soup.find('meta', property='og:description').get('content', '')`

8. **Browser upgrade warning** appears as a <p> tag ("You are using an outdated browser..."). Filter: `if len(text) > 20 and 'outdated browser' not in text.lower()`

9. **news.mingpao.com subdomain works** but www.mingpao.com is fully CF-blocked. Always use the news subdomain.

10. **MiniMax-M2.7 for cron jobs** — the daily digest cron job uses MiniMax model for summarization, not DeepSeek.

11. **⚠️ Phase 2 article content: proxy is reliable, retry pattern is key** — In practice, direct `requests.get()` with proxy succeeded 49/49 on retry. The scraper script's Phase 2 may still have failures for some articles; always retry failed URLs with a separate concurrent batch. Proxy is NOT the failure point — CloakBrowser's tunnel is (ERR_TUNNEL_CONNECTION_FAILED on section pages).

12. **⚠️ Subagent data location** — When dispatching to subagents for Phase 3 summarization, pass article content directly in the `context` parameter. Subagents will NOT find `/tmp/mingpao_YYYYMMDD.json` by searching the workspace — they only see their isolated context. Always include the JSON data or file path explicitly. Data file path: `/tmp/mingpao_{date}.json` (e.g., `/tmp/mingpao_20260610.json`).

13. **⚠️ Subagent model override** — When using `delegate_task` with `acp_command: minimax`, always pass `acp_args: ["--model", "MiniMax-M2.7"]` to ensure MiniMax is used. Without this, subagents may default to other models.

9. **news.mingpao.com subdomain works** but www.mingpao.com is fully CF-blocked. Always use the news subdomain.

10. **MiniMax-M2.7 for cron jobs** — the daily digest cron job uses MiniMax model for summarization, not DeepSeek.

## Output File Size Reference
- 264 articles raw extract: ~565KB (pure text)
- AI summary text: ~16KB
- Full output file: ~125KB (parsed format with OG descriptions)
