---
name: openrice-api-reverse-engineering
description: Reverse-engineered OpenRice internal API for HK restaurant data scraping. Use when: OpenRice API, restaurant data, Hong Kong food, reverse engineer
created: 2026-05-10
tags: [hongkong, food, openrice, web-scraping, api]
priority: backup
---

# OpenRice Scraper — Reverse-Engineered API

## Discovery Date
2026-05-10

## Status
Working (as of discovery)

## Problem
OpenRice has no public API. Old endpoints at `api.openrice.com` are defunct and protected by BytePlus (ByteDance) WAF JavaScript challenge.

## Solution — Internal API

OpenRice's frontend uses an internal API endpoint that bypasses WAF when called with proper headers.

### Endpoint
```
GET https://www.openrice.com/api/v2/search
```

### Required Headers
```
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
Referer: https://www.openrice.com/zh/hongkong/
```

### Parameters
| Parameter | Value | Description |
|-----------|-------|-------------|
| `apiEntryPoint` | `PoiSR1` | POI Search Result |
| `sortBy` | `ORScoreDesc` | Sort by rating |
| `regionId` | `0` | Hong Kong region |
| `uiLang` | `zh` | Chinese UI |
| `uiCity` | `hongkong` | Hong Kong city |
| `rows` | `N` (max 250) | Number of results |
| `startAt` | `N` | Pagination offset |
| `districtId` | `NNNN` | Filter by district |
| `cuisineId` | `NNNN` | Filter by cuisine |
| `priceRangeId` | `1-6` | Price range ($50 increments) |
| `searchTerm` | `...` | Text search query |

### Known District IDs
```
1999 = 香港島 (Hong Kong Island)
2010 = 旺角 (Mong Kok)
2008 = 尖沙咀 (Tsim Sha Tsui)
... (87 total districts)
```

### Known Cuisine IDs
```
2004 = 泰國菜 (Thai)
... (many more)
```

### Response Fields
- `name` — Restaurant name
- `address` — Full address
- `phones` — Phone numbers array
- `scoreOverall` — Rating (e.g., 4.38)
- `priceRangeId` — Price tier (1-6)
- `district` — District name
- `categories` — Cuisine categories
- `reviewCount` — Number of reviews
- `photoCount` — Number of photos
- `bookmarkedUserCount` — User bookmarks
- `coupons`, `promotions` — Active deals

### Python Example
```python
import requests, json

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Referer': 'https://www.openrice.com/zh/hongkong/'
}

params = {
    'apiEntryPoint': 'PoiSR1',
    'sortBy': 'ORScoreDesc',
    'regionId': '0',
    'uiLang': 'zh',
    'uiCity': 'hongkong',
    'rows': 20,
    'startAt': 0
}

r = requests.get('https://www.openrice.com/api/v2/search', headers=headers, params=params)
data = r.json()
for poi in data.get('data', []):
    print(f"{poi['name']} — {poi['scoreOverall']}")
```

### Limitations
- Rate limit unknown — be respectful
- Pagination max `rows` seems to be 250 per request
- Some restaurant detail endpoints may require additional auth

## Alternatives (if this stops working)
1. **Firecrawl** — Use Firecrawl API to scrape JS-rendered pages (user has API key)
2. **Browser automation** — Playwright with `python3.9` to capture network traffic
3. **Mobile app API** — Reverse engineer OpenRice Android APK
4. **Third-party** — scraping cloud services (ScrapingBee, ZenRows)

## User Priority
User ranked this as BACKUP — primary HK food CLI targets:
1. Foodpanda HK
2. HK Government Open Data (data.gov.hk)