---
name: hk-stocks-yahoo-finance
description: Fetch and analyze HKEX stocks using Yahoo Finance API. Use when Hong Kong stock analysis, investment framework, financial analysis.
---

# HK Stocks via Yahoo Finance API

## HK Stock Code Format (CRITICAL)

HK stocks must use 4-digit format plus .HK suffix:

```python
# Correct
tickers = ["0285.HK", "1810.HK", "0700.HK", "9988.HK", "1211.HK"]

# Wrong - causes HTTP 404
tickers = ["285.HK", "700.HK"]
```

Formula: str(code).zfill(4) + ".HK"

| Stock     | Wrong     | Correct    |
|-----------|-----------|------------|
| BYD Electronic | 285.HK | 0285.HK   |
| Tencent   | 700.HK    | 0700.HK    |
| Xiaomi    | 1810.HK   | 1810.HK    |

## Quick Fetch Template

```python
import urllib.request, json
from datetime import datetime

def fetch_hk_stock(code, range="6mo"):
    code = code.zfill(4) + ".HK"
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{code}?interval=1d&range={range}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())

def analyze(data):
    meta = data['chart']['result'][0]['meta']
    quotes = data['chart']['result'][0]['indicators']['quote'][0]
    timestamps = data['chart']['result'][0]['timestamp']

    closes_raw = quotes['close']
    price = meta['regularMarketPrice']
    high52 = meta['fiftyTwoWeekHigh']
    low52 = meta['fiftyTwoWeekLow']
    closes = [c for c in closes_raw if c is not None]
    position = (price - low52) / (high52 - low52) * 100

    # Monthly averages (filter None)
    monthly = {}
    for i, ts in enumerate(timestamps):
        if closes_raw[i] is None:
            continue
        dt = datetime.fromtimestamp(ts).strftime('%Y-%m')
        monthly.setdefault(dt, []).append(float(closes_raw[i]))

    return {
        'price': price,
        'high52': high52,
        'low52': low52,
        'position_pct': position,
        'drop_from_high': (high52 - price) / high52 * 100,
        'recovery_from_low': (price - low52) / low52 * 100,
        'monthly_avg': {m: sum(v)/len(v) for m, v in sorted(monthly.items())}
    }
```

## Investment Framework (5 dimensions)

| 維度 | 信號 |
|------|------|
| 技術面 | 🔍 接近支持位/低位 / ⚠️ 繼續跌緊 |
| 基本面 | ✅ 穩健 / ⚠️ 放緩 |
| 估值 | ✅ 歷史低位/防守性 / ⚠️ 偏高 |
| 宏觀 | ✅ 利好 / ⚠️ 中美關係/消費/關稅風險 |
| 催化劑 | 🔍 明確催化劑信號 |

1. Technical - 52wk position, moving averages, RSI, volume
2. Fundamental - revenue growth, margins, market position
3. Valuation - PE PB EV EBITDA vs industry
4. Macro - policy risk, FX, domestic consumption
5. Catalysts - new products, earnings, buybacks

## Common Pitfall: None Values in Close Array

Always filter None before calculations:
```python
closes = [c for c in closes_raw if c is not None]  # REQUIRED
# Do NOT do: sum(closes_raw) / len(closes_raw)  # Fails with None
```

## Output Format: Monthly Trend + Comparison Table

### Monthly Trend Display
```python
print("=== 月均價 (近6月) ===")
for m in sorted(monthly_data.keys()):
    avg = sum(monthly_data[m]) / len(monthly_data[m])
    print(f"  {m}: HK${avg:.2f}")
```

### Comparison Table (2 stocks side-by-side)
```python
print(f"| | {stock1} | {stock2} |")
print(f"|---|---|---|")
print(f"| 現價位置 | {pos1:.1f}% | {pos2:.1f}% |")
print(f"| 高位回落 | -{drop1:.1f}% | -{drop2:.1f}% |")
print(f"| 業務風險 | 自主品牌+汽車 | 依賴客戶訂單 |")
print(f"| 防守性 | 較高（品牌效應） | 中等（EMS周期性強） |")
print(f"| 催化劑 | 汽車+AI生態 | BYD汽車交付量 |")
```
