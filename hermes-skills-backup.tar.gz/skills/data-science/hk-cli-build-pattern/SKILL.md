---
name: hk-cli-build-pattern
description: Go CLI build pattern for Hong Kong data sources (OpenRice, Foodpanda, data.gov.hk, weather). Use when: Go CLI, Hong Kong data, OpenRice, 香港, Go build
---

# HK CLI Build Pattern (Printing Press paradigm)

Skills for building Hong Kong-focused CLI tools in Go.

## Pattern Overview

Go CLI + Cobra + SQLite local cache + JSON default / `--human` flag.
- Binary output: `~/go/bin/<name>-hk`
- Source: `$GOPATH/src/github.com/hk-cli/<name>-hk/main.go`
- Local DB: `~/.openrice-hk.db`, `~/.foodpanda-hk.db`, etc.

## HK Data Sources

### OpenRice HK
- **API**: `https://www.openrice.com/api/v2/search`
- **Params**: `sortBy=ORScoreDesc`, `apiEntryPoint=PoiSR1`, `regionId=0`, `uiLang=zh`, `uiCity=hongkong`, `rows=N`, `startAt=N`
- **Total restaurants**: ~32,982
- **Cuisine filter**: `categoryTypeId=1` in categories array
- **District filter**: `districtId=N` (e.g., 2013=土瓜灣, 2004=紅磡)
- **Known columns** (18): `poi_id, name, name_other, address, address_other, score, review_count, price_range, photo_count, district_id, district_name, cuisine, open_now, map_lat, map_lon, phone, open_since`
- **DB status** (May 2026): ~10,800 restaurants (page 0-43 via global pagination; rate limited at startAt=10800+, gentle sync cron job running every 10 min)

### Foodpanda HK
- **Sitemap**: `https://www.foodpanda.hk/adventure-map/adventure-map-restaurant-0.xml`
- **Total restaurants**: ~18,377
- **Area/cuisine**: Extracted from URL slugs

### HK Gov Data (data.gov.hk)
- **Status**: API endpoint `/api/1/` returns HTML (WAF blocked). CKAN standard endpoints `/api/3/action/*` also return HTML from WAF, not the actual data.
- **Workaround**: Browse the website directly at `https://data.gov.hk/en/` or use dataset URLs like `/en-data/dataset/<id>`. No programmatic API access available.
- **Structure**: Site is NOT a standard CKAN instance despite CKAN-style URLs

### HK Weather
- **API**: Open-Meteo (free, no key) — `https://api.open-meteo.com/v1/forecast?latitude=22.3193&longitude=114.1694`
- **Params**: `current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,weather_code,apparent_temperature&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia/Hong_Kong&forecast_days=3`
- **Weather codes**: 0=Clear, 1=Mainly Clear, 2=Partly Cloudy, 3=Cloudy, 65=Heavy Rain, 80/81/82=Showers
- **Wind direction**: Convert degrees to compass (N/NE/E/SE/S/SW/W/NW) via `dirs = []string{"N","NE","E","SE","S","SW","W","NW"}; idx = int((deg+22.5)/45)%8`
- **Binary**: `~/go/bin/hk-weather` — commands: `now`, `forecast [days]`, `aqi`, `tides`, `warning`

### HK MTR
- **Status**: `mtr.idata.host` not responsive. Use data.gov.hk transport datasets instead.

## Critical Bug: URL Encoding Chinese Characters

**Problem**: Simple string concatenation `k+"="+v` for URL query params does NOT URL-encode non-ASCII characters.

**Wrong**:
```go
query := "sortBy=" + sortBy + "&rows=" + rows  // Chinese chars broken
```

**Correct**:
```go
params := url.Values{}
params.Add("sortBy", sortBy)
params.Add("rows", rows)
// ...
url := baseURL + "?" + params.Encode()  // Properly encoded
```

This caused OpenRice Chinese search (e.g., "牛肉") to fail until switching to `url.Values{}.Add()` + `.Encode()`.

## Schema Discovery Pattern

When building SQLite schema from API responses:
1. Fetch one page (rows=1)
2. Inspect actual JSON keys and types
3. Count columns carefully — `INSERT INTO ... VALUES (?,?,...)` must match column count
4. If mismatch error occurs, re-inspect the actual API response schema

## OpenRice Rate Limiting (CRITICAL BUG)

### Symptom
- Works fine for rows 0–9750 (39 pages × 250)
- Page 40 (startAt=10000) starts returning HTTP 500
- After triggering, ALL subsequent requests to that API endpoint return 500 even with different parameters

### Root Cause (CRITICAL — Updated 2026-05-10)
This is a **SERVER-SIDE PAGINATION BUG**, NOT a rate limit. Verified: the same error occurs from different IP addresses, no matter the delay or User-Agent. OpenRice's backend physically cannot handle `startAt >= 10000` for global queries.

| startAt | Result |
|---------|--------|
| 0 | ✅ OK |
| 5000 | ✅ OK |
| 10000 | ❌ HTTP 500 |
| 15000 | ❌ HTTP 500 |

Browser automation CANNOT help — the browser makes the same API calls and gets the same 500 error.

### Confirmed behavior (May 2026)
- `sortBy=ORScoreDesc`: fails at page 40 with 500
- `sortBy=ReviewCountDesc`: also fails at page 40 with 500 (same underlying bug)
- Recovery: NO recovery possible via retry/delay — must switch to district-based scraping

### Background Sync Pattern (Gentle)

For long-running syncs that need to survive session boundaries, use this pattern:

```bash
# Script template at /tmp/openrice_gentle.py
cat > /tmp/openrice_gentle.py << 'PYEOF'
#!/usr/bin/env python3
import sqlite3, json, ssl, urllib.request, urllib.parse, time, sys, os

DB_PATH = os.path.expanduser("~/.openrice-hk.db")
BASE_URL = "https://www.openrice.com/api/v2/search"
BATCH = 250
TOTAL = 32982

def log(msg):
    ts = time.strftime("%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)

def fetch(start_at):
    params = {
        "sortBy": "ORScoreDesc", "apiEntryPoint": "PoiSR1",
        "regionId": "0", "uiLang": "zh", "uiCity": "hongkong",
        "rows": str(BATCH), "startAt": str(start_at)
    }
    url = BASE_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        "Referer": "https://www.openrice.com/zh/hongkong/restaurants"
    })
    resp = urllib.request.urlopen(req, context=ctx, timeout=30)
    return json.loads(resp.read())

# Resume-safe: INSERT OR IGNORE + COUNT check
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()
c.execute("SELECT COUNT(*) FROM restaurants")
start = c.fetchone()[0]

# Do ONE batch per run (gentle)
try:
    data = fetch(start)
    results = data.get("paginationResult", {}).get("results", [])
    for r in results:
        cuisines = "|".join([c["name"] for c in r.get("categories",[]) if c.get("categoryTypeId")==1])
        d = r.get("district", {})
        c.execute("""INSERT OR IGNORE INTO restaurants VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (r["poiId"], r.get("name",""), r.get("nameOtherLang",""),
             r.get("address",""), r.get("addressOtherLang",""),
             r.get("scoreOverall",0), r.get("reviewCount",0),
             r.get("priceRangeId",0), r.get("photoCount",0),
             d.get("districtId",0), d.get("name",""),
             cuisines, 1 if r.get("openNow") else 0,
             r.get("mapLatitude"), r.get("mapLongitude"),
             "|".join(r.get("phones",[])), r.get("openSince","")))
    conn.commit()
    c.execute("SELECT COUNT(*) FROM restaurants")
    total = c.fetchone()[0]
    log(f"OK +{total-start} ({start}->{total}/{TOTAL})")
except Exception as e:
    log(f"Error at {start}: {e}")
conn.close()
PYEOF

# Run: nohup + background + log
nohup python3 /tmp/openrice_gentle.py > /tmp/openrice_gentle.out 2>&1 &
echo "PID: $!"

# Check progress
tail /tmp/openrice_gentle.out

# Stop
pkill -f openrice_gentle.py
```

**Cron-based gentle sync** (for very long gaps):
```python
# Cron: every 10 minutes, 240 times
cronjob(action='create', prompt='Run /tmp/openrice_gentle.py, read /tmp/openrice_gentle.log, report count',
        schedule='10m', repeat=240, deliver='origin')
```

**Key patterns:**
- `INSERT OR IGNORE` — safe resume on duplicate poiId
- `SELECT COUNT(*) FROM restaurants` at start — determines resume point
- `SELECT COUNT(*) FROM restaurants` at end — progress logging
- ONE batch per run — idempotent, safe for cron
- 25-30s delay between API calls — avoids triggering rate limit
- Log file at `/tmp/<name>.log` — check progress anytime with `tail /tmp/<name>.log`

### Workaround: District-Based Scraping (Recommended)

**Problem with global pagination**: OpenRice returns 500 at page 40 regardless of sortBy. No server-side workaround (delay, different UA, different sort) succeeds.

**Solution**: Switch from global pagination to **district-based scraping**. Each district has its own pagination and doesn't hit the global rate limit.

**OpenRice Metadata API** (district list):
```
GET https://www.openrice.com/api/v2/metadata/region/all?uiLang=zh&uiCity=hongkong
```
Returns 82 valid districts (filter: districtId > 0, not containing "香港島/九龍/新界/離島").

**District scraping params**:
```
?sortBy=ORScoreDesc&apiEntryPoint=PoiSR1&regionId=0&uiLang=zh&uiCity=hongkong
&districtId=N&rows=250&startAt=0
```

**Key districts** (high density):
- 尖沙咀 (2008): 2,112 restaurants → 9 pages
- 中環 (1003): 1,589 restaurants → 7 pages
- 旺角 (2010): 1,358 restaurants → 6 pages
- 銅鑼灣 (1019): 1,292 restaurants → 6 pages
- 灣仔 (1022): ~1,000 restaurants

**Strategy** (May 2026):
1. Existing DB: 10,000 restaurants (page 0-39 via global pagination)
2. Remaining ~22,982: scrape by district (82 districts, 2.5s delay between calls)
3. Total time: ~20-30 minutes (2.5s × ~40 API calls per district × 82 districts)
4. Resume support via checkpoint file (`.openrice_checkpoint.json`)

**Production-ready Python scraper**: `openrice_district_scraper.py` (standalone, no dependencies beyond stdlib)

```bash
# Run (auto-resume from checkpoint)
python3 openrice_district_scraper.py

# Status only (no scraping)
python3 openrice_district_scraper.py --status

# Reset and restart
python3 openrice_district_scraper.py --reset
```

**Output files:**
- `~/.openrice-hk.db` — SQLite with 17 columns: poi_id, name, name_other, address, address_other, score, review_count, price_range, photo_count, district_id, district_name, cuisine, open_now, map_lat, map_lon, phone, open_since
- `~/.openrice_checkpoint.json` — `{"done": [], "failed": [], "last_district": null, "last_start": 0}`
- `/tmp/openrice_district_scraper.log` — timestamped progress log

**Key implementation details:**
- 82 districts fetched from `https://www.openrice.com/api/v2/metadata/region/all`
- `districtId` filter gives each district independent pagination (no 500 error at page 40)
- BATCH=250, BATCH_DELAY=20s, ERROR_DELAY=60s, REQUEST_TIMEOUT=20s
- `INSERT OR IGNORE` for idempotent resume
- Per-district checkpoint saves `last_district` + `last_start` (within district) after each batch
- `last_start` reset to 0 when moving to next district (key fix for district-switching resume)
- Bot detection: retries on non-JSON response or HTTP 500 with 5-retry limit then skip district

**Script source** (standalone, ~270 lines):
gdrive:/OpenClaw_Backups/openrice_district_scraper.py.txt

## Go Build Process

```bash
export PATH=$PATH:$HOME/go/bin:/usr/local/go/bin
cd $GOPATH/src/github.com/hk-cli/<name>
go mod init github.com/hk-cli/<name>
# write main.go
go build -o ~/go/bin/<name> .
```

## Flag Parsing Pattern

```go
human := flag.Bool("human", false, "Human-readable output")
flag.Parse()
args := flag.Args()

if len(args) == 0 {
    // show help
    os.Exit(0)
}
cmd := args[0]
switch cmd {
case "now":
    getCurrentWeather(cli, *human)
}
// For sub-args: args[1], args[2], etc.
```