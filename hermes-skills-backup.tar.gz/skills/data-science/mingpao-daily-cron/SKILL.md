---
name: mingpao-daily-cron
title: 明報每日 cron job（修復版）
description: 每日自動爬取明報新聞，純 Python 句子邊界截斷，確保完整句子唔會中途被 cut
trigger: setup / fix 明報 cron job / 句子截斷問題
---

# 明報每日 cron job — 修復版（2026-05-17）

## 問題

**現象**：明報每日精華嘅 summary 成日喺句子中途被 cut 斷，例如：
- 「...據悉，其中一個方向為研究是否把ICU執行《建築物條...」（缺後文）
- 「...加劇通脹，最終美國單月通脹曾飈逾9」（缺 `%`）

**根本原因**：舊版 cron job 用 MiniMax-M2 做 AI 摘要，但 MiniMax-M2 係 **Reasoner model**，輸出時帶有 `<think>` 標籤（推理過程），導致：
1. 實際內容被推理過程混入，token 計算錯誤
2. 截斷位置喺推理標籤內，句子唔完整
3. 偶爾完全冇 AI 摘要，直接 output raw article body

**其他嘗試（失敗）**：
- `abab6.5s-chat` → 400 unknown model
- `MiniMax-Text-01` → 500 token plan not supported
- 純 prompt engineering → 無法阻止 `<think>` 標籤輸出

## 修復方案

放棄 AI 摘要，改用 **純 Python 句子邊界檢測** — 見 `mingpao_digest_v2.py`。

核心邏輯（`truncate_sentence` 函數）：
1. 清理 text（移除換行、明報前綴【明報專訊】）
2. 如果正文已係完整句子且喺限制內 → 直接返回
3. 喺 `[max_len-1, max_len-50]` 範圍內，向前搵最近嘅句號（。！？）
4. 回退：搵最近嘅 natural break（`，`、`；`）
5. 最後手段：hard truncate + `…`

## Cron Job 配置

```
job_id: 0bebfe2c7202
script: /home/opc/.hermes/scripts/mingpao_digest_v2.py
schedule: "0 7 * * *"
deliver: telegram:-1002153587332:805
```

**Prompt（精簡版）**：
```
今日係明報每日精華時間。請用 terminal() 行以下命令：
python3 /home/opc/.hermes/scripts/mingpao_digest_v2.py
等佢完成，完成後，輸出呢句做 final response：明報今日精華已生成 ✅
```

## Script 位置

- 爬取 + 截斷 script: `~/.hermes/scripts/mingpao_digest_v2.py`
- 輸出目錄: `~/.hermes/cron/output/mingpao_digest_YYYYMMDD.txt`

## 驗證方法

```bash
# 檢查完整句子（70-110 字，結尾係句號/問號/嘆號）
python3 -c "
with open('/home/opc/.hermes/cron/output/mingpao_digest_$(date +%Y%m%d).txt') as f:
    for line in f:
        s = line.strip()
        if 50 < len(s) < 120 and s[-1] in '。！？':
            print(f'[{len(s)}] {s}')
"

# 確認冇中途截斷
grep '…$' ~/.hermes/cron/output/mingpao_digest_$(date +%Y%m%d).txt
```

## MiniMax API 摘要方案（已修復 2026-06-12）

**問題**：使用 `MiniMax-M2.7` 做摘要時，模型會把完整推理過程（`<think>...</think>`）output 埋嚟，長達 400+ tokens，完全淹沒真正嘅摘要內容。

**解決方案**：使用 `MiniMax-Text-01` model — 係 direct text generation model，**唔會**輸出推理過程，干干净净。

```python
import urllib.request, json

data = {
    "model": "MiniMax-Text-01",   # 關鍵：唔係 M2.7
    "messages": [{"role": "user", "content": prompt}],
    "max_tokens": 400,
    "temperature": 0.3
}
req = urllib.request.Request(
    "https://api.minimax.io/v1/chat/completions",
    data=json.dumps(data).encode(),
    headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    method="POST"
)
with urllib.request.urlopen(req, timeout=60) as resp:
    result = json.loads(resp.read())
content = result["choices"][0]["message"]["content"]  # 乾淨輸出，直接用
```

**Prompt 範例（粵語口語摘要）**：
```
你係香港明報記者。用口語化粵語（就像平時傾偈咁）為以下新聞寫一份摘要，
每個版塊最多2句，總共唔好超過200字。要地道口語，唔好用書面語。
=== 新聞 ===
{digest_text}
```

**模型對比**：
| 模型 | 輸出 | 適合場景 |
|------|------|----------|
| `MiniMax-M2.7` | 带推理過程（數百tokens） | 複雜推理任務 |
| `MiniMax-Text-01` | 乾淨直接 | 新聞摘要、翻譯、指令跟蹤 |

**結論**：`MiniMax-Text-01` + 適當 prompt 可以做到靠譜嘅粵語新聞摘要，唔再需要純 Python 句子截斷。