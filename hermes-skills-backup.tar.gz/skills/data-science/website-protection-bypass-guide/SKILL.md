---
name: website-protection-bypass-guide
description: 網站防護系統 bypass 速查手冊 — Cloudflare vs Akamai vs Normal，分析邊個方法掂邊個網站. Use when: Cloudflare bypass, Akamai bypass, bot detection, CAPTCHA, web scrape
category: data-science
---

# Website Protection Bypass Guide

## Purpose
Quick reference for which scraping approach works against which website protection system. Based on real testing (2026-05-13).

## Protection Systems by Provider

### Cloudflare (最常見)
- **CloakBrowser**: bypasses (C++ source-level patches vs JS injection)
- **Python requests + Chrome headers**: sometimes bypasses (L7 simple protection)
- **明報**: news.mingpao.com → 需要 residential proxy bypass Cloudflare

### Proxy Auth 認證格式（重要！2026-06-05 實戰經驗）
```bash
# ❌ curl --proxy-user "user:pass" → 407 Proxy Auth Required
curl -x "http://user:pass@proxyhost:port" http://target.com

# ✅ curl + embedded auth → work
curl -x "http://prs:gru@c9.hk2.yfip.top:30426" http://target.com

# ✅ Python requests → 直接在 proxies dict 裏面
requests.get(url, proxies={'http': 'http://user:pass@proxyhost:port', 'https': '...'})
```
**結論**: proxy URL 格式 `http://user:pass@host:port` 兩個都適用，但 `--proxy-user` flag 只係 curl 專用，Python requests 必須 embed 喺 URL 裏面。

### Akamai Bot Manager (最難)
- **CloakBrowser**: ❌ 不能bypass
- **uTLS (Chrome 131 fingerprint)**: TLS handshake成功，但HTTP/2立即GOAWAY kill
- **curl / standard Go HTTP**: 全部403
- **真正解決**: residential proxy 或 mobile app抓包

### 普通網站 (無保護)
- **CloakBrowser**: ✅ 零成本
- **Python requests**: ✅ 零成本

## 等級分類

| 等級 | 保護類型 | 示例網站 | 難度 | 解決方案 |
|------|---------|---------|------|---------|
| 1 | 普通 | Nike.com, HKJC | ✅ $0 | requests / CloakBrowser |
| 2 | Cloudflare L7 | DSEPP, HKEAA | ✅ $0 | requests + Chrome headers |
| 3 | Cloudflare JS | DSE00 | ✅ $0 | CloakBrowser |
| 4 | Cloudflare + 明報 | 明報 news.mingpao.com | ⚠️ 需proxy | residential proxy (c9.hk2.yfip.top:30426, user=prs, pass=gru) |
| 5 | Akamai | HK Express, Amazon | ❌ 需成本 | residential proxy / mobile app |
| 6 | reCAPTCHA | - | ⚠️ 需服務 | 2captcha |

## 實戰結果

| 網站 | 方法 | 結果 |
|------|------|------|
| 明報 | Python requests + proxy (c9.hk2.yfip.top:30426, prs:gru) | ✅ 239 articles (2026-06-05) |
| HKJC足智彩 | CloakBrowser | ✅ 213KB |
| Nike.com | CloakBrowser | ✅ 43款跑鞋 |
| DSEPP | CloakBrowser | ✅ 363KB |
| HKEAA/DSE00 | CloakBrowser | ✅ 66KB/1.5MB |
| HK Express | uTLS / CloakBrowser | ❌ Akamai block |
| Amazon.com | CloakBrowser | ❌ Akamai + CAPTCHA |

## 快速決策樹

```
網站係乜？
├── 普通網站 → CloakBrowser 或 requests
├── Cloudflare → Python requests + Chrome headers 或 CloakBrowser
│   └── 明報 → 需要 residential proxy（c9.hk2.yfip.top:30426, auth: prs:gru）
├── Akamai →
│   ├── 機票/電商 → 用Skyscanner/Kiwi.com API
│   ├── 要爬官網 → residential proxy（成本高）
│   └── App有數據 → 嘗試App抓包
└── Google CAPTCHA → 2captcha服務
```

## 明報爬蟲腳本
- 主 script: `~/.hermes/scripts/mingpao_scraper.py`
- Digest script: `~/.hermes/scripts/mingpao_digest_v2.py`
- Proxy: `http://prs:gru@c9.hk2.yfip.top:30426`
