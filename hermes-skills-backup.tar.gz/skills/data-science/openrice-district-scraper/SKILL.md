---
name: openrice-district-scraper
description: Scrapes OpenRice by district to bypass 10,000 startAt limit. Use when: OpenRice district, restaurant by district, 香港餐廳, food scraping
---

# OpenRice District Scraper

## Key Findings
- **API**: `https://www.openrice.com/api/poi/search`
- **startAt limit**: 0-9999 works, >=10000 returns HTTP 500 (server-side, NOT rate limit)
- **Bypass**: Use `districtId=X` param - each district has independent pagination
- **99 districts** found, server reports ~32,982 total restaurants
- **Bot detection**: Returns HTML (not JSON) when blocked - check response Content-Type

## Known District IDs & Counts
| District | ID | Est. Count |
|----------|----|------------|
| Tsim Sha Tsui | 2008 | 2,112 |
| Central | 1003 | 1,589 |
| Mong Kok | 2010 | 1,358 |
| Causeway Bay | 1019 | 1,292 |
| Wan Chai | 1023 | ~1,100 |
| Yuen Long | 2003 | 1,489 |
| Tsuen Wan | 2019 | 1,418 |
| Kwun Tong | 2005 | 1,305 |

## Scraper Script (Python)
Initial prototype location: `/tmp/openrice_district_scraper.py` (Python, partial run)

Features:
- Checkpoint after every batch (not just district)
- 20s delay between batches
- 60s wait on 500 error + retry
- INSERT OR IGNORE to avoid duplicates

## Go CLI (Production — completed run)
The production scrape used a **Go CLI** (`openrice-hk-cli`) built via `hk-cli-build-pattern`.

### Command pattern:
```bash
# Scrape all districts with checkpointing
openrice-hk-cli district scrape --from-checkpoint

# Check status
openrice-hk-cli status

# Search/filter
openrice-hk-cli search "茶餐廳"
openrice-hk-cli search "沙田"

# Export
openrice-hk-cli export --format csv --output openrice_restaurants.csv
openrice-hk-cli export --format json --output openrice_restaurants.json
```

### Completed Run Stats (May 2026):
- **82 districts** scraped (API supports 99 but 82 had data — some are islands/remote)
- **31,540 restaurants** in database (Go CLI shows ~32,983 — slight diff from real-time API)
- **29% missing ratings** (~9,153) — expected for new/low-review venues
- **Last district**: 4011 (蒲苔島) — completed May 9 20:39
- Checkpoint state: completed

### DB/Export locations:
- SQLite DB: `~/.hermes/scripts/openrice_hk.db` (31,540 records)
- JSON export: `~/.hermes/scripts/openrice_restaurants.json` (15 MB)
- CSV export: `~/.hermes/scripts/openrice_restaurants.csv` (5.0 MB)
- Data fields: name, address, district, cuisine, score, review_count, price_range, map_lat, map_lon