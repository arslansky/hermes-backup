---
name: cloakbrowser-crawl
description: Use CloakBrowser (stealth Chromium with source-level C++ patches) to crawl Cloudflare-protected and bot-blocked websites — bypasses CF Turnstile, reCAPTCHA v3, DataDome, and common bot detection.. Use when: CloakBrowser, crawl, web scraping, Cloudflare bypass, stealth browser
trigger: When a target website returns 403, Cloudflare challenge, CAPTCHA, or bot detection block via plain HTTP/requests
---

# CloakBrowser Crawl

Use CloakBrowser (stealth Chromium, source-level C++ fingerprint patches) to crawl websites that block standard HTTP requests or Playwright.

## Architecture

CloakBrowser wraps a patched Chromium binary (49-57 C++ patches) that:
- Sets `navigator.webdriver=false` at C++ level (not JS injection)
- Spoofs GPU/screen/fonts/WebGL from a random fingerprint seed
- Normalizes network timing to hide proxy detection
- Removes CDP automation signals
- Gets reCAPTCHA v3 score 0.9 (human level)
- Passes Cloudflare Turnstile, FingerprintJS, BrowserScan

## Prerequisites

```bash
# Install
pip install cloakbrowser

# Optional: GeoIP timezone/locale auto-detection from proxy IP
pip install cloakbrowser[geoip]
```

First run auto-downloads ~200MB patched Chromium binary to ~/.cloakbrowser/

## Installation Notes (May 2026 — Oracle VM Hermes Agent)

The Hermes agent runs from a uv-managed venv at `~/.hermes/hermes-agent/venv/`. System `pip` may target a different Python version:

```bash
# Check which Python Hermes uses
which python3  # → ~/.hermes/hermes-agent/venv/bin/python3

# Install into Hermes venv
uv pip install cloakbrowser --python ~/.hermes/hermes-agent/venv/bin/python
```

## Usage

### Basic Crawl

```python
from cloakbrowser import launch

browser = launch(headless=True)
page = browser.new_page()
page.goto("https://cf-protected-site.com", timeout=30000)
content = page.content()  # Full HTML, no CAPTCHA in sight
title = page.title()
browser.close()
```

### With Proxy

```python
browser = launch(
    headless=True,
    proxy="http://user:pass@proxy:8080",  # or socks5://
    geoip=True,  # auto-detect timezone/locale from proxy IP
)
```

### With Human-like Behavior (bypasses behavioral detection)

```python
browser = launch(
    headless=True,
    humanize=True,  # Bezier mouse curves, per-char typing, smooth scroll
)
```

### Content Extraction Example

```python
from cloakbrowser import launch
import json, re

browser = launch(headless=True)
page = browser.new_page()
page.goto("https://target-site.com", wait_until="domcontentloaded")
import time; time.sleep(3)  # Let JS render

# Get full HTML
html = page.content()

# Or extract text with JS
text = page.evaluate("document.body.innerText")

# Or extract specific elements
links = page.evaluate("""() => JSON.stringify(
    Array.from(document.querySelectorAll('a[href*="article"]'))
        .map(a => ({text: a.textContent.trim(), href: a.href}))
)""")

browser.close()
```

## Test Results (Oracle VM, May 13 2026)

All tests with `headless=True`, NO proxy, NO humanize:

| Website | Protection | Plain HTTP (requests) | CloakBrowser |
|---------|-----------|----------------------|--------------|
| 明報 www.mingpao.com | Cloudflare | 403 ❌ | **137KB ✅ PASS** |
| 明報 news.mingpao.com | Cloudflare | **200 ✅ PASS** (see note) | **137KB ✅ PASS** |
| DSEPP dsepp.com | Cloudflare | 429/CF ❌ | **363KB ✅ PASS** |
| HKEAA hkeaa.edu.hk | Cloudflare + TuniS | CF challenge ❌ | **66KB ✅ PASS** |
| DSE00 dse00.com | Cloudflare | CF challenge ❌ | **1.5MB ✅ PASS** |

**Key finding:** CloakBrowser bypasses Cloudflare protection WITHOUT any proxy on Oracle Cloud IPs. Even the hardest site (明報, which returns 403 on all workers' plain HTTP requests) passes through.

> **⚠️ 明報 CF bypass discovery (2026-05-13):** `www.mingpao.com` is fully CF-blocked (403) for plain HTTP, but `news.mingpao.com` (the subdomain serving news content under `/pns/` and `/ins/` paths) passes Cloudflare with just Python `requests` + desktop Chrome User-Agent. No CloakBrowser needed for `news.mingpao.com`.  
> Always try the subdomain first before reaching for CloakBrowser — 9 out of 10 times it'll save you a browser launch.

## Worker Integration

### On Oracle VM (Hermes Agent)

CloakBrowser + browser tool pattern — works directly in your Hermes session:

```python
# Option A: Use CloakBrowser directly (recommended for heavy crawls)
from cloakbrowser import launch
browser = launch(headless=True)
page = browser.new_page()
page.goto(url)
content = page.content()

# Option B: Use Hermes built-in browser tools (lighter, no install needed)
browser_navigate(url)
browser_console(expression="document.querySelector('...').innerText")
```

### On LightNode Worker (SSH)

LightNode has **cleaner IP** for crawling but doesn't have CloakBrowser installed yet:

```bash
# Install on LightNode
ssh -i ~/.ssh/lightnode_worker root@130.94.40.226 \
  "pip3 install cloakbrowser"

# Test crawl
ssh -i ~/.ssh/lightnode_worker root@130.94.40.226 \
  "python3 -c \"
from cloakbrowser import launch
b = launch(headless=True)
p = b.new_page()
p.goto('https://www.mingpao.com/')
print(p.title(), len(p.content()))
b.close()
\""
```

## Automation via TaskForge (WIP)

TaskForge dispatch has a JSON escaping issue with SSH pipes (May 2026). Direct SSH is more reliable until fixed:

```bash
# Direct SSH crawl (instead of TaskForge dispatch)
ssh -i ~/.ssh/lightnode_worker root@130.94.40.226 "python3 << 'PYEOF'
from cloakbrowser import launch
b = launch(headless=True)
p = b.new_page()
p.goto('$TARGET_URL')
html = p.content()
with open('/tmp/crawl_result.html', 'w') as f:
    f.write(html)
print(f'Done: {len(html)} bytes')
b.close()
PYEOF"

# Pull result
scp -i ~/.ssh/lightnode_worker root@130.94.40.226:/tmp/crawl_result.html /tmp/
```

## Mingpao Special Case: Direct HTTP Scrape (no CloakBrowser needed)

`news.mingpao.com` (not `www.mingpao.com`) can be scraped with plain Python `requests`. Full workflow:

```python
import requests, re
from urllib.parse import unquote, urljoin

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Accept-Language': 'zh-HK,zh;q=0.9,en;q=0.8',
}

# Step 1: Crawl a section page to get article links
section_url = "https://news.mingpao.com/ins/%E6%B8%AF%E8%81%9E/section/latest/s00001"
r = requests.get(section_url, headers=headers, timeout=15)
r.encoding = 'utf-8'

# Step 2: Extract article URLs using regex
# URLs are relative: ../ins/港聞/article/20260513/s00001/1778670616924/財務總監涉偷逾7600萬...
article_links = re.findall(r'href="(\.\./(?:ins|pns)/[^"]*?article/[^"]+)"', r.text)

base = "https://news.mingpao.com/"
for href in article_links:
    abs_url = urljoin(base, href.lstrip('../'))
    # Get title from URL slug (last segment)
    title = unquote(abs_url.split('/')[-1]).replace('-', '，')
    
    # Step 3: Read article content
    r2 = requests.get(abs_url, headers=headers, timeout=15)
    r2.encoding = 'utf-8'
    # Content is in <p> tags (skip browser upgrade warning <p>)
    paras = re.findall(r'<p[^>]*>\s*(.*?)\s*</p>', r2.text, re.DOTALL)
    for p in paras:
        text = re.sub(r'<[^>]+>', '', p).strip()
        if len(text) > 20:  # Skip short nav items
            print(text)
```

**Available section pages:**

| Section | URL | Code |
|---------|-----|------|
| 要聞 (PNS) | `/pns/%E8%A6%81%E8%81%9E/section/latest/s00001` | s00001 |
| 港聞 (PNS) | `/pns/%E6%B8%AF%E8%81%9E/section/latest/s00002` | s00002 |
| 經濟 (PNS) | `/pns/%E7%B6%93%E6%BF%9F/section/latest/s00004` | s00004 |
| 娛樂 (PNS) | `/pns/%E5%A8%9B%E6%A8%82/section/latest/s00016` | s00016 |
| 副刊 (PNS) | `/pns/%E5%89%AF%E5%88%8A/section/latest/s00005` | s00005 |
| 社評 (PNS) | `/pns/%E7%A4%BE%E8%A9%95/section/latest/s00003` | s00003 |
| 觀點 (PNS) | `/pns/%E8%A7%80%E9%BB%9E/section/latest/s00012` | s00012 |
| 中國 (PNS) | `/pns/%E4%B8%AD%E5%9C%8B/section/latest/s00013` | s00013 |
| 國際 (PNS) | `/pns/%E5%9C%8B%E9%9A%9B/section/latest/s00014` | s00014 |
| 即時港聞 (INS) | `/ins/%E6%B8%AF%E8%81%9E/section/latest/s00001` | s00001 |
| 即時熱點 (INS) | `/ins/%E7%86%B1%E9%BB%9E/section/latest/s00024` | s00024 |
| 即時兩岸 (INS) | `/ins/%E5%85%A9%E5%B2%B8/section/latest/s00004` | s00004 |
| 即時國際 (INS) | `/ins/%E5%9C%8B%E9%9A%9B/section/latest/s00005` | s00005 |

Full URL = `https://news.mingpao.com` + path above.

## Google News Proxy (backup for blocked content)

If `news.mingpao.com` is blocked, Google News aggregates Mingpao articles at:
```
https://news.google.com/search?q=site:mingpao.com&hl=zh-HK&gl=HK&ceid=HK:zh-Hant
```
Each article links through Google's proxy read page, which also bypasses CF. Note: Google News pages are SPA (JS-rendered) — for plain HTTP scrapes you'll only get headlines + URLs, not article content.

## Known Pitfalls

1. **First run is slow** — ~200MB binary download from cloakbrowser.dev. Subsequent runs are instant.
2. **headless=True is default** — explicit is better.
3. **JS-rendered content** — some sites load content dynamically. Add `time.sleep(3-5)` after `goto()` or use `wait_until="networkidle"`.
4. **No proxy needed** for Oracle Cloud IP — surprisingly CloakBrowser passes CF even from Oracle datacenter IPs. This saves $0. This may change as CF updates detection.
5. **Memory usage** — Each CloakBrowser instance uses ~200-400MB RAM. On Oracle VM (15GB), can run multiple instances. On LightNode (2GB), run one at a time.
6. **Not a CAPTCHA solver** — CloakBrowser prevents CAPTCHA from appearing. If one appears (rare), you still need manual solving or a solving service.
7. **reCAPTCHA v3 score 0.9** — server-verified. This is the "invisible" CAPTCHA that scores your session. Score persists for the browser session, so multiple page loads within same session keep the score.
