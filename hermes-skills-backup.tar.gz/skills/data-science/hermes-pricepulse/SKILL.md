---
name: hermes-taskforge
description: Universal Multi-Agent Task Dispatch Framework — Oracle VM (brain + dispatcher) dispatches tasks to Zeabur / Big VM workshops via SSH, orchestrated by Hermes Harness. Use when: TaskForge, dispatch, distribute tasks, multi-agent, Hermes Harness
category: data-science
---

# Hermes TaskForge

Universal multi-agent task dispatch framework. **Oracle VM (15GB RAM)** is the brain + dispatcher, **Big VM + Zeabur** are workshops that execute tasks via SSH.

**Actual topology (this setup):**
- Oracle VM (`instance-20260405-1324`, 140.245.111.2) — 2 vCPU, 15GB RAM, 30GB disk ← BRAIN + DISPATCHER
- Big VM (`s909679`, 47.79.224.55) — 2 vCPU, 3.7GB RAM, 58GB disk ← WORKER + TG bot host
- Zeabur (`VM-17-222-ubuntu`, 43.156.247.30) — 2 vCPU (AMD EPYC), 1.9GB RAM, 40GB disk ← LIGHTWEIGHT WORKER

## Architecture

```
你 (TG @arslanskybot)
  │
Big VM (OpenClaw Gateway)
  ├── Receives TG message
  └── SSH relay → Oracle VM (brain)
      │
      ├── Workflow Engine (YAML DAG)
      ├── TelemetryTracer (span tree)
      ├── Auto-Router (智能路由)
      │
      ├── local exec ──→ Oracle VM 自身 (15GB, 最強 worker)
      ├── SSH ──→ Big VM (3.7GB, 輕量 worker)
      └── SSH ──→ Zeabur (1.9GB, 輕量 worker)
```

## Auto-Router (智能路由)

`dispatch auto <action> [params]` 自動揀最合適嘅 worker：

| Action | Routed to | Reasoning |
|--------|-----------|-----------|
| `ping` | big-vm / zeabur | 輕量，save Oracle 做重嘢 |
| `exec` | big-vm / zeabur | 簡單指令，唔使大 RAM |
| `python` | oracle-vm1 | 可能 heavy compute，15GB 夠 |
| `scrape` | oracle-vm1 | RAM intensive，留俾大佬 |
| `docker` | oracle-vm1 | 得 Oracle VM 有 docker |
| `node` | oracle-vm1 | 同 python |

Override: `dispatch zeabur exec '{"command":"..."}'` — 強制指定

Error penalty: worker error 後 score *= 0.2，自動避開死咗嘅 worker

## Worker Capacity

| Worker | RAM | Max concurrent tasks | Monthly cost |
|--------|-----|---------------------|-------------|
| Oracle VM (15GB) | 13GB free | ~300 | $0 (already have) |
| Big VM (3.7GB) | 2.5GB free | ~60 | $0 (already have) |
| Zeabur (1.9GB) | 0.5GB free | ~7 | $2/mo |
| **Total** | **20.6GB** | **~367** | **$2/mo** |

## SSH Topology

Big VM has NO private keys — cannot initiate SSH. Oracle VM is the SSH hub:

```
Oracle VM (140.245.111.2) ← this machine
  ├── ~/.ssh/oracle_to_bigvm → root@47.79.224.55 ✅
  ├── ~/.ssh/zeabur_devbox.pem → ubuntu@43.156.247.30 ✅
  └── Can reach both workers

Big VM (47.79.224.55)
  └── Cannot SSH out
  └── Only has authorized_keys (can be connected TO)
  └── /root/taskforge.sh — relays commands via SSH to Oracle VM

Zeabur (43.156.247.30)
  └── User: ubuntu (NOT root)
```

## Commands

```bash
# On Oracle VM (this machine):
cd /home/opc/hermes-pricepulse

# Dispatch with auto-routing
node src/index.js dispatch auto ping
node src/index.js dispatch auto exec '{"command":"df -h"}'
node src/index.js dispatch auto python '{"code":"print(2**100)"}'

# Dispatch to specific worker
node src/index.js dispatch zeabur ping
node src/index.js dispatch big-vm exec '{"command":"uptime"}'

# Fan-out to all workers
node src/index.js fanout zeabur,big-vm exec '{"command":"hostname"}'

# Pipeline across workers
node src/index.js pipeline '[...]'

# From Big VM (via relay script):
bash /root/taskforge.sh dispatch auto exec '{"command":"df -h"}'
```

## Hermes Harness Modules Used

| Module | File | Role |
|--------|------|------|
| WorkflowEngine | `/home/opc/.hermes/harness/core/workflow-engine.js` | YAML DAG execution |
| MessageBus | `/home/opc/.hermes/harness/core/message-bus.js` | Event routing |
| TelemetryTracer | `/home/opc/.hermes/harness/core/telemetry.js` | Span tree per pipeline |
| SandboxManager | `/home/opc/.hermes/harness/core/sandbox.js` | Task isolation |
| Eval Framework | `/home/opc/.hermes/harness/core/eval-framework.js` | Health checks |

## Workshop Agent Actions

| Action | Description |
|--------|-------------|
| `ping` | Heartbeat — hostname, memory, uptime, node version |
| `exec` | Run shell command (`params.command`) |
| `python` | Run Python code or script |
| `node` | Run Node.js code or script |
| `docker` | Run Docker container |
| `run-script` | Run local script from `~/hermes-worker/scripts/` |
| `scrape` | Web scrape URL (puppeteer then curl fallback) |
| `custom` | Load custom handler from `~/hermes-worker/scripts/<name>.js` |

## Key Lessons (Experiential — learned the hard way)

### 1. Harness YAML Parser Limitations
- **NO block scalar support** (`>` or `|`) — the simple YAML parser only parses `>` as a literal `>` char
- **CODE node must be single-line string**: `code: "var x=1; return x;"`
- Multi-line code will be silently parsed incorrectly — use inline everything

### 2. Workflow Engine State Access
- **`output_key` is REQUIRED** on TOOL_CALL nodes to retrieve results
- Without `output_key: my_result`, `state.get("my_result")` returns undefined
- State injection via `WorkflowEngine.run({ task: {...} })` — access as `state.get("task")`, NOT `state.get("currentTask")`

### 3. Template Resolution Gotchas
- `{task.params}` in YAML serializes to `[object Object]` for objects
- Tool handlers must manually resolve templates: `JSON.parse(params.replace(/\{([^}]+)\}/g, ...))`
- Simple values (`{task.worker}`) work fine in YAML template resolution

### 4. Worker Agent Deployment
- Use `~/hermes-worker/agent.js` — tilde expands correctly on all systems
- `/home/hermes-worker/` fails with permission denied on most machines
- Local execution (Oracle VM self): write task JSON to /tmp, then `node ~/hermes-worker/agent.js /tmp/task-xxx.json`
- Remote: pipe via SSH stdin: `echo 'task-json' | ssh host "cat > /tmp/task.json && node ~/hermes-worker/agent.js /tmp/task.json"`

### 5. SSH Key Management
- Big VM has NO private keys — must be the "receiving end" only
- Oracle VM has ALL keys and acts as SSH hub
- Zeabur user is `ubuntu`, NOT `root`
- Reverse tunnel: `ssh -R 2222:localhost:22` allows Big VM to reach Oracle VM

### 6. Auto-Router Design
- Weight-based routing: Oracle=130, BigVM=25, Zeabur=5
- Oracle VM capped at 30 in scoring to prevent it eating all tasks
- Lightweight tasks (ping/exec) get +20 bonus for Zeabur, +10 for BigVM
- Heavy tasks (scrape/python/docker) get +20 bonus for Oracle VM
- Error penalty: score *= 0.2 for errored workers
- Capability matching: score = 0 if action requires capability worker doesn't have