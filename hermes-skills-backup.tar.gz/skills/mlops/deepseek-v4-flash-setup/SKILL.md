---
name: deepseek-v4-flash-setup
description: Add DeepSeek v4 Flash model to Hermes Agent — register in model catalog, set as default, override normalization, configure API key.. Use when: DeepSeek, DeepSeek v4, Flash model, model setup, add model
version: 1.0.0
author: Hermes Agent
tags: [deepseek, model-setup, provider, config]
---

# DeepSeek v4 Flash Setup

Register DeepSeek v4 Flash (and v4 Pro) as usable models in Hermes Agent.

## Steps

### 1. Set API Key

```bash
# Add to ~/.hermes/.env
echo 'DEEPSEEK_API_KEY=sk-your-key-here' >> ~/.hermes/.env
```

Or edit `~/.hermes/.env` directly and add:
```
DEEPSEEK_API_KEY=sk-your-key-here
```

### 2. Register Model in Catalog

Edit `~/.hermes/config.yaml` and set:

```yaml
model:
  default: deepseek-v4-flash
  provider: deepseek
```

### 3. Add Model Entries

In `hermes_cli/models.py`, add to the model catalog for the `deepseek` provider:

```python
ModelEntry(
    id="deepseek-v4-flash",
    provider="deepseek",
    name="DeepSeek v4 Flash",
    context_length=131072,
    description="DeepSeek v4 Flash — fast, cost-effective reasoning",
    supports_streaming=True,
    supports_vision=False,
    supports_tools=True,
),
ModelEntry(
    id="deepseek-v4-pro",
    provider="deepseek",
    name="DeepSeek v4 Pro",
    context_length=131072,
    description="DeepSeek v4 Pro — full reasoning power",
    supports_streaming=True,
    supports_vision=False,
    supports_tools=True,
),
```

### 4. Override Normalization (critical!)

In `hermes_cli/models.py` or where `model_normalize` is defined, add entries to prevent name remapping:

```python
# IMPORTANT: DeepSeek v4 models must use their exact names, not be remapped to "deepseek-chat"
# Add these to the normalization map or ensure the normalize function passes them through unchanged
MODEL_NORMALIZE_OVERRIDES = {
    "deepseek-v4-flash": "deepseek-v4-flash",
    "deepseek-v4-pro": "deepseek-v4-pro",
}
```

If using `model_normalize()` in the agent code path, modify it to:
```python
def model_normalize(model: str) -> str:
    # Check overrides first
    if model in MODEL_NORMALIZE_OVERRIDES:
        return MODEL_NORMALIZE_OVERRIDES[model]
    # ... rest of normalization logic
```

## Pitfalls

1. **Normalization will silently remap "deepseek-v4-flash" to "deepseek-chat"** — DeepSeek's API uses model name directly. If normalization maps it, the API receives "deepseek-chat" instead of "deepseek-v4-flash", giving you the old model. Always add override entries.

2. **API key location** — Must be in `~/.hermes/.env` under `DEEPSEEK_API_KEY`. The `.env` file is loaded by `hermes_cli/config.py` via `dotenv`. If using systemd/gateway, ensure the env var is passed to the service.

3. **Model name in API calls** — DeepSeek API expects the model name as-is: `model="deepseek-v4-flash"` in the request body. No prefix, no remapping.

4. **Context window** — v4 Flash supports 128K context (set as 131072 in catalog for compatibility).

5. **Tool support** — DeepSeek v4 Flash supports function/tool calling (set `supports_tools=True`).

## Verification

```bash
# Test API connectivity
curl -s https://api.deepseek.com/v1/models \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY" \
  | python3 -m json.tool | grep -i "deepseek-v4"

# Quick test in Hermes
echo "ping" | hermes -m deepseek-v4-flash
```
