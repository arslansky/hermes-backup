---
name: openclaw-minimax-setup
description: Configure OpenClaw with MiniMax API key — env var only, config file not supported. Use when: MiniMax, OpenClaw MiniMax, model config, MiniMax API
category: devops
---

# OpenClaw MiniMax Setup

## Key Discovery

OpenClaw 的 MiniMax plugin **只接受環境變量** `MINIMAX_API_KEY`，**唔支援** config 檔案存储 API key。

- `providers` key 在 `openclaw.json` 中是 **無效的**，會導致 `Config invalid: Unrecognized key: "providers"`
- CLI flag `--minimax-api-key` 不存在
- `openclaw config set --json providers.minimax.apiKey` 也不支援

Plugin 定義在 `openclaw.plugin.json` 中：
```json
"providerAuthEnvVars": {
  "minimax": ["MINIMAX_CODE_PLAN_KEY", "MINIMAX_CODING_API_KEY", "MINIMAX_API_KEY"]
}
```

## 正確用法

```bash
export MINIMAX_API_KEY="your-minimax-api-key"
openclaw agent --session-id test -m "hello" --timeout 30
```

`openclaw.json` 完整結構（**必須有 `gateway.mode`**）：
```json
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "minimax/MiniMax-M2.7"
      }
    }
  },
  "gateway": {
    "mode": "local"
  }
}
```

## 完整安裝流程（從零開始）

```bash
# 1. 確認 openclaw 已安裝
openclaw --version

# 2. 設置環境變量（每次 terminal 都要設置，或者加入 ~/.bashrc）
export MINIMAX_API_KEY="your-key"

# 3. 修復 openclaw.json（如果之前有錯誤配置）
# 正確的 openclaw.json 結構：
cat > ~/.openclaw/openclaw.json << 'EOF'
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "minimax/MiniMax-M2.7"
      }
    }
  },
  "gateway": {
    "mode": "local"
  }
}
EOF

# 4. 驗證配置
openclaw config validate

# 5. 安裝 systemd service（可選，但推薦）
openclaw gateway install
systemctl --user daemon-reload
systemctl --user enable openclaw-gateway.service
systemctl --user start openclaw-gateway.service
systemctl --user status openclaw-gateway.service

# 6. 確認 gateway 正常運行
openclaw gateway status
# Runtime: active (running) ✓

# 7. 測試 agent
openclaw agent --session-id test -m "hello"
```

## 常見錯誤

| 錯誤 | 原因 | 解決方法 |
|------|------|----------|
| `HTTP 401 login fail: Please carry the API secret key` | 環境變量未設置或未傳遞 | `export MINIMAX_API_KEY="your-key"` |
| `Config invalid: Unrecognized key: "providers"` | openclaw.json 中不能有 providers key | 移除 providers key，只保留 agents 和 gateway |
| `Gateway start blocked: missing gateway.mode` | config 缺少 `gateway.mode` | 在 openclaw.json 加入 `"gateway": {"mode": "local"}` |
| `gateway connect failed: scope upgrade pending approval` | 設備需要 pairing | 使用 `openclaw device-pair` 或直接用 `--local` 模式 |
| `Runtime: stopped` | gateway 未啟動 | `systemctl --user start openclaw-gateway.service` |
| `Channels: Telegram ON but "no token"` | 環境變量未寫入 systemd service | 在 service 文件加入 `Environment=TELEGRAM_BOT_TOKEN=...` |
| `Channels: Telegram ON but SETUP` | bot 已啟動但未完成 pairing | 發 `/start` 給 bot，輸入 pairing code，然後 `openclaw pairing approve telegram <CODE>` |

## 故障排除

```bash
# 檢查 gateway 狀態
openclaw gateway status

# 查看實時日誌
tail -f /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log

# 手動啟動 gateway（調試用）
export MINIMAX_API_KEY="your-key"
openclaw gateway

# 修復配置（自動修複常見問題）
openclaw doctor --fix

# 確認 API key 格式正確（應該是 sk-cp- 開頭）
echo $MINIMAX_API_KEY | head -c 10
```

## 驗證方法

```bash
export MINIMAX_API_KEY="your-key" && openclaw config validate && openclaw agent --session-id test -m "hello"
```

成功回覆示例：
```
Hey. I just came online — fresh start, blank slate. Who am I? Who are you?...
```

## Systemd Service 配置（完整版）

如果使用 systemd service 运行 gateway，**必須**在 service 文件中加入所有環境變量。否則 CLI 能正常工作但 service 模式會失敗。

```ini
[Service]
Environment=MINIMAX_API_KEY=your-minimax-api-key
Environment=TELEGRAM_BOT_TOKEN=your-telegram-bot-token
```

**完整 service 文件示例**（`~/.config/systemd/user/openclaw-gateway.service`）：
```ini
[Unit]
Description=OpenClaw Gateway (v2026.4.22)
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/home/opc/.nvm/versions/node/v22.22.2/bin/node /home/opc/.nvm/versions/node/v22.22.2/lib/node_modules/openclaw/dist/index.js gateway --port 18789
Restart=always
Environment=HOME=/home/opc
Environment=OPENCLAW_GATEWAY_PORT=18789
Environment=MINIMAX_API_KEY=sk-cp-mNrtisBo...   # 你的 MiniMax API key
Environment=TELEGRAM_BOT_TOKEN=123456789:ABCdef... # 你的 Telegram bot token

[Install]
WantedBy=default.target
```

**更新 service 後重啟**：
```bash
systemctl --user daemon-reload
systemctl --user restart openclaw-gateway.service
```

## Telegram Bot 設定

### 1. 啟用 Telegram plugin
```bash
openclaw plugins enable telegram
```

### 2. 確認 bot token 正確
在 [@BotFather](https://t.me/BotFather) 創建 bot 並獲取 token，格式：`123456789:ABCdefGHIjklMNO...`

### 3. 設置 allowlist（用戶 ID）
你的 Telegram User ID: `160408068`（用戶需要先發 `/start` 給 bot 触发 pairing）

### 4. Pairing 審批
Bot 連接後會显示 pairing code，然後在 CLI 審批：
```bash
openclaw pairing approve telegram <PAIRING_CODE>
```

如果 code 過期，重新發 `/start` 獲取新 code。

## Systemd Service 重要提醒

- 使用 `systemctl --user`（不是 `systemctl`）
- Service 文件位於 `~/.config/systemd/user/openclaw-gateway.service`
- Node version: OpenClaw 需要 Node 22.14+，會自動使用 NVM 的 Node 22
- **所有環境變量都要寫在 service 文件的 Environment= 行**，CLI 的 export 對 service 無效
