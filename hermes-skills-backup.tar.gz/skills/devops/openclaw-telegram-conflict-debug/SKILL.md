---
name: openclaw-telegram-conflict-debug
description: "Debug and fix OpenClaw Telegram bot Conflict error"
category: devops
---

# OpenClaw Telegram Bot Conflict Debug

## Problem
OpenClaw Telegram bot shows "Conflict: terminated by other getUpdates request" error and cannot receive messages.

## Root Cause
Another service (e.g., `telegram-bot.service`) is using the same Bot Token and competing for getUpdates.

## Diagnosis Steps

```bash
# 1. Check gateway logs for the conflict error
tail -50 /tmp/openclaw-gateway.log

# 2. Check for competing bot processes
ps aux | grep -E 'telegram|8302835438' | grep -v grep

# 3. Check ingress spool status
ls -la /root/.openclaw/telegram/ingress-spool-default/
```

## Resolution Steps

```bash
# 1. Stop all competing services
systemctl stop telegram-bot 2>/dev/null
systemctl stop telegram-bot.service 2>/dev/null
pkill -f 'telegram-bot' 2>/dev/null
pkill -f '8302835438' 2>/dev/null  # Token part of process name

# 2. Kill all OpenClaw gateway processes
pkill -f 'openclaw.*gateway'
sleep 2

# 3. Clear ingress spool
rm -f /root/.openclaw/telegram/ingress-spool-default/*

# 4. Restart OpenClaw gateway
nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-gateway.log 2>&1 &
sleep 10

# 5. Verify
tail -20 /tmp/openclaw-gateway.log
curl -s http://localhost:18789/health
```

### Oracle VM Special Case: Hermes + OpenClaw on Same VM

On Oracle VM (140.245.111.2), BOTH Hermes gateway AND OpenClaw standalone may be running with the same bot token, causing conflict.

**Diagnosis:**
```bash
ps aux | grep -E "hermes_cli.main gateway|openclaw/dist/index.js" | grep -v grep
# Both will show if both are running
journalctl --user-unit hermes-gateway -n 20 | grep Conflict
```

**Fix — disable OpenClaw standalone, keep Hermes only:**
```bash
# STOP AND DISABLE the OpenClaw systemd service (CRITICAL: disable alone is not enough)
systemctl --user stop openclaw-gateway.service
systemctl --user disable openclaw-gateway.service

# Kill any remaining standalone process
pkill -f 'openclaw/dist/index.js'
sleep 2

# Verify only Hermes remains
ps aux | grep "hermes_cli.main gateway" | grep -v grep
# Should show PID; no openclaw/dist/index.js process
```

**Key difference from other VMs:**
- On Zeabur/other VMs: OpenClaw is the only bot, just stop competing `telegram-bot` services
- On Oracle VM: OpenClaw standalone AND Hermes gateway may BOTH be running — you must choose which to keep
- The systemd service WILL respawn the process if you only `kill` without `disable`

## Prevention
- Never run two services with the same Telegram Bot Token
- Use separate tokens for separate bots
- Check for telegram-bot.service before starting OpenClaw

## Key Log Messages
- `[telegram] [default] channel exited: Conflict: terminated by other getUpdates request` = Token conflict
- `[telegram] [default] auto-restart attempt X/10` = Gateway retrying due to conflict
- `[gateway] ready` + `[telegram] [default] starting provider` = Successful startup
