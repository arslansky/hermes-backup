---
name: taskforge-worker-onboard
description: Complete workflow to onboard a new VM worker into TaskForge — SSH setup, environment, agent.js, and TaskForge registry registration. Use when: TaskForge worker, VM onboarding, worker setup, new worker
metadata:
  hermes:
    triggers: ["new worker", "VM onboarding", "TaskForge setup", "add worker", "register worker"]
---

# TaskForge Worker Onboarding

Complete workflow to add a new VM worker to the existing Hermes TaskForge multi-agent dispatch system.

## Prerequisites

- Oracle VM (Hermes) with TaskForge orchestrator at `~/hermes-pricepulse/src/orchestrator/index.js`
- New VM with root SSH access (IP, user, password or key)

## Step 1 — SSH Key Setup

```bash
# Generate a new SSH key pair on Oracle VM (if needed)
ssh-keygen -t ed25519 -f ~/.ssh/<worker-name>_worker -N ""

# Copy public key to new worker (if you have password)
sshpass -p '<PASSWORD>' ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/<worker-name>_worker.pub root@<IP>

# Or add manually
cat ~/.ssh/<worker-name>_worker.pub
# → paste into worker's ~/.ssh/authorized_keys
```

**Test connection:**
```bash
ssh -i ~/.ssh/<worker-name>_worker -o StrictHostKeyChecking=no root@<IP> "whoami && hostname"
```

## Step 2 — Environment Setup

Run this on the new worker (adjust for OS — Ubuntu/Debian/CentOS):

```bash
# System update
apt-get update -qq && apt-get upgrade -y -qq

# Install basics
apt-get install -y -qq curl wget git python3 python3-pip python3-venv jq netcat-openbsd

# Python libs for crawling
pip3 install beautifulsoup4 requests lxml

# Node.js 20 (Ubuntu/Debian)
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y -qq nodejs
```

**Verify:**
```bash
python3 --version && node --version && npm --version
```

## Step 3 — Install agent.js

The worker agent is a Node.js script that receives task JSON files via SSH pipe and executes them:

```bash
mkdir -p ~/hermes-worker/scripts ~/hermes-worker/tasks ~/hermes-worker/results
```

Create `~/hermes-worker/agent.js`:

> ⚠️ **KNOW BUG:** TaskForge dispatch sends `{params: {command: "..."}}` (not a flat `command` key). The agent MUST check `task.params.command` as a fallback, otherwise `output.substring(0, 100000)` crashes when `output` is undefined.

```javascript
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const RESULTS_DIR = path.join(__dirname, 'results');
if (!fs.existsSync(RESULTS_DIR)) fs.mkdirSync(RESULTS_DIR, { recursive: true });

function executeTask(taskPath) {
    const task = JSON.parse(fs.readFileSync(taskPath, 'utf8'));
    const taskId = path.basename(taskPath, '.json');
    const resultFile = path.join(RESULTS_DIR, taskId + '.json');
    
    try {
        let output = '';
        // Support both task.command (legacy) and task.params.command (TaskForge)
        const cmd = task.command || (task.params && task.params.command);
        if (cmd) {
        if (cmd) {
            output = execSync(cmd, { 
                timeout: (task.timeout || 300) * 1000,
                cwd: task.cwd || __dirname,
                shell: '/bin/bash',
                maxBuffer: 10 * 1024 * 1024
            }).toString();
        }
        // Safe substring — output might be undefined
        fs.writeFileSync(resultFile, JSON.stringify({
            taskId, success: true,
            output: (output || '').substring(0, 100000),
            exitCode: 0, completedAt: new Date().toISOString()
        }));
        console.log(output);
        process.exit(0);
    } catch (err) {
        fs.writeFileSync(resultFile, JSON.stringify({
            taskId, success: false,
            error: (err.message || 'Unknown error').substring(0, 5000),
            output: ((err.stdout || '')).substring(0, 100000),
            stderr: ((err.stderr || '')).substring(0, 10000),
            exitCode: err.status || -1,
            completedAt: new Date().toISOString()
        }));
        process.exit(1);
    }
}
const taskFile = process.argv[2];
if (!taskFile) { console.error('Usage: node agent.js <task.json>'); process.exit(1); }
executeTask(taskFile);
```

**Test agent.js:**
```bash
cd ~/hermes-worker
echo '{"command":"echo Hello from $(hostname) && date"}' > /tmp/test-task.json
node agent.js /tmp/test-task.json
cat results/*.json
```

## Step 4 — Register in TaskForge

### 4a. Add RESOURCE_LIMITS entry

Edit `/home/opc/hermes-pricepulse/src/orchestrator/index.js`, find `RESOURCE_LIMITS` object and add:

```javascript
'<worker-id>': {
    maxConcurrent: 10,        // Max concurrent tasks
    light: 100,               // Lightweight task priority (0-100)
    medium: 80,               // Medium task priority
    heavy: 30,                // Heavy task priority (only if RAM allows)
},
```

**Tier scoring logic (from TaskForge):**
- light: ping, exec, status, heartbeat
- medium: everything else (typical crawl/queries)
- heavy: python, scrape, docker, build
- 0 means "never route this tier to this worker"
- Score is multiplied by load penalty: `score * (1 - active/maxConcurrent * 0.5)`
- Workers with 3+ consecutive errors are excluded
- `light` tasks get a +20 idleness bonus on `big-vm`

When auto-routing, the worker with the highest final score gets the task.
A worker must have a configured `host` and a capability matching the action type (e.g., `scrape` needs `python` capability) to be eligible.

### 4b. Add worker to defaults

Find the `_loadWorkshops()` method's defaults object and add:

```javascript
'<worker-id>': {
    name: '<Display Name>',
    host: '<IP_ADDRESS>',
    user: 'root',
    sshKey: '~/.ssh/<worker-name>_worker',
    capabilities: ['node', 'python', '<specialty>', 'lightweight'],
    status: 'unknown',
    availableRamGB: <RAM_GB - 0.1 reserve>,
    totalRamGB: <RAM_GB>,
    cpuCores: <N>,
    maxConcurrent: RESOURCE_LIMITS['<worker-id>'].maxConcurrent,
    memoryReserveMB: RESOURCE_LIMITS['<worker-id>'].memoryReserveMB,
},
```

**Capabilities guide:**
- `node` — can run Node.js tasks
- `python` — can run Python/scrape tasks  
- `scrape` — IP is clean for web crawling (use for DSE/education sites)
- `lightweight` — basic exec/ping
- `docker` — can run Docker containers

### 4c. Verify syntax

```bash
cd ~/hermes-pricepulse && node -e "require('./src/orchestrator/index')" 2>&1 | head -5
# Should show the CLI help, not a syntax error
```

### 4d. Add SSH key to authorized_keys

Ensure the Oracle VM can SSH into the new worker (done in Step 1).

## Step 5 — Post-Boot Smoke Test (quick check before TaskForge)

When a worker has just been rebooted, run this first to confirm it's alive:

```bash
# Check SSH + basic info
ssh -i ~/.ssh/<worker-key> root@<IP> "hostname && uptime && free -h && python3 --version && node --version"

# Check agent.js exists
ssh -i ~/.ssh/<worker-key> root@<IP> "ls ~/hermes-worker/agent.js && echo 'agent.js OK' || echo 'agent.js MISSING'"

# Direct agent test (bypasses TaskForge dispatch)
ssh -i ~/.ssh/<worker-key> root@<IP> "echo '{\"command\":\"echo Hello from \$(hostname) && date\"}' > /tmp/test-task.json && node ~/hermes-worker/agent.js /tmp/test-task.json && cat ~/hermes-worker/results/test-task.json"
```

Expected output for a successful agent.js test:
```json
{"taskId":"test-task","success":true,"output":"Hello from <hostname>\n<date>\n","exitCode":0,"completedAt":"..."}
```

## Step 6 — TaskForge Test Dispatch

```bash
cd ~/hermes-pricepulse

# Check all workers alive
node src/orchestrator/index.js health all

# Test dispatch to new worker
node src/orchestrator/index.js dispatch <worker-id> exec '{\"command\":\"echo Hello && hostname && date\"}'

# Test auto-route (may pick new worker if it scores highest)
node src/orchestrator/index.js auto exec '{\"command\":\"uptime\"}'
```

Expected output for a successful dispatch:
```
🚀 dispatch-single — <worker-id>: exec
<worker-id>: completed (ok)
```

> ⚠️ If TaskForge dispatch fails but direct SSH works, it's a JSON escaping issue (see Troubleshooting).

## Step 7 — Crawl Test (for scrape workers)

Run this on the new worker to compare IP cleanliness against existing workers:

```bash
# On new worker directly
ssh -i ~/.ssh/<worker-name>_worker root@<IP> "
python3 << 'PYEOF'
import requests, json
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'}
test_sites = [
    ('https://www.hkeaa.edu.hk/tc/', 'HKEAA'),
    ('https://www.dse00.com/', 'DSE00'),
    ('https://dsepp.com/', 'DSEPP'),
    ('https://www.mingpao.com/', '明報'),
]
for url, name in test_sites:
    try:
        r = requests.get(url, headers=headers, timeout=15)
        cf_blocked = 'cloudflare' in r.text.lower() or 'attention required' in r.text.lower() or 'challenge' in r.text.lower()
        print(f'{name}: HTTP {r.status_code}, size={len(r.text):,}, blocked={cf_blocked}')
    except Exception as e:
        print(f'{name}: ERROR - {e}')
PYEOF
"
```

**Interpreting results:**
- `blocked=True` with HTTP 200 + large body → Cloudflare JS challenge (needs browser/stealth)
- `blocked=False` with HTTP 200 → Clean IP, direct HTTP scrape works ✅
- HTTP 403 → Cloudflare/WAF full block (need residential proxy)
- HTTP 429 → Rate limited (different IP may help)
- Always run the **same test on another worker** to compare IP cleanliness

**Known IP cleanliness ranking (from LightNode/Zeabur comparison):**
| Worker | IP | DSEPP | HKEAA | DSE00 | 明報 |
|--------|-----|-------|-------|-------|------|
| LightNode 🟢 | New Asian VPS ranges | ✅ Direct pass | 🟡 CF JS challenge | 🟡 CF JS challenge | 🔴 CF 403 |
| Zeabur 🟡 | GCP shared | 🔶 429 rate limit | 🟡 CF JS challenge | 🟡 CF JS challenge | 🔴 CF 403 |
| DigitalOcean 🔴 | AS14061 | Worst — many sites block entirely |
| Oracle Cloud 🟡 | Mixed | Some sites block, some pass |

## Step 8 — Save to Memory

```python
memory(action="add", target="user",
       content="<Worker-Name> Worker (<IP>) added YYYY-MM-DD as Nth TaskForge worker. IP clean test results. SSH key at ~/.ssh/<worker-name>_worker.")
```

## Cost-Saving: Idle Shutdown

For hourly-billed VMs (like LightNode at $0.012/hr), implement idle shutdown:

```bash
# Power off from Oracle VM
ssh -i ~/.ssh/<worker-name>_worker root@<IP> "poweroff"

# Power on requires console (no SSH when off → no API available for LightNode)
# User must click "Start" in LightNode/DigitalOcean console
```

## Troubleshooting

### Dispatch fails with SSH pipe error
TaskForge uses: `echo '<JSON>' | ssh <worker> \"cat > /tmp/task-<id>.json && node ~/hermes-worker/agent.js /tmp/task-<id>.json\"`

If the JSON contains quotes/special chars, escaping issues occur. Fix: ensure `params.command` doesn't have nested quotes, or use a pre-written script on the worker.

**Known TaskForge dispatch JSON escaping bug:** TaskForge sends `{params: {command: "..."}}` structure, but the SSH pipe encoding mangling can break quotes. Symptom: `exitCode: -1` with `error: "Cannot read properties of undefined (reading 'substring')"` — this means the agent.js received valid JSON but `task.command` was undefined because it's nested under `task.params.command`. Fix: use the updated agent.js above that handles both formats.

Alternative workaround: skip TaskForge dispatch and test directly via SSH pipe:
```bash
ssh -i ~/.ssh/<worker-key> root@<IP> "echo '{\"command\":\"echo test && hostname\"}' > /tmp/test-task.json && node ~/hermes-worker/agent.js /tmp/test-task.json && cat ~/hermes-worker/results/test-task.json"
```

### Health check succeeds but dispatch fails
Check if agent.js is at the expected path (`~/hermes-worker/agent.js` — `~` resolves to the worker's HOME, not the dispatcher's).

### Worker shows "unknown" or "error" status
Run `node src/orchestrator/index.js health <worker-id>` to force a ping.

## Worker Routing Summary (May 2026)

| Worker | Host | User | SSH Key | Capabilities | Tier Limits |
|--------|------|------|---------|------------|-------------|
| oracle-vm1 | 140.245.111.2 | opc | ~/.ssh/id_rsa | compute,python,node,docker | L:30 M:100 H:100, max:50 |
| big-vm | 47.79.224.55 | root | ~/.ssh/oracle_to_bigvm | node,python,lightweight,exec | L:80 M:0 H:0, max:3 |
| zeabur | 43.156.247.30 | ubuntu | ~/.ssh/zeabur_devbox.pem | node,python,lightweight | L:100 M:50 H:0, max:8 |
| lightnode | 130.94.40.226 | root | ~/.ssh/lightnode_worker | node,python,scrape,lightweight | L:100 M:80 H:30, max:10 |

## Big VM SSH Troubleshooting (June 2026)

**Problem:** All SSH keys rejected + password `S909679` rejected on Big VM (47.79.224.55)

**Symptoms:**
- `Permission denied (publickey,password)` for all keys: `oracle_to_bigvm`, `zeabur_devbox.pem`, `id_ed25519`, `lightnode_worker`
- `sshpass -p 'S909679' ssh ...` also fails with Permission denied
- Ping works (2.43ms), VM is powered ON
- Image: Ubuntu 24.04 LTS (Noble Numbat)

**Likely cause:** Ubuntu 24.04 disables password SSH by default. SSH keys on the VM have been replaced after reimage.

**Fix options:**
1. **Oracle Console VNC** — Open the console, login as root, run `ssh-copy-id` or edit `/etc/ssh/sshd_config` to enable password auth
2. **New SSH key** — User adds Hermes public key (`~/.ssh/id_ed25519.pub`) to Big VM's `~/.ssh/authorized_keys`
3. **Reset password** — Use Oracle Console to reset root password, then enable SSH password auth
