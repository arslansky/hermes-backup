---
name: openclaw-zeabur-restore
description: Restore OpenClaw workspace from GitHub backup to Zeabur VM
triggers:
  - openclaw workspace restore
  - zeabur openclaw backup
  - openclaw github backup restore
---

# OpenClaw Zeabur Restore Workflow

Restore OpenClaw workspace from GitHub backup to Zeabur VM.

## Context
- Zeabur VM: `43.156.247.30`, user `ubuntu`, pass `@Q2%YTCbe%)mvSGQ42`
- OpenClaw path: `~/.openclaw/`
- OpenClaw binary: `/home/ubuntu/.npm-global/bin/openclaw`
- GitHub token available as `ghp_*` PAT with repo access

## Step-by-Step

### 1. Clone Repo
```bash
cd ~/.openclaw
git clone https://ghp_TOKEN@github.com/arslansky/openclaw-workspace.git temp-clone
```

### 2. Stop OpenClaw
```bash
pgrep -a openclaw  # find PID
kill <PID>
```

### 3. Restore Workspace (git reset method)
```bash
cd ~/.openclaw/workspace
git init  # if not already git repo
git remote add origin https://ghp_TOKEN@github.com/arslansky/openclaw-workspace.git
git fetch origin
git reset --mixed origin/master  # unstages all tracked files, leaving working dir intact
```
This preserves local untracked files (like `.bak` backups) while restoring all tracked files from repo.

### 4. Restore Agent Config (CRITICAL — often missing after reset)
The agent config lives in `agents_backup/main/agent/` inside the workspace:
```bash
cp workspace/agents_backup/main/agent/auth-profiles.json ~/.openclaw/agents/main/agent/auth-profiles.json
cp workspace/agents_backup/main/agent/auth-state.json ~/.openclaw/agents/main/agent/auth-state.json
cp workspace/agents_backup/main/agent/config.json ~/.openclaw/agents/main/agent/config.json
cp workspace/agents_backup/main/agent/model.json ~/.openclaw/agents/main/agent/model.json
cp workspace/agents_backup/main/agent/models.json ~/.openclaw/agents/main/agent/models.json
```

### 5. Clean Up
```bash
rm -rf temp-clone
rm ~/.openclaw/workspace/BOOTSTRAP.md  # if exists from fresh install
```

### 6. Restart OpenClaw
```bash
nohup /home/ubuntu/.npm-global/bin/openclaw gateway run > ~/openclaw.log 2>&1 &
sleep 8 && tail -5 ~/openclaw.log
```

## Key Learnings
- Private GitHub repos return 404 without auth token — API and web both fail
- `git reset --mixed` is the right restore approach — preserves local untracked files
- Agent config (auth profiles, model settings) is NOT in workspace root — it's in `agents_backup/main/agent/`
- After restore, `agents/main/agent/` only had `models.json` (22 bytes) — had to restore full config from backup
- Workspace files can be restored from the git repo, but agent credentials must be copied from `agents_backup/`

## Verification
```bash
# Check OpenClaw is running
pgrep -a openclaw

# Check Telegram connected
tail ~/openclaw.log | grep -E "(gateway ready|telegram|provider auth)"

# Check model config
cat ~/.openclaw/agents/main/agent/model.json
cat ~/.openclaw/agents/main/agent/auth-profiles.json | python3 -c "import sys,json; d=json.load(sys.stdin); [print(k) for k in d.get('profiles',{}).keys()]"
```
