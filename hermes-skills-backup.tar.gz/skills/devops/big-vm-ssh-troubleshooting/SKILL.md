---
name: big-vm-ssh-troubleshooting
description: Big VM (Zeabur) SSH connection troubleshooting — when all keys and passwords fail and connection times out
category: devops
---

# Big VM SSH Troubleshooting

# Big VM SSH Troubleshooting

## Important Clarification
- **Big VM is on Claw Cloud** (NOT Oracle Cloud, NOT Zeabur)
- SSH key: `~/.ssh/oracle_to_bigvm` — THIS IS THE CORRECT KEY
- User: `root` (NOT `opc`)
- IP: `47.79.224.55`
- Password: `S909679` (but key auth is preferred)

## Connection Command
```bash
ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no -i ~/.ssh/oracle_to_bigvm root@47.79.224.55
```

## Diagnostic Steps

### 1. Verify VM is Online
```bash
ping -c 2 -W 3 47.79.224.55
```
✅ Ping works = VM is running

### 2. Test SSH Connection
```bash
ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no -i ~/.ssh/oracle_to_bigvm root@47.79.224.55 "echo '✅ Connected' && uptime"
```

### 3. Common Error Patterns

| Error | Meaning | Solution |
|-------|---------|----------|
| `Permission denied (publickey,password)` | Wrong credentials | Check key/token/password |
| `Connection timed out` | Network block or VM down | Check if VM is powered on |
| `Connection refused` | SSH not running | VM may be stopped |

### 4. If All Keys Rejected
- VM may have been reinstalled — ask user for new SSH key or reset via console
- Try all keys in `~/.ssh/` directory
- Password auth may be disabled on Ubuntu 24.04

### 5. If Connection Times Out (but ping works)
Likely firewall blocking your IP. Options:
- Ask user to whitelist your IP in Claw Cloud console
- Use VPN (Surfshark available at `~/.ssh/surfshark_wg.conf`)

## Lessons Learned (2026-06-07)

| Observation | Meaning |
|-------------|---------|
| `oracle_to_bigvm` key works | This is the correct key for Big VM |
| User is `root` | Not `opc` as on Oracle VM |
| Big VM is Claw Cloud | Different provider from Oracle VM |
| "Permission denied" | Wrong credentials, not IP block |
| "Connection timed out" | Network issue or VM stopped |
| All keys rejected | VM may have been reinstalled |

## Prevention
- Before troubleshooting: confirm VM provider (Oracle vs Claw Cloud vs Zeabur)
- Confirm which SSH key is registered on the VM
- Confirm username (often `root` on Ubuntu, `opc` on Oracle Linux)
- Limit authentication attempts to avoid IP block