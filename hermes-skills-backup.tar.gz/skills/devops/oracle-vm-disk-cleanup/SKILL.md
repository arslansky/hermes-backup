---
name: oracle-vm-disk-cleanup
description: Oracle VM disk cleanup workflow — analyze and free disk space on Oracle Linux
category: devops
---

# Oracle VM Disk Cleanup

## Problem
Oracle VM (30GB) running at 96% disk usage. Need to free space.

## Approach (Sequential)

### 1. Analyze Usage
```bash
sudo du -hsm /* 2>/dev/null | sort -rn | head -20  # What uses space
df -h /                                            # Current usage
```

### 2. Safe Cleanups (Always Safe)
```bash
# Journal logs
sudo journalctl --vacuum-size=50M

# DNF cache (Oracle Linux)
sudo dnf clean all

# Old Playwright Chrome versions
rm -rf ~/.cache/ms-playwright/chromium-1217/
rm -rf ~/.cache/ms-playwright/chromium_headless_shell-1217/

# Hermes logs (3+ days old)
find /home/opc/.hermes/logs -name "*.log" -mtime +3 -delete

# /tmp old files (exclude sockets)
find /tmp -type f ! -name "*.sock" ! -name "ssh-*" -atime +1 -delete
```

### 3. Conditional Cleanups (Check Before)
```bash
# Only if unused Python environment
du -sh /home/opc/nb311  # Check first
rm -rf /home/opc/nb311  # Delete if truly unused

# Only if multiple kernels installed
rpm -q kernel-core | wc -l  # Check count
# Only clean if > 1
```

### 4. Results from 2026-06-07
| Action | Space Freed |
|--------|-------------|
| journalctl --vacuum-size=50M | 118MB |
| dnf clean all | 1GB |
| Remove old Playwright | ~500MB |
| Delete nb311 | 1GB |
| hermes logs cleanup | ~15MB |
| **Total** | **~3.2GB** |

**Before: 96% (1.4GB free) → After: 85% (5.4GB free)**

## Notes
- nb311 was 1GB Python notebook environment, confirmed unused
- Only 1 kernel installed, skipped kernel cleanup (risk of unbootable)
- hermes logs are small (15MB), not worth aggressive cleanup