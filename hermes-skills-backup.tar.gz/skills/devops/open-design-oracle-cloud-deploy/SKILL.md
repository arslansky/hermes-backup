---
name: open-design-oracle-cloud-deploy
description: Deploy nexu-io/open-design on Oracle Cloud VM using Podman — pre-built image, host network mode, API verification
tags: [open-design, podman, oracle-cloud, deployment, docker-alternative]
created: 2026-06-02
---

# Open Design on Oracle Cloud VM — Podman Deployment

## Context
Deploying [nexu-io/open-design](https://github.com/nexu-io/open-design) on Oracle Cloud Linux VM using Podman (instead of Docker). Open Design v0.8.1.

## Environment
- Oracle Linux Server 9.7 (AMD EPYC)
- Podman 5.6.0 (NOT Docker)
- Node v22 (host) — OD requires Node ~24 but pre-built image bundles its own Node 24
- No docker-compose — use podman-compose instead
- Disk space constraint — prune podman images if needed

## Quick Deploy (Pre-built Image)

```bash
# 1. Check available container runtime (Big VM has Docker, not Podman)
docker --version  # Use docker if available, not podman

# 2. Generate API token
OD_TOKEN=$(openssl rand -hex 32)

# 3. Pull and run with Docker (host network required for external access)
docker run -d --name open-design \
  --network=host \
  -e OD_API_TOKEN="$OD_TOKEN" \
  -e OD_BIND_HOST=0.0.0.0 \
  -v open_design_data:/app/.od \
  --restart always \
  docker.io/vanjayak/open-design:latest

# 4. Verify
curl http://127.0.0.1:7456/api/health
# Expected: {"ok":true,"version":"0.8.1"}

# 5. Get API token from running container when needed
docker inspect open-design --format '{{range .Config.Env}}{{println .}}{{end}}' | grep OD_API
```

## Critical: Network Binding Gotcha

**Problem**: Even with `OD_BIND_HOST=0.0.0.0` and `-p 0.0.0.0:7456:7456`, the daemon inside the container binds to `127.0.0.1`. Port mapping `-p` has no effect.

**Solution**: Use `--network=host`. This makes the service accessible on the VM's public IP at port 7456.

```bash
# WRONG — port not accessible externally
podman run -d --name open-design -p 0.0.0.0:7456:7456 ...

# RIGHT — host network mode
podman run -d --name open-design --network=host ...
```

With `--network=host`, the service binds to `0.0.0.0:7456` on the host and is reachable at `http://<vm-public-ip>:7456`.

## Disk Space Recovery

If disk is full (97%+ used):

```bash
podman system prune -af
```

This freed 5GB+ in the Oracle Cloud VM environment.

## API Verification

```bash
TOKEN=$(docker inspect open-design --format '{{range .Config.Env}}{{println .}}{{end}}' | grep OD_API | cut -d= -f2)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:7456/api/agents
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:7456/api/skills
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:7456/api/design-systems
```

Expected: 22 agents, 137 skills, 150+ design systems.

## Fetching Design System Rules

```bash
TOKEN=$(docker inspect open-design --format '{{range .Config.Env}}{{println .}}{{end}}' | grep OD_API | cut -d= -f2)

# List all design systems
curl -s -H "Authorization: Bearer $TOKEN" http://127.0.0.1:7456/api/design-systems | python3 -c "
import sys,json
d=json.loads(sys.stdin.read())
for x in d['designSystems']: print(x['id'], '-', x['title'])
"

# Get full design system rule (for applying to code generation)
curl -s -H "Authorization: Bearer $TOKEN" \
  "http://127.0.0.1:7456/api/design-systems/contemporary" | \
  python3 -c "import sys,json; d=json.loads(sys.stdin.read()); print(d['body'])"
```

Key design systems for landing pages:
- `professional` — Poppins, #FECE14 primary, structured corporate
- `contemporary` — Jost, #C800DF primary, modern minimal
- `clean` — minimal with ample whitespace
- `minimal` — stripped-back modern minimal

## Build from Source (Not Recommended on Oracle Cloud)

Building from source inside Podman requires Node 24 in the build environment and ~5GB+ disk space for the build cache. The pre-built image is strongly preferred.

If build is attempted and fails with "no space left on device", see Disk Space Recovery above.

## Quick Tunnel Access (No Cloudflare Account)

For testing without a persistent tunnel:

```bash
# Install cloudflared (no root needed)
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /tmp/cloudflared
chmod +x /tmp/cloudflared
sudo mv /tmp/cloudflared /usr/bin/cloudflared

# Start quick tunnel (temporary URL each time)
nohup /usr/bin/cloudflared tunnel --url http://localhost:7456 > /tmp/cloudflared.log 2>&1 &
sleep 5
cat /tmp/cloudflared.log | grep "https://"
```

**Systemd Service** (for permanent tunnel):
```bash
sudo tee /etc/systemd/system/cloudflared-tunnel.service > /dev/null << 'EOF'
[Unit]
Description=Cloudflare Tunnel to Open Design
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/cloudflared tunnel --url http://localhost:7456
Restart=always
RestartSec=5
StandardOutput=append:/tmp/cloudflared.log
StandardError=append:/tmp/cloudflared.log

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable cloudflared-tunnel.service
sudo systemctl start cloudflared-tunnel.service
```

## Tunnel Reliability: Cloudflare vs Serveo

**Cloudflare quick tunnel problems (2026-06):**
- Frequent 500 errors on trycloudflare.com: "invalid character 'e' looking for beginning of value"
- Random edge node allocation - some nodes (SIN08, SIN12) have mobile compatibility issues
- `--protocol http2` flag doesn't actually force HTTP/2 - cloudflared still uses QUIC internally as primary protocol
- Mobile ISPs sometimes block trycloudflare.com entirely

**Serveo.net (SSH-based tunnel) - MORE RELIABLE FOR MOBILE:**
```bash
# Install SSH if not present (Oracle Linux has it by default)
# Start serveo tunnel
nohup ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:7456 serveo.net > /tmp/serveo.log 2>&1 &
sleep 6
cat /tmp/serveo.log | grep "Forwarding HTTP traffic from"
# Output: "Forwarding HTTP traffic from https://xxxx.serveousercontent.com"
```

**Systemd service for serveo:**
```bash
sudo bash -c 'cat > /etc/systemd/system/serveo-tunnel.service << EOF
[Unit]
Description=SSH Tunnel to Serveo.net for Open Design
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:7456 serveo.net
Restart=always
RestartSec=5
StandardOutput=append:/tmp/serveo.log
StandardError=append:/tmp/serveo.log

[Install]
WantedBy=multi-user.target
EOF'
sudo systemctl daemon-reload
sudo systemctl enable serveo-tunnel.service
sudo systemctl start serveo-tunnel.service
```

**Run both tunnels simultaneously** for redundancy - serveo is more reliable on mobile, cloudflare as backup.

## Security Note

OD_API_TOKEN is required for all /api/* endpoints. The quick tunnel exposes the service to the public internet via a random trycloudflare.com URL. For production, use a named Cloudflare tunnel with authentication.