---
name: hermes-backup-sync
description: Sync Hermes system evaluation to GitHub backup repo
---
# hermes-backup-sync

Sync Hermes system evaluation to GitHub backup repo.

## Trigger

When? Either:
- User requests: "update hermes backup" or "sync to github"
- After any significant system config change (tool additions, skill changes, config updates)
- Via cron: daily at 07:00 HKT

## Workflow
## Workflow (one-shot backup)

### Step 1: Uncomment and activate token

```bash
sed -i 's/^# GITHUB_TOKEN=/GITHUB_TOKEN=/' ~/.hermes/.env
export GITHUB_TOKEN=$(grep '^GITHUB_TOKEN=' ~/.hermes/.env | cut -d'=' -f2)
gh auth status
```

If `gh auth status` shows "You are not logged in", authenticate:
```bash
export GITHUB_TOKEN=ghp_...
gh auth login --with-token <<< "$GITHUB_TOKEN"
```

### Step 2: Create backup directory

```bash
BACKUP_DIR="/tmp/hermes-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
```

### Step 3: Copy files to backup

```python
import subprocess, os, re

BACKUP = "/tmp/hermes-backup-YYYYMMDD_HHMMSS"
HERMES = os.path.expanduser("~/.hermes")
HERMES_AGENT = os.path.expanduser("~/.hermes/hermes-agent")

# Source files to back up
source_files = [
    "run_agent.py", "model_tools.py", "toolsets.py",
    "agent/prompt_builder.py", "agent/context_compressor.py",
    "agent/skill_commands.py", "hermes_cli/commands.py",
    "hermes_cli/config.py", "hermes_cli/models.py",
    "gateway/run.py", "tools/registry.py",
]
src_backup = os.path.join(BACKUP, "hermes-agent-source")
os.makedirs(src_backup, exist_ok=True)
for f in source_files:
    src = os.path.join(HERMES_AGENT, f)
    dst = os.path.join(src_backup, f.replace("/", "_"))
    if os.path.exists(src):
        with open(src) as fp: content = fp.read()
        with open(dst, "w") as fp: fp.write(content)

# Copy skills (preserve directory structure)
skills_backup = os.path.join(BACKUP, "skills")
os.makedirs(skills_backup, exist_ok=True)
for s in os.listdir(os.path.join(HERMES, "skills")):
    subprocess.run(["cp", "-r", os.path.join(HERMES, "skills", s), skills_backup],
                  stderr=subprocess.DEVNULL)

# Redact secrets in config
with open(os.path.join(HERMES, "config.yaml")) as f:
    content = re.sub(r'(minimax|openai|deepseek|telegram)_api_key["\s]*[:=]["\s]*[^\n]+',
                    r'\1_api_key: "***REDACTED***"', f.read())
    content = re.sub(r'ghp_[a-zA-Z0-9]+', '***TOKEN***', content)
with open(os.path.join(BACKUP, "config.yaml"), "w") as f:
    f.write(content)

with open(os.path.join(HERMES, ".env")) as f:
    content = re.sub(r'ghp_[a-zA-Z0-9]+', '***TOKEN***', f.read())
with open(os.path.join(BACKUP, ".env"), "w") as f:
    f.write(content)
```

### Step 4: Git init, commit, push

```bash
cd "$BACKUP_DIR"
git init
git add -A
git commit -m "Hermes backup $(date +%Y-%m-%d)"
git branch -M main
git remote add origin https://ghp_...@github.com/arslansky/hermes-backup.git
git push -u origin main
rm -rf "$BACKUP_DIR"  # cleanup after successful push
```

### Step 5: Verify push

```bash
gh repo view arslansky/hermes-backup --json name,pushedAt
```

## Backup Repo Location

GitHub: `https://github.com/arslansky/hermes-backup`
Local staging: `/tmp/hermes-backup-YYYYMMDD_HHMMSS` (deleted after push)

## GitHub Repo

`https://github.com/arslansky/hermes-backup`

## Token Activation (critical)

Token stored in `~/.hermes/.env` as `# GITHUB_TOKEN=ghp_...` — **commented out by default**.
Steps to activate:
1. `sed -i 's/^# GITHUB_TOKEN=/GITHUB_TOKEN=/' ~/.hermes/.env` — uncomment it
2. `export GITHUB_TOKEN=$(grep '^GITHUB_TOKEN=' ~/.hermes/.env | cut -d'=' -f2)`
3. `gh auth status` — if "not logged in", run:
   `gh auth login --with-token <<< "$GITHUB_TOKEN"`

## Pitfalls

- `GITHUB_TOKEN=***` in output = commented out, not active → `gh` fails silently with "You are not logged in"
- Token must be UNCOMMENTED in `.env` before `gh` CLI works
- Repo must exist before push — create with: `gh repo create arslansky/hermes-backup --public --description "..."`
- After push, delete staging dir: `rm -rf /tmp/hermes-backup-*` to avoid confusion