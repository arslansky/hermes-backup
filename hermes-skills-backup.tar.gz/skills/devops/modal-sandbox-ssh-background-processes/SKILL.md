---
name: modal-sandbox-ssh-background-processes
description: Modal Sandbox SSH constraints - background processes die when SSH disconnects. Workarounds and deployment patterns for Modal sandbox environments (ZO VM, Modal Cloud Shell, etc.)
tags: [modal, sandbox, ssh, background-processes, zocomputer, deployment]
created: 2026-06-02
---

# Modal Sandbox SSH Background Process Behavior

## Problem

On Modal Sandbox environments (e.g., ZO VM at ts8.zocomputer.io port 10661), background processes started via SSH with `nohup`, `&`, or even `ssh -f` are **automatically killed when the SSH connection closes**. This is different from standard Linux VMs.

Symptoms:
- `nohup node daemon &` → process appears to start but exits immediately after SSH disconnect
- `ssh -f host "daemon"` → same, daemon listens but dies on disconnect
- `setsid`, `disown` → also ineffective, Modal controls the process lifecycle
- Process appears in `ps aux` but listening port is unreachable after SSH disconnect

## Environment Tested

- ZO VM: Debian 12 (bookworm), Node 22.22.2, Bun 1.3.11
- Modal Sandbox (containerized environment)
- SSH port: 10661
- User: root

## Key Characteristics

| Feature | Standard Linux VM | Modal Sandbox |
|---------|-------------------|---------------|
| nohup & | Survives disconnect | ❌ Killed on disconnect |
| ssh -f | Survives disconnect | ❌ Killed on disconnect |
| setsid/disown | Survives disconnect | ❌ Killed on disconnect |
| Foreground (SSH session active) | Works while connected | ✅ Works while connected |
| Process persistence | Yes | Only while SSH alive |

## Workarounds

### 1. Keep SSH Session Alive (for development/demo)

Keep a long-running SSH session in a terminal. Use a **second SSH session** for commands.

```bash
# Session 1: Keep this alive - runs the daemon
ssh -i ~/.ssh/id_ed25519_zo -p 10661 root@ts8.zocomputer.io
# Inside: node apps/daemon/bin/od.mjs daemon start --headless

# Session 2: Use the daemon
ssh -i ~/.ssh/id_ed25519_zo -p 10661 root@ts8.zocomputer.io "curl http://127.0.0.1:7456/api/health"
```

### 2. Inline daemon start (foreground, SSH-dependent)

```bash
ssh -i ~/.ssh/id_ed25519_zo -p 10661 -t root@ts8.zocomputer.io \
  "cd /open-design && node apps/daemon/bin/od.mjs daemon start --headless"
```

Use `-t` for pseudo-terminal allocation (needed for some interactive programs).

## What DOES Work on Modal Sandbox

- Foreground processes while SSH is connected
- Inline `ssh host "command1 && command2"` execution
- Interactive terminal sessions

## What DOESN'T Work

- Any form of backgrounding that relies on SSH disconnect to orphan the process
- Persistent daemons that outlive SSH connection
- Cron jobs (typically reset on sandbox restart)

## Implications for Deployment

On Modal Sandbox, treat programs as **ephemeral and SSH-dependent**. For Open Design:

- Works: `ssh → od daemon start --headless → use while connected`
- Works: Educational demos with active SSH session
- Doesn't work: Headless production deployment (needs a real VM with proper process supervision like systemd)

## Detection

```bash
# If daemon works via inline curl but not after backgrounding, it's a Modal constraint
ssh host "node daemon &" && sleep 3 && ssh host "curl localhost:7456/api/health"
# Second curl fails = Modal Sandbox process lifecycle issue
```

## Related

- ZO VM (ts8.zocomputer.io port 10661) has Modal daemon running as PID 26 (`modal-daemon`)
- Modal sandbox also has `/tmp` with only 1.8MB, limited to in-memory filesystem
- Network isolation prevents external port exposure
- Key file: `~/.ssh/id_ed25519_zo` (Oracle VM's ZO VM key)