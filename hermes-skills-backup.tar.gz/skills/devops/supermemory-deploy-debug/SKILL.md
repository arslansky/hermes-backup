---
name: supermemory-deploy-debug
title: Supermemory Phase 1 Deploy & Debug
description: Deploy and debug Supermemory AI memory system on Oracle VM — covers Podman vs Docker, Chroma running on port 8000, FastAPI app on port 8001, and known POST /memory error.
trigger: Post-Phase 1 deployment and debugging of Supermemory project
---

# Supermemory Phase 1 Deploy & Debug Notes

## Project Location
`/home/opc/supermemory/`

## Infrastructure Findings

### Oracle VM Stack
- **Podman 5.6.0** (NOT Docker — use `podman` commands, Docker-compatible)
- RAM: 15GB total, 13GB available (good for Chroma)
- Disk: 30GB total, only 1.5GB free (96% used — may need cleanup)

### Services Already Running
| Service | Container Name | Port | Status |
|---------|---------------|------|--------|
| Chroma | `chroma` | 8000 | Running (5+ hours) |
| Supermemory FastAPI | — | 8001 | Running |

**Important:** Supermemory app runs on port **8001** (not 8000), because Chroma already occupies 8000.

### Checking Status Commands
```bash
# Check Chroma
curl http://localhost:8000/api/v2/heartbeat

# Check Supermemory app
curl http://localhost:8001/health

# Check Podman containers
podman ps -a --filter "name=chroma"

# Check if Supermemory app is running
ps aux | grep uvicorn | grep -v grep
```

## Known Issues

### POST /memory Returns Internal Server Error
**Symptom:** `POST /memory` fails with Internal Server Error
**Likely cause:** Chroma client connection issue in `/home/opc/supermemory/app/core/db.py`

The Chroma HttpClient needs to connect to `localhost:8000` (the existing container).
Current `app/core/config.py` may have wrong host/port settings.

**Debug steps:**
```bash
# Test Chroma directly
curl http://localhost:8000/api/v2/heartbeat

# Check Supermemory logs
cat /tmp/supermemory.log 2>/dev/null || echo "No log found"
```

### Disk Space Critical
Only 1.5GB free. Chroma + Docker images may fill up.
```bash
# Clean up
podman system prune -a
```

## Phase 1 QA Results
- 37 checks, 100% pass rate
- Tests located: `/home/opc/supermemory/tests/test_harness.py`
- Run: `cd /home/opc/supermemory && python3 tests/test_harness.py`

## Files Created (Phase 1)
```
/home/opc/supermemory/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── app/
│   ├── main.py          # FastAPI entry (port 8001)
│   ├── api/memory.py    # CRUD endpoints
│   ├── core/config.py   # TTK_API_KEY, CHROMA_HOST
│   ├── core/db.py       # Chroma HttpClient
│   ├── models/memory.py  # Pydantic schemas
│   └── services/extractor.py  # LLM fact extraction (TTK gpt-5.5)
└── tests/
    ├── test_api.py
    ├── test_extractor.py
    └── test_harness.py
```

## TTK API Key (Active)
```
sk-dJfy8GWR5czhLBHtvSmkrsWy0ZV6js5fT5e2WuAoJsQfRNAd
```
Model for extraction: `[按量计费]-gpt-5.5`

## Next Steps (Phase 2)
1. Fix POST /memory Internal Server Error
2. Verify Chroma CRUD fully works
3. Proceed to Profile + temporal features
