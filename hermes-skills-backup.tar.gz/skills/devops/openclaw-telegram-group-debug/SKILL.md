---
name: openclaw-telegram-group-debug
description: "Debug and fix OpenClaw Telegram bot not responding in group chats — covers Privacy Mode, group config, allowlist issues, and API verification. Use when: Telegram group, OpenClaw debug, bot not responding, group chat, not-allowed"
category: devops
---

# OpenClaw Telegram Group Not Responding — Debug & Fix

## Symptoms
- Bot is member of Telegram group (confirmed via `getChatMember`)
- Bot responds to DMs but ignores group messages
- CLI `curl` can send to group via API, but bot doesn't receive/respond to messages
- Logs show no incoming group messages

## Diagnostic Steps

### 1. Verify bot is in the group
```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getChat?chat_id=<GROUP_ID>"
curl -s "https://api.telegram.org/bot<TOKEN>/getChatMember?chat_id=<GROUP_ID>&user_id=<BOT_USER_ID>"
```
Should return `"status": "administrator"` or `"member"`.

### 2. Verify bot can send to group (outbound works)
```bash
curl -s "https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<GROUP_ID>&text=Test"
```
If this succeeds but bot doesn't auto-reply to group messages, the issue is inbound.

### 3. Check OpenClaw config
```bash
python3 -c "import json; d=json.load(open('/home/opc/.openclaw/openclaw.json')); print(json.dumps(d.get('channels',{}).get('telegram',{}), indent=2))"
```
Ensure `groups."*".requireMention: false` is set.

### 4. Check logs for group activity
```bash
grep -E "group|-1003" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | tail -20
```
If no incoming group messages in logs, bot is not receiving them.

## Root Cause: Telegram Bot Privacy Mode

By default, Telegram bots can only read:
- Messages that @mention the bot
- Commands (starting with /)
- Replies to the bot

 Bots **cannot** read regular messages in groups unless:
1. Bot is an admin with "Read Messages" permission, **OR**
2. Privacy mode is disabled in @BotFather

## Solution: Disable Privacy Mode via @BotFather

1. Open Telegram → search **@BotFather**
2. Send `/mybots`
3. Select **@your_bot** (or your bot name)
4. → **Bot Settings** → **Group Privacy** → **Turn off**
5. Confirm

After disabling, you may need to **remove and re-add the bot** to the group for the privacy change to take effect.

Then restart the service:
```bash
systemctl --user restart openclaw-gateway.service
```

## Critical Diagnostic: getUpdates API

If `sendMessage` works but the bot never auto-replies to group messages, use `getUpdates` to confirm whether the bot is actually **receiving** messages:

```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getUpdates?limit=5&timeout=0"
```

- **Empty result** = bot is NOT receiving any messages (privacy mode issue)
- **Messages present** = bot is receiving but OpenClaw isn't processing them (config issue)

Also check `getWebhookInfo` to ensure no webhook is interfering:
```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

## Soft Reset vs Full Reinstall

If config gets corrupted (e.g., after crash loops), prefer **soft reset** over full reinstall:

```bash
openclaw reset --scope config --non-interactive
# This deletes openclaw.json and restores from openclaw.json.last-good
# Does NOT require re-entering bot tokens
```

Full reinstall (`openclaw reset --scope all`) is unnecessary — SIGTERM is Oracle infrastructure, not an OpenClaw bug. Soft reset fixes config corruption; the service auto-restarts via systemd Restart=always.

## Oracle Cloud SIGTERM Pattern

If OpenClaw shows frequent SIGTERM restarts on Oracle Cloud VM (free tier):
- SIGTERM count suddenly spikes (e.g., 0→29 in one day)
- Often accompanied by `Config auto-restored` logs indicating crash loops
- **Root cause**: Oracle Cloud infrastructure (live migration, resource throttling), NOT OpenClaw config
- **Solution**: Soft reset if config is corrupted, otherwise just wait — service auto-recovers via Restart=always
- Monitor: `grep -c "SIGTERM received" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log`

## Updating Telegram Bot Token

When updating the Telegram bot token (e.g., via @BotFather `/revoke`):
1. Update `openclaw.json`: `channels.telegram.botToken`
2. Update systemd service file: `Environment=TELEGRAM_BOT_TOKEN=<NEW_TOKEN>`
3. Update backup: `~/.hermes/openclaw_backup/openclaw-gateway.service`
4. Reload and restart:
   ```bash
   systemctl --user daemon-reload
   systemctl --user restart openclaw-gateway.service
   ```

## Prevention
When setting up a new Telegram bot for group use, disable privacy mode **before** adding to groups. Privacy mode changes take effect immediately for new groups, but existing groups may need to remove/re-add the bot.

## Quick Reference
| Check | Command |
|-------|---------|
| Bot in group? | `curl "https://api.telegram.org/bot<TOKEN>/getChatMember?chat_id=<ID>&user_id=<BOT_ID>"` |
| Send test message | `curl "https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<ID>&text=Test"` |
| Group config | `python3 -c "import json; print(json.dumps(json.load(open('~/.openclaw/openclaw.json')).get('channels',{}).get('telegram',{}), indent=2))"` |

## New Group 'not-allowed' — Missing from Groups Allowlist

When a group shows `not-allowed` in logs even though the bot is a member:
```
{'chatId': -1003924885824, 'title': '知庫群組', 'reason': 'not-allowed'}
```

**Root cause**: `groupPolicy` is `allowlist` and the group's chat ID is not in `channels.telegram.groups`.

**Fix**: Add the group to `channels.telegram.groups` in openclaw.json:
```python
import json

f = '/home/opc/.openclaw/openclaw.json'
d = json.load(open(f))

# Add new group — get chatId from the 'not-allowed' log entry
d['channels']['telegram']['groups']['-1003924885824'] = {
    'enabled': True,
    'requireMention': False
}

json.dump(d, open(f, 'w'), indent=2, ensure_ascii=False)
print('Group added, triggering hot reload...')
```

Then trigger hot reload:
```bash
kill -15 $(pgrep -f "openclaw.*gateway")
```

**Verify in logs** — look for these on restart:
```
config change detected; evaluating reload (channels.telegram.botToken)
restarting telegram channel
[default] starting provider (@Know2learn_bot)
```

**Important**: With `groupPolicy: allowlist`, EVERY group the bot should respond in must be explicitly listed in `channels.telegram.groups`. If you want the bot to respond in ALL groups, set `groupPolicy: "open"` (no restriction).
