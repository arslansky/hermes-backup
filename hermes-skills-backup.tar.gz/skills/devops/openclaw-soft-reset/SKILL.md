---
name: openclaw-soft-reset
metadata:
  hermes:
    triggers: ["OpenClaw", "bot reset", "config reset", "soft reset"]

description: Clean OpenClaw config without losing bot tokens — restore from last-good backup after crash loops. Use when: OpenClaw reset, config restore, bot recovery, Telegram bot reset
category: devops
---

# OpenClaw Soft Reset — Clean Config Without Losing Tokens

## When to Use
OpenClaw has corrupted config, stuck sessions, or crash loops, but bot tokens and credentials are intact.

**Do NOT use this for token changes** — see `openclaw-token-update` skill instead.

## Steps

### 1. Stop the service
```bash
systemctl --user stop openclaw-gateway.service
```

### 2. Backup credentials (critical!)
```bash
# Tokens are stored in credentials/, NOT in openclaw.json
cat ~/.openclaw/credentials/env                    # API keys (OPENROUTER_API_KEY, etc.)
cat ~/.openclaw/credentials/telegram-*-allowFrom.json  # Telegram allowFrom list

# Also backup the service file (contains TELEGRAM_BOT_TOKEN)
cat /home/opc/.config/systemd/user/openclaw-gateway.service
```

### 3. Soft Reset (config only)
```bash
openclaw reset --scope config --non-interactive --yes
```
This deletes `~/.openclaw/openclaw.json` but **keeps**:
- `~/.openclaw/credentials/` (tokens)
- `~/.openclaw/extensions/` (plugins like kimi-claw)
- `~/.openclaw/workspace/` (agent workspace)
- Systemd service file

### 4. Restore from last-good backup
```bash
# OpenClaw auto-saves last-known-good config
cp ~/.openclaw/openclaw.json.last-good ~/.openclaw/openclaw.json
```

### 5. Restart service
```bash
systemctl --user daemon-reload
systemctl --user start openclaw-gateway.service
sleep 3
systemctl --user status openclaw-gateway.service --no-pager
```

### 6. Verify
```bash
# Verify bot token still works
curl -s "https://api.telegram.org/bot<TOKEN>/getMe"

# Check channels
openclaw status | grep -A 5 "Channels"
```

## Key Files
| File | Purpose | Reset preserved? |
|------|---------|-----------------|
| `~/.openclaw/openclaw.json` | Main config | ❌ Deleted |
| `~/.openclaw/openclaw.json.last-good` | Auto-backup | ✅ Kept |
| `~/.openclaw/openclaw.json.bak` | Manual backup | ✅ Kept |
| `~/.openclaw/credentials/env` | API keys (env vars) | ✅ Kept |
| `~/.openclaw/credentials/telegram-*-allowFrom.json` | Telegram auth | ✅ Kept |
| `~/.openclaw/extensions/` | Local plugins | ✅ Kept |
| `/home/opc/.config/systemd/user/openclaw-gateway.service` | Systemd unit | ✅ Kept |

## Troubleshooting

### Config won't restore from last-good
Check if `openclaw.json.last-good` exists and has valid content:
```bash
python3 -c "import json; json.load(open('~/.openclaw/openclaw.json.last-good'))"
```

### Telegram/Discord channels show error after reset
The credentials may have been cleared. Re-add tokens:
```bash
# Edit openclaw.json to add botToken
python3 -c "
import json
with open('~/.openclaw/openclaw.json') as f:
    d = json.load(f)
d['channels']['telegram']['botToken'] = 'YOUR_TOKEN'
d['channels']['discord']['accounts']['default']['token'] = 'YOUR_DISCORD_TOKEN'
with open('~/.openclaw/openclaw.json', 'w') as f:
    json.dump(d, f, indent=2)
"
systemctl --user restart openclaw-gateway.service
```

## Related Skills
- `openclaw-token-update` — Update Telegram/Discord bot tokens without reset
- `openclaw-telegram-token-debug` — Debug Telegram 409 Conflict errors

## Notes
- SIGTERM crashes on Oracle Cloud Free Tier are **infrastructure-level**, not fixable by reinstalling OpenClaw
- If `openclaw reset --scope config` is not enough, use `--scope config+creds+sessions` for deeper clean
- For full reinstall: `openclaw uninstall --all` then `npm install -g openclaw`
