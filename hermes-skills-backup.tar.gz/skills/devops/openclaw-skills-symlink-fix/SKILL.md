---
name: openclaw-skills-symlink-fix
description: Fix OpenClaw "Skipping escaped skill path outside its configured root" errors by replacing symlinks with actual directory copies
triggers:
  - openclaw skills not loading
  - "Skipping escaped skill path outside its configured root"
  - symlink-escape security block
---

# OpenClaw Skills Symlink Escape Fix

## Problem
OpenClaw logs show repeated warnings:
```
Skipping escaped skill path outside its configured root.
reason: symlink-escape
```

This means skills in `~/.openclaw/skills/` are symlinks pointing to directories outside the skills root, and OpenClaw's security policy blocks them.

## Root Cause
Skills are symlinked from `~/.openclaw/skills/` → `~/skills/` (e.g. `/home/opc/.openclaw/skills/config → /home/opc/skills/config`). The real path `/home/opc/skills/` is outside the allowed root `/home/opc/.openclaw/skills/`.

## Fix: Copy directories instead of symlinks
```bash
cd ~/.openclaw/skills

# Remove symlinks
for link in config gstack-openclaw-ceo-review gstack-openclaw-investigate \
            gstack-openclaw-office-hours gstack-openclaw-retro huashu-design \
            knowledge MeiGen_skills prism-thinking-refinery; do
  [ -L "$link" ] && rm "$link" && echo "Removed: $link"
done

# Copy actual directories
for skill in config gstack-openclaw-ceo-review gstack-openclaw-investigate \
            gstack-openclaw-office-hours gstack-openclaw-retro huashu-design \
            knowledge MeiGen_skills prism-thinking-refinery; do
  [ -d "/home/opc/skills/$skill" ] && cp -r "/home/opc/skills/$skill" "$skill" && echo "Copied: $skill"
done
```

## Verify
After restarting OpenClaw gateway, check logs for skill warnings:
```bash
grep -i "skill" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | tail -5
```
No "symlink-escape" warnings = fixed.

## Restart gateway
```bash
pkill -f 'openclaw.*gateway' && sleep 2
nohup /home/opc/.nvm/versions/node/v22.22.2/bin/node /home/opc/.nvm/versions/node/v22.22.2/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-oracle.log 2>&1 &
sleep 5 && curl -s http://localhost:18789/health
```
