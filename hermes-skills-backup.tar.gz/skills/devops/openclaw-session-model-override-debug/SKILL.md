---
name: openclaw-session-model-override-debug
description: Debug "Something went wrong" errors on OpenClaw Telegram bot when model override in sessions.json conflicts with configured default model
---

# OpenClaw Session-Based Model Override Debug

## Context
When an OpenClaw Telegram bot returns "Something went wrong while processing your request" even after changing the default model in `openclaw.json`, the issue is often **per-session model overrides** in `sessions.json` — NOT the default config.

## Symptoms
- Bot fails with "empty response" / "incomplete turn detected" errors
- Log shows a different model than configured (e.g., `moyu/qwen3.6-plus` instead of `moyu/qwen3.7-max`)
- New session (`/new`) does NOT fix it
- Direct API test of configured model works fine

## Root Cause
OpenClaw stores per-session model overrides in:
```
/root/.openclaw/agents/main/sessions/sessions.json
```

**TWO separate binding mechanisms exist:**

### Mechanism 1: Simple fields
```json
"modelProvider": "minimax",
"model": "MiniMax-M2.7"
```

### Mechanism 2: Override fields (takes precedence)
```json
"providerOverride": "moyu",
"modelOverride": "qwen3.6-plus",
"modelOverrideSource": "user"
```

The `providerOverride`/`modelOverride`/`modelOverrideSource` triplet overrides everything — config defaults, simple session bindings, and persists even after clearing simple `modelProvider`/`model`. This was the real culprit after previous fixes only cleared Mechanism 1.

## Debugging Steps

### 1. Find sessions with model overrides (BOTH mechanisms)
```bash
ssh -i ~/.ssh/oracle_to_bigvm root@47.79.224.55 \
  'python3 -c "
import json
with open("/root/.openclaw/agents/main/sessions/sessions.json") as f:
    d = json.load(f)
for k, v in d.items():
    bindings = {k2:v2 for k2,v2 in v.items() if k2 in ["model","modelProvider","providerOverride","modelOverride","modelOverrideSource"]}
    if bindings:
        print(k, json.dumps(bindings, indent=2))
"'
```

### 2. Find the failing session in logs
```bash
ssh ... 'grep "cdf9adef" /tmp/openclaw/openclaw-2026-*.log | tail -3'
# Extract session ID from error: "session=UUID-here"
```

### 3. Clear ALL session model overrides
```bash
ssh ... 'python3 /dev/stdin << '\''EOF'\''
import json
path = "/root/.openclaw/agents/main/sessions/sessions.json"
with open(path) as f:
    d = json.load(f)
for k in list(d.keys()):
    v = d[k]
    changed = False
    if v.get("modelProvider"):
        del v["modelProvider"]
        changed = True
    if v.get("model"):
        del v["model"]
        changed = True
    if changed:
        print("Cleared:", k)
with open(path, "w") as f:
    json.dump(d, f, indent=2)
print("Done.")
EOF'
```

### 4. Check ALL agent directories
```bash
ssh ... 'find /root/.openclaw/agents -name "sessions.json" -exec echo {} \; -exec python3 -c "import json,sys; d=json.load(open(sys.argv[1])); print(list(d.keys())[:3])" {} \;'
```
Other agents (e.g., `knowledge`) may have their own sessions.

### 5. Restart gateway
```bash
ssh ... 'pkill -9 -f "openclaw.*gateway"; sleep 2; nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-gateway.log 2>&1 &'
# Verify:
ssh ... 'curl -s http://localhost:18789/health'
```

### 6. Verify new log is fresh
Old log file is NOT cleared on restart — it appends. For clean debugging:
```bash
ssh ... 'rm /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log 2>/dev/null; pkill -9 -f "openclaw.*gateway"; sleep 2; nohup node ...'
```
Then check: `grep "agent model" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log`

## Key Files
| File | Purpose |
|------|---------|
| `~/.openclaw/openclaw.json` | Default model config |
| `~/.openclaw/agents/main/sessions/sessions.json` | Per-session overrides (BOTH mechanisms) |
| `/tmp/openclaw-gateway.log` | Gateway stdout/stderr |
| `/tmp/openclaw/openclaw-YYYY-MM-DD.log` | Application logs |

## Secondary Issue: moyu API empty response

Even after fixing session override, moyu API (qwen3.6-plus and qwen3.7-max) can return:
```
"moyu/qwen3.7-max ended with an incomplete terminal response"
"empty response detected" → retries exhausted
```

This is an API-side stability issue, not session binding. Direct curl tests show the API works fine — the problem occurs when OpenClaw sends the full system prompt.

**Workaround**: Use `qwen3.7-plus` (more stable than qwen3.7-max), or fall back to minimax.

## Model Config Location
In `openclaw.json`:
```json
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "moyu/qwen3.7-max"
      }
    }
  }
}
```