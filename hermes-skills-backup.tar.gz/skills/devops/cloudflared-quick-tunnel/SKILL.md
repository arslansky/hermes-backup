---
name: cloudflared-quick-tunnel
description: Expose a local HTTP server to the public internet via Cloudflare quick tunnel (no account needed). Use when you need a public URL for a local dev server, webhook testing, or sharing a local tool with external users.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [devops, networking, cloudflare, tunnel, ngrok-alternative]
    created: 2026-05-16
    last_updated: 2026-05-16
---

# Cloudflare Quick Tunnel — $0 Public URL for Local Server

## When to Use This Skill

- Local dev server needs to be accessible from outside the VM
- VM has no public IP or ports are blocked
- Need a temporary public URL for testing webhooks, sharing a prototype, etc.
- Free alternative to ngrok (no account required for quick tunnels)

## Installation (No Root Required)

```bash
# Download to /tmp first (avoids permission issues)
curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /tmp/cloudflared
chmod +x /tmp/cloudflared

# Move to /usr/bin (requires sudo), or use directly from /tmp
sudo mv /tmp/cloudflared /usr/bin/cloudflared

# Verify
cloudflared --version
```

**Common issue:** `/usr/local/bin` requires root, use `/tmp` or `/usr/bin` instead.

## Quick Setup (One Command)

```bash
# Expose local port 3030 publicly
/tmp/cloudflared tunnel --url http://localhost:3030
```

**Expected output:**
```
2026-05-16T15:40:51Z INF Requesting new quick Tunnel on trycloudflare.com...
2026-05-16T15:40:57Z INF |  https://random-words-random-words.trycloudflare.com |
```

**The URL at the bottom is your public URL.** Share this with anyone.

## Running as Background Process (Recommended)

The `watch_patterns` approach can miss the URL because cloudflared outputs it very early (before the watch fires reliably). Use `nohup` + log file instead:

```bash
# Start cloudflared with output redirected to a log file
nohup /tmp/cloudflared tunnel --url http://localhost:3030 --no-autoupdate > /tmp/cloudflared.log 2>&1 &

# Wait for the URL to appear (usually 5-10 seconds)
sleep 10
cat /tmp/cloudflared.log | grep trycloudflare.com
```

**Typical output when ready:**
```
2026-05-16T16:35:36Z INF Requesting new quick Tunnel on trycloudflare.com...
2026-05-16T16:35:41Z INF |  https://poetry-eddie-running-tickets.trycloudflare.com                                    |
```

**Important:** Cloudflare quick tunnels (without an account) are temporary — they expire after the tunnel process stops. For persistent tunnels, you need a Cloudflare account and a named tunnel.

## Finding the URL Again (if tunnel is already running)

If you have an existing cloudflared process running but didn't capture the URL:

```bash
# Find the process
ps aux | grep cloudflared | grep -v grep

# Check the log file
cat /tmp/cloudflared.log | grep trycloudflare.com

# Or check all cloudflared process output
ls -lt /tmp/*.log 2>/dev/null | head -3
```

## Killing and Restarting

```bash
# Kill all cloudflared processes
pkill -f "cloudflared tunnel"

# Verify killed
ps aux | grep cloudflared | grep -v grep | wc -l  # should be 0
```

## Protocol Selection (Mobile-Friendly)

By default cloudflared uses QUIC protocol, which may have compatibility issues with some mobile networks or Cloudflare edge nodes. For better mobile compatibility, force HTTP/2:

```bash
nohup cloudflared tunnel --url http://localhost:3030 --protocol http2 > /tmp/cloudflared.log 2>&1 &
```

**Note:** Even with `--protocol http2` set, cloudflared pre-checks may still report "QUIC" as primary — this is normal. The actual tunnel traffic uses HTTP/2.

## Common Issues

### 500 Internal Server Error when creating tunnel
Cloudflare's quick tunnel API occasionally returns errors. Just retry — it usually works on the 2nd attempt.

### URL works on desktop but not mobile
1. Try switching to HTTP/2 protocol (see above)
2. The random Cloudflare edge node assignment may be the issue — restart tunnel to get a different node
3. Some mobile ISPs block trycloudflare.com — try a different network (e.g., mobile data instead of WiFi)
4. For production/consistent access, use a named tunnel with a Cloudflare account

### "failed to sufficiently increase receive buffer size" warning
Harmless. The UDP receive buffer is smaller than recommended but rarely causes issues in practice.

### cloudflared process appears to hang, no URL in logs
Wait longer (up to 15 seconds). If still nothing, kill and retry.

| Use Case | Command |
|----------|---------|
| Webhook testing (GitHub, Stripe, etc.) | `/tmp/cloudflared tunnel --url http://localhost:3030` |
| Share local prototype with client | `/tmp/cloudflared tunnel --url http://localhost:3000` |
| Test Telegram bot webhook | `/tmp/cloudflared tunnel --url http://localhost:5000` |

## Important Notes

1. **No uptime guarantee** — Cloudflare warns that account-less quick tunnels have no SLA. Use for dev/testing only.
2. **Temporary** — URL changes every time you restart the tunnel. For a fixed URL, use a named tunnel with a Cloudflare account.
3. **Buffer size warning** — You may see this warning in logs: `failed to sufficiently increase receive buffer size`. It's usually harmless for development.
4. **No authentication** — Anyone with the URL can access your local server. Don't use for production!

## Verification

```bash
# Check if tunnel is accessible
curl -s --max-time 5 https://YOUR-URL.trycloudflare.com | head -3
```

## Cleanup

Just kill the background process:
```bash
process(action="kill", session_id="proc_xxxx")
```

Or find and kill manually:
```bash
pkill -f cloudflared
```
