---
name: parallel-phase-build-pattern
description: Split large projects into phases with parallel workers, verify with QA harness. Used for Supermemory Phase 1 (4 workers, 100% pass rate).
tags:
  - parallel-workers
  - phase-delivery
  - qa-harness
  - delegate_task
created: 2026-06-03
---

# Parallel Phase Build Pattern — Supermemory 案例

## 什麼係這個 Pattern？

將大型項目拆解成 phases，每個 phase 用多個並發 workers 同時建造不同組件，最後用 QA harness 驗收。

## 適用場景

- 14日項目拆解為 3 phases（Phase 1-3）
- 每 phase 有 3-4 個獨立 worker 任務
- 需要 QA 驗證交付品質

## Supermemory Phase 1 實戰

### 任務拆解

| Worker | 任務 | 交付 |
|--------|------|------|
| Worker A | Docker + Git + 項目結構 | 18 files, git init |
| Worker B | Chroma 向量DB + CRUD API | config, db, models, API |
| Worker C | LLM Fact Extraction | extractor.py + tests |
| Worker D | QA Harness | 37 checks, 100% pass |

### 關鍵教訓：max_concurrent_children 限制

**問題：** 第一次用 `delegate_task` 傳入 4 tasks，爆咗 `max_concurrent_children=3` 限制。

**解決：** 分兩批執行
```python
# 第一批：3 workers
delegate_task(tasks=[WorkerA, WorkerB, WorkerC])

# 等待完成後第二批：1 worker
delegate_task(tasks=[WorkerD])
```

### Phase 2 拆解（Day 4-8）

| Worker | 任務 |
|--------|------|
| Worker A | Profile 結構 + 自動更新 |
| Worker B | 版本控制 + 時序邏輯 |
| Worker C | 矛盾檢測 + 重複檢測 |
| Worker D | Profile 查詢優化（~50ms）|

## QA Harness 結構

### 檢查類別（37 checks）

| 類別 | Checks |
|------|--------|
| API Health | 1 (status + latency) |
| Project Structure | 16 (all files exist) |
| Import Verification | 6 (modules load) |
| API Endpoints | 4 (routing) |
| Service Layer | 3 (business logic) |
| Configuration | 1 (config loads) |
| Dependencies | 6 (installed packages) |

### Pass Criteria

- API health: 200 OK + < 300ms
- All files present
- All imports successful
- Endpoint routing verified

## 成功關鍵

1. **Worker 隔離** — 每個 worker 獨立檔案路徑，避免衝突
2. **Verification first** — 每個 worker 完成後 verify 再下一個
3. **Fallback 設計** — Chroma external dependency，需要 fallback 模式（如 JSON storage）
4. **分批並發** — 根據 max_concurrent_children 調整 batch size

## 常見問題

### Chroma server not running
- 解決：加 JSON fallback mode
- 或：`docker-compose up -d chroma`

### Import errors at verification
- 原因：系統 sqlite3 version vs chromadb requirements
- 解決：Lazy import inside functions

### TTK API model name
- 模型名唔係 `gpt-5.5`，要睇 `GET /v1/models` 返回值
- 正確名：`[按量计费]-gpt-5.5`

## 下一步

Phase 2 智能化階段：
- Profile 自動學習用戶偏好
- 記憶版本控制
- 矛盾檢測