---
name: openclaw-moyu-debug
description: Debug and configure OpenClaw moyu.info LLM provider — model availability testing and config update
triggers:
  - testing moyu models
  - moyu.info qwen3.6-max not working
  - openclaw moyu provider config
---

# OpenClaw moyu.info Provider Debug

## Key Findings

### Network Access
- **Big VM (Claw Cloud)**: Can reach moyu.info ✅
- **Oracle VM**: Cannot reach moyu.info (timeout) ❌
- When Oracle VM can't reach but Big VM can → test from Big VM via SSH

### Model Availability (tested 2026-06-08)
| Model | Status | Notes |
|-------|--------|-------|
| qwen3.6-max | ❌ model_not_found | Distributor has no channel |
| qwen3.6-max-preview | ❌ timeout | Unavailable |
| qwen3.6-plus | ✅ works | |
| qwen3.7-max | ✅ works | |
| qwen3.7-plus | ✅ works | |
| qwen3.5-flash | ✅ works | Fast, reasoning capable |
| qwen3.5-plus | ✅ works | |
| kimi-k2.6 | ✅ works | |
| claude-opus-4-7 | ✅ works | |
| deepseek-v4-pro | ❌ timeout | |
| MiniMax/MiniMax-M2.7 | ❌ timeout | |

### Discovery Method
```bash
# Get full model list from moyu.info
curl -s https://moyu.info/v1/models \
  -H "Authorization: Bearer $API_KEY" | python3 -c "
import sys,json
d=json.load(sys.stdin)
for m in d.get('data',[]):
    if 'openai' in m.get('supported_endpoint_types',[]):
        print(m['id'])
"
```

### Test a model quickly
```bash
curl -s --max-time 20 -X POST https://moyu.info/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -H "Authorization: Bearer $KEY" \
  -d '{"model":"MODEL_ID","messages":[{"role":"user","content":"Hi"}],"max_tokens":10}'
```

### Oracle VM moyu config update
```python
d['models']['providers']['moyu']['models'] = [
    {'id': 'qwen3.7-plus', 'name': 'Qwen3.7 Plus'},
    {'id': 'qwen3.7-max', 'name': 'Qwen3.7 Max'},
    {'id': 'kimi-k2.6', 'name': 'Kimi K2.6'},
    {'id': 'claude-opus-4-7', 'name': 'Claude Opus 4.7'},
    {'id': 'qwen3.6-plus', 'name': 'Qwen3.6 Plus'},
    {'id': 'qwen3.5-flash', 'name': 'Qwen3.5 Flash'},
    {'id': 'qwen3.6-max-preview', 'name': 'Qwen3.6 Max Preview'},
]
```

## Related: yunyi-codex Fake Model Names
- `yunyi.rdzhvip.com/codex` is unreachable from both VMs
- Model name `gpt-5.5` is fake — OpenAI has no such model
- Best to disable yunyi-codex or replace with working provider
