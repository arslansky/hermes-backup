---
name: openclaw-config-debug
description: Debug and fix OpenClaw config issues on Zeabur VM — image generation model, restart workflow, and common config paths
category: devops
tags: [openclaw, zeabur, telegram, config-debug]
created: 2026-07-01
---

# OpenClaw Config Debug & Fix

Debug and fix OpenClaw config issues on Zeabur VM.

## Connection
```bash
sshpass -p '@Q2%YTCbe%)mvSGQ42' ssh -o StrictHostKeyChecking=no ubuntu@43.156.247.30
```

Binary path: `/home/ubuntu/.npm-global/bin/openclaw` (NOT just `openclaw`)

## Quick Status Check
```bash
# Check if running
ps aux | grep openclaw | grep -v grep

# Recent log
tail -30 /tmp/openclaw/openclaw-2026-07-01.log
```

## Restart Workflow
1. Kill old process: `kill <PID>`
2. Wait: `sleep 2`
3. Start: `nohup /home/ubuntu/.npm-global/bin/openclaw gateway > /tmp/openclaw/openclaw-2026-07-01.log 2>&1 &`
4. Verify: `sleep 5 && ps aux | grep openclaw | grep -v grep`

## Common Config Issues

### Image Generation Model Fail
**Symptom:** `Unknown model: aethercode/gpt-image-2`

**Key locations (checked in order):**
1. `agents.defaults.imageModel.primary` ← MOST COMMON wrong location
2. `imageGeneration.primary`
3. `agents.defaults.imageGenerationModel.primary`

**Fix approach — write script locally then scp:**
1. Write Python fix script to `/tmp/fix_*.py` locally
2. `scp /tmp/fix_*.py ubuntu@43.156.247.30:/home/ubuntu/fix_*.py`
3. `python3 /home/ubuntu/fix_*.py`
4. Restart

**NOTE:** Don't use heredoc/cat <<EOF over SSH for Python — escaping breaks. Always write locally then scp.

## Config File Location
`/home/ubuntu/.openclaw/openclaw.json`

## Image Gen Config Paths (Python search pattern)
```python
import json
with open('/home/ubuntu/.openclaw/openclaw.json') as f:
    d = json.load(f)

def search(obj, path=''):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if 'aethercode' in str(k) or 'aethercode' in str(v):
                print(path + '.' + k, ':', str(v)[:200])
            search(v, path + '.' + k)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            search(item, path + f'[{i}]')

search(d)
```

## Systemd Service (CRITICAL — Service Conflict)

OpenClaw installs its own systemd service `openclaw-gateway.service`. Do NOT create a custom `openclaw.service` — having both enabled causes port conflict (exit code 78) and restart loops.

### Debugging Restart Loops

**Symptom:** Service keeps restarting with exit code 78

**Check for conflicting services:**
```bash
systemctl --user list-units --type=service --all | grep openclaw
```

**Two services may exist:**
- `openclaw.service` — custom service (created manually)
- `openclaw-gateway.service` — original service from OpenClaw install

**If both are enabled:**
```
systemctl --user stop openclaw
systemctl --user disable openclaw
systemctl --user start openclaw-gateway
```

**OpenClaw exit code 78 meaning:** OpenClaw exits with 78 when it detects another instance already holding the lock. This is intentional — it prevents restart loops. The `openclaw-gateway.service` has `RestartPreventExitStatus=78` to handle this correctly.

### Proper Restart Workflow (systemd)
```bash
# Stop both services
systemctl --user stop openclaw
systemctl --user stop openclaw-gateway

# Kill any orphaned processes
pkill -9 -f openclaw
sleep 2

# Verify port is free
ss -tlnp | grep 18789

# Start via original service
systemctl --user start openclaw-gateway

# Monitor
sleep 10 && systemctl --user status openclaw-gateway --no-pager
```

### Finding Orphaned Processes
```bash
# Check all openclaw processes
ps aux | grep openclaw | grep -v grep

# Check port binding
ss -tlnp | grep 18789

# Check cgroup to identify which systemd service owns a process
cat /proc/<PID>/cgroup
```

### Key Findings (Trial-and-Error)
- Exit code 78 = "another instance is healthy, don't restart" (OpenClaw's anti-loop mechanism)
- Original `openclaw-gateway.service` has `RestartPreventExitStatus=78` — correctly handles this
- Custom `openclaw.service` without this will cause restart loops
- Node process (PID) vs bash wrapper (PID in systemd) — always check cgroup to identify true parent
- Always use `openclaw-gateway.service`, NOT a custom systemd service

---

## Running Multiple OpenClaw Instances (Multi-Bot)

Use `OPENCLAW_CONFIG_DIR` env var to isolate instances — each instance gets its own config, state, and Telegram polling.

### Architecture
```
Port 443 → OpenClaw Instance 1 → Bot A (telegram channel 1)
Port 8080 (or any free port) → OpenClaw Instance 2 → Bot B (telegram channel 2)
```

### Setup Steps

**1. Create second config directory:**
```bash
mkdir -p /home/ubuntu/.openclaw2/state /home/ubuntu/.openclaw2/telegram
```

**2. Write second config** (`/home/ubuntu/.openclaw2/openclaw.json`):
```json
{
  "gateway": {
    "mode": "local",
    "auth": { "mode": "token", "token": "<same-or-different-token>" }
  },
  "channels": {
    "telegram": {
      "enabled": true,
      "botToken": "<DIFFERENT-BOT-TOKEN>"
    }
  },
  "agents": { "defaults": { "model": { "primary": "..." } } }
}
```

**3. Start second instance:**
```bash
OPENCLAW_CONFIG_DIR=/home/ubuntu/.openclaw2 \
  nohup /home/ubuntu/.npm-global/bin/openclaw gateway run --port 8080 \
  > /tmp/openclaw/openclaw2-2026-07-01.log 2>&1 &
```

**4. Verify:**
```bash
# Check env var is set
cat /proc/<PID>/environ | tr '\0' '\n' | grep OPENCLAW

# Check Telegram bot identity
curl -s "https://api.telegram.org/bot<TOKEN>/getMe" | python3 -c "import json,sys; print(json.load(sys.stdin)['result']['username'])"

# Check port binding
ss -tlnp | grep 8080
```

### Key Findings (Trial-and-Error)
- `OPENCLAW_CONFIG_DIR` env var is the ONLY reliable isolation mechanism — no `--config-dir` flag
- Both instances share the same log file `/tmp/openclaw/openclaw-YYYY-MM-DD.log` regardless of config dir
- Telegram spool goes to `$OPENCLAW_CONFIG_DIR/telegram/ingress-spool-default` — pre-create this dir
- **409 Conflict error** = two instances polling the same bot token. Each bot token can only have ONE active poller
- To check bot token validity: `curl -s "https://api.telegram.org/bot<TOKEN>/getMe"`
- First instance (Zeabur deploy) typically binds to port 443 via K3s/Traefik; subsequent instances need explicit `--port`
- Log shows `@arslanskybot` but uses new token = log is shared with other instance, read the PID-specific spool path to confirm
