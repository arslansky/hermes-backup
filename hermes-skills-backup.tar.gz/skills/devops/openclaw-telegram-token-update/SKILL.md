---
name: openclaw-telegram-token-update
description: "Update Telegram bot token in OpenClaw gateway — systemd or nohup node, fix defaultAccount, dmPolicy, requireMention"
category: devops
---

# OpenClaw Telegram Bot Token Update

## When to Use
Update the Telegram bot token in the OpenClaw gateway. Required when:
- Telegram shows 409 Conflict errors ("terminated by other getUpdates request")
- Changing to a different bot (e.g., @arslanskybot)
- Bot token is invalid (API returns 404 Not Found)

## Critical: TWO Files Must Match (Oracle VM / systemd only)
The Telegram bot token is stored in TWO places. Both MUST be updated to the SAME token:
1. `~/.config/systemd/user/openclaw-gateway.service` (Environment variable `TELEGRAM_BOT_TOKEN`)
2. `~/.openclaw/openclaw.json` (`channels.telegram.botToken`)

If they differ, Telegram API returns 409 Conflict because two bots try to use getUpdates on the same token.

## 409 Conflict Diagnosis (Do This First)
A "409 Conflict" error means TWO clients are trying to use getUpdates on the same bot token simultaneously. Before updating, check logs:
```bash
tail -n 200 /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | python3 -c "
import sys, json
for line in sys.stdin:
    try:
        d = json.loads(line.strip())
        msg = str(d)
        if '409' in msg or 'conflict' in msg.lower() or 'Conflict' in msg:
            print(d.get('time','')[:19], d.get('msg', msg[:300]))
    except: pass
"
```

If you see `terminated by other getUpdates request` — another instance is running with the old token. Find and kill it:
```bash
ps aux | grep openclaw
pkill -f openclaw
sleep 2
systemctl --user restart openclaw-gateway.service
```

## Steps (Oracle VM / systemd)

### 1. Update the systemd service file
```bash
sed -i 's/TELEGRAM_BOT_TOKEN=.*/TELEGRAM_BOT_TOKEN=NEW_TOKEN/' ~/.config/systemd/user/openclaw-gateway.service
```

### 2. Update openclaw.json (use Python, not patch)
The `patch` tool fails because the token in openclaw.json may be masked as `***`. Use Python instead:
```bash
python3 << 'EOF'
import json
f = '/home/opc/.openclaw/openclaw.json'
d = json.load(open(f))
d['channels']['telegram']['botToken'] = 'NEW_TOKEN'
json.dump(d, open(f, 'w'), indent=2)
EOF
```

### 3. Reload and restart the service
Two options — hot reload (preferred for token-only changes) or full restart:

**Hot reload (SIGTERM)** — faster, preserves session state:
```bash
# Find gateway PID
openclaw gateway status | grep "pid"
# e.g., "Runtime: running (pid 637650, state active, sub running, last exit 0, reason 0)"
# Send SIGTERM for graceful shutdown + auto-restart
kill -15 637650
# Or find PID automatically:
kill -15 $(pgrep -f "openclaw.*gateway")
```

**Full restart** (if hot reload doesn't work):
```bash
systemctl --user daemon-reload && systemctl --user restart openclaw-gateway.service
```

### 4. Verify — Hot Reload Success Indicators
After token update + SIGTERM, watch for these log messages (in `/tmp/openclaw/openclaw-YYYY-MM-DD.log`):
```
config change detected; evaluating reload (channels.telegram.botToken)
config hot reload applied (channels.telegram.botToken)
restarting telegram channel
[default] starting provider (@NEW_BOT_NAME)
```
If you see `[default] starting provider (@NEW_BOT_NAME)` with the correct bot username — token update succeeded.

**409 Conflict gone check**: After restart, there should be NO more 409 errors in the logs.

### 4. Verify
```bash
# Check for new 409 conflicts (should stop after update)
ngrep -c "conflict" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log

# Confirm new bot is recognized
grep "arslanskybot\|NEW_BOT_USERNAME" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log

# Confirm Telegram is working (no recent conflicts)
tail -30 /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -i "telegram\|conflict\|error"
```

## Big VM OpenClaw (Claw Cloud, no systemd)

On Big VM (Claw Cloud, Ubuntu 24.04), OpenClaw runs via nohup, NOT systemd:
- **Gateway command**: `nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /root/.openclaw/logs/gateway.log 2>&1 &`
- **Config location**: `/root/.openclaw/openclaw.json`
- **Health check**: `curl http://localhost:18789/health`

### Restart after config change
```bash
pkill -f 'openclaw.*gateway' && sleep 2 && nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /root/.openclaw/logs/gateway.log 2>&1 & sleep 5 && curl -s http://localhost:18789/health
```

## When Bot Token Gets Invalid (404 Not Found)
Symptom: `curl https://api.telegram.org/botTOKEN/getMe` returns 404
- Bot was deleted from Telegram OR token was revoked
- Solution: Get new token from @BotFather, update openclaw.json

## Critical Config Fixes After Token Update
When updating a Telegram bot token on Big VM, ALSO fix these in openclaw.json:
```python
import json
with open('/root/.openclaw/openclaw.json', 'r') as f:
    d = json.load(f)

# 1. Set defaultAccount to the account with the new token
d['channels']['telegram']['defaultAccount'] = 'main'

# 2. Disable any account with invalid token
d['channels']['telegram']['accounts']['knowledge']['enabled'] = False

# 3. Ensure all accounts using new token
d['channels']['telegram']['accounts']['main']['botToken'] = 'NEW_TOKEN'
d['channels']['telegram']['accounts']['default']['botToken'] = 'NEW_TOKEN'
d['channels']['telegram']['botToken'] = 'NEW_TOKEN'

# 4. For direct message without allowlist restriction:
d['channels']['telegram']['accounts']['main']['dmPolicy'] = 'open'

# 5. For groups without @mention requirement:
d['channels']['telegram']['groups']['*']['requireMention'] = False

with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(d, f, indent=2)
print('Config updated')
```

## Additional Issues Discovered

### Service keeps dying (SIGTERM received)
Symptom: Service becomes `inactive (dead)` unexpectedly without manual intervention.
```
[gateway] signal SIGTERM received
[gateway] received SIGTERM; shutting down
```
Fix: Restart with `systemctl --user start openclaw-gateway.service`

### Discord @Kimi Boy not responding (even with @mention)
Most common cause: **Message Content Intent not enabled** in Discord Developer Portal.
1. Go to https://discord.com/developers/applications
2. Select Kimi Boy application → Bot page
3. Under "Privileged Gateway Intents", enable **Message Content Intent** ✅
4. Restart the service after enabling

Also check: Bot must be added to the server and have proper permissions.

### Telegram group chat ID in allowFrom warning
```
Invalid allowFrom entry: "-1003897497805" - allowFrom/groupAllowFrom authorization expects numeric Telegram sender user IDs only.
```
This means Telegram groups need their negative chat ID added under `groupAllowFrom` (not `allowFrom`). The group still works for inbound messages, but the warning indicates group message sender IDs aren't being validated against allowFrom.

### kimi-claw plugin auto-loading warning
```
[plugins] plugins.allow is empty; discovered non-bundled plugins may auto-load: kimi-claw
```
To pin trust, set in openclaw.json:
```json
"plugins": { "allow": ["kimi-claw"] }
```

### Security warning: allowInsecureAuth=true
```
security warning: dangerous config flags enabled: gateway.controlUi.allowInsecureAuth=true
```
Consider disabling: set `gateway.controlUi.allowInsecureAuth` to `false` in openclaw.json.

## Troubleshooting

### Quick status check
```bash
systemctl --user status openclaw-gateway.service --no-pager
```

### Quick log review
```bash
tail -50 /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | python3 -c "
import sys, json
for line in sys.stdin:
    try:
        d = json.loads(line)
        msg = d.get('1', d.get('0', ''))
        time = d.get('time', '')[-14:]
        lvl = d.get('_meta', {}).get('logLevelName', '')
        print(f'[{lvl}] {time}: {msg[:200]}')
    except:
        pass
"
```

### 409 Conflict persists after update
- Verify both files have the SAME token: `grep TELEGRAM /path/to/service` and `python3 -c "import json; print(json.load(open('/path/to/openclaw.json'))['channels']['telegram']['botToken'])"`
- The gateway may need a full restart: `systemctl --user stop openclaw-gateway && sleep 2 && systemctl --user start openclaw-gateway`
- Check if another process is using the token: `ps aux | grep openclaw`

### Token appears masked in openclaw.json
- Token shows as `8302835438:***` — the `***` is cosmetic masking by the tool, the actual stored value is the full token
- Use Python to read/write the real value as shown above
