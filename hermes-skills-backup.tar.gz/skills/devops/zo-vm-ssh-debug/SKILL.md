---
name: zo-vm-ssh-debug
description: ZO Computer VM SSH connection debugging and key management
category: devops
---

# ZO VM SSH Debugging Skill

## Context
ZO Computer VM (ts8.zocomputer.io) uses non-standard port 10661. When SSH public key auth fails, systematic debugging is needed.

## Connection Details
- Host: `ts8.zocomputer.io`
- Port: `10661`
- User: `opc`
- Local SSH keys: `~/.ssh/id_ed25519_zo`, `~/.ssh/id_ed25519_zo_new`
- Local key fingerprint: `SHA256:XUS+nAUpzFODskAb/iYsCGXZbRvu25JIgWAvS81nygE`

## SSH Key Auth Debugging Sequence

### Step 1: Try each key explicitly
```bash
ssh -i ~/.ssh/id_ed25519_zo -o ConnectTimeout=10 -o StrictHostKeyChecking=no -p 10661 opc@ts8.zocomputer.io "echo OK"
ssh -i ~/.ssh/id_ed25519_zo_new -o ConnectTimeout=10 -o StrictHostKeyChecking=no -p 10661 opc@ts8.zocomputer.io "echo OK"
```

### Step 2: Verbose debug to see which key is offered vs accepted
```bash
ssh -i ~/.ssh/id_ed25519_zo -o ConnectTimeout=10 -o StrictHostKeyChecking=no -p 10661 opc@ts8.zocomputer.io -v 2>&1 | grep -E "Authentications that can continue|Server accepts|Offering public key"
```

### Step 3: Interpret results
- `"Authentications that can continue: publickey"` + NO `"Server accepts"` → server's `authorized_keys` doesn't have this public key
- If all keys show same pattern → VM was likely rebuilt or `authorized_keys` was reset
- Password auth also failing → only option is to add public key via ZO Console

## If VM Was Rebuilt / Keys Lost
Add this public key via ZO Console → VM Access → SSH Keys:
```
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIApLp+ulm4NqngL5oUfigDrEsTK5eRDbTQl7jGnYeQ96 openclaw-zo
```

## Related Skills
- `big-vm-ssh-troubleshooting` — Big VM (Zeabur) SSH troubleshooting
