---
name: openclaw-telegram-debug
description: Debug and fix OpenClaw Telegram bot conflicts and crashes
category: devops
---

# OpenClaw Telegram Debug Skill

## Trigger Conditions
- Telegram bot not responding to messages
- "Conflict: terminated by other getUpdates request" error
- Bot token conflicts between services
- OpenClaw Gateway crash or unexpected termination

## Critical Facts

### Telegram Single-Token Rule
**Telegram only allows ONE program to call `getUpdates` per bot token.**
If two programs use the same token, one gets "Conflict" error. This is the #1 cause of Telegram bot failures.

### Distinguishing Services
| Service | Path | Token |
|---------|------|-------|
| OpenClaw Gateway | `/root/.openclaw/openclaw.json` | Bot token in config |
| Old Python bot | `/opt/telegram-bot/` | Same token (conflict!) |

## Diagnostic Steps

### 1. Check Gateway Health
```bash
curl -s http://localhost:18789/health
```

### 2. Check Gateway Logs
```bash
tail -30 /tmp/openclaw-gateway.log
```

### 3. Check Telegram getUpdates Conflict
```bash
curl -s https://api.telegram.org/bot<TOKEN>/getUpdates
```
If returns `{"ok":false,"error_code":409,"description":"Conflict:..."}`, another service is using the token.

### 4. Find Conflicting Process
```bash
ps aux | grep -E 'telegram|openclaw|bot' | grep -v grep
```

### 5. Check for Old systemd Service
```bash
systemctl list-units | grep telegram
systemctl status telegram-bot.service 2>/dev/null
```

## Fix: Restart OpenClaw Gateway
```bash
nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-gateway.log 2>&1 &
sleep 3
curl -s http://localhost:18789/health
```

## Fix: Remove Conflicting Service
```bash
systemctl stop telegram-bot.service
systemctl disable telegram-bot.service
rm /etc/systemd/system/telegram-bot.service
rm -rf /opt/telegram-bot/
systemctl daemon-reload
```

## Pitfalls

### DO NOT use pkill on Node processes
`pkill node` kills OpenClaw Gateway. Use explicit process names or PIDs instead.

### Big VM ≠ Oracle VM
- Big VM (Claw Cloud): 47.79.224.55, root user, SSH key `~/.ssh/oracle_to_bigvm`
- Oracle VM: Different IP, opc user

### Gateway Port
OpenClaw Gateway runs on port **18789** (not 8000 or 8001).

## OpenClaw Skills Not Loading — symlink-escape Fix

**Symptom:** Logs show `Skipping escaped skill path outside its configured root` for every skill.

**Root Cause:** Skills in `.openclaw/skills/` are symlinks pointing to paths outside the `.openclaw/skills/` root directory (e.g., `/home/opc/skills/`). OpenClaw blocks these with security check.

**Fix:**
```bash
cd ~/.openclaw/skills
# Remove all symlinks
for link in config gstack-openclaw-ceo-review gstack-openclaw-investigate gstack-openclaw-office-hours gstack-openclaw-retro huashu-design knowledge MeiGen_skills prism-thinking-refinery; do
  [ -L "$link" ] && rm "$link" && echo "Removed: $link"
done
# Copy actual directories instead
for skill in config gstack-openclaw-ceo-review gstack-openclaw-investigate gstack-openclaw-office-hours gstack-openclaw-retro huashu-design knowledge MeiGen_skills prism-thinking-refinery; do
  [ -d "/home/opc/skills/$skill" ] && cp -r "/home/opc/skills/$skill" "~/.openclaw/skills/$skill" && echo "Copied: $skill"
done
# Restart gateway
pkill -f 'openclaw.*gateway' && sleep 2
nohup node /home/opc/.nvm/versions/node/v22.22.2/bin/node /home/opc/.nvm/versions/node/v22.22.2/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-oracle.log 2>&1 &
```

**Verification:** After restart, no more `symlink-escape` warnings in logs.

## moyu.info API — Network Asymmetry Discovery (2026-06-08)

| VM | moyu.info 連接 | API 可用模型 |
|----|---------------|-------------|
| Oracle VM | ❌ timeout | - |
| Big VM | ✅ 200 | qwen3.5-flash, qwen-plus, qwen3.6-plus, qwen3.7-plus, qwen3.7-max, kimi-k2.6, claude-opus-4-7 |

**Important findings:**
- API key is valid (`无效的令牌` only appears when using a model not in the key's group)
- `qwen3.6-max` returns `model_not_found` — model not available under this key's group
- Working models: `qwen3.5-flash` (fast), `qwen-plus`, `qwen3.7-plus`, `qwen3.7-max`, `kimi-k2.6`, `claude-opus-4-7`
- Network test: `curl -s --max-time 10 -o /dev/null -w '%{http_code}' https://moyu.info`

## Verification
After fix, send a message to the bot on Telegram. Check logs for:
```
[telegram] Inbound message telegram:XXX -> @Janzaibot (direct, X chars)
```

## Session Model Preference Override — Critical Discovery (2026-06-08)

**Symptom:** Changed model in `openclaw.json` defaults to `moyu/qwen3.7-max`, restarted gateway, but new sessions still fail with:
```
provider=moyu/qwen3.6-plus ended with an incomplete terminal response
```

**Root Cause:** OpenClaw stores per-session model preferences in `sessions.json`. These stored preferences **override** the global defaults. Even starting a `/new` session doesn't help — the session reuses the stored preference.

**Session key pattern:** `agent:main:telegram:direct:<chat_id>`

**Find stored model preferences:**
```bash
python3 /dev/stdin << 'EOF'
import json
d = json.load(open("/root/.openclaw/agents/main/sessions/sessions.json"))
s = d.get("agent:main:telegram:direct:<CHAT_ID>", {})
print("modelProvider:", s.get("modelProvider", "?"))  # e.g. "kimi"
print("model:", s.get("model", "?"))  # e.g. "k2p6"
EOF
```

**Fix: Clear stored model preferences from session:**
```bash
python3 /dev/stdin << 'EOF'
import json
with open("/root/.openclaw/agents/main/sessions/sessions.json") as f:
    d = json.load(f)
key = "agent:main:telegram:direct:<CHAT_ID>"  # e.g. 160408068
if key in d:
    for k in ["modelProvider", "model", "model"]:
        if k in d[key]:
            del d[key][k]
    with open("/root/.openclaw/agents/main/sessions/sessions.json", "w") as f:
        json.dump(d, f, indent=2)
    print("Cleared model preferences from session:", key)
EOF

# Then restart gateway
pkill -f 'openclaw.*gateway' && sleep 2
nohup node /root/.nvm/versions/node/v22.22.1/lib/node_modules/openclaw/dist/index.js gateway --port 18789 > /tmp/openclaw-gateway.log 2>&1 &
sleep 5
curl -s http://localhost:18789/health
```

**Key insight:** When changing the primary model, you must also clear any stored session preferences that override the defaults. The session's stored model takes precedence over `agents.defaults.model.primary`.
