---
name: telegram-media-delivery-fix
title: Fix MEDIA tag document delivery on Telegram gateway
description: Fix the bug where MEDIA path tags for .txt and other document-type files are silently ignored because extract_media and extract_local_files only recognize image/audio/video extensions.
trigger: MEDIA tag not delivering files; .txt files not sent; document delivery broken; user asks where the file is
---

# Telegram MEDIA Delivery Fix

## Problem

When you write `MEDIA:/path/to/file.txt` in your response, the gateway silently ignores it — the .txt file never gets sent.

## Root Cause

Two places in `gateway/platforms/base.py` have extension whitelists that don't include document-type files:

1. **`extract_media()`** (line ~1134) — regex pattern only matches:
   png, jpg, gif, webp, mp4, mov, avi, mkv, webm, ogg, opus, mp3, wav, m4a
   
2. **`extract_local_files()`** (line ~1168) — `_LOCAL_MEDIA_EXTS` tuple only has:
   .png, .jpg, .jpeg, .gif, .webp, .mp4, .mov, .avi, .mkv, .webm

Since .txt (and other document extensions) aren't in either list, the MEDIA tag is extracted but has zero matches, so nothing happens — silently.

## Fix

### Fix 1: extract_media regex

Add document extensions to the regex pattern at `gateway/platforms/base.py` ~line 1134. The key part to modify is the extension group:

```
(?:txt|png|jpe?g|gif|webp|mp4|mov|avi|mkv|webm|ogg|opus|mp3|wav|m4a|pdf|md|csv|json|yaml|yml|xml|log)
```

Use `patch` tool to find and replace this line.

### Fix 2: extract_local_files extensions tuple

Add to `_LOCAL_MEDIA_EXTS` at line ~1168:

```python
'.txt', '.pdf', '.md', '.csv', '.json', '.yaml', '.yml', '.xml', '.log',
```

### Verification

After the fix, the `send_document()` path in `_deliver_media_from_response()` handles .txt files via the fallback `else` branch (line ~4941 of gateway/run.py).

## Notes

- Affects ALL messaging platforms using the base adapter (Telegram, Discord, Slack, WhatsApp, Signal, etc.)
- No restart needed if running — the regex is compiled at import time, so just restart the gateway process
- `send_message()` with attached files uses a different path (adapter.send_document directly). This bug only affects the MEDIA: tag mechanism in free-form assistant responses.
