---
name: zo-vm-access
description: ZO VM SSH connection details and troubleshooting
category: system
created: 2026-07-01
---

# ZO VM Access Info

## Connection Details
- Host: ts8.zocomputer.io
- Port: 10661
- User: root (NOT opc!)
- Key: id_ed25519 (fingerprint: aEa0UIqvQnSBrfgftCMBCYW4mKmKQ+lOQBUGNLNoK20)

## SSH Config (~/.ssh/config)
```
Host zeabur
    HostName 43.156.247.30
    User ubuntu
    IdentityFile ~/.ssh/id_ed25519
    StrictHostKeyChecking no

Host zo
    HostName ts8.zocomputer.io
    Port 10661
    User root
    IdentityFile ~/.ssh/id_ed25519
    StrictHostKeyChecking no
```

## Quick Commands
- `ssh zeabur` → OpenClaw VM (43.156.247.30)
- `ssh zo` → ZO VM (ts8.zocomputer.io:10661)

## VM Specs
- 32GB RAM
- 512GB SSD (99% free)
- OS: Linux modal 4.19.0-gvisor

## SSH Troubleshooting

### Problem: "Permission denied (publickey)"
1. Check which user the VM actually has (some ZO VMs only have root, not opc)
2. Check which key fingerprint is registered in ZO Console SSH Keys
3. Match: Oracle VM's key fingerprint must match ZO VM's authorized_keys
4. Try different users: opc → root
5. Try both port 22 and custom port (10661)

### Key Fingerprint Mapping
- Oracle id_ed25519: aEa0UIqvQnSBrfgftCMBCYW4mKmKQ+lOQBUGNLNoK20 → WORKS with ZO VM
- Oracle id_ed25519_zo: XUS+nAUpzFODskAb/iYsCGXZbRvu25JIgWAvS81nygE → NOT registered in ZO VM
