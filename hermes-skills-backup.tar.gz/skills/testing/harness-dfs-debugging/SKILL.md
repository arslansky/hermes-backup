---
name: harness-dfs-debugging
description: Implement Depth-First Search debugging in Hermes Harness framework — explore error trees to root cause instead of collecting all errors equally.. Use when: DFS debugging, Harness debug, depth-first search debug
category: testing
---

# Harness DFS Debugging - Depth-First Error Analysis

Implement Depth-First Search debugging concept in Hermes Harness framework, replacing traditional BFS (breadth-first) error collection with causal tree exploration.

## Concept

OpenAI's debugging philosophy: "When something failed, the fix was almost never 'try harder.'" Instead of collecting all errors equally, DFS explores one error path to root cause before backtracking.

## Architecture

```
Error → ErrorDetector → DepthFirstDebugger → CapabilityAnalyzer → Root Cause
                                                              ↓
                                                   ReportGenerator (Tree)
```

### Core Files

| File | Purpose |
|------|---------|
| `core/capability-analyzer.js` | DFS capability tree explorer (NETWORK/RUNTIME/STATE/RENDER/AUTH dimensions) |
| `core/depth-first-debugger.js` | Orchestrates DFS diagnosis, builds diagnostic tree |
| `core/dfs-analyzer.js` | Reusable module for direct `require()` integration |
| `scripts/hermes-dfs.js` | CLI tool for quick error analysis |

### Capability Dimensions

```javascript
CAPABILITY_DIMENSIONS = {
  NETWORK: ['connectivity', 'authentication', 'rate_limit', 'proxy', 'ssl'],
  RUNTIME: ['memory', 'api_support', 'feature_flag', 'polyfill', 'permission'],
  STATE: ['store_initialization', 'state_sync', 'immutability', 'transaction'],
  RENDER: ['dom_element', 'css_support', 'animation', 'font', 'asset_loading'],
  AUTH: ['token_validity', 'scope', 'refresh', 'session', 'mfa']
}
```

## Usage

### CLI Tool

```bash
cd ~/.hermes/harness
node scripts/hermes-dfs.js "TypeError: Cannot read property of undefined"
node scripts/hermes-dfs.js "net::ERR_CONNECTION_REFUSED" NETWORK
node scripts/hermes-dfs.js "401 Unauthorized" AUTH

# Interactive mode
node scripts/hermes-dfs.js --interactive
```

### Code Integration

```javascript
const { analyze } = require('~/.hermes/harness/core/dfs-analyzer.js');

try {
  await someOperation();
} catch (error) {
  const result = await analyze(error, { context: 'myModule' });
  
  console.log('Root Cause:', result.rootCause?.label);
  console.log('Confidence:', Math.round(result.confidence * 100) + '%');
  console.log('Fix Actions:', result.fixActions);
}
```

### Full Harness Integration

```javascript
const DebugHarness = require('~/.hermes/harness/core/index.js');

const harness = new DebugHarness({ enableDeepAnalysis: true });
await harness.init();

// Errors captured automatically trigger DFS
await harness.navigate(url);

// Manual trigger
const result = await harness.analyzeDepthFirst(error, context);
```

## Pitfalls Encountered

1. **Test runner format mismatch** - Harness runner expects `{ execute, assert }` objects, not Mocha arrays. Create individual test files per case.

2. **Async diagnose()** - `DepthFirstDebugger.diagnose()` is async. The `dfs-analyzer.js` wrapper MUST await it.

3. **CLI color typos** - Use `this.colors.xxx`, not `thisColors.xxx`. Define all colors including `dim`.

4. **Fix actions format** - Some fix actions return objects, some return strings. Handle both:
   ```javascript
   const cmd = action.cmd || action.message || 
               (typeof action === 'string' ? action : JSON.stringify(action));
   ```

## Report Output Structure

```json
{
  "meta": { "analysisMode": "depth-first" },
  "errorTree": {
    "hasErrors": true,
    "rootCauses": [{
      "errorId": "err-001",
      "rootCause": { "type": "network_failure", "label": "connectivity" },
      "confidence": 0.85,
      "fixActions": [{ "cmd": "check_network", "type": "diagnostic" }]
    }]
  }
}
```

## Run Tests

```bash
cd ~/.hermes/harness
node scripts/run-tests.js --level integration
```
