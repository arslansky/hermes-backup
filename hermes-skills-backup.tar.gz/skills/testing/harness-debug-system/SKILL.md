---
name: harness-debug-system
description: Build a debug harness system for testing and monitoring AI agents - includes ErrorDetector, NetworkMonitor, StateInspector, ReportGenerator, and ArXiv research integration with cron automation.. Use when: Harness debug, test debug, monitoring, debug tool
version: 1.0.0
author: Hermes Agent
license: MIT
tags: [testing, harness, debug, monitoring, AI-agent, oracle-vm]
metadata:
  hermes:
    platform: oracle-cloud
    language: nodejs
    complexity: advanced
---

# Debug Harness System Setup Guide

A complete debug harness system for monitoring AI agents, testing workflows, and generating automated reports.

## 🌲 Depth-First Debugging (v2.0)

Harness v2.0 引入了 Depth-First Debugging 理念，源於 OpenAI 既調試哲學：

> "When something failed, the fix was almost never 'try harder.'"

**核心思想：** 當錯誤發生，唔再嘗試同一樣嘢（try harder），而係問「系統缺少什麼能力導致呢個錯誤？」然後深度探索呢個能力維度，一路行到底，遇到阻礙先返回。

### 對比：廣度優先 vs 深度優先

| 特性 | 廣度優先（v1.0） | 深度優先（v2.0） |
|------|-----------------|-----------------|
| 錯誤響應 | 收集所有錯誤 | 揀一條路徑，行到底 |
| 分析方式 | 分類 → 統計 | 探索 → 回溯 |
| 修復建議 | 等待人類判斷 | 自動生成行動 |
| 類比 | 「這個錯，那個也錯」 | 「這條路不通，因為缺少 X」 |

### 新架構

```
錯誤發生
    ↓
ErrorDetector (捕獲錯誤)
    ↓
DepthFirstDebugger.diagnose()  ← 協調器
    ↓
CapabilityAnalyzer.analyze()   ← DFS 探索能力維度樹
    ↓
找到根本原因 (Root Cause)
    ↓
ReportGenerator (樹狀報告)
    ↓
🛠️ Fix Actions + Alternative Paths
```

### 新增組件

**1. CapabilityAnalyzer** (`core/capability-analyzer.js`)
- 定義能力維度樹：NETWORK, RUNTIME, STATE, RENDER, AUTH
- DFS 遍歷能力維度，一路行到底
- 根據錯誤模式匹配維度，生成 Hypothesis
- 輸出：根本原因 + 修復建議 + 替代方案

**2. DepthFirstDebugger** (`core/depth-first-debugger.js`)
- 協調各組件進行深度優先診斷
- 構建診斷樹，執行 DFS 搜索
- 合併 CapabilityAnalyzer 結果
- 輸出：DiagnosticResult（包含 rootCause, fixActions, confidence）

### 使用 DFS 模式

```javascript
// 預設開啟 DFS 分析
const harness = new DebugHarness({ enableDeepAnalysis: true });

// 手動觸發 DFS 分析
const result = await harness.analyzeDepthFirst(error, context);

// 報告包含樹狀錯誤結構
report.errorTree.rootCauses[0].fixActions
```

### DFS 報告輸出示例

```json
{
  "errorTree": {
    "hasErrors": true,
    "rootCauses": [{
      "rootCause": {
        "type": "network_failure",
        "label": "authentication"
      },
      "confidence": 0.85,
      "fixActions": [
        { "cmd": "openclaw auth refresh", "type": "fix" },
        { "cmd": "openclaw auth verify", "type": "diagnostic" }
      ],
      "alternativePaths": [
        { "label": "rate_limit" }
      ]
    }]
  }
}
```

## Quick Start

```bash
cd /home/opc/.hermes/harness

# Run all tests
npm test

# Generate quick report
node scripts/generate-report.js

# ArXiv research
node scripts/research-arxiv.js "AI agent" --max=5

# Upload reports to GDrive
node scripts/upload-report.js
```

## System Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Debug Harness System                   │
├──────────────────────────────────────────────────────────┤
│  ┌─────────────┐    ┌─────────────┐    ┌────────────┐  │
│  │   Input     │ →  │   Error     │ →  │   Report   │  │
│  │  Collector  │    │  Detector   │    │  Generator │  │
│  └─────────────┘    └─────────────┘    └────────────┘  │
│         ↓                 ↓                  ↓          │
│  ┌─────────────────────────────────────────────────────┐│
│  │              Central Log Aggregator                  ││
│  └─────────────────────────────────────────────────────┘│
│         ↓                 ↓                  ↓          │
│  ┌─────────────┐    ┌─────────────┐    ┌────────────┐  │
│  │  Network    │    │   State     │    │ Screenshot │  │
│  │  Monitor    │    │  Inspector  │    │    Diff    │  │
│  └─────────────┘    └─────────────┘    └────────────┘  │
└──────────────────────────────────────────────────────────┘
```

## Core Components

### 1. ErrorDetector
Catches and classifies errors by severity and source. 集成 DFS 分析。

```javascript
const ErrorDetector = require('./core/error-detector');

// Severity levels
BLOCKING: '🔴 BLOCKING'  // Core functionality blocked
WARNING: '🟡 WARNING'     // Limited functionality
INFO: '⚪ INFO'          // Minor issues

// Error sources
NETWORK, RUNTIME, RENDER, STATE, AUTH

// DFS Integration (v2.0)
const detector = new ErrorDetector({ 
  logger, 
  enableDeepAnalysis: true 
});

// 每個錯誤自動包含 diagnosis
detector.on('error', (error) => {
  console.log(error.diagnosis); // { rootCause, fixActions, confidence }
});
```

### 2. CapabilityAnalyzer 🌲
Depth-First 能力維度探索器。

```javascript
const CapabilityAnalyzer = require('./core/capability-analyzer');

const analyzer = new CapabilityAnalyzer({ logger });

const result = analyzer.analyze(error, context);
// result.recommendation = { rootCause, confidence, actions, evidence }
```

### 3. DepthFirstDebugger 🌲
協調 DFS 診斷的核心引擎。

```javascript
const DepthFirstDebugger = require('./core/depth-first-debugger');

const debugger_ = new DepthFirstDebugger({ logger });
const result = await debugger_.diagnose(error, context);
// result.rootCause, result.fixActions, result.confidence
```

### 2. NetworkMonitor
Tracks API requests, response times, and failures.

```javascript
const NetworkMonitor = require('./core/network-monitor');

// Get failed requests
const failed = monitor.getFailedCalls();

// Get slow requests (>1s)
const slow = monitor.getSlowCalls(1000);
```

### 3. StateInspector
Inspects frontend state (Redux, Vuex, Zustand).

```javascript
const StateInspector = require('./core/state-inspector');

// Take state snapshot
const snapshot = await inspector.takeSnapshot('test-1');
```

### 4. ReportGenerator
Generates multi-format reports (JSON, MD, HTML).

```javascript
const ReportGenerator = require('./core/report-generator');

const report = await generator.generate({
  sessionId: 'test-123',
  testName: 'Research Flow',
  errors: errors,
  networkCalls: calls,
  state: snapshot
});
```

## Directory Structure

```
harness/
├── core/                       # Core modules
│   ├── index.js               # Main DebugHarness class
│   ├── error-detector.js     # Error catching/classification (DFS enabled)
│   ├── capability-analyzer.js # 🌲 DFS capability tree explorer (v2.0)
│   ├── depth-first-debugger.js # 🌲 Core DFS engine (v2.0)
│   ├── network-monitor.js    # API request tracking
│   ├── state-inspector.js    # Frontend state inspection
│   ├── input-collector.js    # User operation capture
│   └── report-generator.js   # Multi-format report generation (DFS tree output)
├── tests/
│   ├── integration/          # Integration tests
│   │   ├── research-agent.js # 8 research test cases
│   │   └── tc-dfs-*.js      # 🌲 DFS component tests
│   └── unit/
├── scripts/
│   ├── run-tests.js          # Test runner
│   ├── generate-report.js    # Quick report
│   ├── upload-report.js      # GDrive upload
│   ├── research-arxiv.js     # ArXiv API integration
│   ├── research-polymarket.js # Polymarket API integration
│   ├── research-blogwatcher.js # RSS feed monitoring
│   ├── research-semantic.js  # Semantic Scholar API
│   └── research-all.js       # Unified research report
├── reports/                  # Generated reports
├── state/                    # Blogwatcher state
├── config/
│   └── default.json
└── package.json
```

## ArXiv Research Integration

```javascript
const { ArXivResearch } = require('./scripts/research-arxiv');

const arxiv = new ArXivResearch();

// Search papers
const results = await arxiv.search('AI agent', {
  maxResults: 10,
  sortBy: 'submittedDate',
  sortOrder: 'descending'
});

// Get specific paper
const paper = await arxiv.getPaper('2505.05191v1');
```

**Rate Limit Handling:** ArXiv returns 429 when rate limited. Built-in retry with 5s delay (3 attempts).

---

## Polymarket Integration

```javascript
const { PolymarketResearch } = require('./scripts/research-polymarket');

const polymarket = new PolymarketResearch();

// Search markets by keyword
const markets = await polymarket.getMarkets('AI', { limit: 10 });

// Format market
markets.forEach((m, i) => {
  const prob = (parseFloat(m.outcomePrices.Yes) * 100).toFixed(1);
  console.log(`${i+1}. ${m.question} → ${prob}%`);
});
```

**Note:** If API unavailable, returns mock data for demonstration.

---

## Semantic Scholar Integration

```javascript
const { SemanticScholarResearch } = require('./scripts/research-semantic');

const ss = new SemanticScholarResearch();

// Search papers
const result = await ss.searchPapers('AI agent', {
  limit: 10,
  offset: 0
});

// Get paper details
const paper = await ss.getPaper('paper-id');

// Get recommended papers
const recs = await ss.getRecommendations('paper-id', 5);
```

**Rate Limit Handling:** Free tier is 100 requests/minute. Retry logic built-in (5s delay, 3 attempts).

---

## Blogwatcher RSS Integration

```javascript
const { Blogwatcher, DEFAULT_FEEDS } = require('./scripts/research-blogwatcher');

const watcher = new Blogwatcher();

// Add feeds
await watcher.addFeed('TechCrunch', 'https://techcrunch.com/feed/');
await watcher.addFeed('Hacker News', 'https://hnrss.org/frontpage');

// Fetch all feeds
const results = await watcher.fetchAll();

// Get new articles
const newArticles = await watcher.getNewArticles();

// Format article
watcher.formatArticle(article, index);
```

**Default Feeds:** TechCrunch, The Verge, ArXiv CS.AI, Hacker News

**RSS Parsing:** Handles both RSS 2.0 and Atom formats. CDATA extraction is robust against special HTML entities.

---

## Unified Research Report

Generate a single report combining all research sources:

```javascript
const { UnifiedResearchReport } = require('./scripts/research-all');

const report = new UnifiedResearchReport({
  topic: 'AI agent',
  maxResults: 10
});

await report.generate();
// Outputs: .md, .json, .html reports
```

Or via CLI:
```bash
node scripts/research-all.js "AI agent" --max=10
```

**Output includes:**
- ArXiv papers (sorted by date)
- Polymarket predictions (probability prices)
- Semantic Scholar papers (citation counts)
- Blog articles (from all monitored feeds)

---

## All Available Scripts

```bash
cd /home/opc/.hermes/harness

# Individual research tools
node scripts/research-arxiv.js "AI" --max=5
node scripts/research-polymarket.js "AI"
node scripts/research-blogwatcher.js
node scripts/research-semantic.js "ML" --max=5

# Unified report (ALL sources)
node scripts/research-all.js "AI agent" --max=10

# Debug harness
node scripts/generate-report.js
node scripts/upload-report.js
```

## Automation Setup

### Cron Jobs

```bash
# Daily research report (8 AM)
0 8 * * * /home/opc/daily_research.sh >> /home/opc/logs/research_cron.log 2>&1

# OpenClaw health check (every 6 hours)
0 */6 * * * /home/opc/scripts/check_openclaw.sh >> /home/opc/logs/openclaw_cron.log 2>&1
```

### daily_research.sh Template

```bash
#!/bin/bash
TOPICS=("AI agent architecture" "LLM reasoning" "autonomous AI")

for topic in "${TOPICS[@]}"; do
    node scripts/research-arxiv.js "$topic" --max=5
done

node scripts/upload-report.js
```

## Testing

### Run All Tests
```bash
cd /home/opc/.hermes/harness
npm test
```

### Run Specific Level
```bash
npm run test:unit
npm run test:integration
npm run test:e2e
```

### Run DFS Integration Tests
```bash
cd /home/opc/.hermes/harness
node scripts/run-tests.js --level integration
```

### DFS Integration Test Cases (v2.0)
- `tc-dfs-001-capability-analyzer.js` - CapabilityAnalyzer 網絡錯誤分析
- `tc-dfs-002-depth-first-debugger.js` - DepthFirstDebugger 診斷
- `tc-dfs-003-report-generator.js` - ReportGenerator DFS 樹狀報告

### Generate Quick Report
```bash
node scripts/generate-report.js
```

## Common Issues & Fixes

### Puppeteer createBrowserContext
```javascript
// Puppeteer v23+ API change
// Old (v22): createIncognitoBrowserContext()
// New (v23): createBrowserContext()
this.context = await this.browser.createBrowserContext();
```

### Window Registry Initialization
```javascript
// Always initialize __hermes_harness__ before use
await this.page.evaluate(() => {
  window.__hermes_harness__ = window.__hermes_harness__ || {};
});
```

### ArXiv API Rate Limit (429)
```javascript
// ArXiv limits requests to 1 per 3 seconds
// Built-in retry with 5s delay handles this automatically
const results = await arxiv.search('AI agent', { maxResults: 5 });
// If 429 received, retries 3 times with 5s wait between
```

### Semantic Scholar API Rate Limit
```javascript
// Free tier: 100 requests/minute
// Returns 429 when exceeded - retry logic built-in
const results = await ss.searchPapers('query', { limit: 10 });
```

### RSS/CDATA Parsing with Special Characters
```javascript
// Problem: Complex regex breaks on HTML entities like & < > " '
// Solution: Simple CDATA extraction before text fallback

_extract(item, tag) {
  // Try CDATA first
  const cdataRegex = new RegExp(`<${tag}[^>]*>\\s*<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>\\s*<\\/${tag}>`, 'i');
  const cdataMatch = item.match(cdataRegex);
  if (cdataMatch) return cdataMatch[1].trim();

  // Simple text fallback
  const textRegex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const textMatch = item.match(textRegex);
  return textMatch ? textMatch[1].trim() : '';
}
```

### Request Timeout on Slow APIs
```javascript
// All API clients use 30s timeout with retry
// Set timeout explicitly
req.setTimeout(30000, () => {
  req.destroy();
  reject(new Error('Request timeout'));
});
```

## Report Output

Reports are saved to:
```
/home/opc/.hermes/harness/reports/
├── report-{session}-{timestamp}.json
├── report-{session}-{timestamp}.md
└── report-{session}-{timestamp}.html
```

Auto-uploaded to:
```
gdrive:/OpenClaw_Backups/Harness-Reports/
```
