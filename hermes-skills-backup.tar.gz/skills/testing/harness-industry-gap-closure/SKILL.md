---
name: harness-industry-gap-closure
description: Complete gap analysis and implementation of 10 missing industry-standard features in the Hermes Harness system — Workflow Engine, MessageBus, Eval Framework, Telemetry, Sandbox, Model Router, Cost Manager, Tool Marketplace, Session Replay, Human Loop.. Use when: gap closure, Harness gap, missing features, industry standard
version: 1.0.0
author: Hermes Agent
tags: [harness, workflow, messagebus, eval, telemetry, sandbox, model-router, cost-management, marketplace, session-replay, human-loop]
---

# Harness Industry Gap Closure

Complete the Hermes Harness with 10 industry-standard features found in LangGraph, AutoGen, CrewAI, smolagents, and Codex CLI — but missing from the original Hermes system. Integration into Hermes Agent Python tools is handled by `tools/harness_tools.py` (23 tools registered in the "harness" toolset).

## Architecture Overview

```
hermes/harness/core/
├── workflow-engine.js     # YAML-defined graph pipeline (LangGraph-like)
├── message-bus.js         # Agent-to-Agent pub/sub protocol (AutoGen-like)
├── eval-framework.js      # Benchmark runner (GAIA/SWE-bench compatible)
├── telemetry.js           # Span tracing + OpenTelemetry format
├── sandbox.js             # 3-mode security isolation
├── model-router.js        # Multi-provider fallback + cost-aware routing
├── cost-manager.js        # TokenBucket rate limiter + cost tracking
├── tool-marketplace.js    # MCP tool registry + install/uninstall
├── session-replay.js      # Trajectory playback + ASCII timeline
└── human-loop.js          # Human-in-the-loop handoff management
```

All **233 tests** pass.

---

## 1. Workflow Engine (`workflow-engine.js`)

A graph-based pipeline engine inspired by LangGraph. Workflows are defined in YAML.

### Supported Node Types

| Type | Description |
|------|-------------|
| `LLM_CALL` | Execute an LLM prompt with template resolution |
| `TOOL_CALL` | Call a registered tool (web_search, etc.) |
| `CONDITION` | if/else branching with Python expression |
| `PARALLEL` | Fan-out N parallel executions with configurable concurrency |
| `MAP` | Sequential iteration over list items |
| `SUB_WORKFLOW` | Nested workflow execution |
| `HUMAN_INPUT` | Pause for human input (with default) |
| `CODE` | Inline JS code execution |
| `PASS` | No-op passthrough node |

### Edge Types

- **Direct**: `{ from: "A", to: "B" }`
- **Conditional**: `{ from: "A.if", to: "B" }`, `{ from: "A.else", to: "C" }`
- **Retry**: `retry: { max_attempts: 3, delay: 1, backoff: 2 }`
- **Fallback**: `{ from: "A.fallback", to: "B" }`

### YAML Format

```yaml
workflow:
  id: my-workflow
  version: 1
  config:
    max_iterations: 50
    timeout: 120
  nodes:
    step1:
      type: LLM_CALL
      prompt: "Analyze {query}"
      output_key: analysis
    check:
      type: CONDITION
      condition: "len(state.analysis) > 0"
  edges:
    - from: __start__
      to: step1
    - from: step1
      to: check
    - from: check.if
      to: __end__
```

### Usage

```javascript
const { WorkflowEngine } = require('./core/workflow-engine');
const engine = new WorkflowEngine();
await engine.load('workflows/my-workflow.yaml');

// Register custom tools
engine.registerTool('web_search', async (nodeDef, state) => {
  return { value: 'search results...', summary: 'searched' };
});

const result = await engine.run({ query: 'AI agents' });
console.log(result.status);    // 'completed'
console.log(result.state);     // final state
console.log(result.history);   // execution trace
```

### Visualization

```javascript
console.log(engine.visualize());
```

### Key Implementation Detail: YAML Parser

The `parseSimpleYaml()` function is a **zero-dependency YAML parser** built from scratch. It handles:

- Nested objects (`key:\n  subkey: value`)
- Arrays of scalars (`- item1\n- item2`)
- Arrays of objects (`- key1: val1\n  key2: val2`)
- Comments (`#`)
- Quoted strings, numbers, booleans, null

**Critical pitfall**: YAML array items like:
```yaml
edges:
  - from: __start__
    to: collect_topics
```
Must be parsed as a SINGLE object `{from: "__start__", to: "collect_topics"}`, not two separate array items. The parser uses a tree-building approach:

1. **Tokenize** lines into `{indent, key, value, isArrayMarker}`
2. **BuildTree**: recursive descent grouping children by indent level
3. **treeToObj**: convert tree nodes to plain JS objects, merging consecutive `- key: val` lines into single objects

### Tests: 32 tests, all pass

---

## 2. MessageBus (`message-bus.js`)

Agent-to-Agent communication protocol with pub/sub, direct messaging, and request/response.

### Components

| Class | Purpose |
|-------|---------|
| `MessageBus` | Central event bus — channels, subscriptions, delivery |
| `AgentBridge` | Agent-side convenience wrapper for send/receive/subscribe |
| `Message` | Typed message with ID, TTL, priority, correlation |
| `Channel` | Named channel with history buffer |
| `Subscription` | Handler with filter, oneShot, wildcard support |

### Message Types

- `CHAT` — conversational text
- `DATA` — structured data transfer
- `CONTROL` — pause/resume/cancel signals
- `ERROR` — error propagation
- `REQUEST/RESPONSE` — request-response pattern
- `BROADCAST` — broadcast to all subscribers
- `HEARTBEAT` — keep-alive

### Usage

```javascript
const { MessageBus, AgentBridge, Message } = require('./core/message-bus');
const bus = new MessageBus();

// Agent alpha
const alpha = new AgentBridge('alpha', bus);
await alpha.send('research', { query: 'AI agents' });

// Agent beta subscribes
const beta = new AgentBridge('beta', bus);
beta.on('research', (msg) => {
  console.log(`Got: ${msg.payload.query}`);
});

// Request/response
const response = await alpha.request('compute', { task: 'analyze' }, 5000);

// Direct message
await alpha.sendTo('beta', 'secret message');

// Wildcard subscription
beta.on('agent.*', (msg) => { /* matches agent.research, agent.coding */ });

// Channel history
const history = bus.getChannelHistory('research', 10);
```

### Features

- **Backpressure**: queue limit (default 1000), throws when full
- **TTL**: messages expire (default 30s)
- **Priority**: LOW(0), NORMAL(1), HIGH(2), CRITICAL(3)
- **One-shot subscriptions**: auto-remove after first delivery
- **Wildcard channels**: `agent.*` matches `agent.research`, `agent.coding`
- **Agent heartbeat**: track agent liveness
- **Channel auto-creation**: channels created on first publish

### Tests: 14 tests, all pass

---

## 3. Eval Framework (`eval-framework.js`)

Benchmark runner compatible with GAIA and SWE-bench evaluation patterns.

### Scoring Methods

| Scorer | Description |
|--------|-------------|
| `exact_match` | String equality |
| `contains` | Substring match |
| `regex` | Regex pattern match |
| `llm_judge` | AI-powered evaluation (async function) |
| `code_execution` | Run test code against output |

### Usage

```javascript
const { BenchmarkRunner, TestCase, EvalReport } = require('./core/eval-framework');

const runner = new BenchmarkRunner();
runner.addScorer('custom', async (actual, expected) => {
  return actual.includes(expected);
});

const tc = new TestCase({
  id: 'TC-001',
  name: 'Simple test',
  prompt: 'What is 2+2?',
  expected: '4',
  evaluator_type: 'exact_match'
});

const result = await runner.runSingle(tc, (prompt) => '4');
console.log(result.passed); // true

// Multi-test benchmark
const report = await runner.run({
  testCases: [tc1, tc2, tc3],
  agent: async (prompt) => { return await myAgent(prompt); }
});
console.log(`Pass rate: ${report.passRate}%`);
console.log(report.toMarkdown());
```

### Report Formats

- `toJSON()` — structured data
- `toMarkdown()` — human-readable MD
- Support for custom scorers via `addScorer()`

### Tests: 38 tests, all pass

---

## 4. Telemetry/Tracing (`telemetry.js`)

OpenTelemetry-compatible span tracing system with auto-flush to JSON files.

### Usage

```javascript
const { TelemetryTracer } = require('./core/telemetry');
const tracer = new TelemetryTracer({ service: 'hermes' });

const parent = tracer.startSpan('workflow', { type: 'llm_call' });
const child = tracer.startSpan('subtask', { parentId: parent.spanId });

// Do work...
tracer.addEvent(child.spanId, 'api_call', { url: '...' });

tracer.endSpan(child.spanId, { status: 'ok' });
tracer.endSpan(parent.spanId);

// Get trace tree
const trace = tracer.getTrace();
// trace = { traceId, spans: [{ spanId, parentId, name, type, startTime, endTime, duration, events, ...children }] }
```

### Features

- Parent-child span tree (tracing DAG)
- Auto-flush to `/home/opc/.hermes/harness/traces/trace-{traceId}.json`
- OpenTelemetry-compatible output format
- `getActiveSpans()`, `getSpan()`, `reset()`, `dispose()`
- Events with attributes

### Tests: 28 tests, all pass

---

## 5. Sandbox (`sandbox.js`)

Security isolation with 3 modes and command filtering.

### Security Modes

| Mode | Description |
|------|-------------|
| `strict` | Block ALL dangerous patterns (rm -rf /, sudo, chmod 777, eval, exec, fork, bomb, wget/curl to shell) |
| `standard` | Allow some, block critical ones (rm -rf /, sudo, fork bomb, chmod 777) |
| `permissive` | Allow everything except the most dangerous (rm -rf /, fork bomb) |

### Usage

```javascript
const { Sandbox, SandboxManager } = require('./core/sandbox');

// Single sandbox
const sandbox = new Sandbox({ mode: 'strict' });
const result = sandbox.exec('ls -la');
console.log(result.stdout);

// Will throw: blocked: rm -rf /
sandbox.exec('rm -rf /'); // Throws SandboxPermissionError

// Manager with resource limits
const manager = new SandboxManager({
  maxMemory: 512 * 1024 * 1024,  // 512MB
  maxCpuTime: 30,                 // 30 seconds
  maxFileSize: 10 * 1024 * 1024,  // 10MB
});
const sb = manager.createSandbox('worker-1', { mode: 'standard' });
manager.destroySandbox('worker-1');
```

### Tests: 22 tests, all pass

---

## 6. Model Router (`model-router.js`)

Multi-provider fallback with cost-aware selection and capability-based routing.

### Usage

```javascript
const { ModelRouter } = require('./core/model-router');

const router = new ModelRouter({
  providers: [
    { id: 'openrouter', name: 'OpenRouter', models: [
      { id: 'claude-opus-4', cost: 15, capabilities: ['coding', 'reasoning', 'vision'] },
      { id: 'gpt-4', cost: 10, capabilities: ['coding', 'reasoning'] },
    ]},
    { id: 'deepseek', name: 'DeepSeek', models: [
      { id: 'deepseek-v4-flash', cost: 0.5, capabilities: ['coding', 'reasoning'] },
    ]},
  ]
});

// Select by type
const best = router.select('coding');
// Returns: { provider: 'deepseek', model: 'deepseek-v4-flash' }

// Cheapest with specific capabilities  
const cheap = router.getCheapestWithCapabilities(['coding', 'vision']);
// Returns: { provider: 'openrouter', model: 'claude-opus-4' }

// With auto-fallback
const result = await router.withFallback('coding', async (provider, model) => {
  return await callLLM(provider, model, prompt);
});
// On failure, tries next cheapest model
```

### Features

- Cost-aware selection (cheapest first)
- Capability matching (coding, vision, reasoning, etc.)
- Auto-fallback chain on rate limits and errors
- Custom fallback order override
- Provider metadata (name, base_url, api_key)

### Tests: 16 tests, all pass

---

## 7. Cost Manager (`cost-manager.js`)

Rate limiting (TokenBucket) + cost tracking per model/session.

### Usage

```javascript
const { CostManager, TokenBucket } = require('./core/cost-manager');

// Rate limiter
const bucket = new TokenBucket({
  capacity: 100000,      // 100K tokens burst
  refillRate: 10000,     // 10K tokens/sec refill
});
bucket.consume(500);     // Consume 500 tokens (returns true)
bucket.getWaitTime(5000); // How long to wait before consuming 5K tokens

// Cost tracking
const cm = new CostManager();
cm.trackUsage('claude-opus-4', 1000, 500);
cm.trackUsage('deepseek-v4-flash', 2000, 1000);

console.log(cm.getCost('claude-opus-4')); // Cost for that model
console.log(cm.getTotalCost());           // Total cost all models
console.log(cm.getUsageReport());         // Full report
```

### Features

- Per-model token counting
- Configurable cost per 1K tokens
- Session-level aggregation
- TokenBucket rate limiter with refill
- Usage report with totals

### Tests: 24 tests, all pass

---

## 8. Tool Marketplace (`tool-marketplace.js`)

Registry of installable MCP tools with install/uninstall/search API.

### Built-in Tools

| Tool | Category | Description |
|------|----------|-------------|
| web_search | data | Search the web for current information |
| code_executor | code | Execute Python/JS code in sandbox |
| file_reader | data | Read and parse files |
| browser_automation | automation | Control headless browser |
| image_analyzer | vision | Analyze images with AI vision |
| data_visualizer | visualization | Create charts and graphs |
| api_client | data | Make HTTP API requests |
| database_query | data | Query SQL databases |

### Usage

```javascript
const { ToolMarketplace } = require('./core/tool-marketplace');
const marketplace = new ToolMarketplace({ toolsDir: '/tmp/tools-test' });

// List all available tools
const all = marketplace.list();
console.log(all.map(t => t.name));

// Search
const results = marketplace.search('web');

// Get info
const info = marketplace.getInfo('web_search');
// { name, description, version, author, category, params }

// Install (creates executable stub in toolsDir)
marketplace.install('web_search');
// Creates: /tmp/tools-test/web_search (executable Node.js script)

// Uninstall
marketplace.uninstall('web_search');
```

### Features

- Search by keyword
- Install creates executable stubs
- Uninstall removes stubs
- Version tracking per tool
- Param definitions for each tool

### Tests: 23 tests, all pass

---

## 9. Session Replay (`session-replay.js`)

Step-by-step playback of saved Hermes trajectories with ASCII timeline.

### Usage

```javascript
const { SessionReplayer } = require('./core/session-replay');
const replayer = new SessionReplayer();

// Load from trajectory file
replayer.load('/home/opc/.hermes/trajectories/session-123.json');

// Or create sample for testing
replayer.createSampleTrajectory();
console.log(replayer.getTimeline());
// [0] start → user: "Research AI agents"
// [1] → tool: web_search AI agents
// [2] → assistant: "Here are the results..."

// Step through
const step1 = replayer.step();  // Forward one step
const timeline = replayer.getTimeline();  // Current view
const currentState = replayer.getCurrentState();

// Navigation
replayer.stepBack();  // Go back
replayer.stepTo(3);   // Jump to step 3
```

### Features

- Load from JSON trajectory files
- Auto-detect trajectory format (hermes, openclaw)
- Forward/backward step-by-step playback
- ASCII timeline visualization
- State snapshot at each step

### Tests: 23 tests, all pass

---

## 10. Human Loop (`human-loop.js`)

Human-in-the-loop handoff management with 5 interaction types.

### Handoff Types

| Type | Purpose |
|------|---------|
| `APPROVAL` | Yes/no approval required |
| `DECISION` | Multiple choice decision |
| `INPUT` | Free-form text input |
| `REVIEW` | Content review/feedback |
| `CLARIFICATION` | Clarify ambiguous request |

### Usage

```javascript
const { HumanLoop } = require('./core/human-loop');
const loop = new HumanLoop({ defaultTimeout: 30000 });

// Request approval
const handoff1 = loop.requestInput('APPROVAL', 'Deploy to production?', {
  choices: ['Approve', 'Reject'],
  timeout: 60000
});

// Later, when human responds:
loop.approve(handoff1.id);  // or loop.reject(handoff1.id)

// Or wait for decision
const decision = await loop.waitFor(handoff1.id);

// Check pending
const pending = loop.getPendingHandoffs();
// [{ id, type, prompt, ... }]

// Review mode
const review = loop.requestInput('REVIEW', 'Review this code', { content: 'print("hello")' });
loop.review(review.id, 'LGTM', 'approved');

// Clarification
const clarify = loop.requestInput('CLARIFICATION', 'Which environment?', { choices: ['dev', 'staging', 'prod'] });
loop.clarify(clarify.id, 'staging');
```

### Features

- Promise-based `waitFor()` for async workflows
- Configurable timeout per handoff
- Default responses on timeout
- Pending handoff queue
- Type-specific response methods (approve, reject, review, clarify, input)

### Tests: 27 tests, all pass

---

## Known Pitfalls

### YAML Parser Recursion
The original YAML parser used recursion (`return parseSimpleYaml(content)`) when encountering array items with previously-parsed object keys. This caused stack overflow. Fixed with a two-pass tree-based approach.

### Integration Into Hermes (Python Bridge)
The 23 harness tools are registered via `tools/harness_tools.py` using the standard `registry.register()` pattern. The bridge works by building a Node.js code string and executing it via `subprocess.run(["node", "-e", code])`. Key gotchas:

1. **Python f-strings + Node.js code** — JavaScript uses `{` which clashes with Python f-string `{}`. Use `{{ }}` to escape. Example: `code = f"""...const x = {{ key: '{value}' }}..."""`
2. **Backslashes in f-strings** — `f"...{x.replace("'", "\\'")}..."` causes `SyntaxError: f-string expression part cannot include a backslash`. Extract to a variable first: `escaped = x.replace("'", "\\'"); f"...{escaped}..."`
3. **Tool schema must match** — Handlers registered via lambda: `handler=lambda args, fn=tool_fn, **kw: fn(**args)`. The `fn=tool_fn` default arg capture is critical — without it, the closure captures the last value of the loop variable.
4. **Toolset must be in config.yaml** — Adding `"harness"` to `_HERMES_CORE_TOOLS` in `toolsets.py` is insufficient for the gateway. Must also add `harness` to the `toolsets:` list in `config.yaml`.
5. **check_fn must be at module scope** — The harness toolset uses `_check_harness` which checks `CORE_DIR.exists()`. This is evaluated once at discovery time.
6. **23 tools are registered** — The full list in the "harness" toolset includes all workflow, bus, eval, telemetry, sandbox, model router, cost manager, marketplace, session replay, and human loop tools.

### Context: `_treeToObj` vs `treeToObj`
The YAML parser has both an inner `treeToObj` (local to `parseSimpleYaml`) and an outer `_treeToObj` (module-level). The inner one delegates to the outer one. When modifying these, ensure recursive calls within `_fillObjectFromTree` use `_treeToObj` not `treeToObj`.

### MessageBus Agent Registration
The `subscribe()` method requires agents to be registered first. Added auto-registration in `subscribe()` to handle this transparently. Without this, `getAgent()` returns null, breaking cleanup on `unregisterAgent()`.

### unregisterAgent Cleanup  
When unregistering an agent, `unregisterAgent()` iterates all channels to remove subscriptions. The `agent.subscriptions[]` array stores subscription IDs — ensure these match the channel's internal subscription map. Without auto-registration in `subscribe()`, this array is never populated.

### Node.js subprocess from Python  
Tools use `subprocess.run(["node", "-e", code])` with a 30s timeout. The Node.js code must print JSON to stdout. Any non-JSON output (debug logs, console.error) breaks parsing. Use `try/catch` + `JSON.stringify()` in Node.js, and always capture `stderr` separately in Python.

### YAML Workflow Files Location  
Workflow YAML files go in `/home/opc/.hermes/harness/workflows/`. The `workflow_run` tool looks for them by name (without .yaml extension) in that directory, or accepts a full `workflow_path`.

### Unregister Cleanup
When unregistering an agent, `unregisterAgent()` iterates all channels to remove subscriptions. The `agent.subscriptions[]` array stores subscription IDs — ensure these match the channel's internal subscription map.

### ModelRouter Fallback Chain
The fallback chain uses Promise-based error handling. Provider functions that throw errors trigger fallback to the next model in the chain. Ensure the function signature matches `async (provider, model) => result`.

### Workflow Engine Cycle Detection  
`_detectCycle()` uses DFS with `visited` + `inStack` tracking. If a cycle is detected, it reconstructs the path for debugging. The engine throws an error on cycle detection, preventing infinite loops.
