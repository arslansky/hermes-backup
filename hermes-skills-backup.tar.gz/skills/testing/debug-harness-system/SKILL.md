---
name: debug-harness-system
description: Build a complete debug/test harness system for monitoring and testing AI agents - captures operations, errors, network calls, state changes, generates reports. Use when: debug harness, testing harness, monitoring system, debug framework
category: testing
---

# Debug Harness System for AI Agents

Build a complete debug/test harness system for monitoring and testing AI agents running on a VM.

## Overview

A Debug Harness captures operations, errors, network calls, and state changes during agent execution, then generates multi-format reports (JSON/MD/HTML) with auto-upload to GDrive.

## Architecture

```
harness/
├── core/                    # Core modules
│   ├── index.js             # Main DebugHarness class
│   ├── input-collector.js   # Captures user operations
│   ├── error-detector.js    # Intercepts and classifies errors
│   ├── network-monitor.js   # Tracks API requests/responses
│   ├── state-inspector.js   # Inspects frontend state
│   └── report-generator.js  # Generates multi-format reports
├── tests/
│   └── integration/          # Integration test cases
├── scripts/
│   ├── run-tests.js         # Test runner
│   ├── generate-report.js    # Quick report generation
│   └── upload-report.js     # Upload to GDrive
└── reports/                 # Output directory
```

## Setup

```bash
mkdir -p /home/opc/.hermes/harness/{core,tests/{unit,integration,e2e},reports,scripts,config}
cd /home/opc/.hermes/harness
npm init -y
npm install puppeteer playwright chrome-remote-interface winston dotenv
```

## Key Implementation Details

### Puppeteer v23.x API Changes

If using Puppeteer 23+, the API changed:
```javascript
// OLD (v22 and below)
this.context = await this.browser.createIncognitoBrowserContext();

// NEW (v23+)
this.context = await this.browser.createBrowserContext();
```

### Window Registry Initialization

When using `page.evaluate()`, always initialize the harness registry first:
```javascript
await this.page.evaluate(() => {
  window.__hermes_harness__ = window.__hermes_harness__ || {};
  // Now safe to set properties
  window.__hermes_harness__.testData = {...};
});
```

### Error Classification

```javascript
const ErrorSeverity = {
  BLOCKING: '🔴 BLOCKING',  // Core functionality affected
  WARNING: '🟡 WARNING',      // Limited but usable
  INFO: '⚪ INFO'             // Minor issues
};

const ErrorSource = {
  NETWORK: '🌐 Network',    // API/network issues
  RUNTIME: '⚡ Runtime',    // JS execution errors
  RENDER: '🎨 Render',      // UI rendering issues
  STATE: '📦 State',        // State management
  AUTH: '🔐 Auth'          // Auth/permission issues
};
```

### Report Generation

Reports auto-generate in three formats:
- JSON: Machine-readable full data
- MD: Human-readable markdown summary
- HTML: Styled web report

Upload target: `gdrive:/OpenClaw_Backups/Harness-Reports/`

## Commands

```bash
cd /home/opc/.hermes/harness

# Run all tests
node scripts/run-tests.js

# Run specific level
node scripts/run-tests.js --level integration

# Generate quick report
node scripts/generate-report.js

# Upload to GDrive
node scripts/upload-report.js
```

## Test Case Structure

```javascript
const testCase = {
  id: 'TC-XXX-001',
  name: 'Test description',
  execute: async (harness) => {
    // Setup and actions
    await harness.page.goto('...');
  },
  assert: async (harness) => {
    // Verification
    const errors = harness.collectErrors();
    if (errors.length > 0) throw new Error('...');
  }
};
```

## Gap Analysis (2026-05-10)

This skill describes the *current* system. For a full comparison against industry standard frameworks (Codex CLI, LangGraph, AutoGen, CrewAI, smolagents) and prioritized improvement roadmap, see the **harness-gap-analysis** skill.

Key gaps identified:
- No graph-based workflow engine (most critical)
- No eval/benchmark framework
- No telemetry/tracing
- No agent-to-agent communication protocol

## Lessons Learned

1. Puppeteer 23.x changed `createIncognitoBrowserContext()` to `createBrowserContext()`
2. `page.evaluate()` runs in isolated context - must init `window.__hermes_harness__` first
3. NetworkMonitor needs CDP/Chrome DevTools for full request/response capture
4. StateInspector works best with Redux DevTools or Vue Devtools present

## Integration with Hermes

The harness can be invoked from Hermes:
```javascript
const DebugHarness = require('/home/opc/.hermes/harness/core/index');
const harness = new DebugHarness({ headless: true });
await harness.init();
await harness.launchBrowser();
// ... run tests ...
await harness.generateReport('test-name');
await harness.cleanup();
```

## Status

🟢 Production ready - tested on Oracle Linux 9.7 / Node.js v22.22.2
