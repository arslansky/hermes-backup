---
name: openclaw-token-debug
description: Debug OpenClaw Telegram 409 Conflict errors caused by token mismatch between systemd service and openclaw.json. Use when: OpenClaw debug, 409 error, token conflict, Telegram token
category: devops
---

# OpenClaw Token Mismatch Debugging

## Problem
Telegram bot showing 409 Conflict errors even after restarting the service. The gateway was reading a different bot token than expected.

## Root Cause
OpenClaw reads Telegram bot tokens from TWO locations:
1. Systemd service environment variable: `TELEGRAM_BOT_TOKEN` in `/home/opc/.config/systemd/user/openclaw-gateway.service`
2. `openclaw.json` channels.telegram.botToken

If these don't match, Telegram API gets conflicting requests from two different bots.

## Fix
Update BOTH locations to the same token:

```bash
# Update systemd service
sed -i 's/TELEGRAM_BOT_TOKEN=.*/TELEGRAM_BOT_TOKEN=NEW_TOKEN/' /home/opc/.config/systemd/user/openclaw-gateway.service

# Update openclaw.json (use python to avoid sed escaping issues)
python3 -c "
import json
d = json.load(open('/home/opc/.openclaw/openclaw.json'))
d['channels']['telegram']['botToken'] = 'NEW_TOKEN'
json.dump(d, open('/home/opc/.openclaw/openclaw.json', 'w'), indent=2)
"

# Reload and restart
systemctl --user daemon-reload && systemctl --user restart openclaw-gateway.service
```

## Verification
After restart, check logs for:
- `[default] starting provider (@botname)` - correct bot loaded
- No more `409 Conflict` errors  
- `telegram sendMessage ok` in logs

## SIGTERM / Service Restarts Diagnosis

If OpenClaw repeatedly dies with SIGTERM (visible as `signal SIGTERM received` in logs), this is often systemd's `Restart=always` kicking in — NOT an OpenClaw crash.

**Key diagnostic commands:**
```bash
# Check systemd service restart behavior
systemctl show --user openclaw-gateway.service | grep -i "restart\|startlimit\|oom"

# Check journalctl for service-level events
journalctl --user -u openclaw-gateway.service --no-pager

# Check how many SIGTERMs today
grep -c "SIGTERM received" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log

# Check service current state
systemctl --user status openclaw-gateway.service --no-pager

# Watchdog messages (bonjour/mDNS) are NORMAL — OpenClaw uses them for service discovery
# "watchdog detected non-announced service" = OpenClaw is trying to re-advertise itself
# "restarting advertiser" = normal behavior when service re-announces
# These are NOT errors and do NOT indicate a problem
```

**Watchdog logs you can ignore:**
- `watchdog detected non-announced service; attempting re-advertise`
- `restarting advertiser (service stuck in announcing for Xms)`
- `bonjour: advertised gateway fqdn=... state=announcing`

These are benign mDNS/Bonjour discovery messages.

## Telegram Group Configuration

For groups where the bot should auto-respond WITHOUT needing a mention:
```python
python3 -c "
import json
d = json.load(open('/home/opc/.openclaw/openclaw.json'))
d['channels']['telegram']['groups']['*']['requireMention'] = False
json.dump(d, open('/home/opc/.openclaw/openclaw.json', 'w'), indent=2)
print('Done')
"
systemctl --user restart openclaw-gateway.service
```

After reload, check logs for: `config hot reload applied (channels.telegram.groups.*.requireMention)`

## Discord Note
Discord channels require @mention to trigger responses (mention-gated). Use `@BotName` format in groups. Also ensure **Message Content Intent** is enabled in Discord Developer Portal → Bot → Privileged Gateway Intents.
