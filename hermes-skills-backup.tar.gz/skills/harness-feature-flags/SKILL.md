---
name: harness-feature-flags
description: Feature flag system for Harness research framework - controls data sources and experimental features without code changes. Use when: Harness, feature flag, A/B test, flag management
category: research
tags: [harness, feature-flags, research, openalex, arxiv, polymarket]
last_updated: 2026-05-10
---

# Harness Feature Flag System

## Overview
Feature flag system added to `/home/opc/.hermes/harness/` on 2026-05-10 for controlling research data sources and experimental features without code changes.

## Files
- `lib/feature-flags.js` — Core FeatureFlags class
- `scripts/feature-flags-cli.js` — CLI management tool
- `scripts/research-all.js` — Updated to check flags before fetching each source

## Usage
```bash
cd /home/opc/.hermes/harness

# List all flags
node scripts/feature-flags-cli.js list

# Enable/disable flags
node scripts/feature-flags-cli.js enable research-arxiv
node scripts/feature-flags-cli.js disable research-polymarket

# View flag status
node scripts/feature-flags-cli.js status research-openalex

# List active (enabled) flags
node scripts/feature-flags-cli.js active

# Emergency mode (disable all research)
node scripts/feature-flags-cli.js emergency

# Exit emergency
node scripts/feature-flags-cli.js exit-emergency

# Reset flag to default
node scripts/feature-flags-cli.js reset <flag-name>
```

## Default Flags
| Flag | Default | Purpose |
|------|---------|---------|
| research-openalex | ON | OpenAlex free paper API |
| research-arxiv | OFF | ArXiv (rate limited) |
| research-polymarket | ON | Prediction markets |
| research-blogwatcher | ON | Blog/RSS feeds |
| research-semantic | OFF | Needs API key |
| ai-summary | OFF | AI summarization |
| report-html | ON | HTML report format |
| report-json | ON | JSON output |
| report-gdrive-upload | ON | Auto GDrive upload |
| research-retry-arxiv | ON | Retry on rate limit |
| research-timeout-extended | OFF | Longer timeouts |
| experiment-new-report-format | OFF | New format test |
| kill-all-research | OFF | Emergency stop |
| kill-polymarket | OFF | Emergency Polymarket off |

## Adding New Flags
Edit `lib/feature-flags.js` DEFAULT_FLAGS object:
```javascript
'my-new-flag': {
  description: 'What this flag does',
  defaultValue: false,  // or true, or { percentage: 10 }
  type: 'release',       // release/ops/experiment/kill
  env: 'production'      // production/staging
}
```

## Storage
Flags are stored in `~/.hermes/harness/.feature-flags.json` (auto-created).

## Pattern
Feature flags control which research sources are fetched in `research-all.js`:
```javascript
if (flags.isEnabled('research-openalex')) {
  // fetch OpenAlex data
}
```
