---
name: github-hn-browser-scraping
title: GitHub Trending & HN Scraping with Browser Tools
description: Extract GitHub Trending repos and Hacker News stories using browser console JS, handling GitHub's bot-detection truncation and HN's dynamic rendering quirks.
category: data-science
---

# GitHub Trending + Hacker News Browser Scraping

## GitHub Trending — Preferred: REST API (no browser needed)

GitHub Trending page is JS-rendered and truncates to ~8 repos in bot-detected sessions.
Use the GitHub REST API instead — reliable, auth-free for public repos:

```python
import urllib.request, json

# Search AI/agent repos sorted by stars
url = "https://api.github.com/search/repositories?q=agent+framework+langchain+language:TypeScript+stars:>5000&sort=stars&order=desc&per_page=20"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/vnd.github.v3+json"})
with urllib.request.urlopen(req, timeout=15) as r:
    data = json.loads(r.read().decode("utf-8"))
for item in data['items']:
    print(f"{item['full_name']} | ⭐{item['stargazers_count']:,} | {item.get('description','')}")
```

Key query syntax:
- Spaces in `q=` → use `+` not `%20` (e.g., `q=agent+framework+langchain`)
- Language filter: `+language:TypeScript`
- Stars filter: `+stars:>5000`
- Multiple queries: chain with `+` (AND) or use separate API calls
```javascript
// GOOD — implicit return, no return keyword
[...document.querySelectorAll('tr.athing')].slice(0,30).map(...)

// BAD — return keyword causes SyntaxError
return [...document.querySelectorAll('tr.athing')].slice(0,30).map(...)
```

### RECOMMENDED: Use Algolia API (no browser needed)
HN provides a free, auth-free Algolia API that returns structured JSON. This is far more reliable than browser scraping:
```python
import json, urllib.request
url = "https://hn.algolia.com/api/v1/search?tags=front_page&hitsPerPage=30"
with urllib.request.urlopen(url) as r:
    data = json.loads(r.read())
for h in data.get("hits", [])[:30]:
    print(h["title"] + " | https://news.ycombinator.com/item?id=" + str(h["objectID"]))
```
No curl/python quoting headaches — just use `execute_code` with the Python stdlib directly.
Use this over browser methods for HN.

### Fallback: browser_console (implicit return, no return keyword)
HN page renders via JS — `browser_snapshot` shows truncated rows. Use `browser_console` with implicit-return JS:
```javascript
[...document.querySelectorAll('tr.athing')].slice(0,30).map((item,i) => { var titleEl = item.querySelector('.titleline a'); var subtext = item.nextElementSibling && item.nextElementSibling.querySelector ? item.nextElementSibling.querySelector('.subtext') : null; return {rank: i+1, title: titleEl ? titleEl.textContent : null, url: titleEl ? titleEl.href : null, points: subtext ? subtext.textContent : null}; })
```
- Note: `.nextElementSibling` in HN has `.subtext` with score, age, and comment link — time link text matches `/^\d+\s*(hour|day|minute)/i` so skip it to find actual comment count

### GitHub — use browser_snapshot for Trending, not console
- GitHub Trending page elements (`article`, `.Box-row`) are **not accessible via console JS** in stealth browsers — `document.querySelectorAll('.Box-row').length` returns 0, suggesting GitHub serves a truncated DOM to bot-detected sessions
- Workaround: use `browser_snapshot` (compact view) for GitHub Trending — it reliably shows the first 8–10 repos in the article list
- If repo count from snapshot is < 10, note "GitHub 今日只展示 X 個項目" in the report
- Do NOT spend time trying console JS selectors on GitHub — snapshot is the reliable fallback

## Hacker News Pitfalls

### HN — comment count is not in `.score` sibling
- HN `.subtext` row has three links: score (hidden), age, and comment count
- The `.score` span is visually hidden — actual points text is inside `.score` class span
- Age link text matches `/^\d+\s*(hour|day|minute)/i` — must filter it out
- Comment count link href starts with `item?id=` — filter by href pattern AND text not matching time pattern
- Simplest extraction: just grab full subtext into `points` field, parse later in Python

### Correct extraction JS
```javascript
const rows = document.querySelectorAll('tr.athing');
const stories = [];
rows.forEach((row) => {
  const titleEl  = row.querySelector('.titleline > a');
  const subtext  = row.nextElementSibling;
  const scoreEl  = subtext?.querySelector('.score');
  // comment link has href like "item?id=XXXXX" — must filter OUT time-ago links
  const allLinks = subtext?.querySelectorAll('a');
  let comments = '';
  allLinks?.forEach(a => {
    const href = a.getAttribute('href') || '';
    if (href.startsWith('item?id=') && !href.includes('from=')) {
      // skip the "X hours ago" link — its text matches /^\d+ hour/
      const txt = a.textContent.trim();
      if (/^\d+\s*(hour|day|minute)/i.test(txt)) return; // time link — skip
      comments = txt;
    }
  });
  stories.push({
    title:    titleEl ? titleEl.textContent.trim() : '',
    url:      titleEl ? titleEl.href : '',
    score:    scoreEl ? scoreEl.textContent.trim() : '',
    comments: comments
  });
});
JSON.stringify(stories.slice(0, 20));
```

### HN ranking changes between renders
- Scores and comment counts shift as votes come in
- Extract all fields from a single consistent page load; do not re-navigate

## GitHub Trending Workflow (REST API)
1. Use `execute_code` with Python stdlib + `urllib.request` hitting GitHub REST API (see above)
2. For AI/agent tooling scan: use multiple queries (`agent+framework`, `AI+CLI+agent`, `llm+inference+serving`, etc.)
3. Filter by topics/description keywords post-fetch: `['agent', 'llm', 'ai', 'claude', 'tool', 'cli', 'coding', 'model']`
4. Sort by stars and present top 20

## Hacker News — Preferred: Firebase API (no browser needed)

HN provides a free, auth-free Firebase API:
```python
import urllib.request, json

url = "https://hacker-news.firebaseio.com/v0/topstories.json"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
with urllib.request.urlopen(req, timeout=15) as r:
    top_ids = json.loads(r.read().decode("utf-8"))

for story_id in top_ids[:30]:
    url2 = f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json"
    req2 = urllib.request.Request(url2, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req2, timeout=10) as r2:
        item = json.loads(r2.read().decode("utf-8"))
    print(f"[#{story_id}] ({item.get('score',0)}pts) {item.get('title','')}")
    if item.get('url'):
        print(f"  → {item['url']}")
```
No auth, no curl quoting issues. Returns top 30 stories with full metadata (title, URL, score, comments). Python stdlib only.

## Hacker News Workflow (Browser Fallback)
1. `browser_navigate` → `https://news.ycombinator.com/`
2. Use `browser_console` with implicit-return JS (no `return` keyword) to extract top 30:
```javascript
[...document.querySelectorAll('tr.athing')].slice(0,30).map((item,i) => { var titleEl = item.querySelector('.titleline a'); var subtext = item.nextElementSibling && item.nextElementSibling.querySelector ? item.nextElementSibling.querySelector('.subtext') : null; return {rank: i+1, title: titleEl ? titleEl.textContent : null, url: titleEl ? titleEl.href : null, points: subtext ? subtext.textContent : null}; })
```
3. HN ranking shifts between page loads — extract all fields from single consistent load

## Workflow
1. `browser_navigate` → GitHub Trending (collect repos via snapshot)
2. `execute_code` → HN Algolia API (collect stories via Python stdlib)
3. Compile report with note if GitHub repo count < 10
