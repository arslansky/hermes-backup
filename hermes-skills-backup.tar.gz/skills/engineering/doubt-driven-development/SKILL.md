---
name: doubt-driven-development
description: "Subjects every non-trivial decision to fresh-context adversarial review before it stands. Use when correctness matters more than speed, stakes are high, or working in unfamiliar code. Trigger: architectural decision, production deploy, data migration, public API change."
category: engineering
---

# Doubt-Driven Development

## Overview

A confident answer is not a correct one. Long sessions accumulate context that quietly turns assumptions into "facts." Doubt-driven development materializes a fresh-context reviewer — biased to **disprove**, not approve — before any non-trivial output stands.

This is NOT `/review`. `/review` is a verdict on a finished artifact. This is an in-flight posture: non-trivial decisions get cross-examined while course-correction is still cheap.

## When to Use

A decision is **non-trivial** when at least one of these is true:

- It introduces or modifies branching logic
- It crosses a module or service boundary
- It asserts a property the type system cannot verify (thread safety, idempotence, ordering, invariants)
- Its correctness depends on context the future reader cannot see
- Its blast radius is irreversible (production deploy, data migration, public API change)

**When NOT to use:** Mechanical operations, clear user instructions, one-line changes, pure tooling.

## The Process

```
Doubt cycle:
- [ ] Step 1: CLAIM — wrote the claim + why-it-matters
- [ ] Step 2: EXTRACT — isolated artifact + contract, stripped reasoning
- [ ] Step 3: DOUBT — invoked fresh-context reviewer with adversarial prompt
- [ ] Step 4: RECONCILE — classified every finding against the artifact text
- [ ] Step 5: STOP — met stop condition (trivial findings, 3 cycles, or user override)
```

### Step 1: CLAIM — Surface what stands

Name the decision in two or three lines:

```
CLAIM: "The new caching layer is thread-safe under the
        read-heavy workload described in the spec."
WHY THIS MATTERS: a race here corrupts user data and is
                  hard to detect in QA.
```

If you can't write the claim that compactly, you have a vibe, not a decision.

### Step 2: EXTRACT — Smallest reviewable unit

Strip your reasoning. Hand over:
- **Artifact**: the diff, function, or proposal — not the whole file
- **Contract**: the constraints the artifact must satisfy

The unit must be small enough that a reviewer can hold it in mind in one read.

### Step 3: DOUBT — Invoke the fresh-context reviewer

The reviewer's prompt **must be adversarial**:

```
Adversarial review. Find what is wrong with this artifact.
Assume the author is overconfident. Look for:
- Unstated assumptions
- Edge cases not handled
- Hidden coupling or shared state
- Ways the contract could be violated
- Existing conventions this might break
- Failure modes under unexpected input

Do NOT validate. Do NOT summarize. Find issues, or state
explicitly that you cannot find any after thorough examination.

ARTIFACT: <paste artifact>
CONTRACT: <paste contract>
```

**Pass ARTIFACT + CONTRACT only. Do NOT pass the CLAIM.** Handing the reviewer your conclusion biases it toward agreement.

#### Cross-Model Escalation (Interactive Sessions)

After single-model review, ask the user:

> "Single-model review complete. Want a cross-model second opinion? Options: Gemini CLI, Codex CLI, manual external review, or skip."

This is **mandatory** in every interactive doubt cycle. The user decides whether the cost is worth it.

If the user picks a CLI:
1. Check the tool is in PATH (`which gemini`, `which codex`)
2. Test it works before passing the full prompt
3. Write the full prompt to a file, pipe via stdin (artifact may contain shell metacharacters)
4. Take output into Step 4

**Non-interactive contexts**: Cross-model is skipped and the skip must be announced.

### Step 4: RECONCILE — Fold findings back

For each finding, classify in this **precedence order**:

1. **Contract misread** — CONTRACT was unclear. Fix the contract first.
2. **Valid + actionable** — real issue requiring a change. Change it, re-loop.
3. **Valid trade-off** — issue is real but cost of fixing exceeds cost of accepting. Document it.
4. **Noise** — reviewer flagged something that's correct under context the reviewer didn't have.

A fresh reviewer can be wrong because it lacks context. Don't defer just because it's "fresh."

### Step 5: STOP — Bounded loop

Stop when:
- Next iteration returns only trivial or already-considered findings, **or**
- 3 cycles completed (escalate to user), **or**
- User explicitly says "ship it"

If after 3 cycles the reviewer still surfaces substantive issues, surface this to the user.

## Interaction with Other Skills

- **`/review`**: complementary. `/review` is post-hoc PR verdict; doubt-driven is in-flight per-decision.
- **`test-driven-development`**: TDD's RED step is doubt made concrete — a failing test is a disproof attempt.
- **`debugging-and-error-recovery`**: when the reviewer surfaces a real failure mode, drop into the debugging skill.

## Common Rationalizations

| Rationalization | Reality |
|---|---|
| "I'm confident, skip the doubt step" | Confidence correlates poorly with correctness on novel problems. |
| "Spawning a reviewer is expensive" | Debugging a wrong commit in production is more expensive. |
| "I'll do doubt at the end with /review" | By PR time it's too late. Doubt-driven catches wrong directions early. |
| "If I doubt every step I'll never ship" | The skill applies to non-trivial decisions, not every keystroke. |
| "Cross-model is always better" | Cross-model catches blind spots, but adds cost/tool fragility. Offer it every cycle — user decides. |

## Red Flags

- Spawning a fresh-context reviewer for a one-line rename or formatting change
- Treating reviewer output as authoritative without re-reading the artifact text
- Looping >3 cycles without escalating to the user
- Prompting the reviewer with "is this good?" instead of "find issues"
- Skipping doubt under time pressure on a high-stakes decision
- **Doubt theater**: across 2+ cycles, zero findings classified as actionable. You are validating, not doubting. Stop and escalate.
- **Silently skipping cross-model** in an interactive doubt cycle. Skipping is fine; silent skipping is not.
- Passing the CLAIM to the reviewer (biases toward agreement)

## Verification

After applying doubt-driven development:
- [ ] Every non-trivial decision was named explicitly as a CLAIM before standing
- [ ] At least one fresh-context review per non-trivial artifact
- [ ] Reviewer received ARTIFACT + CONTRACT — NOT the CLAIM
- [ ] Reviewer's prompt was adversarial ("find issues"), not validating ("is it good")
- [ ] Findings were classified against the artifact text using the precedence order
- [ ] A stop condition was met (trivial findings, 3 cycles, or user override)
- [ ] In interactive mode, cross-model was explicitly offered to the user
- [ ] In non-interactive mode, cross-model was skipped and the skip was announced
