---
name: programming-patterns
description: 記錄每日學到既編程邏輯、架構技巧、設計模式
---

# Programming Patterns Learned

記錄每日學到既編程邏輯、架構技巧、設計模式。

## Indirection（間接引用）

**核心概念：** 用 pointer/reference 代替直接操作，改嘢時只改目標，唔使郁引用。

**用法：**
```
Memory（pointer） → Skill（實際邏輯）
```

**例子：**
- Memory: 「通知有事 →揾 notification-skill」
- 换通知方式 → 只改 skill，memory 唔使郁

**好處：**
- Loose Coupling（鬆耦合）— 兩邊獨立
- Late Binding（延遲綁定）— 運行時先決定用邊個
- 集中改規則 — 邏輯寫喺 skill，唔使四周搵

**擴展用法：**
```
memory: 「翻譯 → translation-skill」
memory: 「爬蟲 → crawler-skill」
memory: 「長文 → pdf-generator-skill」
memory: 「錯誤 → error-handler-skill」
```

---
*最後更新：2026-06-06*