---
name: security-and-hardening
description: "Hardens code against vulnerabilities. Use when handling user input, authentication, data storage, or external integrations. Trigger: building auth, accepting user input, storing sensitive data, integrating external APIs."
category: engineering
---

# Security and Hardening

## Overview

Security-first development. Treat every external input as hostile, every secret as sacred, and every authorization check as mandatory. Security isn't a phase — it's a constraint on every line of code.

## Process: Threat Model First

Before hardening, spend five minutes thinking like an attacker:

1. **Map the trust boundaries** — Where does untrusted data cross into your system? HTTP requests, form fields, file uploads, webhooks, third-party APIs, **LLM output**.
2. **Name the assets** — What's worth stealing or breaking? Credentials, PII, payment data, admin actions.
3. **Run STRIDE over each boundary:**

| Threat | Ask | Typical Mitigation |
|--------|-----|-------------------|
| **S**poofing | Can someone impersonate a user/service? | Authentication, signature verification |
| **T**ampering | Can data be altered in transit or at rest? | Integrity checks, parameterized queries, HTTPS |
| **R**epudiation | Can an action be denied later? | Audit logging |
| **I**nformation disclosure | Can data leak? | Encryption, field allowlists, generic errors |
| **D**enial of service | Can it be overwhelmed? | Rate limiting, input size caps, timeouts |
| **E**levation of privilege | Can a user gain rights they shouldn't? | Authorization checks, least privilege |

4. **Write abuse cases next to use cases** — "how would I misuse this?" Then make that your first test.

## Three-Tier Boundary System

### Always Do (No Exceptions)

- **Validate all external input** at the system boundary
- **Parameterize all database queries** — never concatenate user input into SQL
- **Encode output** to prevent XSS (use framework auto-escaping)
- **Use HTTPS** for all external communication
- **Hash passwords** with bcrypt/scrypt/argon2 (never store plaintext)
- **Set security headers** (CSP, HSTS, X-Frame-Options, X-Content-Type-Options)
- **Use httpOnly, secure, sameSite cookies** for sessions
- **Run `npm audit`** before every release

### Ask First (Requires Human Approval)

- Adding new authentication flows
- Storing new categories of sensitive data
- Adding new external service integrations
- Modifying CORS configuration
- Adding file upload handlers
- Granting elevated permissions

### Never Do

- **Never commit secrets** to version control
- **Never log sensitive data** (passwords, tokens, full credit card numbers)
- **Never trust client-side validation** as a security boundary
- **Never use `eval()` or `innerHTML`** with user-provided data
- **Never store sessions in localStorage** for auth tokens
- **Never expose stack traces** to users

## OWASP Top 10 Prevention Patterns

### Injection (SQL, NoSQL, OS Command)

```typescript
// BAD: SQL injection via string concatenation
const query = `SELECT * FROM users WHERE id = '${userId}'`;

// GOOD: Parameterized query
const user = await db.query('SELECT * FROM users WHERE id = $1', [userId]);
```

### Broken Authentication

```typescript
// Password hashing
import { hash, compare } from 'bcrypt';
const SALT_ROUNDS = 12;
const hashedPassword = await hash(plaintext, SALT_ROUNDS);

// Session management
app.use(session({
  secret: process.env.SESSION_SECRET,
  cookie: {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000,
  },
}));
```

### Cross-Site Scripting (XSS)

```typescript
// BAD: Rendering user input as HTML
element.innerHTML = userInput;

// GOOD: Use framework auto-escaping
return <div>{userInput}</div>;

// If you MUST render HTML, sanitize first
import DOMPurify from 'dompurify';
const clean = DOMPurify.sanitize(userInput);
```

### Broken Access Control

```typescript
app.patch('/api/tasks/:id', authenticate, async (req, res) => {
  const task = await taskService.findById(req.params.id);
  if (task.ownerId !== req.user.id) {
    return res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Not authorized' } });
  }
  const updated = await taskService.update(req.params.id, req.body);
  return res.json(updated);
});
```

### Server-Side Request Forgery (SSRF)

```typescript
// BAD: fetch whatever the user gives you
await fetch(req.body.webhookUrl);

// GOOD: allowlist scheme + host, reject private IPs
import { lookup } from 'node:dns/promises';
import ipaddr from 'ipaddr.js';

const ALLOWED_HOSTS = new Set(['hooks.example.com']);

async function assertSafeUrl(raw: string): Promise<URL> {
  const url = new URL(raw);
  if (url.protocol !== 'https:') throw new Error('https only');
  if (!ALLOWED_HOSTS.has(url.hostname)) throw new Error('host not allowed');
  const addrs = await lookup(url.hostname, { all: true });
  if (addrs.some((a) => ipaddr.parse(a.address).range() !== 'unicast')) {
    throw new Error('private/reserved IP');
  }
  return url;
}
```

## Input Validation Patterns

```typescript
import { z } from 'zod';

const CreateTaskSchema = z.object({
  title: z.string().min(1).max(200).trim(),
  description: z.string().max(2000).optional(),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
});

app.post('/api/tasks', async (req, res) => {
  const result = CreateTaskSchema.safeParse(req.body);
  if (!result.success) {
    return res.status(422).json({ error: { code: 'VALIDATION_ERROR', details: result.error.flatten() } });
  }
  const task = await taskService.create(result.data);
  return res.status(201).json(task);
});
```

## Securing AI / LLM Features

- **Treat all model output as untrusted input** — never pass LLM output into `eval`, SQL, `innerHTML`, or file paths
- **Assume prompts can be hijacked** — untrusted text in context can carry instructions
- **Keep secrets out of prompts** — anything in context can be echoed back
- **Constrain tool permissions** — scope to minimum, require confirmation for destructive actions
- **Bound consumption** — cap tokens, rate, loop depth

```typescript
// BAD: trusting model output as a command or markup
const sql = await llm.generate(`Write SQL for: ${userQuestion}`);
await db.query(sql);

// GOOD: model output is data — parse defensively, validate, encode
let intent;
try {
  intent = CommandSchema.parse(JSON.parse(await llm.replyJson(userMessage)));
} catch {
  throw new ValidationError('unexpected model output');
}
await runAllowlistedAction(intent.action, intent.params);
```

## Security Review Checklist

```
### Authentication
- [ ] Passwords hashed with bcrypt/scrypt/argon2 (salt rounds >= 12)
- [ ] Session tokens are httpOnly, secure, sameSite
- [ ] Login has rate limiting
- [ ] Password reset tokens expire

### Authorization
- [ ] Every endpoint checks user permissions
- [ ] Users can only access their own resources
- [ ] Admin actions require admin role verification

### Input
- [ ] All user input validated at the boundary
- [ ] SQL queries are parameterized
- [ ] HTML output is encoded/escaped
- [ ] Server-side URL fetches are allowlisted (no SSRF)

### Data
- [ ] No secrets in code or version control
- [ ] Sensitive fields excluded from API responses

### Infrastructure
- [ ] Security headers configured
- [ ] CORS restricted to known origins
- [ ] Dependencies audited for vulnerabilities
- [ ] Error messages don't expose internals

### AI / LLM
- [ ] Model output treated as untrusted
- [ ] Tool permissions scoped; destructive actions require confirmation
```

## Common Rationalizations

| Rationalization | Reality |
|---|---|
| "This is internal, security doesn't matter" | Internal tools get compromised. Attackers target the weakest link. |
| "We'll add security later" | Security retrofitting is 10x harder than building it in. |
| "No one would exploit this" | Automated scanners will find it. |
| "The framework handles security" | Frameworks provide tools, not guarantees. |
| "It's just LLM output, it's only text" | That text can be a SQL statement, script tag, or shell command. |

## Red Flags

- User input passed directly to database queries, shell commands, or HTML rendering
- Secrets in source code or commit history
- API endpoints without authentication or authorization checks
- Missing CORS or wildcard (`*`) origins
- No rate limiting on authentication endpoints
- Stack traces exposed to users
- LLM/model output passed into query, DOM, shell, or `eval`
