---
name: ttk-pioneer-api-research
description: TTK API and Pioneer.ai model discovery, working models, and billinggotchas
tags: [api, ttK, pioneer, AI]
created: 2026-05-27
updated: 2026-05-27
---

# TTK API & Pioneer.ai Research Notes

## TTK API (api.ttk.homes)

**Authentication:** Bearer token in `Authorization` header.

**Endpoints (2026-06-18 confirmed working):**
- `https://api.ttk.homes/v1` ✅ primary
- `https://ai.ttk.homes/v1` ✅
- `https://api-cn.ttk.homes:3333/v1` ✅

**Key:** `sk-dJfy8GWR5czhLBHtvSmkrsWy0ZV6js5fT5e2WuAoJsQfRNAd`

**Models — MUST use Chinese prefix!**
- GPT: `[按量计费]-gpt-5.5`
- DeepSeek: `[按量计费]deepseek-v4-flash`, `[按量计费]deepseek-v4-pro`
- Claude: `【按量计费】claude-opus-4.6`, `【按量计费】claude-opus-4.7`, `【按量计费】claude-opus-4.8`
- Gemini: `[按次计费]gemini-3.1-pro-low-反重力`, `gemini-3-flash-preview-联网搜索`
- MiniMax: `MiniMax-M2.7`, `MiniMax-M3`
- 圖片: `gpt-image-2`

❌ Wrong: `model: "opus-4.6"` → model_not_found
✅ Correct: `model: "【按量计费】claude-opus-4.6"`

**List models:**
```bash
curl -s "https://api.ttk.homes/v1/models" -H "Authorization: Bearer YOUR_KEY"
```

## Pioneer.ai

**Endpoint:** `https://api.pioneer.ai/v1` (OpenAI-compatible)

**Key issue:** Even free tier returns:
```json
{"detail":{"code":"card_verification_required","message":"To get started with Pioneer, please add a payment method..."}}
```

**Solution:** Must add payment method at `https://agent.pioneer.ai/billing` (requires email/password login, API key alone insufficient).

**Payment method:** Stripe — used solely for identity verification, no charge for free tier. HK card能不能用 unknown, requires user to test themselves.

**Available models (after card verification):**
- GLiNER series: `fastino/gliner2-base-v1`, `fastino/gliner2-large-v1`, `fastino/gliner2-multi-v1`, etc.
- Decoders: `Qwen/Qwen3-32B`, `Qwen/Qwen3-8B`, `deepseek/DeepSeek-V3`, etc.

**Rate limits:** OpenAI compat endpoint 200/min, GLiNER 15,000/min.

## Zo Computer (zocomputer.com)

- Cloud computer service, Free plan $0
- Payment method needed for premium models (verification only)
- Not same company as Pioneer.ai