---
name: big-vm-fable-integration
description: Extract valuable components from Big VM frameworks (like fable_reasoner.py) and integrate into Oracle VM Hermes
triggers:
  - found framework on Big VM
  - integrate from remote VM
  - fable_reasoner
---

# Big VM → Oracle VM Framework Integration Pattern

When you find a useful framework on Big VM and want to port it to Oracle VM/Hermes.

## Discovery

Big VM SSH: `ssh -i ~/.ssh/oracle_to_bigvm root@47.79.224.55`

Key files found on Big VM:
- `/root/.openclaw/workspace/fable_reasoner.py` — Fable reasoning framework v3.2
- `/root/.openclaw/workspace/fable_memory.db` — SQLite memory
- `/root/.openclaw/workspace/fable_cache.db` — SQLite cache

## Integration Approach: Pick & Choose, Don't Wholesale Copy

The Fable framework had these components:
- `AdaptiveReasoner` — full reasoning orchestration (SKIP)
- `call_model()` — API wrapper (SKIP — Hermes already has minimax_client)
- `MemoryStore` — SQLite user preference persistence (KEEP)
- `AnswerEvaluator` — answer quality scoring (KEEP)
- `analyze_complexity()` — question complexity classification (KEEP)
- `assess_domain_expertise()` — domain expertise assessment (KEEP)
- Multi-path reasoning with ThreadPoolExecutor (SKIP — adds latency)

**Decision criteria:**
- stdlib-only components → KEEP (no new deps)
- API wrapper duplicates → SKIP
- Complex orchestration → SKIP or simplify
- Parallel execution patterns → SKIP unless truly needed

## Files Created

- `/home/opc/.hermes/scripts/fable_components.py` — core extracted library
- `/home/opc/.hermes/skills/fable-light/SKILL.md` — skill wrapper
- `/home/opc/.hermes/fable_memory.db` — SQLite DB (auto-created)

## Testing Pattern

Found a bug during testing: `save_session()` parameter is `duration` not `duration_ms`. Always test the actual function signature, don't assume from the original source.

```python
import sys
sys.path.insert(0, '/home/opc/.hermes/scripts')
from fable_components import analyze_complexity, assess_domain_expertise, AnswerEvaluator, MemoryStore

# Test complexity analysis
q = "你的問題"
c = analyze_complexity(q)
e = assess_domain_expertise(q)

# Test quality evaluation
evaluator = AnswerEvaluator()
result = evaluator.evaluate(answer="...", question=q, complexity=c)

# Test memory store (param is: duration=int, NOT duration_ms)
store = MemoryStore()
store.save_session(user_id="default", question=q, complexity=c.name, 
                   expertise=e.name, model="minimax", tokens=500, 
                   cost=0.001, duration=1000, quality=result['total_score'])
```

## Known Issues

1. Complexity analysis may misclassify Cantonese questions (e.g. "點樣學好 Python" classified as TRIVIAL) — the Cantonese keyword "點樣" should map to MODERATE but currently maps to TRIVIAL due to the greeting detection firing first. Edge case to watch.
