---
name: github-project-deep-dive
title: GitHub 項目深入研究報告
description: 對任何 GitHub 開源項目進行深度研究 — clone repo、分析源碼架構、理解核心原理，最後產出結構化中文報告. Use when: GitHub project research, code analysis, open source study
trigger: 用戶要求「深入研究某個 GitHub 項目」、「分析 repo」、「睇 code 架構」
metadata:
  hermes:
    triggers: ["GitHub project", "code analysis", "repo research", "open source study", "deep dive"]
    red_flags:
      - "I can just read the README and summarize"
      - "The repo is too big to analyze fully"
      - "I know this project already"
    iron_laws:
      - "ALWAYS CLONE THE REPO — DO NOT RELY ON README ALONE"
      - "ALWAYS ANALYZE SOURCE CODE STRUCTURE BEFORE WRITING REPORT"
---

# GitHub 項目深入研究

## Overview
當用戶要求深入研究某個 GitHub 項目時，進行系統性分析：
1. 主頁資料收集（README、stars、license、commit 活躍度）
2. Clone repo 並分析完整源碼架構
3. 理解核心原理（C++/Python/JS 各層面）
4. 產出結構化中文報告（txt 檔 deliver）

## Steps

### 1. GitHub Trending 頁面爬取（重要！）

**問題：** GitHub trending 頁面係 JS-heavy，requests/BeautifulSoup 會fail（返回空殼HTML）。
**解決方案：** 用 Playwright 瀏覽器 automation。

```python
from playwright.sync_api import sync_playwright

def fetch_github_trending(lang="python", since="daily"):
    url = f"https://github.com/trending/{lang}?since={since}"
    # 用 browser_console() 執行 JS 提取数据
    # GitHub trending 用 class="Box-row" 包住每個 repo
    # 提取：repo名、⭐數、描述、今天⭐增量、語言
```

關鍵步驟：
1. `browser_navigate(url)` → 加载页面
2. `browser_console(expression="...")` → 執行 JS 提取所有 repo 數據

JS 提取模式：
```javascript
Array.from(document.querySelectorAll('article.Box-row')).map(item => ({
  name: item.querySelector('h2 a').innerText,
  stars: item.querySelector('.d-inline-block.float-sm-right').innerText.trim(),
  desc: item.querySelector('p').innerText.trim(),
  lang: item.querySelector('[itemprop="programmingLanguage"]')?.innerText || 'N/A',
  stars_today: item.querySelector('.muted-link')?.innerText || ''
}))
```

**為何不用 requests：** GitHub 用 dynamic content rendering，HTML 係 client-side JS 生成，requests 只攞到骨架 HTML。

---

### 2. 收集主頁資料
先用 browser_navigate 上 GitHub repo 主頁：
- 睇 description、stars、license
- 睇目錄結構
- 如果有 README，拉落去睇完整內容

### 3. Clone Repo
```bash
cd /tmp && git clone --depth 1 https://github.com/{owner}/{repo}.git
```
用 --depth 1 只拉最新版本，加快速度。

### 4. 分析目錄結構
```bash
find . -type f -not -path './.git/*' -not -path '*/node_modules/*' | sort
```
了解整體架構後，揀重點檔案嚟讀。

### 5. 源碼深讀（揀優先級）
優先讀嘅檔案（由高至低）：
- **README.md / pyproject.toml / package.json** — 項目概覽、依賴、版本
- **入口檔案**（__init__.py, index.ts, main.py）— 公開 API
- **核心邏輯檔案**（browser.py, config.py 等）— 理解實現原理
- **測試檔案**（test_*.py, test_*.ts）— 了解點樣驗證
- **CHANGELOG.md** — 版本演進同修復咗咩

用 read_file 逐段讀，唔好用 terminal cat（有 cache trap）。
若有 read_file cache trap（回傳 "File unchanged..."），用 terminal subprocess bypass。

### 6. 分析關鍵數字
- Lines of code（Python/TS/JS/Rust 各幾多）
- 檔案總數
- 依賴關係
- 版本號、最近更新日期

### 6a. 跨系統比較分析（可選）
如果任務係比較兩套系統/frameworks/approaches：
- 建立 **對比維度**（架構、功能、token效率、易用性等）
- 用 delegate_task 開 subagent 深入研究每個系統嘅具體細節
- 產出 **comparison table**（唔好齋 text description）
- 每個維度要講清楚邊個贏、點解
- 最後俾 actionable recommendation（邊個適合咩情況用）

### 6b. PDF Report Generation（可選）
如果需要產出高可讀性 PDF report（唔係 txt）：
- 用 **fpdf2** library（pip install fpdf2）
- 一定要用 Unicode font（eg. DejaVuSans），因 Helvetica 唔支援 Unicode
- Font paths 喺 Oracle VM: `/usr/share/fonts/dejavu-sans-fonts/DejaVuSans*.ttf`
- 用 `add_font("DejaVu", "", "/path/to/DejaVuSans.ttf")` + `set_font("DejaVu", ...)` 代替 `"Helvetica"`
- set_font 用 `"DejaVu"` 唔係 `"Helvetica"`，`"Courier"` 改成 `"DejaVuMono"`（可用 DejaVuSans 代替 monospace）
- `multi_cell()` 要傳 width 參數（`self.w - self.r_margin - x`），唔好傳 0，否則 bullet point 排版會爛
- 用 `deprecationWarning` 可忽略（`uni=True` 參數已 deprecated 但仲用得）
- 避免用 em dash（—）、bullet（•）以外嘅特殊 Unicode characters

### 6c. 產出結構化中文報告
寫成 txt 檔，格式如下：

```
══════════════════════════════════════
  項目名稱 — 原理 · 代碼 · 應用
══════════════════════════════════════
  來源: {repo URL}
  版本: {version}
  授權: {license}
  星數: {stars} ⭐ | Fork: {forks}
══════════════════════════════════════


一、概覽
═════════
{一段概括呢個 project 係做咩}


二、核心原理
═════════════
{拆解核心技術原理，多層面分析}


三、效能/測試結果（如有）
══════════════════════════
{table 形式比較}


四、代碼架構分析
══════════════════
{目錄樹 + 每部分解釋，總 LOC 等}


五、應用場景
══════════════
{幾個主要 use cases}


六、安裝同使用
══════════════
{pip install / npm install + 基本使用 code}


七、對應我哋環境嘅用法（如有）
════════════════════════════════
{點樣喺 Oracle VM / TaskForge 用}


══════════════════════════════════════
  報告完成
══════════════════════════════════════
```

### 8. Deliver
用 MEDIA:/path/to/file.txt 直接 send txt 檔畀用戶。

## Pitfalls
- 大 repo（>50MB）用 --depth 1 減少 download 時間
- README truncated 時用 browser 睇，唔好用 read_file 硬食（太大）
- 如果 repo 有 submodules，留意 clone 完係咪完整
- 用 read_file 逐段讀唔好貪心一次過讀太多，會爆 100K char limit
- 記得 todo 管理多步驟進度

## Verification
- 報告結構完整（7 個 sections 全部有）
- 中英文夾雜，用戶睇得明
- 有具體 code example 唔好齋講概念
- 有對應我哋環境嘅實用建議
