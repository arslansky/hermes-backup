---
name: deep-github-repo-analysis
description: Deep research GitHub repos for architecture patterns, reusable components, and comparative analysis against existing systems.
trigger: "deep dive repo, analyze github repo, 深度研究, 比對架構"
---

# Deep Repository Analysis Skill

## When to Use
When asked to deeply research a GitHub repository for architecture insights, reusable patterns, or comparison against another system — especially when no existing skill covers the target domain.

## How to Use (Step-by-Step)

### Phase 1: Quick Reconnaissance
```bash
# Always start with the API (no auth needed for public repos)
curl -s "https://api.github.com/repos/{owner}/{repo}" | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(d.get('description',''), d.get('stargazers_count',''), d.get('language',''), d.get('topics',[]))"

# Readme
curl -s "https://api.github.com/repos/{owner}/{repo}/readme" | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(base64.b64decode(d.get('content','')).decode('utf-8', errors='ignore')[:3000])"
```

### Phase 2: Directory Structure
```bash
# List top-level directories and files
curl -s "https://api.github.com/repos/{owner}/{repo}/contents/{path}" | python3 -c "
import sys,json; d=json.load(sys.stdin); [print(x['name'], x.get('size','')) for x in d]"
```
Do this recursively for key directories.

### Phase 3: Key File Content — Browser Console Parallel Fetch (Recommended)

When you need to read **multiple files in parallel**, use the browser console with `Promise.all` + `fetch` against `raw.githubusercontent.com`. This is faster and cleaner than sequential curl calls:

```javascript
// List directory first to get file names
fetch('https://api.github.com/repos/{owner}/{repo}/contents/{path}')
  .then(r => r.json())
  .then(items => items.map(i => i.name))

// Then fetch multiple files in parallel
Promise.all([
  fetch('https://raw.githubusercontent.com/{owner}/{repo}/main/path/file1.md').then(r=>r.text()),
  fetch('https://raw.githubusercontent.com/{owner}/{repo}/main/path/file2.md').then(r=>r.text()),
  fetch('https://raw.githubusercontent.com/{owner}/{repo}/main/path/file3.md').then(r=>r.text()),
]).then(([a,b,c]) => JSON.stringify({a:a.slice(0,2000), b:b.slice(0,2000), c:c.slice(0,2000)}))
```

For large repos with many files (e.g. 24 skills), fetch in batches of 4-6 to avoid overwhelming the connection. Cap each file at 2000 chars in the response to keep the result manageable, then request the full content for files you want to study in depth.

**Fallback**: Use `raw.githubusercontent.com/{owner}/{repo}/main/{path}` with `curl` if browser fetch fails:
```bash
curl -s "https://raw.githubusercontent.com/{owner}/{repo}/main/{path}" | head -400
```

For large files (100KB+), sample first:
```bash
curl -s "https://raw.githubusercontent.com/{owner}/{repo}/main/{path}" | wc -l
curl -s "https://raw.githubusercontent.com/{owner}/{repo}/main/{path}" | head -100
```

### Phase 4: Synthesize Findings
Convert findings into:
1. **What this repo does** — one-line description
2. **Core components** — table of major parts with sizes
3. **Key patterns worth borrowing** — numbered list with rationale
4. **Specific rules/mechanisms explained** — detailed breakdown of interesting internals

## Key Insight
The most valuable research targets are often `checks.mjs` / `rules.py` / `patterns.ts` style files — they contain the actual logic rather than scaffolding. Look for these first.

## What Made This Skill Worth Saving

**2026-06-18**: Analysis of `addyosmani/agent-skills` (24 skills, 56K+ stars) revealed a superior pattern:

1. API recon for repo metadata (stars, language, topics)
2. `browser_console` → `Promise.all` + `fetch` to parallel-fetch ALL skill files at once from `raw.githubusercontent.com`
3. Batch fetch in groups of 4-6, cap each at 2000 chars, then deep-dive on interesting ones
4. Synthesize quality tiers — Tier 1 (immediately useful), Tier 2 (good but needs work), Tier 3 (weak)

**Key lesson**: For repos with many small files (skills, rules, patterns), the browser console parallel fetch is dramatically better than sequential curl. Batch by 4-6 files, cap response length, iterate.

## Files
- references/deep-repo-research-techniques.md