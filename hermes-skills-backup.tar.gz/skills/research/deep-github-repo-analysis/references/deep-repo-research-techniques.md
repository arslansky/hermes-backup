# Deep Repository Research Techniques

## GitHub API Endpoints (No Auth Required for Public Repos)

### Repo Metadata
```
https://api.github.com/repos/{owner}/{repo}
```
Returns: description, stars, language, topics, forks, open_issues, default_branch, etc.

### Directory Listing
```
https://api.github.com/repos/{owner}/{repo}/contents/{path}
```
Returns: array of {name, path, sha, size, type}

### File Content (Base64)
```
https://api.github.com/repos/{owner}/{repo}/contents/{path}
```
Content is base64 encoded in the `content` field. Decode with:
```bash
curl -s "https://api.github.com/repos/{owner}/{repo}/contents/{path}" | python3 -c "
import sys,json; d=json.load(sys.stdin)
print(base64.b64decode(d.get('content','')).decode('utf-8', errors='ignore'))"
```

### Raw File (Direct)
```
https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{path}
```
No base64 encoding needed. Use this for quick sampling with `head`, `wc`, `grep`.

## Research Patterns

### 1. Stars + Description (Instant Context)
Always start here. Stars indicate community validation. Description gives one-line purpose.

### 2. README → SKILL.src.md Chain
Many AI coding skill repos put the main skill definition in `SKILL.src.md` at the repo root or in `skill/` directory. This often contains:
- Full description
- Commands table
- Design rules
- Anti-pattern references

### 3. Find the Core Logic (CLI/Engine/Rule Directories)
Many repos have:
- `cli/` — standalone CLI tools
- `engine/` — core logic
- `rules/` — pattern detection rules
- `scripts/` — automation scripts

**Key insight**: The skill wrapper (SKILL.src.md) is often just the prompt. The real implementation is in `cli/` or `engine/`.

### 4. Rule Extraction Pattern
For rule-based systems (linters, anti-pattern detectors):
```bash
# Count rules
grep -c "id:" rules/checks.mjs

# Extract rule IDs
grep -oP "id: '[^']+'" rules/checks.mjs | sort -u

# Extract rule + snippet pattern
grep -oP "id: '[^']+'[^,]+snippet: '[^']+'" rules/checks.mjs
```

### 5. Size-Based Prioritization
Files > 50KB are usually the core implementation. Files < 5KB are often wrappers/entry points.

| Size Range | Likely Meaning |
|------------|----------------|
| < 5KB | Entry point, wrapper, CLI stub |
| 5-50KB | Individual command/module |
| 50KB+ | Core engine, rule engine, full detection system |
| 100KB+ | Complex system (like impeccable's checks.mjs at 100KB) |

## Common Repo Structures for AI Tools

### Pattern A: Skill + CLI Split
```
repo/
├── SKILL.src.md          # The AI-facing prompt/skill
├── skill/
│   ├── reference/        # Command-specific references
│   └── scripts/          # Helper scripts
└── cli/                  # Standalone CLI (for non-AI usage)
    └── engine/
        └── rules/        # Actual detection logic
```

### Pattern B: Monolithic Skill
```
repo/
├── SKILL.md              # Full skill
└── references/           # Reference files only
```

### Pattern C: Library + CLI
```
repo/
├── src/                  # Core library
├── cli/                  # CLI wrapper
└── README.md
```

## What to Look For by Tool Type

| Tool Type | Key Files to Find |
|-----------|-------------------|
| Linter/Detector | `rules.mjs`, `checks.ts`, `patterns.py` |
| Design System | `tokens.json`, `theme.*`, `*.css` |
| AI Coding Skill | `SKILL.md`, `skill/*.md`, `agents/` |
| CLI Tool | `cli/`, `bin/`, `src/cli.rs` |
| Library | `src/`, `lib/`, `*.py` (for Python) |

## Workflow Summary

1. **API recon** → understand the repo at a glance
2. **README** → understand the purpose and philosophy
3. **Directory tree** → find the real implementation
4. **Core file content** → extract the actual rules/logic
5. **Synthesize** → explain what's worth borrowing and why

## Anti-Patterns to Avoid

- **Don't just read SKILL.md** — many repos hide the real logic elsewhere
- **Don't assume structure** — always explore directories
- **Don't skip large files** — 100KB+ files often contain the most valuable content
- **Don't use npx/npm for one-off checks** — the GitHub API gives direct access without install