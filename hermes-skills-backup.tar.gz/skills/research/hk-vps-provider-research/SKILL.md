---
name: hk-vps-provider-research
description: Systematic research for Hong Kong VPS pricing and provider comparison when review sites are blocked
category: research
tags: [vps, cloud, hong-kong, research, infrastructure]
---

# HK VPS Provider Research

Systematic research methodology for finding Hong Kong VPS pricing and comparing providers when review sites are blocked.

## Use When
- User asks about Hong Kong VPS options, pricing, or provider comparisons
- Need to replace Big VM (Claw Cloud) or find alternative HK VPS

## Research Pipeline

### Step 1: Direct Provider Pricing (Static HTML)
Most VPS providers put pricing in static HTML on their main pricing page.

```bash
# Try VPS page first
curl -sL "https://{provider}.com/vps/" -H "User-Agent: Mozilla/5.0" \
  | grep -iE 'price|\\$|cost|vps|plan|hong|kvm|cpu|ram|month'

# Try cloud servers page
curl -sL "https://{provider}.com/cloud-servers/" -H "User-Agent: Mozilla/5.0" \
  | grep -iE 'price|\\$|cost|vps|plan|vm|cpu|ram|month'
```

**Good targets (static HTML pricing):**
- `cloudcone.com/vps/` - SSD VPS plans: $1.08-$10.47/mo
- CloudCone SC2 scalable cloud: $5.20-$63.09/mo (modular)

**Bad targets (JS-rendered, need browser):**
- Most providers with "price calculator" components

### Step 2: Status Page for Datacenter Info
Status pages often reveal datacenter locations via incident reports and server IDs.

```bash
curl -sL "https://status.{provider}.com/" -H "User-Agent: Mozilla/5.0" \
  | grep -iE 'region|location|hong|singapore|dc|hypervisor|maintenance'
```

**CloudCone status page** (`status.cloudcone.com`) shows HK servers via incidents:
- "S160-V", "S210-V", "S158-V" = Hong Kong hypervisors
- Regular maintenance incidents confirm active HK presence

### Step 3: API Endpoints (if auth not required)
```bash
# Try public API endpoints
curl -sL "https://app.{provider}.com/api/v1/locations" -H "Accept: application/json"
curl -sL "https://app.{provider}.com/api/v1/vps" -H "Accept: application/json"
```

### Step 4: If All Else Fails - Try Nitter/Twitter
```bash
# Nitter instances (Twitter alternative)
curl -sL "https://nitter.net/search?q={provider}+vps" \
  | grep -iE 'vps|review|uptime|down|reliable|slow|fast'
```

## Blocked By Cloudflare (Need Browser)
These cannot be scraped via curl:
- `reddit.com/r/cloudcone`, `webhostingtalk.com`, `lowendtalk.com`
- `trustpilot.com` (returns Cloudflare challenge)
- Most major review aggregators

**Workaround:** Use `browser_navigate` tool with CloakBrowser for these.

## Known HK VPS Providers

### CloudCone (cloudcone.com)
**Status:** Active, HK datacenter confirmed
**VPS Plans:**
| Plan | Price | Specs |
|------|-------|-------|
| SSD VPS 1 | $1.08/mo | 1 vCPU, 1GB RAM, ~20GB SSD |
| SSD VPS 2 | $1.63/mo | 1 vCPU, 1GB RAM |
| SSD VPS 3 | $1.79/mo | 1 vCPU, 1GB RAM |
| SSD VPS 4 | $1.96/mo | 1 vCPU, 2GB RAM |
| **SSD VPS 5** | **$4.79/mo** | **2 vCPU, 2GB RAM** |
| SSD VPS 6 | $10.47/mo | 2 vCPU, 4GB RAM |

**Cloud Servers (Scalable):**
| Plan | Price | Specs |
|------|-------|-------|
| SC2 Starter | $5.20/mo | 1 vCPU, 1GB RAM, 20GB SSD |
| **SC2 Basic** | **$10.34/mo** | **2 vCPU, 2GB RAM, 40GB SSD** |
| SC2 Standard | $14.51/mo | 3 vCPU, 3GB RAM, 60GB SSD |
| SC2 Business | $17.56/mo | 2 vCPU, 4GB RAM |

### Other Providers to Check
- **RackNerd** (racknerd.com) - Budget VPS, check HK availability
- **LightNode** (lightnode.com) - HK VPS available, modular pricing
- **CCNIC/CCN** - Hong Kong based, check via direct sales
- **Thetaa** - May have HK nodes

### Free Options
- **Oracle Ampere** (oracle.com/cloud/free) - Always free: 2 vCPU, 12GB RAM, 200GB block storage
  - Requires credit card, may not be available in all regions
  - HK region not always available

## Comparison Criteria
| Factor | Weight | How to Verify |
|--------|--------|---------------|
| Price | High | Direct pricing page |
| vCPU/RAM | High | Direct pricing page |
| Disk | Medium | Direct pricing page |
| HK location | Critical | Status page / ticket support |
| Network quality | High | Need user reports (blocked) |
| API connectivity | Critical | Test from Oracle VM (curl) |
| Uptime | Medium | Status page history |

## Output Format
```
## [Provider Name] (HK Datacenter: Yes/No/Unknown)

### Pricing
| Plan | Price | vCPU | RAM | Disk |
|------|-------|------|-----|------|
| ... | ... | ... | ... | ... |

### Notes
- Source: [URL]
- Last checked: [date]
- HK confirmed via: [method]
```

## Related Skills
- `oracle-vm-disk-cleanup` - Clean Oracle VM before installing new services
- `big-vm-ssh-troubleshooting` - For troubleshooting other VPS providers
