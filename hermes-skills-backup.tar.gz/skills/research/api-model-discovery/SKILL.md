---
name: api-model-discovery
description: Discover available models from an AI API provider when model names from docs don't match what's deployed. Also tracks which providers block HK cards.
---

# API Model Discovery Pattern

## Context
When testing an AI API provider (like TTK, OpenRouter, etc.), model names from documentation often don't match what's actually deployed. Need to discover available models before using them.

## Trigger
When given an API key + endpoint, and you need to find which models are actually available.

## Pattern

### Step 1: List available models
```bash
curl -s "https://api.PROVIDER.com/v1/models" \
  -H "Authorization: Bearer YOUR_API_KEY" | python3 -c "
import sys,json; d=json.load(sys.stdin); 
for m in d.get('data',[]): print(m['id'])
"
```

### Step 2: Test with a simple prompt
```bash
curl -s -X POST "https://api.PROVIDER.com/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{"model":"MODEL_NAME","messages":[{"role":"user","content":"hi"}],"stream":false}'
```

### Step 3: Check error codes
- `"model_not_found"` → model not available, try another
- `"card_verification_required"` → provider requires credit card even for free tier (blocks HK cards)
- `"invalid_api_key"` → key is wrong

### TTK Models (2026-05)
Known working models:
- `gemini-3-flash-preview-联网搜索` — works, has web search
- `gpt-image-2` — works for image generation
- `MiniMax-M2.7` — available but API name may differ

Chinese-labeled models like `gemini-3-flash-preview-联网搜索` are the actual IDs, not the English-only names.

## Providers with HK Card issues
- **Pioneer.ai** — requires credit card verification for free tier, blocks HK cards
- **TTK API** — works fine with HK card (uses standard billing)

## Verification
After finding a working model, always verify with a 3-word response test:
```bash
curl -s -X POST ".../chat/completions" \
  -d '{"model":"WORKING_MODEL","messages":[{"role":"user","content":"Say hello in exactly 3 words"}],"stream":false}'
```