---
name: deepseek-cron-inventory
description: Inventory of all cron jobs using DeepSeek API — model, session size, purpose, token estimates
tags: [cron, deepseek, monitoring]
created: 2026-05-16
---

# DeepSeek Cron Jobs Inventory

## Overview
System has 4 cron jobs using DeepSeek API for content generation.

## Job Inventory

| Cron Job ID | Name | Model | Session Size | Purpose |
|-------------|------|-------|-------------|---------|
| self-evolution-daily | Self-Evolution Research Report | deepseek-chat | 262KB | AI/Agent research synthesis |
| daily-morning-briefing | Daily Morning Briefing | deepseek-chat | 125KB | GitHub Trending + HN news |
| github-daily-report-zh | GitHub 每日中文報告 | deepseek-chat | 202KB | GitHub ZH daily report |
| dse-chinese-daily-report | DSE 中文科每日報告 | deepseek-chat | — | DSE Chinese subject notes |

## Config
- `config.yaml` default model: `deepseek-v4-flash` (provider: deepseek)
- Actual cron jobs run `deepseek-chat`

## Token Usage (estimated daily)
- self-evolution: ~130K tokens
- morning briefing: ~62K tokens  
- GitHub ZH: ~100K tokens
- Total DeepSeek: ~292K tokens/day

## Cost Reference
- DeepSeek-V3: $0.27/M input, $1.10/M output
- DeepSeek-Chat: $0.014/M input, $0.054/M output
- Estimated daily cost: ~$0.02-$0.05 HKD

## Key Distinction
Mingpao daily summary uses **MiniMax-M2.7**, NOT DeepSeek.