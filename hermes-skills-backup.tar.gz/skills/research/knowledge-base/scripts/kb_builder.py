#!/usr/bin/env python3
"""
Knowledge Base Builder — starter template
Usage: python kb_builder.py --urls file.txt --db mytopic.db
"""

import argparse, sqlite3, re, os
from pathlib import Path

# ─── Core Functions ────────────────────────────────────────────────

def split_sentences(text: str) -> list[str]:
    """CJK-aware sentence splitting."""
    pattern = r'(?<=[。！？．.!?])\s+'
    sentences = re.split(pattern, text.strip())
    return [s.strip() for s in sentences if s.strip()]


def chunk_text(text: str, max_chars: int = 800, overlap: int = 100) -> list[str]:
    """Context-preserving text chunking with overlap."""
    sentences = split_sentences(text)
    chunks, current = [], ""
    last_sent = ""
    
    for sent in sentences:
        if len(current) + len(sent) <= max_chars:
            current += sent + " "
        else:
            if current:
                chunks.append(current.strip())
            overlap_text = last_sent if last_sent else ""
            current = overlap_text + sent + " "
        last_sent = sent
    
    if current.strip():
        chunks.append(current.strip())
    return chunks


def init_db(db_path: str, schema_sql: str = None):
    """Create KB tables + FTS5."""
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    
    default_schema = """
    CREATE TABLE IF NOT EXISTS sources (
        id INTEGER PRIMARY KEY,
        url TEXT UNIQUE,
        title TEXT,
        source_type TEXT DEFAULT 'web',
        domain TEXT,
        crawled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    CREATE TABLE IF NOT EXISTS articles (
        id INTEGER PRIMARY KEY,
        source_id INTEGER REFERENCES sources(id),
        title TEXT,
        content TEXT,
        summary TEXT,
        chunk_count INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    CREATE VIRTUAL TABLE IF NOT EXISTS articles_fts USING fts5(
        title, content, summary,
        content='articles', content_rowid='id'
    );
    
    CREATE TRIGGER IF NOT EXISTS articles_ai AFTER INSERT ON articles BEGIN
        INSERT INTO articles_fts(rowid, title, content, summary)
        VALUES (new.id, new.title, new.content, new.summary);
    END;
    """
    
    conn.executescript(schema_sql or default_schema)
    conn.commit()
    return conn


def insert_articles(conn, articles: list[dict], batch_size: int = 100):
    """Batch insert with progress reporting."""
    cursor = conn.cursor()
    total = len(articles)
    
    for i in range(0, total, batch_size):
        batch = articles[i:i+batch_size]
        cursor.executemany("""
            INSERT OR IGNORE INTO articles 
            (source_id, title, content, summary, chunk_count)
            VALUES (:source_id, :title, :content, :summary, :chunk_count)
        """, batch)
        conn.commit()
        print(f"  [{min(i+batch_size, total)}/{total}] inserted")
    
    return total


def search(conn, query: str, limit: int = 20) -> list[tuple]:
    """FTS5 search returning (id, title, snippet, rank)."""
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.id, a.title,
               snippet(articles_fts, 1, '【', '】', '...', 64) as context,
               rank
        FROM articles_fts
        JOIN articles a ON articles_fts.rowid = a.id
        WHERE articles_fts MATCH ?
        ORDER BY rank
        LIMIT ?
    """, (query, limit))
    return cursor.fetchall()


def export_for_context(conn, query: str, max_chars: int = 4000) -> str:
    """Export top FTS matches as AI-context string."""
    results = search(conn, query, limit=10)
    if not results:
        return "No results found."
    
    lines = [f"## {r[1]}\n{r[2]}\n" for r in results]
    output = "\n---\n".join(lines)
    
    if len(output) > max_chars:
        output = output[:max_chars] + "\n\n[...truncated...]"
    return output


# ─── URL Fetching (basic, no Cloudflare/Akamai) ────────────────────

def fetch_url_text(url: str) -> dict:
    """Fetch and extract title + text from a URL. Basic implementation."""
    import httpx
    try:
        resp = httpx.get(url, timeout=30, follow_redirects=True, 
                         headers={"User-Agent": "Mozilla/5.0 (compatible; KB Bot/1.0)"})
        resp.raise_for_status()
        
        # Simple title extraction
        title_match = re.search(r'<title>(.*?)</title>', resp.text, re.S)
        title = title_match.group(1).strip() if title_match else url
        
        # Simple text extraction (strip HTML tags)
        text = re.sub(r'<script.*?</script>', '', resp.text, flags=re.S)
        text = re.sub(r'<style.*?</style>', '', text, flags=re.S)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        
        return {"url": url, "title": title, "text": text[:50000]}
    except Exception as e:
        return {"url": url, "title": url, "text": "", "error": str(e)}


# ─── CLI ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Knowledge Base Builder")
    parser.add_argument("--db", default="knowledge.db", help="Output SQLite DB path")
    parser.add_argument("--urls", help="File with URLs (one per line)")
    parser.add_argument("--url", help="Single URL to crawl")
    parser.add_argument("--query", help="Search query (skip crawling)")
    parser.add_argument("--text", help="Raw text to ingest")
    parser.add_argument("--title", help="Title for raw text input")
    parser.add_argument("--limit", type=int, default=10, help="Search result limit")
    args = parser.parse_args()

    # Init or open DB
    conn = init_db(args.db)
    
    if args.query:
        result = export_for_context(conn, args.query, max_chars=4000)
        print(result)
    
    elif args.url:
        print(f"Fetching: {args.url}")
        data = fetch_url_text(args.url)
        if data.get("error"):
            print(f"Error: {data['error']}")
            return
        
        chunks = chunk_text(data["text"])
        articles = [{
            "source_id": None,
            "title": data["title"],
            "content": c,
            "summary": c[:200],
            "chunk_count": len(chunks)
        } for c in chunks]
        
        # Insert source
        from urllib.parse import urlparse
        domain = urlparse(args.url).netloc
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR IGNORE INTO sources (url, title, source_type, domain)
            VALUES (?, ?, 'web', ?)
        """, [args.url, data["title"], domain])
        conn.commit()
        
        # Get source_id
        cursor.execute("SELECT id FROM sources WHERE url = ?", [args.url])
        row = cursor.fetchone()
        if row:
            for a in articles:
                a["source_id"] = row[0]
        
        n = insert_articles(conn, articles)
        print(f"Done. {n} chunks stored in {args.db}")
    
    elif args.text:
        title = args.title or "Raw Text"
        chunks = chunk_text(args.text)
        articles = [{
            "source_id": None,
            "title": title,
            "content": c,
            "summary": c[:200],
            "chunk_count": len(chunks)
        } for c in chunks]
        n = insert_articles(conn, articles)
        print(f"Done. {n} chunks stored in {args.db}")
    
    else:
        print("Nothing to do. Use --url, --text, or --query.")
        print(f"DB: {args.db}")

if __name__ == "__main__":
    main()
