---
name: knowledge-base
description: Build and maintain a personal knowledge base from URLs, PDFs, and notes — crawl → structure → SQLite → query. Use when: building a knowledge base, research database, topic corpus, study materials DB, fact lookup system.
---

# Knowledge Base Builder

Build a searchable personal knowledge base from any source: URLs, PDFs, notes, websites. Each knowledge base is scoped to a topic/subject with its own SQLite database.

## When to Use This Skill

- User says "build a knowledge base about X"
- User says "research X and save findings"
- User says "crawl these sources and make them queryable"
- User has a DSE subject, technical topic, or domain they want searchable
- Any task that involves gathering structured information over time

## Pipeline Overview

```
URLs / Notes / PDFs
       │
       ▼
┌──────────────────┐
│  Phase 1: Gather  │  (crawl, download, extract text)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  Phase 2: Parse   │  (sentence splitting, chunking, dedup)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Phase 3: Store    │  (SQLite + FTS5, structured tables)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ Phase 4: Query    │  (keyword search, semantic search, export)
└──────────────────┘
```

## Recommended Database Schema

Each topic gets its own SQLite DB. Recommended structure:

```sql
-- Core tables
CREATE TABLE sources (
    id INTEGER PRIMARY KEY,
    url TEXT UNIQUE,
    title TEXT,
    source_type TEXT,  -- 'web', 'pdf', 'note'
    domain TEXT,
    crawled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE articles (
    id INTEGER PRIMARY KEY,
    source_id INTEGER REFERENCES sources(id),
    title TEXT,
    content TEXT,       -- full text
    summary TEXT,       -- AI-generated summary
    chunk_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE VIRTUAL TABLE articles_fts USING fts5(
    title, content, summary,
    content='articles',
    content_rowid='id'
);

-- Topic-specific tables (add per subject)
-- e.g. for DSE Chinese:
CREATE TABLE classical_texts (
    id INTEGER PRIMARY KEY,
    article_id INTEGER REFERENCES articles(id),
    title TEXT,
    author TEXT,
    dynasty TEXT,
    content TEXT,
    translation TEXT,
    notes TEXT
);

-- e.g. for cybersecurity:
CREATE TABLE techniques (
    id INTEGER PRIMARY KEY,
    name TEXT,
    category TEXT,  -- 'recon', 'exploit', 'persistence', etc.
    description TEXT,
    commands TEXT,  -- JSON array of example commands
    MITRE_ID TEXT
);
```

## Phase 1: Gathering

### Web Crawling (I/O-bound, single VM sufficient)

For normal sites (no Cloudflare/Akamai):
```python
import asyncio, httpx, re

async def crawl_urls(urls: list[str], concurrency: int = 10):
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        tasks = [crawl_one(client, url) for url in urls]
        return await asyncio.gather(*tasks)

async def crawl_one(client, url):
    resp = await client.get(url)
    text = resp.text
    # Parse title, content with readability or regex
    title = re.search(r'<title>(.*?)</title>', text, re.S)
    return {"url": url, "title": title.group(1) if title else "", "text": text}
```

For Cloudflare-protected sites — use the `mingpao-cf-bypass-scraper` skill.

### PDF Ingestion
```python
import subprocess
# Extract text from PDF
result = subprocess.run(["pdftotext", "-layout", "input.pdf", "-"], 
    capture_output=True, text=True)
text = result.stdout
```

### Note Ingestion
Plain `.txt`, `.md`, `.json`, `.csv` files — read directly and chunk.

## Phase 2: Parsing

### Sentence Boundary Detection (Critical for CJK)

**Must handle CJK characters properly** — don't split mid-sentence:

```python
import re

def split_sentences(text: str) -> list[str]:
    """Split text into sentences. Works for CJK + English."""
    # CJK: full-width punctuation
    # English: regular punctuation
    pattern = r'(?<=[。！？．.!?])\s+'
    sentences = re.split(pattern, text.strip())
    return [s.strip() for s in sentences if s.strip()]

def chunk_text(text: str, max_chars: int = 800, overlap: int = 100) -> list[str]:
    """Chunk text with sentence awareness, include context header."""
    sentences = split_sentences(text)
    chunks, current = [], ""
    
    for sent in sentences:
        if len(current) + len(sent) <= max_chars:
            current += sent + " "
        else:
            if current:
                chunks.append(current.strip())
            # Overlap: keep last sentence for context
            overlap_sent = current.strip().split("。")[-1] + "。"
            current = overlap_sent + sent + " "
    
    if current.strip():
        chunks.append(current.strip())
    return chunks
```

## Phase 3: Storage

### Database Initialization
```python
import sqlite3, os

def init_db(db_path: str):
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    
    # Create tables + FTS5
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS sources (...);
        CREATE TABLE IF NOT EXISTS articles (...);
        CREATE VIRTUAL TABLE articles_fts USING fts5(title, content, summary,
            content='articles', content_rowid='id');
        
        -- Triggers to keep FTS in sync
        CREATE TRIGGER IF NOT EXISTS articles_ai AFTER INSERT ON articles BEGIN
            INSERT INTO articles_fts(rowid, title, content, summary)
            VALUES (new.id, new.title, new.content, new.summary);
        END;
    ''')
    conn.commit()
    return conn
```

### Batch Insert with Progress
```python
def insert_articles(conn, articles: list[dict], batch_size: int = 100):
    cursor = conn.cursor()
    for i in range(0, len(articles), batch_size):
        batch = articles[i:i+batch_size]
        cursor.executemany('''
            INSERT OR IGNORE INTO articles (source_id, title, content, summary, chunk_count)
            VALUES (:source_id, :title, :content, :summary, :chunk_count)
        ''', batch)
        conn.commit()
        print(f"  [{i+len(batch)}/{len(articles)}] inserted")
```

## Phase 4: Querying

### Basic Full-Text Search
```python
def search(conn, query: str, limit: int = 20) -> list[dict]:
    cursor = conn.cursor()
    cursor.execute('''
        SELECT a.id, a.title, snippet(articles_fts, 1, '【', '】', '...', 64) as context
        FROM articles_fts
        JOIN articles a ON articles_fts.rowid = a.id
        WHERE articles_fts MATCH ?
        ORDER BY rank
        LIMIT ?
    ''', (query, limit))
    return cursor.fetchall()
```

### Export for AI Context
```python
def export_for_context(conn, query: str, max_chars: int = 4000) -> str:
    """Export top matches as AI-context string."""
    results = search(conn, query, limit=10)
    lines = [f"## {r['title']}\n{r['context']}\n" for r in results]
    
    output = "\n---\n".join(lines)
    if len(output) > max_chars:
        output = output[:max_chars] + "\n\n[...truncated...]"
    return output
```

## Multi-Subject Pattern

For multiple related knowledge bases (e.g., DSE subjects), use a shared parent directory:

```
~/.hermes/kb/
  dse-chinese/
    dse_chinese.db
    migrate.py
  dse-geography/
    dse_geography.db
    migrate.py
  dse-economics/
    dse_economics.db
    migrate.py
```

Each subject has its own schema with topic-specific tables while sharing the same pipeline code.

## Key Functions to Implement

| Function | Purpose |
|----------|---------|
| `DomainResolve(domain)` | Resolve domain to IP (for ASN lookup) |
| `GetASN(ip)` | Get ASN info for an IP (MIT/CAIDA lookup) |
| `split_sentences(text)` | CJK-aware sentence splitting |
| `chunk_text(text, max_chars, overlap)` | Context-preserving text chunking |
| `init_db(db_path)` | Create tables + FTS5 + triggers |
| `insert_articles(conn, articles, batch_size)` | Batch insert with progress |
| `search(conn, query, limit)` | FTS5 search with snippets |
| `export_for_context(conn, query, max_chars)` | Format results for AI context |

## Database Naming Convention

- Single topic: `<topic>.db` (e.g., `dse_chinese.db`)
- Multi-subject: `<topic>_<subject>.db` (e.g., `dse_geography.db`)
- Path: `~/.hermes/kb/<topic>/` or project-specific `data/` directory

## Known Pitfalls

1. **CJK sentence splitting** — naive regex splits every `。` and `.`. Use `split_sentences()` above which handles both CJK full-width and English punctuation without mid-sentence cuts.

2. **FTS5 sync triggers** — If you insert articles directly without triggers, FTS index goes stale. Always use triggers or rebuild: `INSERT INTO articles_fts(articles_fts) VALUES('rebuild')`.

3. **WAL mode** — Always use `PRAGMA journal_mode=WAL` for concurrent reads during queries while writing.

4. **Content-length cap on models** — When exporting for AI context, cap at 4000 chars. For large DBs, use FTS5 ranking to surface most relevant chunks first.

5. **Akamai Bot Manager** — TLS fingerprint impersonation (uTLS) doesn't work. Use real browser engine (chromedp/Puppeteer) + residential proxy for anti-bot sites. See `website-protection-bypass-guide` skill.

6. **Cloudflare bypass** — Use `mingpao-cf-bypass-scraper` skill. Don't try to fight CF programmatically.
