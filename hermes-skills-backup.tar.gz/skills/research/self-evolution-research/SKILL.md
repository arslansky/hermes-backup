---
name: self-evolution-research
title: Self-Evolution Research Report
description: "Weekly deep-dive research scan: scrape GitHub Trending + Hacker News for agent framework / AI tooling developments, cross-reference against existing Hermes skills, produce structured gap analysis and actionable recommendations. Use when: self-evolution, research report, gap analysis, agent trends, AI tooling scan, skill gap, competitive intelligence"
trigger: "Cron job — weekly or bi-weekly at ~05:00"
---

# Self-Evolution Research Report

## Overview
A focused research pipeline that scans GitHub Trending and Hacker News specifically for **agent framework / AI tooling / LLM infrastructure** developments, then cross-references findings against the existing Hermes skills catalog to identify gaps, update opportunities, and new directions. Unlike the general daily morning briefing, this is a deeper competitive intelligence scan.

## Steps

### Step 1: Scan GitHub Trending (Daily)
Navigate to `https://github.com/trending?since=daily`.

**Extract ALL repos using JavaScript** — the snapshot truncation often misses most repos:
```javascript
Array.from(document.querySelectorAll('article')).map(a => {
  const h2 = a.querySelector('h2')?.textContent?.trim().replace(/\s+/g, ' ') || '';
  const p = a.querySelector('p')?.textContent?.trim() || '';
  const starLink = a.querySelector('[href$=stargazers]');
  const todayStars = a.textContent.match(/([\d,]+)\s*stars\s*today/);
  return {
    repo: h2,
    desc: p || '',
    stars: starLink?.textContent?.trim() || '?',
    today: todayStars?.[1] || '0'
  };
});
```

**Filter for relevance**: Only repos related to:
- Agent frameworks (skills, orchestration, multi-agent)
- LLM tooling (CLI agents, MCP, function calling)
- AI infrastructure (inference, serving, fine-tuning)
- AI-powered developer tools
- Agent skill repositories / skill ecosystems

Skip: frontend libraries, game dev, databases, non-AI DevOps, general programming languages.

**For relevant repos, dig deeper** — navigate to each repo page and inspect:
- Description + README structure
- Directory layout (look for `skills/`, `agent/`, `.claude/`, `spec/` directories)
- Commits count and recency (indicates active development)
- Tags / releases (indicates maturity)
- For skill repos: what skills/categories do they cover?

### Step 2: Scan Hacker News
Navigate to `https://news.ycombinator.com/`.

Extract top 30 stories (or all on front page):
```javascript
Array.from(document.querySelectorAll('.athing')).slice(0,30).map(row => ({
  rank: row.querySelector('.rank')?.textContent?.trim(),
  title: row.querySelector('.titleline > a')?.textContent?.trim(),
  url: row.querySelector('.titleline > a')?.href?.trim()
}));
```

**Filter for relevance**: AI agents, ML research, tooling discussions, engineering culture (mitchellh-style hot takes about AI). Skip: security exploits, retro computing, physics/hardware, general news.

### Step 3: Cross-reference Against Existing Skills
Call `skills_list()` to get the full catalog. For each relevant finding:

1. **Match found?** — Our existing skill covers this area? Verify overlap.
2. **Gap identified?** — New technology or pattern not covered by any skill.
3. **Outdated?** — An existing skill references an older approach that's been superseded.

Check specific skill categories to watch:
- `autonomous-ai-agents` — competing agent CLI tools, new agent patterns
- `mcp` — MCP ecosystem developments, new servers/protocols
- `mlops` — new model serving, training, or evaluation tools
- `research` — research pipeline improvements, new data sources
- `creative` — generative AI tools, new media capabilities
- `devops` — agent infrastructure, deployment patterns

### Step 4: Compile Structured Report

Format:
```
═══ Self-Evolution Report ═══
日期：YYYY-MM-DD

【GitHub Trending 發現】
- {repo} — {description} (⭐{N}, +{today}/day)
- ...

【HN 熱門相關】
- {title} ({url})
- ...

【Skills Gap 分析】
- 建議補充：{new technology not covered by any skill}
- 建議更新：{existing skill that needs updating}
- 新方向：{completely new domain to watch}

【推薦行動】（0-3 項，每項一句簡短說明）
1. {action item} — {why}
2. ...
3. ...

【總結】
一句話總結今日發現嘅價值。
```

### Step 5: Deliver
The cron system handles delivery. Put the full report as the final response.

## Key Differences from daily-morning-briefing

| Aspect | daily-morning-briefing | self-evolution-research |
|--------|----------------------|------------------------|
| Scope | General tech news | AI/agent/tooling only |
| Depth | Top 10 repos + top 10 HN stories | All repos + top 30 HN, then deep-dive on relevant ones |
| Research | Scrape only | Scrape → filter → explore repos → cross-ref skills |
| Output | Briefing | Structured gap analysis with recommendations |
| Frequency | Daily | Weekly/bi-weekly |

## Pitfalls

- **Snapshot truncation**: Both GH Trending and HN pages truncate at ~8000 chars. Always use `browser_console()` with JavaScript extraction for complete data.
- **Not all trending repos are relevant**: Skip repos that aren't AI/agent related — don't waste time investigating non-relevant projects.
- **Skills inventory is large (~108 skills)**: Don't manually compare every skill. Use a heuristic: if it's in `autonomous-ai-agents`, `mlops`, `mcp`, `research`, or `software-development` categories — pay extra attention.
- **Read-only**: Never install, update, or modify anything. This is a pure research task.
- **Cron jobs can't ask questions**: Make reasonable default decisions about relevance.
- **[SILENT] protocol**: If nothing genuinely new to report (no new repos, no relevant HN stories, no gaps found), respond with exactly `[SILENT]` to suppress delivery. Never combine [SILENT] with content.

## Verification
Before finishing, confirm:
- [ ] All relevant GH Trending repos extracted (not just first 6)
- [ ] Top 30 HN stories scanned
- [ ] Existing skills loaded with `skills_list()`
- [ ] Gap analysis references specific existing skill names
- [ ] Recommendations are actionable (not vague)
