---
name: hermes-research-harness
description: Unified research pipeline combining ArXiv, Polymarket, Blogwatcher, and Semantic Scholar for comprehensive AI research reports. Built on the Hermes Debug Harness framework.. Use when: Hermes Harness, research pipeline, ArXiv, Polymarket, blog monitor
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [Research, ArXiv, Polymarket, Blogwatcher, Semantic Scholar, Reports, Automation]
    related_skills: [arxiv, ocr-and-documents]
---

# Hermes Research Harness

Unified research pipeline combining **OpenAlex** (primary), **ArXiv** (backup), **Polymarket**, **Blogwatcher**, and **Semantic Scholar** for comprehensive AI research reports. Built on the Hermes Debug Harness framework.

## ⚠️ CRITICAL: Data Source Priority

| Source | Status | Role | Notes |
|--------|--------|------|-------|
| **OpenAlex** | ✅ Primary | 13,000+ papers, no rate limit | **USE THIS FIRST** - 100% free API |
| ArXiv | ⚠️ Backup | ~10 papers when working | HTTP 429 rate limited - use jitter + 5 retries |
| Polymarket | ✅ Working | 70+ AI markets | `response.data[0].tokens[]` format |
| Semantic Scholar | ❌ Broken | 0 papers | HTTP 404 without API key |
| Blogwatcher | ✅ Working | 10-20 articles | Most reliable source |

**Key Learning: OpenAlex replaced ArXiv as the PRIMARY paper source** because ArXiv gets rate limited and Semantic Scholar needs an API key that isn't configured. OpenAlex has NO rate limits and returns 13,000+ AI agent papers.

## Research Scripts (in /home/opc/.hermes/harness/scripts/)

| Script | Purpose | Key Finding |
|--------|---------|-------------|
| `research-openalex.js` | **NEW - PRIMARY paper source** | No rate limits, 100% free, returns detailed paper metadata |
| `research-arxiv.js` | ArXiv academic paper search | Needs retry with jitter (3→6→12→24→48s exponential backoff) |
| `research-semantic.js` | Semantic Scholar paper search | Returns HTTP 404 without API key - DO NOT rely on this |
| `research-blogwatcher.js` | RSS feed monitoring | Fixed CDATA parsing with regex |
| `research-polymarket.js` | Prediction market data | `response.data[0].tokens[]` array format, not `outcomePrices` |
| `research-all.js` | Unified multi-source report | Now integrates 5 sources with OpenAlex as primary |

## Quick Commands

```bash
cd /home/opc/.hermes/harness

# Generate unified research report (OpenAlex primary + ArXiv backup + Polymarket + Blogwatcher)
node scripts/research-all.js "AI agent" --max=5

# Individual sources
node scripts/research-openalex.js "AI" --max=5
node scripts/research-arxiv.js "AI" --max=5
node scripts/research-polymarket.js "AI"
node scripts/research-blogwatcher.js
```

## Report Output

- Markdown: `reports/unified-research-*.md`
- JSON: `reports/unified-research-*.json`
- HTML: `reports/unified-research-*.html`
- Gdrive: `gdrive:/OpenClaw_Backups/Harness-Reports/`

## PDF Generation from Report

```bash
# Convert MD to HTML first (use python markdown module)
python3 -c "import markdown; html = markdown.markdown(open('report.md').read())"

# Then convert to PDF with weasyprint
weasyprint report.html output.pdf
```

## ArXiv Search Tips

- "harness engineering" returns NO results on ArXiv (too new, industry-focused term)
- Use related terms: "agent framework", "autonomous AI agent", "multi-agent LLM", "LLM software engineering"
- ArXiv is 6-12 months behind industry practice

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   Research Harness                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   OpenAlex   │  │ Polymarket   │  │  Semantic    │    │
│  │  PRIMARY     │  │  預測市場    │  │  Scholar     │    │
│  │  13k+ papers │  │  70+ markets │  │  (needs key) │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │   ArXiv      │  │ Blogwatcher  │  │ Feature      │    │
│  │  (backup)   │  │  RSS 監控    │  │ Flags System  │    │
│  │  429 limited │  │  20 articles │  │ 緊急開關     │    │
│  └──────────────┘  └──────────────┘  └──────────────┘    │
│                           ↓                                 │
│              ┌──────────────────┐                         │
│              │   統一報告生成     │                         │
│              │   (JSON/MD/HTML)  │                         │
│              └──────────────────┘                         │
└─────────────────────────────────────────────────────────────┘
```

## Feature Flags System

The harness includes a **Feature Flag system** for granular control over research sources and behaviors. This allows emergency shutdown of specific sources without code changes.

### Files
- `lib/feature-flags.js` - Core Feature Flag engine
- `scripts/feature-flags-cli.js` - CLI management tool

### Usage
```bash
cd /home/opc/.hermes/harness

# List all flags
node scripts/feature-flags-cli.js list

# Enable/disable flags
node scripts/feature-flags-cli.js enable research-arxiv
node scripts/feature-flags-cli.js disable research-polymarket

# Emergency mode (disable ALL research)
node scripts/feature-flags-cli.js emergency
node scripts/feature-flags-cli.js exit-emergency

# View summary
node scripts/feature-flags-cli.js summary
```

### Flag List
| Flag | Default | Purpose |
|------|---------|---------|
| `research-openalex` | ✅ ON | Primary paper source (no rate limit) |
| `research-arxiv` | ❌ OFF | Backup paper source (rate limited) |
| `research-polymarket` | ✅ ON | Prediction market data |
| `research-blogwatcher` | ✅ ON | RSS feed monitoring |
| `research-semantic` | ❌ OFF | Needs API key |
| `ai-summary` | ❌ OFF | AI-powered summary (needs LLM API) |
| `report-html/json` | ✅ ON | Report format output |
| `report-gdrive-upload` | ✅ ON | Auto-upload to GDrive |
| `research-retry-arxiv` | ✅ ON | Retry on rate limit |
| `kill-all-research` | ❌ OFF | Emergency kill switch |
| `kill-polymarket` | ❌ OFF | Emergency Polymarket disable |

### Integration with research-all.js
All 5 research sources are controlled by Feature Flags:
```javascript
if (this.flags.isEnabled('research-openalex')) {
  // fetch OpenAlex papers
} else {
  console.log('⏭️  Disabled via feature flag');
}
```

### Reference: AI-First SDLC Paper Insights
**Paper:** "AI-First Software Development Lifecycle: An Agent-Driven Framework for Autonomous Planning, Coding, Testing, and Deployment" (2026)
**Authors:** Ambar Nath Saha, Debashis Patra
**DOI:** 10.5281/zenodo.19506964

Key concepts implemented in Harness:
1. **Central Orchestrator Agent** - Coordinates specialized agents (Backlog Planning, Code Generation, Testing, CI/CD, etc.)
2. **Automated Testing Agent** - Rigorous testing with mutation testing
3. **Self-Healing Systems** - Production monitoring + autonomous hotfix generation
4. **Feature Flags** - Control feature rollout and emergency shutdown

The Feature Flag system in Harness is inspired by the "Kill Switches" concept from this paper.

## Quick Start

```bash
cd /home/opc/.hermes/harness

# Individual tools
node scripts/research-arxiv.js "AI agent" --max=5
node scripts/research-polymarket.js "AI"
node scripts/research-blogwatcher.js
node scripts/research-semantic.js "machine learning" --max=5

# Unified report (recommended)
node scripts/research-all.js "AI agent" --max=5
```

## Components

### 1. ArXiv Research (`research-arxiv.js`)

Search academic papers from ArXiv.

**Features:**
- Keyword search with category filtering
- Automatic retry on rate limit (429)
- XML parsing to structured JSON/MD
- Sorted by date or relevance

**Key Implementation Notes:**
- ArXiv returns HTTP 429 when rate limited — implement retry logic
- Use `sortBy=submittedDate` for latest papers
- API: `https://export.arxiv.org/api/query`

### 2. Polymarket Research (`research-polymarket.js`)

Fetch prediction market data from Polymarket.

**Features:**
- Search markets by keyword
- Probability and volume data
- Mock data fallback when API unavailable

**API:** `https://clob.polymarket.com/markets`

### 3. Blogwatcher (`research-blogwatcher.js`)

Monitor RSS/Atom feeds for latest articles.

**Features:**
- Add/remove feed sources
- Automatic RSS and Atom parsing
- Tracks read/unread state
- Persistent state in JSON

**RSS Parsing Notes (Important):**
The original regex-based parsing had issues with CDATA content. Use **split-based parsing** instead:

```javascript
// Instead of complex regex, use string splitting
const items = content.split('<item>').slice(1);
for (const item of items) {
  const endIndex = item.indexOf('</item>');
  const itemContent = item.substring(0, endIndex);
  // Then extract fields with simple _extract() helper
}

// Simple CDATA extractor that works:
_extract(item, tag) {
  // Try CDATA first
  const cdataRegex = new RegExp(`<${tag}[^>]*>\\s*<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>\\s*<\\/${tag}>`, 'i');
  const cdataMatch = item.match(cdataRegex);
  if (cdataMatch) return cdataMatch[1].trim();
  
  // Simple text fallback
  const textRegex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i');
  const textMatch = item.match(textRegex);
  return textMatch ? textMatch[1].trim() : '';
}
```

### 4. Semantic Scholar (`research-semantic.js`)

Search academic papers with citation data.

**Features:**
- JSON API (easier than ArXiv XML)
- Citation counts and influence metrics
- Author profiles
- Rate limit: 100 requests/hour (free)

**API:** `https://api.semanticscholar.org/graph/v1`

### 6. OpenAlex Research (`research-openalex.js`) ⭐ PRIMARY

**NEW - Recommended as the primary paper source.** No rate limits, 100% free API.

**Features:**
- Title search with relevance scoring
- Returns 13,000+ AI agent papers (vs ArXiv's ~10 when rate limited)
- Author names, publication date, DOI, citations, open access status
- 100% free, no API key needed

**API:** `https://api.openalex.org/works?filter=title.search:{keyword}&sort=relevance_score:desc&per_page={n}`

**URL encoding:** Use `encodeURIComponent(keyword)` for multi-word searches.

**Example:**
```javascript
const response = await fetch(`https://api.openalex.org/works?filter=title.search:${encodeURIComponent(keyword)}&sort=relevance_score:desc&per_page=10`);
const data = await response.json();
const papers = data.results.map(work => ({
  title: work.title,
  authors: work.authorships.map(a => a.author.display_name),
  published: work.publication_date,
  doi: work.doi,
  citations: work.citation_count,
  openAccess: work.open_access?.is_oa
}));
```

### 7. Unified Report (`research-all.js`)

Generate comprehensive reports combining all 5 sources.

**Integration order (as of 2026-05-10):**
1. OpenAlex (primary - no rate limit) ✅ 13,006 papers
2. ArXiv (backup - 429 rate limited) ✅ 10 papers
3. Polymarket (working) ✅ 71 markets
4. Semantic Scholar (broken - 404) ❌
5. Blogwatcher (working) ✅ 20 articles

**Output Formats:**
- Markdown (`.md`)
- JSON (`.json`)
- HTML (`.html`)

## File Structure

```
/home/opc/.hermes/harness/
├── core/                    # Debug Harness framework
│   ├── index.js            # Main class
│   ├── error-detector.js   # Error interception
│   ├── network-monitor.js  # API monitoring
│   └── report-generator.js # Report generation
├── scripts/
│   ├── research-arxiv.js        # ArXiv integration
│   ├── research-polymarket.js    # Polymarket integration
│   ├── research-blogwatcher.js   # RSS monitoring
│   ├── research-semantic.js      # Semantic Scholar
│   └── research-all.js          # Unified report
├── reports/                # Output reports
└── state/                 # Persistent state
```

## Default RSS Feeds

```javascript
const DEFAULT_FEEDS = [
  { name: 'TechCrunch', url: 'https://techcrunch.com/feed/' },
  { name: 'The Verge', url: 'https://www.theverge.com/rss/index.xml' },
  { name: 'ArXiv CS.AI', url: 'https://arxiv.org/rss/cs.AI' },
  { name: 'Hacker News', url: 'https://hnrss.org/frontpage' }
];
```

## Automation

### Cron Setup

```bash
# Morning research (08:00) - expanded engineering-focused topics
0 8 * * * /home/opc/daily_research.sh >> /home/opc/logs/research_cron.log 2>&1

# Nightly analysis (21:00) - Harness self-diagnostics + optimization recommendations
0 21 * * * /home/opc/nightly_harness_analysis.sh >> /home/opc/logs/harness_analysis.log 2>&1

# Check current crontab
crontab -l
```

### Daily Script - Expanded Topics

The `daily_research.sh` now runs **6 topics** in two batches:

**Morning (08:00) - Core AI:**
- `AI agent framework`
- `autonomous testing`

**Afternoon (17:00) - Engineering Focus:**
- `harness framework engineering`
- `test automation AI`
- `agent orchestration`
- `debugging framework AI`

### Nightly Analysis Script

`/home/opc/nightly_harness_analysis.sh` at 21:00:
- Reads latest research reports from `reports/unified-research-*.md`
- Runs `DebugHarness` self-diagnostics
- Generates `/home/opc/.hermes/harness/analysis/analysis-YYYY-MM-DD.md` with:
  - Research data quality matrix (ArXiv/Polymarket/Semantic/Blogwatcher counts)
  - Harness system health status
  - Optimization recommendations based on detected errors
  - Next steps

### Known Issues (as of 2026-05-10)

| Issue | Source | Impact | Status |
|-------|--------|--------|--------|
| ArXiv 429 Rate Limit | research-arxiv.js | ~10 papers retrieved (backup mode) | Fixed with exponential backoff + jitter (3→6→12→24→48s) |
| Semantic Scholar 404 | research-semantic.js | 0 papers retrieved | DEPRECATED - Use OpenAlex instead |
| OpenAlex | research-openalex.js | ✅ 13,006 papers (primary) | WORKING - No rate limits |
| Polymarket | research-polymarket.js | ✅ 71+ markets | WORKING - `response.data[0].tokens[]` format confirmed |
| Blogwatcher | research-blogwatcher.js | ✅ 20 articles | Only reliable source |

### Daily Script Template

```bash
#!/bin/bash
LOG_FILE="/home/opc/logs/research_cron.log"
HARNESS_DIR="/home/opc/.hermes/harness"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

cd "$HARNESS_DIR"

# Multiple topics
TOPICS=("AI agent" "machine learning")
for topic in "${TOPICS[@]}"; do
    node scripts/research-all.js "$topic" --max=5 >> "$LOG_FILE" 2>&1
done

# Upload to GDrive
node scripts/upload-report.js >> "$LOG_FILE" 2>&1
```

## Troubleshooting

### ArXiv Rate Limit (429)
```javascript
// Add retry logic
async _request(path, retries = 3, delay = 5000) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await this._doRequest(path);
    } catch (error) {
      if (error.message.includes('429') && attempt < retries) {
        console.log(`Rate limited, retrying in ${delay/1000}s...`);
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
      throw error;
    }
  }
}
```

### RSS Parsing Issues
```javascript
// Use split-based parsing instead of regex for <item>/</item>
const items = content.split('<item>').slice(1);
for (const item of items) {
  const endIndex = item.indexOf('</item>');
  const itemContent = item.substring(0, endIndex);
  // Extract fields with _extract() helper
}
```

### pymupdf Import Error
```bash
# If module not found, use system Python with explicit path
PYTHONPATH=/home/opc/.local/lib/python3.9/site-packages python3 script.py

# Check where pymupdf is installed
pip show pymupdf | grep Location
```

## Report Output

Reports are saved to:
```
/home/opc/.hermes/harness/reports/
├── research-*.md/json          # Individual ArXiv reports
├── polymarket-*.json          # Polymarket reports
├── semantic-*.md/json         # Semantic Scholar reports
├── unified-research-*.md/json/html  # Combined reports
└── report-*.md/json/html      # Debug Harness reports
```

## GDrive Upload

```bash
# Manual upload
node scripts/upload-report.js

# Or use rclone directly
rclone copy /home/opc/.hermes/harness/reports/ gdrive:/OpenClaw_Backups/Harness-Reports/
```

## Related Skills

- `arxiv` — ArXiv API details and search syntax
- `ocr-and-documents` — PDF extraction with pymupdf/marker
