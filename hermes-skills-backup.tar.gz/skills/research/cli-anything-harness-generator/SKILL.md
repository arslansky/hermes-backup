---
name: cli-anything-harness-generator
description: HKUDS framework for auto-generating AI Agent harnesses to control any software via CLI + structured JSON
version: 1.0
created: 2026-05-19
tags: [ai-agent, open-source, hku, taskforge]
---

# CLI-Anything (HKUDS) — AI Agent Native Software Control

## What It Is
HKUDS (Hong Kong University) open-source framework that auto-generates AI Agent harnesses for any software — no API, no UI automation, just CLI command + structured JSON output.

GitHub: https://github.com/HKUDS/CLI-Anything
Stars: 36,592 | +1,047 today (2026-05-19)

## Core Value
If TaskForge Worker needs to control a software tool, instead of researching its API:
1. Generate a harness via CLI-Anything pipeline
2. Run CLI commands from Python subprocess
3. Parse structured JSON output
4. TaskForge dispatches and parses

## Architecture
- **40+成熟harness**: GIMP, Blender, QGIS, Draw.io, Obsidian, LibreOffice, FFmpeg, ImageMagick...
- **7-stage pipeline**: Analysis → Design → Implementation → Testing → Documentation → Preview → Publish
- **Preview Bundle protocol**: Standardized intermediate result format
- **CLI-Hub marketplace**: `pip install cli-anything-hub` ecosystem
- **2,280+ tests**: All real software validation

## Key Insight
The "Preview Bundle" is the contract — software outputs to a standard JSON structure that any agent can parse. This decouples the software from the agent.

## Connection to TaskForge
TaskForge Worker on Oracle VM could use CLI-Anything harnesses to control software tools, dispatching via subprocess + JSON parsing — same pattern as existing heavy tier routing.