---
name: harness-engineering-research
description: Research workflow for finding and synthesizing Harness Engineering concepts from ArXiv, local PDFs, and web resources. Use when: Harness research, engineering synthesis, research pipeline
category: research
---

# Harness Engineering Research Skill

Research workflow for finding and synthesizing information about Harness Engineering concepts.

## Data Sources

### Local PDFs (already on VM)
- `/home/opc/.openclaw/media/inbound/Default_Harness_Engineering_到底是什么_概念_实战与争议_一次全部讲---549f16e4-904b-4d6e-a7cc-cdcfe9a81e28.pdf` - Chinese comprehensive guide (9 pages)
- `/home/opc/.openclaw/media/inbound/Default_Agent_Harness_vs_Everything_Else...` - English technical breakdown (6 pages, 9 components)

### ArXiv Search
```bash
curl -s "https://export.arxiv.org/api/query?search_query=all:agent+framework&start=0&max_results=10&sortBy=submittedDate&sortOrder=descending"
```

### Local Guides
- `/home/opc/.openclaw/workspace/guides/HARNESS_ENGINEERING_GUIDE.md` - Main guide

## Key Concepts (from PDFs)

### Core Formula
```
Harness = Agent − Model
```

### 9 Core Components
1. Iteration Loop - while 迴圈控制整個流程
2. Context Management - 80-90% 觸發 compaction
3. Skills & Tools - 工具原語 + 技能
4. Sub-agent Management - 任務太大時隔離子會話
5. Built-in Skills - Git commit, PR, 測試運行
6. Session Persistence - append-only JSON，崩潰可恢復
7. System Prompt Assembly - 動態掃描加載 agents.md
8. Lifecycle Hooks - Pre-tool + Post-tool 擴展
9. Permissions - read/workspace/full 動態分類

### Depth-First Principle
> "When something failed, the fix was almost never 'try harder.'"

When a task fails:
1. Stop and ask: "What capability is the system missing?"
2. Build that building block
3. Use it to unlock more complex tasks

NOT: repeatedly trying the same failing approach.

### Three-Layer Evolution
| Layer | Question | Core Issue |
|-------|----------|------------|
| Prompt Engineering | How to ask | Organizing prompts clearly |
| Context Engineering | How to give info | Right timing, right content in context |
| Harness Engineering | How to build system | Building reliable agents around LLMs |

### OpenAI Metrics
- 3.5 PRs/engineer/day throughput
- 1/10 time vs human coding
- ~100万行 code in 5 months
- 3 → 7 engineers initially

## Automated Pipeline (Setup Completed 2026-05-10)

### Daily Research Cron
- **08:00**: Run `daily_research.sh` — topics: AI agent framework, autonomous testing
- **17:00**: Additional topics: harness framework engineering, test automation AI, agent orchestration, debugging framework AI
- **Reports**: `/home/opc/.hermes/harness/reports/unified-research-*.md`

### Nightly Analysis Cron (21:00)
- **Script**: `/home/opc/nightly_harness_analysis.sh`
- **Output**: `/home/opc/.hermes/harness/analysis/analysis-YYYY-MM-DD.md`
- **Checks**: ArXiv rate limit status, Semantic Scholar API status, Blogwatcher health
- **Actions**: Runs Harness self-diagnostics, generates optimization recommendations

### GDrive Upload
- Reports auto-uploaded to `gdrive:/OpenClaw_Backups/Harness-Reports/`
- Script: `upload-report.js`

## Workflow

1. **Day**: Crons run research at 08:00 and 17:00
2. **Night (21:00)**: Analysis script checks system health + research quality
3. **Review**: Check `/home/opc/.hermes/harness/analysis/` for recommendations
4. **Iterate**: Use insights to improve Harness components

## Known Issues & Fixes

### ArXiv Rate Limiting
- **Problem**: ArXiv returns 429 when over-requested (3+ requests quickly)
- **Fix**: Exponential backoff with jitter (3s → 6s → 12s → 24s → 48s), 5 retries max
- **Files**: `research-arxiv.js` has this implemented
- **Tip**: Wait 1+ hour between intensive requests

### OpenAlex (PRIMARY paper source - use first)
- **URL**: `https://api.openalex.org/works?filter=title.search:{keyword}&per_page={n}`
- **Why**: 100% free, no API key needed, no rate limits
- **Usage**: `const { OpenAlexResearch } = require('./research-openalex');`
- **Result format**: `{ count, papers, total }` where papers have `title`, `authors`, `published`, `doi`, `citations`, `openAccess`

### Semantic Scholar API
- **Problem**: Returns 429 "Too Many Requests" without API key
- **Fix**: Get free API key from https://api.semanticscholar.org (100 req/hour)
- **Alternative**: Use OpenAlex as primary, ArXiv as backup

### Polymarket API
- **Endpoint**: `https://clob.polymarket.com/markets`
- **Fix**: Response uses `response.data` (not top-level data) and `tokens[]` array for market details
- **Probability**: Use `outcomePrices.Yes` field, multiply by 100 for percentage

## Key Research Papers Discovered

### AI-First SDLC (2026) — Must Read
- **Title**: "AI-First Software Development Lifecycle: An Agent-Driven Framework for Autonomous Planning, Coding, Testing, and Deployment"
- **Authors**: Ambar Nath Saha, Debashis Patra
- **URL**: https://zenodo.org/doi/10.5281/zenodo.19506964
- **Key Findings**:
  - Central Orchestrator Agent coordinates specialized agents (backlog planning, code gen, testing, CI/CD, monitoring)
  - Human role shifts from "doing" to "governing"
  - Self-healing systems with autonomous hotfix generation
  - Mutation testing for coverage validation
- **Tech Stack**: Docker, Argo CD, Prometheus, Datadog, LaunchDarkly, Jenkins, Kubernetes

### JAT: Test Automation Framework for Multi-Agent Systems (2007)
- **Citations**: 36 | Authors: Coelho, Lucena et al.
- **Key**: Early work on multi-agent testing, regression testing, async communication

### CATest: Test Automation Framework for Multi-Agent Systems (2012)
- **Citations**: 10 | Authors: Shufeng Wang, Hong Zhu
- **Key**: Formal specification, correctness verification, automation

## Feature Flags in Harness Systems

Feature Flags enable gradual rollout, risk control, and A/B testing without redeployment.

### Core Concepts
- **Release Flags**: Control feature visibility (default: OFF)
- **Experiment Flags**: A/B testing with user groups
- **Ops Flags**: Runtime behavior control (disable non-essential features under load)
- **Kill Switches**: Emergency one-click disable

### Harness Applications
```javascript
// Research data source control
flags = { openalex-primary: true, polymarket: true, blogwatcher: false }

// Emergency degradation
flags = { disable-llm-summary: true, disable-polymarket: true, research-timeout-reduced: true }

// Gradual rollout
flags = { new-report-format: false }  // → 10% → 50% → 100%
```

### Implementation Pattern
```javascript
class FeatureFlags {
  constructor() {
    this.flags = { 'new-feature': false };
  }
  isEnabled(flag) { return this.flags[flag] || false; }
  enable(flag) { this.flags[flag] = true; }
  disable(flag) { this.flags[flag] = false; }
}
```

## Commands

```bash
# OpenAlex paper search (free, no rate limit - use PRIMARY)
node -e "
const { OpenAlexResearch } = require('./scripts/research-openalex');
const openalex = new OpenAlexResearch({ maxResults: 10 });
openalex.search('keyword').then(r => {
  const p = openalex.parseResults(r);
  console.log('Total:', p.total, 'papers');
  p.papers.forEach((t,i) => console.log((i+1)+'. '+t.title));
});
"

# Unified research report (OpenAlex + ArXiv + Polymarket + Blogwatcher)
cd /home/opc/.hermes/harness && node scripts/research-all.js "AI agent"

# Generate unified research report

```bash
# ArXiv search (manual test)
curl -s "https://export.arxiv.org/api/query?search_query=all:KEYWORD&start=0&max_results=5&sortBy=submittedDate&sortOrder=descending"

# PDF to text
pdftotext -layout /path/to/pdf - | head -200

# Generate unified research report
cd /home/opc/.hermes/harness
node scripts/research-all.js "keyword" --max=5

# Run nightly analysis (checks Harness health + generates recommendations)
bash /home/opc/nightly_harness_analysis.sh

# Check analysis reports
cat /home/opc/.hermes/harness/analysis/analysis-$(date +%Y-%m-%d).md

# Convert to PDF
pandoc /home/opc/.hermes/harness/reports/REPORT.md -o /home/opc/REPORT.pdf
```
