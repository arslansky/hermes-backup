---
name: daily-morning-briefing
title: Daily Morning Briefing
description: "Fetch GitHub Trending repos and Hacker News top stories, compile a concise morning briefing report, and deliver to the user's chat. Use when: daily briefing, morning briefing, GitHub trending, Hacker News"
trigger: "Cron job running at 05:00-05:30 daily"
---

# Daily Morning Briefing

## Overview
Every morning, scrape GitHub Trending (today) and Hacker News (front page), then compile a concise briefing report. The report focuses on AI/tooling/dev projects from GitHub and notable tech stories from HN, formatted for quick reading.

## Steps

### 1. Fetch GitHub Trending (Today)
Navigate to `https://github.com/trending` and extract the top 10 repos.

For each repo, capture:
- Repo name (e.g. `bytedance / UI-TARS-desktop`)
- Description paragraph
- Language (e.g. TypeScript, Python)
- Stars count + stars today
- URL (construct from: `https://github.com/{owner}/{repo}`)

**⚠️ Pitfall: Snapshot truncation.** The GitHub Trending page typically has 15+ repo articles, but `browser_snapshot` truncates the accessibility tree at ~8000 chars — often only returning the first ~6 repos. To get the full list, use `browser_console()` with JavaScript to extract data from all `<article>` elements:

```javascript
// After navigating to github.com/trending, get all repos:
Array.from(document.querySelectorAll('article')).map(a => {
  const h2 = a.querySelector('h2')?.textContent?.trim().replace(/\s+/g, ' ') || '';
  const desc = a.querySelector('p')?.textContent?.trim() || '';
  const text = a.textContent;
  const langMatch = text.match(/\b(Python|Rust|TypeScript|Go|Shell|Java|C\+\+|C#|Ruby|JavaScript|Zig|Lua|Swift|C)\b/);
  const todayMatch = text.match(/([\d,]+)\s*stars?\s*today/i);
  return { name: h2, desc, lang: langMatch?.[1] || '?', today: todayMatch?.[1] || '0' };
});
```

Use the snapshot for the first ~6 repos (clean structured data), then JavaScript extraction for the remaining items.

### 2. Fetch Hacker News Front Page
Navigate to `https://news.ycombinator.com/` and extract top 10 stories.

For each story, capture:
- Title
- URL (the external link, not HN)
- Points
- Comment count
- Time posted

**⚠️ Pitfall: Snapshot truncation.** The HN page also truncates. Use `browser_console()` with JS to extract structured data:

```javascript
// After navigating to news.ycombinator.com:
const rows = document.querySelectorAll('.athing');
const results = [];
for (let i = 0; i < Math.min(rows.length, 30); i++) {
  const a = rows[i];
  const titleEl = a.querySelector('.titleline a');
  if (!titleEl) continue;
  const sub = a.nextElementSibling?.querySelector('.subline');
  const commentLinks = sub?.querySelectorAll('a');
  const commentEl = commentLinks?.[commentLinks.length-1];
  results.push({
    rank: a.querySelector('.rank')?.textContent?.trim(),
    title: titleEl.textContent?.trim(),
    url: titleEl.href,
    points: sub?.querySelector('.score')?.textContent || '?',
    comments: commentEl?.textContent?.includes('comment') ? commentEl.textContent : '0 comments',
    time: sub?.querySelector('.age')?.textContent
  });
}
```

You can also use `document.body.innerText` to quickly dump both page texts for reading — great for scanning.

### 3. Compile Report
Format into a clean briefing with three sections:

#### Today's GitHub Trends 🔥
Top repos with brief description + stars today. Highlight anything AI/tooling/agent-related.

#### Hacker News Highlights 📰
Stories ranked by points. Brief 1-line summary of each. Note interesting comments count.

#### Key Takeaways 📌
1-3 bullet points on what's most relevant or interesting.

### 4. Deliver
Send the report as the final response. The cron system handles delivery automatically.

## Notes
- Both sites are browsable without auth
- Use browser_navigate + browser_console(JS) for full extraction when snapshots truncate
- Keep it concise — this is a morning read, not a deep dive
- Target ~500-800 words total
