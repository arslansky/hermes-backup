---
name: harness-gap-analysis
description: Systematic gap analysis of Hermes Harness vs industry-standard agent frameworks — research sources, comparison dimensions, and actionable recommendations. Use when: gap analysis, Hermes Harness, industry comparison, missing features
category: research
---

# Harness Gap Analysis

Systematically compare the Hermes Harness system against industry-standard agent frameworks (Codex CLI, LangGraph, AutoGen, CrewAI, smolagents) and generate actionable improvement recommendations.

## Trigger

Use this skill when the user asks to compare Hermes against other frameworks, wants to know "what's missing", or asks about industry standard agent infrastructure.

## Research Sources

| Framework | GitHub | Stars | Key Feature |
|-----------|--------|-------|-------------|
| **OpenAI Codex CLI** | github.com/openai/codex | 81.5k | Lightweight coding agent, ACP protocol, sandboxed exec |
| **LangGraph** | github.com/langchain-ai/langgraph | 31.6k | StateGraph-based workflow engine, checkpointing, LangSmith tracing |
| **AutoGen (MS)** | github.com/microsoft/autogen | 57.9k | Multi-agent conversations, nested human-in-the-loop |
| **CrewAI** | github.com/crewAIInc/crewAI | 51.1k | Role-based agents, task delegation, Flow orchestration |
| **smolagents (HF)** | github.com/huggingface/smolagents | 27.2k | Code-as-action agents, GAIA benchmark runner |

## Comparison Dimensions

### 🛑 Missing (Critical — must build)
1. **Graph-based Workflow Engine** — LangGraph has StateGraph, Hermes only has linear loop. Need: conditional branching, parallel nodes, retry/fallback edges, YAML workflow definitions
2. **Agent-to-Agent Communication** — AutoGen/CrewAI have multi-agent chat/events. Hermes delegate_task is black-box one-shot
3. **Evaluation/Benchmark Framework** — smolagents runs GAIA, AutoGen has AutoGen Bench. Hermes has zero evaluation infrastructure

### ⚠️ Missing (Important — should build)
4. **Telemetry/Tracing** — LangSmith, AgentOps, Langfuse (OpenTelemetry-based). Hermes has no structured tracing
5. **Sandbox Security Isolation** — Codex CLI uses restricted env, smolagents has code executors. Hermes only has TIRITH approval
6. **Multi-Provider Smart Routing** — Task-type aware, cost-aware model selection
7. **Rate Limiting / Cost Management** — No token counting or budget tracking at all

### 🔵 Missing (Nice to have)
8. **Session Replay / Debug Mode** — LangGraph Studio has step-by-step debugger
9. **Human-in-the-Loop Workflow Handoff** — Complex approval workflows with context preservation
10. **Tool Marketplace** — MCP ecosystem, installable tools from registry

## Methodology

1. Visit each framework's GitHub README for key features and architecture
2. Compare each feature against what Hermes Harness currently has
3. For features Hermes lacks: determine if it's a missing capability (gaps 1-3) or an enhancement (gaps 4-10)
4. Prioritize by: (a) does it unlock new use cases, (b) is it standard industry practice, (c) implementation complexity

## Priority Order (Recommended)

```
Week 1  → Workflow Engine (biggest impact, unblocks most patterns)
Week 2  → Eval Framework (quality assurance, benchmarks)
Week 3  → Telemetry/Tracing (debuggability)
Week 4+ → Sandbox + Cost Management
```

## Known Pitfalls

- LangGraph is 31.6k stars but has 6,831 commits — building a graph engine is non-trivial. Start with a minimal DAG runner, not a full state machine
- AutoGen was recently put into "maintenance mode" (Apr 2026) — learn from their architecture but don't copy their mistakes (over-engineered)
- Codex CLI has 3003 branches — it's very actively developed; use it as the "state of the art" reference for coding agent UX
- CrewAI's Flow API (crew-to-flow migration guide just released May 2026) is the best pattern for simple pipeline orchestration — study it before designing the Hermes workflow engine
- smolagents' GAIA benchmark runner is the simplest eval framework to reference — ~500 lines of code
