---
name: oracle-vm-systemd-debug
description: Oracle VM systemd EACCES debugging — SELinux Enforcing causing Permission denied on valid executables
category: devops
---

# Oracle VM Systemd Debugging

## Context
Oracle Cloud VM (Oracle Linux 7) with SELinux Enforcing. Hermes gateway configured via systemd service.

## Symptom
systemd service fails with:
```
Failed to locate executable /home/opc/.hermes/hermes-agent/venv/bin/python: Permission denied
```
Exit code 203/EXEC. Retries 40,000+ times.

## Root Cause

On Oracle Cloud VM with SELinux Enforcing, systemd services running as `User=opc` on user-owned Python installations under `/home/` get EACCES even when:
- The binary is executable by all (`rwxr-xr-x`)
- Direct execution works
- The symlink target is valid

The venv python is a symlink to UV bare python:
```
venv/bin/python -> /home/opc/.local/share/uv/python/cpython-3.11-linux-x86_64-gnu/bin/python3.11
```

The actual running gateway (PID 536802) is NOT managed by systemd — it was started manually and keeps running. Cron jobs work because this manual process is alive.

## Verification Commands
```bash
# Check if gateway is actually running (not via systemd)
ps aux | grep hermes

# Test direct execution
sudo /home/opc/.hermes/hermes-agent/venv/bin/python -c "print('hello')"

# Check SELinux status
getenforce

# Check running process's SELinux context
ps -eo pid,label,cmd | grep 536802
```

## Workaround
Use background nohup instead of systemd:
```bash
nohup /home/opc/.hermes/hermes-agent/venv/bin/python -m hermes_cli.main gateway run --replace &
```

## Related: Telegram Composite chat_id Bug
When `deliver=origin` with composite chat_id like `"-1003654034759:1907"`, `_create_dm_topic()` fails with `int()` error. The `send()` method handles this but `_create_dm_topic()` doesn't.

File: `gateway/platforms/telegram.py` line ~459