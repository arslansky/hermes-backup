---
name: fable-light
description: Fable-style reasoning components — complexity analysis, domain expertise assessment, and answer quality evaluation
triggers:
  - /fable
  - /quality
  - complexity analysis
  - assess expertise
---

# Fable Light

Fable-style reasoning components extracted from the Big VM's `fable_reasoner.py`.

## Components

### 1. Complexity Analysis
Automatically classifies question complexity into 5 levels:
- **TRIVIAL** (0) — greetings, one-liners
- **SIMPLE** (1) — basic factual questions
- **MODERATE** (2) — analysis, explanations, comparisons
- **COMPLEX** (3) — multi-step reasoning, architecture
- **VERY_COMPLEX** (4) — expert-level deep reasoning

### 2. Domain Expertise Assessment
Based on Anthropic research — domain expertise matters more than coding skill:
- **NOVICE** (0) — needs basic explanations
- **BEGINNER** (1) — needs clear guidance
- **INTERMEDIATE** (2) — optimal cost/performance balance
- **ADVANCED** (3) — needs deep analysis
- **EXPERT** (4) — needs professional-grade output

### 3. Answer Quality Evaluator
5-dimension scoring:
- Structure (0-10)
- Depth (0-10)
- Relevance (0-10)
- Actionability (0-10)
- Clarity (0-10)
- Overall: 優秀(≥8) / 良好(≥6) / 需改進(<6)

## Usage

### As Python module

```python
import sys
sys.path.insert(0, '/home/opc/.hermes/scripts')
from fable_components import analyze_complexity, assess_domain_expertise, AnswerEvaluator, Complexity

question = "設計一個高併發系統，必須滿足 CAP 定理嘅邊界條件"
c = analyze_complexity(question)
e = assess_domain_expertise(question)
print(f"複雜度: {c.name}, 專業度: {e.name}")

evaluator = AnswerEvaluator()
result = evaluator.evaluate(answer="...", question=question, complexity=c)
print(f"質量: {result['total_score']}/10 ({result['quality_level']})")
```

### As skill (via `/fable` or `/quality`)

- `/fable <question>` — analyze question complexity and expertise level
- `/quality <answer> vs <question>` — evaluate answer quality against a question

## Files

- `/home/opc/.hermes/scripts/fable_components.py` — core library
- `/home/opc/.hermes/fable_memory.db` — SQLite memory store (auto-created)
