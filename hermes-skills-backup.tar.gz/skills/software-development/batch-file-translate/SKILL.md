---
name: batch-file-translate
description: 批量翻譯大型文字檔案（30KB+）做中文，使用 terminal() 一次性 Python script 方案. Use when: batch translate, file translation, bulk translate, Chinese translation
trigger: 用戶要求將大型英文檔案翻譯做中文，尤其係多行/長檔案
metadata:
  hermes:
    tags: [translation, batch, Chinese, file-processing]
    related_skills: [systematic-debugging, writing-plans]
    triggers: ["translate", "translation", "Chinese", "batch translate", "bulk", "files"]
    red_flags:
      - "I'll translate them one by one with write_file"
      - "The files are small enough to do manually"
      - "I can use read_file/write_file in a loop"
      - "A subagent can handle this"
    iron_laws:
      - "USE terminal() WITH A SINGLE PYTHON SCRIPT FOR BATCH TRANSLATION"
      - "DO NOT USE read_file/write_file IN A LOOP — USE TERMINAL PYTHON"
---

# Batch File Translation (EN → 繁體中文)

## When to Use
- 用戶要求將 >500行文字檔案翻譯做中文
- 筆記、文件、文章等長篇內容
- 需要保留格式、術語中英對照

## Workflow

### DO NOT
- ❌ 用 delegate_task 翻譯大檔案 — output limit (~8KB) 會截斷
- ❌ 用 read_file() 讀同一檔案兩次 — cache bug 會回傳 "File unchanged..."
- ❌ 逐行 dict matching — 太多邊際情況match唔到

### DO
- ✅ 用 `terminal()` 行一次性 Python script

## Steps

### 1. 讀取原檔案
用 terminal 行 cat 或 python open()，唔好用 read_file tool：
```bash
python3 << 'PYEOF'
with open("/path/to/source.txt") as f:
    content = f.read()
lines = content.split('\n')
print(f"Read {len(content)} chars, {len(lines)} lines")
PYEOF
```

### 2. 分段翻譯策略
將內容拆做多個 ~200行區塊，逐塊翻譯再合併：
- Section headers / titles → 直接翻譯
- 專業術語 → 首次出現加英文對照：需求 (demand)
- 公式/代碼 → 保留不翻譯
- 比較表格 → 保留格式

### 3. 寫入腳本模式
```bash
python3 << 'PYEOF'
content = """..."""  # or open/read

translations = {
    "English text": "中文翻譯",
    # ...
}

for eng, chi in translations.items():
    content = content.replace(eng, chi)

with open("/path/to/output.txt", "w") as f:
    f.write(content)
print(f"Written {len(content)} chars")
PYEOF
```

### 4. 驗證
```bash
python3 -c "
with open('/path/to/output.txt') as f:
    lines = f.readlines()
# Check remaining English terms
import re
eng = [l for l in lines if re.search(r'\bDefinition\b|\bFormula\b|\bFactors\b', l)]
print(f'Remaining English lines: {len(eng)}')
"
```

## Pitfalls
- read_file() cache: 第二次讀同一檔案會回傳 dedup=True 假資料 (result.get("dedup") == True 或 "File unchanged" in str(result))
- 自動偵測：遇到 dedup=True 就唔好用 result 嘅 content，要用 subprocess.run(["cat", path], capture_output=True, text=True) 或 terminal() python open().read() 讀取真實內容
### read_file() cache trap — 自動偵測 + 修復
第二次讀同一檔案會回傳假資料（154 chars garbage），特徵：
- `result.get("dedup") == True`
- `"File unchanged since last read" in str(result)`

**自動修復 pattern（喺 execute_code 入面用）：**
```python
from hermes_tools import read_file
import subprocess

def safe_read(path):
    """read_file with cache bypass fallback"""
    result = read_file(path)
    # 偵測 cache 假資料
    if isinstance(result, dict) and result.get("dedup"):
        raw = subprocess.run(["cat", path], capture_output=True, text=True)
        lines = raw.stdout.split('\\n')
        return "\\n".join(lines)
    elif isinstance(result, str) and "File unchanged" in result:
        raw = subprocess.run(["cat", path], capture_output=True, text=True)
        return raw.stdout
    else:
        return result.get("content", "")

content = safe_read("/path/to/file.txt")
```

或者乾脆唔用 read_file，直接：
```python
import subprocess
raw = subprocess.run(["cat", path], capture_output=True, text=True)
content = raw.stdout
```

### delegate_task output limit
>8KB會被截斷 ("Response truncated due to output length limit")。大檔案用 terminal() Python script 一次過。

### 逐行 dict matching 唔可靠
太多邊際情況（空格、標點差異）會match唔到。應用 `replace()` 做整句匹配，或直接翻譯整個區塊。

### 中英文混排注意空格
中文前後唔使加空格，英文單字之間要保留空格。
