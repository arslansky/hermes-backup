---
name: subagent-driven-development
description: Use when executing implementation plans with independent tasks. Dispatches fresh delegate_task per task with two-stage review (spec compliance then code quality).
version: 1.1.0
author: Hermes Agent (adapted from obra/superpowers)
license: MIT
metadata:
  hermes:
    tags: [delegation, subagent, implementation, workflow, parallel]
    related_skills: [writing-plans, requesting-code-review, test-driven-development]
    triggers: ["execute plan", "implement tasks", "subagent", "delegate work", "parallel tasks", "batch execution"]
    red_flags:
      - "I can do all the tasks myself, no need for subagents"
      - "Spinning up subagents is overhead, faster to do it inline"
      - "The tasks are too simple to delegate"
      - "I'll lose context if I delegate"
    iron_laws:
      - "FRESH SUBAGENT PER TASK — NO CONTEXT POLLUTION"
      - "TWO-STAGE REVIEW AFTER EACH TASK: SPEC COMPLIANCE FIRST, THEN CODE QUALITY"
---

# Subagent-Driven Development

## Overview

Execute implementation plans by dispatching fresh subagents per task with systematic two-stage review.

**Core principle:** Fresh subagent per task + two-stage review (spec then quality) = high quality, fast iteration.

## When to Use

Use this skill when:
- You have an implementation plan (from writing-plans skill or user requirements)
- Tasks are mostly independent
- Quality and spec compliance are important
- You want automated review between tasks

**vs. manual execution:**
- Fresh context per task (no confusion from accumulated state)
- Automated review process catches issues early
- Consistent quality checks across all tasks
- Subagents can ask questions before starting work

## The Process

### 0. Pre-Flight: Define Shared API Contract (MANDATORY for multi-worker app builds)

Before dispatching ANY parallel workers, define and include in EVERY worker's context:

```
SHARED API CONTRACT (all workers must follow):
- File: api.js
  Exports: generateReportFromContent(rawText: string, templateId: string) → Promise<string>
  MUST use browser fetch(), NOT Node.js https module
  MUST attach generateReportFromContent to window object for browser access

- File: app.js
  Imports: window.generateReportFromContent (the global set by api.js)
  NEVER require/import api.js directly

- File: index.html
  Script load order: <script src="api.js"></script> BEFORE <script src="app.js"></script>
  Template dropdown values: bullet-emoji | three-section | info-cards (MUST match TEMPLATE_IDS)

- Template IDs (canonical list): bullet-emoji, three-section, info-cards
```

**BROWSER APP RULE:** Every worker building browser code must use:
- `fetch()` for HTTP calls — NOT `require('https')`, NOT `https.request`
- Browser globals (`window.X`) for function sharing between scripts
- NO Node.js builtins (`process`, `Buffer`, `require`, `module.exports` in browser context)

**NODE.JS APP RULE:** Specify `module.exports` format explicitly in the contract.

This step prevents the #1 failure mode of parallel worker app builds: mismatched function names, wrong runtime APIs, and integration mismatches.

### 1. Read and Parse Plan

Read the plan file. Extract ALL tasks with their full text and context upfront. Create a todo list:

```python
# Read the plan
read_file("docs/plans/feature-plan.md")

# Create todo list with all tasks
todo([
    {"id": "task-1", "content": "Create User model with email field", "status": "pending"},
    {"id": "task-2", "content": "Add password hashing utility", "status": "pending"},
    {"id": "task-3", "content": "Create login endpoint", "status": "pending"},
])
```

**Key:** Read the plan ONCE. Extract everything. Don't make subagents read the plan file — provide the full task text directly in context.

### 2. Per-Task Workflow

For EACH task in the plan:

#### Step 1: Dispatch Implementer Subagent

Use `delegate_task` with complete context:

```python
delegate_task(
    goal="Implement Task 1: Create User model with email and password_hash fields",
    context="""
    TASK FROM PLAN:
    - Create: src/models/user.py
    - Add User class with email (str) and password_hash (str) fields
    - Use bcrypt for password hashing
    - Include __repr__ for debugging

    FOLLOW TDD:
    1. Write failing test in tests/models/test_user.py
    2. Run: pytest tests/models/test_user.py -v (verify FAIL)
    3. Write minimal implementation
    4. Run: pytest tests/models/test_user.py -v (verify PASS)
    5. Run: pytest tests/ -q (verify no regressions)
    6. Commit: git add -A && git commit -m "feat: add User model with password hashing"

    PROJECT CONTEXT:
    - Python 3.11, Flask app in src/app.py
    - Existing models in src/models/
    - Tests use pytest, run from project root
    - bcrypt already in requirements.txt
    """,
    toolsets=['terminal', 'file']
)
```

#### Step 2: Dispatch Spec Compliance Reviewer

After the implementer completes, verify against the original spec:

```python
delegate_task(
    goal="Review if implementation matches the spec from the plan",
    context="""
    ORIGINAL TASK SPEC:
    - Create src/models/user.py with User class
    - Fields: email (str), password_hash (str)
    - Use bcrypt for password hashing
    - Include __repr__

    CHECK:
    - [ ] All requirements from spec implemented?
    - [ ] File paths match spec?
    - [ ] Function signatures match spec?
    - [ ] Behavior matches expected?
    - [ ] Nothing extra added (no scope creep)?

    OUTPUT: PASS or list of specific spec gaps to fix.
    """,
    toolsets=['file']
)
```

**If spec issues found:** Fix gaps, then re-run spec review. Continue only when spec-compliant.

#### Step 3: Dispatch Code Quality Reviewer

After spec compliance passes:

```python
delegate_task(
    goal="Review code quality for Task 1 implementation",
    context="""
    FILES TO REVIEW:
    - src/models/user.py
    - tests/models/test_user.py

    CHECK:
    - [ ] Follows project conventions and style?
    - [ ] Proper error handling?
    - [ ] Clear variable/function names?
    - [ ] Adequate test coverage?
    - [ ] No obvious bugs or missed edge cases?
    - [ ] No security issues?

    OUTPUT FORMAT:
    - Critical Issues: [must fix before proceeding]
    - Important Issues: [should fix]
    - Minor Issues: [optional]
    - Verdict: APPROVED or REQUEST_CHANGES
    """,
    toolsets=['file']
)
```

**If quality issues found:** Fix issues, re-review. Continue only when approved.

#### Step 4: Mark Complete

```python
todo([{"id": "task-1", "content": "Create User model with email field", "status": "completed"}], merge=True)
```

### 3. Final Review

After ALL tasks are complete, dispatch a final integration reviewer:

```python
delegate_task(
    goal="Review the entire implementation for consistency and integration issues",
    context="""
    All tasks from the plan are complete. Review the full implementation:
    - Do all components work together?
    - Any inconsistencies between tasks?
    - All tests passing?
    - Ready for merge?
    """,
    toolsets=['terminal', 'file']
)
```

### 4. Verify and Commit

After ALL tasks complete, perform MANUAL integration verification (do not skip):

```bash
# 1. Syntax check all generated files
node --check api.js && node --check app.js

# 2. Verify file structure and script load order in HTML
#    api.js must load BEFORE app.js in <head> or before </body>

# 3. For browser apps: verify NO Node.js specific code in browser JS files
#    grep -c "require\|process.env\|https.request\|module.exports" *.js
#    (should be 0 or only in Node.js-specific blocks)

# 4. Verify UI integration points (dropdown values, button IDs, etc.)
#    match between HTML and JS

# 5. Run full test suite
pytest tests/ -q

# 6. Review all changes
git diff --stat

# 7. Final commit if needed
git add -A && git commit -m "feat: complete [feature name] implementation"
```

**For browser-only apps** (no test suite): Open index.html directly in a browser and verify:
- Page loads without errors
- All buttons functional
- API calls succeed (if credentials available)

## Task Granularity

**Each task = 2-5 minutes of focused work.**

**Too big:**
- "Implement user authentication system"

**Right size:**
- "Create User model with email and password fields"
- "Add password hashing function"
- "Create login endpoint"
- "Add JWT token generation"
- "Create registration endpoint"

## Red Flags — Never Do These

- Start implementation without a plan
- Skip reviews (spec compliance OR code quality)
- Proceed with unfixed critical/important issues
- Dispatch multiple implementation subagents for tasks that touch the same files
- Make subagent read the plan file (provide full text in context instead)
- Skip scene-setting context (subagent needs to understand where the task fits)
- Ignore subagent questions (answer before letting them proceed)
- Accept "close enough" on spec compliance
- Skip review loops (reviewer found issues → implementer fixes → review again)
- Let implementer self-review replace actual review (both are needed)
- **Start code quality review before spec compliance is PASS** (wrong order)
- Move to next task while either review has open issues

## Handling Issues

### If Subagent Asks Questions

- Answer clearly and completely
- Provide additional context if needed
- Don't rush them into implementation

### If Reviewer Finds Issues

- Implementer subagent (or a new one) fixes them
- Reviewer reviews again
- Repeat until approved
- Don't skip the re-review

### If Subagent Fails a Task

- Dispatch a new fix subagent with specific instructions about what went wrong
- Don't try to fix manually in the controller session (context pollution)

## Efficiency Notes

**Why fresh subagent per task:**
- Prevents context pollution from accumulated state
- Each subagent gets clean, focused context
- No confusion from prior tasks' code or reasoning

**Why two-stage review:**
- Spec review catches under/over-building early
- Quality review ensures the implementation is well-built
- Catches issues before they compound across tasks

**Cost trade-off:**
- More subagent invocations (implementer + 2 reviewers per task)
- But catches issues early (cheaper than debugging compounded problems later)

## Integration with Other Skills

### With writing-plans

This skill EXECUTES plans created by the writing-plans skill:
1. User requirements → writing-plans → implementation plan
2. Implementation plan → subagent-driven-development → working code

### With test-driven-development

Implementer subagents should follow TDD:
1. Write failing test first
2. Implement minimal code
3. Verify test passes
4. Commit

Include TDD instructions in every implementer context.

### With requesting-code-review

The two-stage review process IS the code review. For final integration review, use the requesting-code-review skill's review dimensions.

### With systematic-debugging

If a subagent encounters bugs during implementation:
1. Follow systematic-debugging process
2. Find root cause before fixing
3. Write regression test
4. Resume implementation

## Example Workflow

```
[Read plan: docs/plans/auth-feature.md]
[Create todo list with 5 tasks]

--- Task 1: Create User model ---
[Dispatch implementer subagent]
  Implementer: "Should email be unique?"
  You: "Yes, email must be unique"
  Implementer: Implemented, 3/3 tests passing, committed.

[Dispatch spec reviewer]
  Spec reviewer: ✅ PASS — all requirements met

[Dispatch quality reviewer]
  Quality reviewer: ✅ APPROVED — clean code, good tests

[Mark Task 1 complete]

--- Task 2: Password hashing ---
[Dispatch implementer subagent]
  Implementer: No questions, implemented, 5/5 tests passing.

[Dispatch spec reviewer]
  Spec reviewer: ❌ Missing: password strength validation (spec says "min 8 chars")

[Implementer fixes]
  Implementer: Added validation, 7/7 tests passing.

[Dispatch spec reviewer again]
  Spec reviewer: ✅ PASS

[Dispatch quality reviewer]
  Quality reviewer: Important: Magic number 8, extract to constant
  Implementer: Extracted MIN_PASSWORD_LENGTH constant
  Quality reviewer: ✅ APPROVED

[Mark Task 2 complete]

... (continue for all tasks)

[After all tasks: dispatch final integration reviewer]
[Run full test suite: all passing]
[Done!]
```

**For browser-only apps** (no test suite): Open index.html directly in a browser and verify:
- Page loads without errors
- All buttons functional
- API calls succeed (if credentials available)

## Lessons Learned (Post-Incident Updates)

### Lesson 1: Browser App API Layer — Node.js vs Browser Runtime

**Incident:** Workers built api.js using Node.js `https.request` and `module.exports`, but app.js expected browser globals (`window.generateReportFromContent`). API layer didn't work in browser at all.

**Root cause:** Workers assumed Node.js context without explicit contract specifying browser runtime.

**Fix:** Rewrote api.js to use `fetch()` (browser) and attach function to `window.generateReportFromContent`. Added browser export check.

**Prevention:** Always specify runtime context in shared API contract. For browser apps, say "MUST use fetch(), NOT https module" in every worker's context.

### Lesson 2: UI Integration Points — Template Dropdown Values

**Incident:** Workers used placeholder template IDs in HTML (meeting/status/summary) that didn't match the actual template IDs (bullet-emoji/three-section/info-cards) used in api.js.

**Root cause:** UI worker and API worker had inconsistent assumptions about template IDs.

**Fix:** Patched index.html to use correct template IDs.

**Prevention:** Include canonical ID list in shared API contract. "Template IDs (canonical list): bullet-emoji, three-section, info-cards" must appear in every worker's context.

### Lesson 3: Inline Error Correction is Acceptable for Trivial Fixes

Some issues are small enough to fix inline (controller session) rather than spinning up a new worker:
- Wrong dropdown values (1-line fix)
- Syntax errors caught by node --check
- Script load order in HTML

The bar for "spin up a new fix worker" is: issues requiring 5+ minutes of work or architectural changes. Everything else is fair game for inline correction after parallel workers complete.

## Remember

```
Fresh subagent per task
Two-stage review every time
Spec compliance FIRST
Code quality SECOND
Never skip reviews
Catch issues early

Pre-flight: Define shared API contract BEFORE dispatching workers
Post-flight: Manual integration verification of all generated files
```
