---
name: hermes-dfs-debugging
description: Hermes Depth-First Debugging System - analyze errors using DFS capability tree exploration. Use when: DFS debugging, depth-first debug, error analysis, bug tracking
---

# Hermes Depth-First Debugging System

## Concept
Based on OpenAI's debugging philosophy: when something fails, ask "What capability is missing?" instead of "try harder". This is a Depth-First approach vs traditional BFS "collect all errors" approach.

## Architecture

```
Error → ErrorDetector → DepthFirstDebugger → CapabilityAnalyzer → Root Cause + Fix
                                 ↓
                          ReportGenerator (tree structure)
```

## Key Files
- `core/dfs-analyzer.js` — Main entry point for analysis
- `core/depth-first-debugger.js` — DFS diagnosis engine
- `core/capability-analyzer.js` — Capability tree with 5 error sources × 5 dimensions

## Capability Tree Structure
5 Error Sources: NETWORK, RUNTIME, STATE, RENDER, AUTH
Each source has 5 capability dimensions with test cases.

## Usage

### CLI (globally available)
```bash
hermes-dfs "error message" [SOURCE]
# e.g. hermes-dfs "net::ERR_CONNECTION_REFUSED" NETWORK
```

### Code Integration
```javascript
const { analyze } = require('~/.hermes/harness/core/dfs-analyzer.js');
const result = await analyze(error, { context: 'myFunc', source: 'RUNTIME' });
// result.rootCause, result.confidence, result.fixActions, result.alternativePaths
```

## Reports
- Location: `/home/opc/.hermes/harness/reports/`
- Format: DFS tree structure with root cause → fix actions

## Commands
- `node scripts/hermes-dfs.js "error" [SOURCE]` — Local CLI
- `hermes-dfs "error"` — Global CLI (after `npm install -g`)
- `node scripts/run-tests.js --level integration` — Run DFS tests