---
name: karpathy-coding-guidelines
description: Behavioural coding guidelines derived from Andrej Karpathy's observations — Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution. Use when writing, reviewing, debugging, or refactoring code to avoid common LLM pitfalls.
version: 1.0.0
author: Hermes Agent (adapted from multica-ai/andrej-karpathy-skills, 131K⭐)
license: MIT
metadata:
  hermes:
    tags: [karpathy, coding-guidelines, code-quality, code-review, refactoring, best-practices]
    related_skills: [systematic-debugging, test-driven-development, writing-plans, requesting-code-review, superpowers-integration-pattern]
    triggers:
      - "code review"
      - "refactor"
      - "fix bug"
      - "write code"
      - "implement feature"
      - "code quality"
      - "overcomplicated"
      - "surgical change"
      - "keep it simple"
      - "assumptions"
      - "verification"
    red_flags:
      - "I already know what the code needs, I can just write it"
      - "Adding abstractions now will make future changes easier"
      - "I'll clean up the formatting/style while I'm here"
      - "The code is small enough, I don't need verification steps"
      - "This pattern is obvious, no need to surface assumptions"
    iron_laws:
      - "NEVER ADD FEATURES BEYOND WHAT WAS ASKED — NO SPECULATIVE ABSTRACTIONS"
      - "EVERY CHANGED LINE MUST TRACE DIRECTLY TO THE USER'S REQUEST"
      - "ALWAYS SURFACE ASSUMPTIONS BEFORE IMPLEMENTING — DON'T PICK SILENTLY"
      - "DEFINE VERIFIABLE SUCCESS CRITERIA BEFORE STARTING MULTI-STEP TASKS"
---

# Karpathy Coding Guidelines

Behavioural guidelines adapted from [multica-ai/andrej-karpathy-skills](https://github.com/multica-ai/andrej-karpathy-skills) (131K⭐), based on Andrej Karpathy's observations on LLM coding pitfalls.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment. When in doubt, follow them.

The four principles are also injected into the system prompt via KARPATHY_CODING_GUIDELINES in prompt_builder.py. This skill provides REAL-WORLD EXAMPLES with before/after diffs to illustrate correct application.

---

## Principle 1: Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them — don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

### Example: Hidden Assumptions

**User:** "Add a feature to export user data"

❌ **What LLMs do (wrong assumptions)**
```python
def export_users(format='json'):
    """Export all users to a file."""
    users = User.query.all()
    if format == 'json':
        with open('users.json', 'w') as f:
            json.dump([u.to_dict() for u in users], f)
    elif format == 'csv':
        with open('users.csv', 'w') as f:
            writer = csv.DictWriter(f, fieldnames=['id', 'email', 'name'])
            writer.writeheader()
            writer.writerows([u.to_dict() for u in users])
    return f"Exported {len(users)} users"
```

Problems: Assumed ALL users (pagination? privacy?), file location, fields, CSV columns without checking.

✅ **What should happen (surface assumptions)**
```
Before implementing, I need to clarify:
1. Scope: Export all users or filtered subset? (privacy implications)
2. Format: Did you mean download in browser, background job, or API endpoint?
3. Fields: Which user fields? (some might be sensitive)
4. Volume: How many users? (affects approach)

Simplest approach: Add an API endpoint returning paginated JSON.
What's your preference?
```

---

## Principle 2: Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

### Example: Over-Abstraction

**User:** "Add a function to calculate discount"

❌ **What LLMs do (overengineered)**
```python
from abc import ABC, abstractmethod
from enum import Enum
from typing import Protocol, Union
from dataclasses import dataclass

class DiscountStrategy(ABC):
    @abstractmethod
    def calculate(self, amount: float) -> float:
        pass

class PercentageDiscount(DiscountStrategy):
    def __init__(self, percentage: float):
        self.percentage = percentage
    def calculate(self, amount: float) -> float:
        return amount * (self.percentage / 100)

class FixedDiscount(DiscountStrategy):
    def __init__(self, fixed_amount: float):
        self.fixed_amount = fixed_amount
    def calculate(self, amount: float) -> float:
        return min(self.fixed_amount, amount)

# 50+ lines for a simple percentage calculation
```

✅ **What should happen (simple)**
```python
def calculate_discount(amount: float, percent: float) -> float:
    """Calculate discount amount. percent should be 0-100."""
    return amount * (percent / 100)

# Usage
discount = calculate_discount(100.0, 10.0)  # $10 off
```

**When to add complexity:** Only when you actually need multiple discount types. If that requirement comes later, refactor then.

---

## Principle 3: Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Do NOT "improve" adjacent code, comments, or formatting.
- Do NOT refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it.
- Remove imports/variables/functions that YOUR changes made unused.
- Do NOT remove pre-existing dead code unless asked.
- The test: every changed line should trace directly to the user's request.

### Example: Drive-by Refactoring

**User:** "Fix the bug where empty emails crash the validator"

❌ **What LLMs do (too much)**
```diff
  def validate_user(user_data):
-     # Check email format
-     if not user_data.get('email'):
+     """Validate user data."""
+     email = user_data.get('email', '').strip()
+
+     # Validate email
+     if not email:
          raise ValueError("Email required")
-
-     # Basic email validation
-     if '@' not in user_data['email']:
+     if '@' not in email or '.' not in email.split('@')[1]:
          raise ValueError("Invalid email")

-     # Check username
-     if not user_data.get('username'):
+     # Validate username
+     username = user_data.get('username', '').strip()
+     if not username:
          raise ValueError("Username required")
+     if len(username) < 3:
+         raise ValueError("Username too short")
+     if not username.isalnum():
+         raise ValueError("Username must be alphanumeric")

      return True
```

Problems: "Improved" email validation beyond bug fix, added username validation nobody asked for, changed comments, added docstring.

✅ **What should happen (surgical)**
```diff
  def validate_user(user_data):
      # Check email format
-     if not user_data.get('email'):
+     email = user_data.get('email', '')
+     if not email or not email.strip():
          raise ValueError("Email required")

      # Basic email validation
-     if '@' not in user_data['email']:
+     if '@' not in email:
          raise ValueError("Invalid email")

      # Check username
      if not user_data.get('username'):
          raise ValueError("Username required")

      return True
```

**Only changed:** The specific lines that fix empty email handling.

### Example: Style Drift

**User:** "Add logging to the upload function"

❌ **What LLMs do (reformat everything)**
```diff
- def upload_file(file_path, destination):
+ def upload_file(file_path: str, destination: str) -> bool:
+     """Upload file to destination with logging."""
+     logger.info(f"Uploading {file_path} to {destination}")
+
      try:
-         with open(file_path, 'rb') as f:
-             data = f.read()
-
-         response = requests.post(destination, files={'file': data})
-
-         if response.status_code == 200:
-             return True
-         else:
-             return False
+         with open(file_path, "rb") as f:
+             data = f.read()
+         response = requests.post(destination, files={"file": data})
+         success = response.status_code == 200
+
+         if success:
+             logger.info(f"Upload successful: {file_path}")
+         else:
+             logger.error(f"Upload failed: {file_path}, status={response.status_code}")
+
+         return success
      except Exception as e:
-         print(f"Error: {e}")
+         logger.exception(f"Upload error for {file_path}: {e}")
          return False
```

Problems: Changed quote style ('' to ""), added type hints, added docstring, reformatted whitespace, changed boolean return logic.

✅ **What should happen (match existing style)**
```diff
+ import logging
+
+ logger = logging.getLogger(__name__)
+
  def upload_file(file_path, destination):
+     logger.info(f'Starting upload: {file_path}')
      try:
          with open(file_path, 'rb') as f:
              data = f.read()

          response = requests.post(destination, files={'file': data})

          if response.status_code == 200:
+             logger.info(f'Upload successful: {file_path}')
              return True
          else:
+             logger.error(f'Upload failed: {file_path}, status={response.status_code}')
              return False
      except Exception as e:
-         print(f"Error: {e}")
+         logger.exception(f'Upload error: {file_path}')
          return False
```

**Matched:** Single quotes, no type hints, existing boolean pattern, spacing style.

---

## Principle 4: Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan with verification checkpoints:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

### Example: Vague vs Verifiable

**User:** "Fix the authentication system"

❌ **What LLMs do (vague approach)**
```
I'll fix the authentication system by:
1. Reviewing the code
2. Identifying issues
3. Making improvements
4. Testing the changes

[Proceeds to make changes without clear success criteria]
```

✅ **What should happen (verifiable goals)**
```
To "fix authentication," I need to define success criteria.
What specific issue are we solving?

If the issue is "users stay logged in after password change":

Plan:
1. Write test: Change password → verify old session invalidated
   Verify: Test fails (reproduces bug)

2. Implement: Invalidate sessions on password change
   Verify: Test passes

3. Check edge cases: Multiple active sessions, concurrent changes
   Verify: Additional tests pass

4. Verify no regression: Existing auth tests still pass
   Verify: Full test suite green

Current test coverage for auth: [shows coverage]
What's the specific auth issue you're seeing?
```

### Example: Test-First Verification

**User:** "The sorting breaks when there are duplicate scores"

❌ **What LLMs do (fix without reproducing)**
```python
# Immediately changes sort logic without confirming the bug
def sort_scores(scores):
    return sorted(scores, key=lambda x: (-x['score'], x['name']))
```

✅ **What should happen (reproduce first)**
```python
# 1. First, write a test that reproduces the issue
def test_sort_with_duplicate_scores():
    """Test sorting when multiple items have same score."""
    scores = [
        {'name': 'Alice', 'score': 100},
        {'name': 'Bob', 'score': 100},
        {'name': 'Charlie', 'score': 90},
    ]
    result = sort_scores(scores)
    # Run this test multiple times, order should be consistent
    assert result[0]['score'] == 100
    assert result[1]['score'] == 100
    assert result[2]['score'] == 90

# Verify: Run test 10 times → fails with inconsistent ordering

# 2. Now fix with stable sort
def sort_scores(scores):
    """Sort by score descending, then name ascending for ties."""
    return sorted(scores, key=lambda x: (-x['score'], x['name']))

# Verify: Test passes consistently
```

---

## Anti-Patterns Summary

| Principle | Anti-Pattern | Fix |
|-----------|-------------|-----|
| Think Before Coding | Silently assumes file format, fields, scope | List assumptions explicitly, ask for clarification |
| Simplicity First | Strategy pattern for single discount calculation | One function until complexity is actually needed |
| Surgical Changes | Reformats quotes, adds type hints while fixing bug | Only change lines that fix the reported issue |
| Goal-Driven | "I'll review and improve the code" | "Write test for bug X → make it pass → verify no regressions" |

## Key Insight

The "overcomplicated" examples aren't obviously wrong — they follow design patterns and best practices. The problem is **timing**: they add complexity before it's needed, which:
- Makes code harder to understand
- Introduces more bugs
- Takes longer to implement
- Harder to test

The "simple" versions are:
- Easier to understand
- Faster to implement
- Easier to test
- Can be refactored later when complexity is actually needed

**Good code is code that solves today's problem simply, not tomorrow's problem prematurely.**

## Pitfalls

- **Do NOT use this as a substitute for systematic-debugging** — debugging has its own dedicated process. This skill guides general coding behaviour, not root cause investigation.
- **Surgical Changes conflicts with "while I'm here" refactoring instincts** — be strict. If you notice dead code, mention it in text but don't delete it.
- **Simplicity First does NOT mean no error handling** — handle real errors, not impossible scenarios.
- **Goal-Driven Execution pairs well with test-driven-development** skill — write the test first, then implement.
- **Think Before Coding does NOT mean overthink** — surface genuine ambiguities, not every possible edge case.
