---
name: superpowers-integration-pattern
title: Superpowers-style Patterns Integration into Hermes Agent
description: Apply obra/superpowers methodology patterns (1% Rule, Red Flags, Iron Laws, SessionStart hooks, TDD for skills) to Hermes Agent's skill system. Use when enhancing agent skill compliance, reducing skill-skipping rationalization, or integrating behavior-shaping patterns from external agent frameworks.
version: 2.0.0
author: Hermes Agent (adapted from obra/superpowers by Jesse Vincent)
license: MIT
metadata:
  hermes:
    tags: [superpowers, skills, agent-behavior, methodology, integration, prompt-engineering]
    related_skills: [systematic-debugging, test-driven-development, writing-plans, subagent-driven-development, requesting-code-review, batch-file-translate, post-task-retrospective, karpathy-coding-guidelines]
    triggers: ["superpowers integration", "skill compliance", "agent rationalization", "behavior-shaping", "1% rule", "red flags", "iron laws", "sessionstart bootstrap", "skill tdd", "karpathy guidelines", "coding behaviour", "complementary patterns"]
    red_flags:
      - "Our skill system is different, Superpowers patterns won't apply"
      - "The 1% Rule is too aggressive, agents will waste time checking skills"
      - "Red Flags are just noise in the system prompt"
      - "This is just copy-pasting Superpowers content"
      - "The TDD testing framework is overkill for skills"
    iron_laws:
      - "UNDERSTAND THE TARGET SYSTEM'S ARCHITECTURE BEFORE INTEGRATING"
      - "EVERY PATTERN MUST BE ADAPTED — NEVER COPY RAW CONTENT"
      - "ALWAYS BACKUP BEFORE MODIFYING CORE SYSTEM FILES"
      - "RUN VERIFICATION SCRIPT AFTER EVERY CHANGE"
---

# Superpowers-style Integration Pattern for Hermes

## Overview
This skill documents how to integrate behavior-shaping patterns from [obra/superpowers](https://github.com/obra/superpowers) (v5.1.0, 191K⭐) into Hermes Agent's skill system. All 5 phases are implemented and documented here.

## The Superpowers Patterns

### 1. The 1% Rule
**Core concept:** Agents naturally rationalize skipping skills. The 1% Rule says: "If there is even a 1% chance a skill might apply, you MUST invoke it. This is not negotiable."

**Hermes mapping:** `<SUPERPOWERS-1%-RULE>` block injected into system prompt in `prompt_builder.py`'s `build_skills_system_prompt()`.

### 2. Red Flags
**Core concept:** Pre-emptively list common rationalizations agents use to skip skills.

**Hermes mapping:** Two places:
- **Global** — 7 common rationalizations in `prompt_builder.py` `<RED-FLAGS>` block
- **Per-skill** — optional `metadata.hermes.red_flags` frontmatter field

### 3. Iron Laws
**Core concept:** Non-negotiable one-line rules defining the skill's hard boundary.

**Hermes mapping:** Optional `metadata.hermes.iron_laws` frontmatter field.

### 4. Triggers
**Core concept:** Keywords to help agent identify relevant skills.

**Hermes mapping:** Optional `metadata.hermes.triggers` frontmatter field.

### 6. Complementary Pattern: Karpathy Coding Guidelines

**Core concept:** In addition to superpowers (which enforce *skill compliance*), Karpathy's 4 principles enforce *coding behaviour quality*: Think Before Coding, Simplicity First, Surgical Changes, Goal-Driven Execution.

**Hermes mapping:** `KARPATHY_CODING_GUIDELINES` constant in `prompt_builder.py`, injected into `_build_system_prompt()` in `run_agent.py` between tool_guidance and nous_subscription. Also a full skill at `software-development/karpathy-coding-guidelines` with before/after diff examples.

**Key design decision:** Karpathy is kept **separate** from superpowers, not merged:
- Superpowers = "check skills first, don't rationalize skipping"
- Karpathy = "how to write code, think before changing, keep it simple"
- Goal-Driven Execution and superpowers verification have overlap, but serve different purposes (task planning vs skill compliance). Keeping them distinct avoids diluting either.

### 5. Context Compaction Reminder
**Core concept:** Remind agent about skills after context compression.

**Hermes mapping:** Updated `SUMMARY_PREFIX` in `context_compressor.py`.

## Complete Implementation — All 5 Phases

### Phase 1: Core Patterns (code-level)

**Files modified:**
| File | Change |
|------|--------|
| `agent/prompt_builder.py` | Added `<SUPERPOWERS-1%-RULE>` + `<RED-FLAGS>` to skills system prompt block |
| `agent/skill_utils.py` | Added `extract_skill_triggers()`, `extract_skill_red_flags()`, `extract_skill_iron_laws()` |
| `agent/context_compressor.py` | Updated `SUMMARY_PREFIX` with skills reminder after compaction |
| 5 core skills (systematic-debugging, tdd, writing-plans, subagent-driven-dev, code-review) | Added triggers + red_flags + iron_laws |

### Phase 2: TDD Testing Framework
**Script:** `~/.hermes/scripts/skill-tdd.py`

Tests each skill using Superpowers-style pressure scenarios:
```bash
python3 ~/.hermes/scripts/skill-tdd.py --all --dry-run  # Generate test plans
python3 ~/.hermes/scripts/skill-tdd.py --list            # List testable skills
python3 ~/.hermes/scripts/skill-tdd.py <skill-name>      # Test one skill
```

Built-in pressure scenarios: 9 skills covered with prompt + baseline (expected failure) + success criteria + verify keywords. Results saved to `~/.hermes/skill-tdd-results/`.

### Phase 3: SessionStart Bootstrap Plugin
**Plugin:** `~/.hermes/plugins/sessionstart-bootstrap/`

- `plugin.yaml` + `__init__.py` with `register(ctx)` function
- Registers `on_session_start` hook — fires on every new session
- Complements the system-prompt-based 1% Rule with session-level observability
- Plugin is auto-discovered from `~/.hermes/plugins/`

### Phase 4: Skills Red Flags Expansion
11 additional skills updated with triggers/red_flags/iron_laws:
- github-code-review, github-pr-workflow, github-project-deep-dive
- batch-file-translate, post-task-retrospective
- taskforge-worker-onboard (triggers only)
- arxiv, polymarket, llm-wiki (triggers only)
- webhook-subscriptions, openclaw-soft-reset (triggers only)

**Final tally:** 11 skills with RedFlags+IronLaws, 19 with triggers

### Phase 5: skill_manage Create Hint
**File:** `tools/skill_manager_tool.py`

After every `skill_manage(action='create', ...)`, the result hint now includes:
> "To add Superpowers-style features (triggers for auto-detection, red_flags for anti-rationalization, iron_laws for non-negotiable rules), add a 'metadata.hermes' section to the SKILL.md frontmatter. See existing skills like systematic-debugging or test-driven-development for examples."

## Skill Frontmatter Format Reference

```yaml
---
name: my-skill
description: What it does. Use when: keywords
metadata:
  hermes:
    tags: [tag1, tag2]
    related_skills: [other-skill-names]
    triggers: ["keyword1", "keyword2", "phrase"]
    red_flags:
      - "Rationalization agents use to skip this skill"
      - "Another escape route to block"
    iron_laws:
      - "IRON LAW IN ALL CAPS — NON-NEGOTIABLE"
      - "SECOND IRON LAW"
---
```

## Implementation Steps

### 1. Backup
```bash
BACKUP="$HOME/.hermes/backups/superpowers-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
cp agent/prompt_builder.py agent/skill_utils.py agent/context_compressor.py tools/skill_manager_tool.py "$BACKUP/"
cp -r ~/.hermes/skills "$BACKUP/skills-before"
```

### 2. Add utility functions
In `agent/skill_utils.py`, add three extract functions. All return empty lists if fields are absent (backward compatible).

### 3. Update system prompt
In `agent/prompt_builder.py` function `build_skills_system_prompt()`, add after the `</available_skills>` closing tag:
- `<SUPERPOWERS-1%-RULE>` block
- `<RED-FLAGS>` block  
End with `"If none match, proceed normally without loading a skill."`

### 4. Clear cache
```bash
rm -f ~/.hermes/skills/.skills_prompt_snapshot.json
```

### 5. Verify
```bash
bash ~/.hermes/scripts/track-superpowers.sh
```

## Pitfalls
- **Don't just copy Superpowers content raw** — adapt to Hermes existing voice
- **Watch for Python syntax** — multi-line string concatenation is fragile; verify lint after edit
- **Memory limit** — memory store caps at 2,200 chars; replace old entries aggressively
- **Snapshot cache** — always delete `.skills_prompt_snapshot.json` after modifying skills
- **1% Rule language must be imperative** — "you must", not "you may" or "consider"
- **Phase 2 TDD tests are dry-run only** — the pressure scenarios require manual execution with real subagents to get meaningful comparisons
- **Plugin discovery** — plugins need `plugin.yaml` + `__init__.py` with `register(ctx)` function; they live in `~/.hermes/plugins/<name>/`

## Verification
Run tracker script:
```bash
bash ~/.hermes/scripts/track-superpowers.sh
```
Expected:
- ✅ 1% Rule injected
- ✅ Red Flags section present
- ✅ 3 extract functions present
- ✅ Compaction reminder present
- ✅ N skills with Red Flags (should be 11+)
- ✅ N skills with Iron Laws (should be 11+)
- ✅ N skills with Triggers (should be 19+)
- ✅ Latest backup found

## Files Reference (all paths)

| Component | Path |
|-----------|------|
| System prompt injection | `~/.hermes/hermes-agent/agent/prompt_builder.py` |
| Frontmatter parser | `~/.hermes/hermes-agent/agent/skill_utils.py` |
| Compaction reminder | `~/.hermes/hermes-agent/agent/context_compressor.py` |
| Create hint | `~/.hermes/hermes-agent/tools/skill_manager_tool.py` |
| TDD framework | `~/.hermes/scripts/skill-tdd.py` |
| Bootstrap plugin | `~/.hermes/plugins/sessionstart-bootstrap/` |
| Tracker script | `~/.hermes/scripts/track-superpowers.sh` |
| Changelog | `~/.hermes/changelogs/superpowers-integration.md` |
| Backups | `~/.hermes/backups/superpowers-integration-20260515_082626/` |
| Backups (P2-5) | `~/.hermes/backups/superpowers-phase2-5-20260515_083233/` |
