---
name: post-task-retrospective
metadata:
  hermes:
    triggers: ["retrospect", "lessons learned", "task review", "post-task", "complex task done"]
    red_flags:
      - "The task was simple, no need for retrospective"
      - "I'll just move on to the next task"
      - "There's nothing to learn from this"
    iron_laws:
      - "AFTER EVERY 5+ TOOL CALL TASK, RUN RETROSPECTIVE"
      - "EVERY LESSON MUST UPDATE MEMORY OR A SKILL"

description: 每完成複雜任務後自動做賽後檢討，記錄教訓並優化系統
useWhen: retrospective, post-task, lessons learnedtask review, lesson learned, task improvement
trigger: 完成5+ tool calls嘅任務，或解決咗從未遇過嘅新問題，或用戶主動要求檢討
---

# Post-Task Retrospective

每次完成複雜任務後強制執行，確保系統持續進化。

## Checklist

### 1. 回顧任務
- [ ] 任務目標係咩？最終達成咗未？
- [ ] 用咗幾多 tool calls / 時間？
- [ ] 有冇偏離原定路線？

### 2. 識別問題
- [ ] 有冇遇到任何 error / 意外行為？
- [ ] 有咩位浪費咗時間？
- [ ] 有冇嘢 trial and error 咗好多次先得？
- [ ] 用戶有冇 correction / 提示？

### 3. 提煉教訓
每個問題都問：
- 呢個問題嘅 root cause 係咩？
- 下次可以點樣避免？
- 有冇通用 pattern？（唔止今次用到，第時都用得）

### 4. 固化改進

**記錄去 memory：**
- 工具 quirks（某個 tool 嘅古怪行為）
- 環境 facts（OS版本、套件兼容性）
- 用戶 preferences（user profile已存？要更新？）

**更新/創建 skill：**
- 如果係新嘅 recurring workflow → 創建 skill
- 如果現有 skill 有遺漏/錯誤 → patch 更新
- 如果係單次特定問題，唔會再遇到 → 唔使save

### 5. 總結評級

| 評分 | 意思 |
|------|------|
| S | 一次過完美完成，冇浪費 |
| A | 順利完成，有小瑕疵 |
| B | 完成但繞咗路 |
| C | 完成但效率低，好多 trial and error |
| F | 失敗，要下次再搞 |

## Key Principles
- **每個錯誤都係一次優化機會** — 唔好 repeat yourself
- **記教訓唔係記仇** — 記通用 pattern，唔好記單次偶發事件
- **如果唔 sure 記唔記，寧可記** — memory可以之後清理
- **用戶 correction 係最高優先級** — 被糾正過嘅嘢一定要record
