---
name: js-dynamic-scraping
description: "Detect and bypass JS dynamic loading when scraping — use CloakBrowser for page structure, requests for content. Pattern: requests=fail → CloakBrowser=success means JS loading."
category: data-science
---

# JS Dynamic Loading Bypass

## When to Use

Any time `requests.get()` returns less content than what you see in a browser, or when article/link lists appear empty despite the page loading fine visually.

## Diagnosis

```python
# 1. Test with requests
r = requests.get(url, headers=HEADERS)
print(f"Status: {r.status_code}, Length: {len(r.text)}")
# → If links/titles missing but status=200 → JS loading

# 2. Test with CloakBrowser
from cloakbrowser import launch
browser = launch(headless=True)
page = browser.new_page()
page.goto(url, timeout=25000)
import time; time.sleep(2)
html = page.content()
browser.close()
# → If links appear here → JS dynamic loading confirmed
```

## Pattern: CloakBrowser + Requests Hybrid

**CloakBrowser** → section index pages (JS loads article lists)
**requests** → individual article pages (usually pure HTML)

### CloakBrowser quirks
- Must be **sequential** — no ThreadPoolExecutor (asyncio conflict)
- Proxy optional — CloakBrowser bypasses Cloudflare on news.mingpao.com directly
- 2-3s sleep after goto for JS to complete
- Use `page.content()` not `page.inner_text()` to get raw HTML

### Title decoding
URL slugs are often URL-encoded:
```python
from urllib.parse import unquote
title = unquote(slug).replace('-', '，')
```

## Known Triggers

| Site Type | Example | Sign |
|-----------|---------|------|
| News sites | 明報, HK01 | Article lists loaded by JS |
| Social feeds | Facebook, Twitter | Infinite scroll |
| React/Vue SPAs | Most modern webapps | Empty body on requests |
| AJAX-loaded content | 任何 XHR/fetch | `data-*` attributes in HTML |

## Quick Test (one-shot)

```python
from cloakbrowser import launch
import re, time

browser = launch(headless=True)
page = browser.new_page()
page.goto('TARGET_URL', timeout=25000)
time.sleep(2)
html = page.content()
browser.close()

links = re.findall(r'href="(https://[^"]*article[^"]+)"', html)
print(f"Found {len(links)} article links")
```
