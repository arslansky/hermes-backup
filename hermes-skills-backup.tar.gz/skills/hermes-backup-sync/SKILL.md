---
name: hermes-backup-sync
description: Sync Hermes Oracle VM config, skills, scripts and reports to GitHub — arslansky/hermes-backup repo
category: devops
---

# Hermes Backup Sync

## Backup Repo
- GitHub: `https://github.com/arslansky/hermes-backup`
- Default branch: `main` (NOT master — local default is master, remote is main)
- Local repo: `~/.hermes/hermes-backup/`

## What's Backed Up
- `config.yaml` — Hermes Agent configuration
- `hermes-skills-backup.tar.gz` — Skills tarball (regenerated each backup)
- `scripts/` — Key Python scripts (mingpao_scraper, fable_components, etc.)
- `cron-output/` — Daily GitHub & Ming Pao digest reports
- `hermes_agent_evaluation_report.*` — System evaluation reports

## OpenClaw Workspace Backup Repo
- GitHub: `https://github.com/arslansky/openclaw-workspace` (PRIVATE)
- 包含 OpenClaw workspace 完整備份（AGENTS.md, agents/, config/, memory/, skills/）
- `agents_backup/` 入面係工廠 default config（moonshot-v1-8k），唔係你真正嘅 config！
- 真正嘅 config喺 `~/.openclaw/openclaw.json`（本地）及 `config/` directory

## Backup Schedule
- Manual trigger only for now

## Critical Gotchas (learned 2026-07-01)

### Wrong remote URL case
- Remote was `Arslan6021` (wrong) → correct is `arslansky`
- Fix: `git remote set-url origin https://github.com/arslansky/hermes-backup.git`

### Wrong branch name
- Local defaults to `master`, remote is `main`
- Fix: `git push origin master:main --force` OR rename local branch:
  ```bash
  git checkout -b newbackup && git checkout -B main newbackup && git branch -D master
  ```

## Manual Sync Commands

```bash
BACKUP="$HOME/.hermes/hermes-backup"
cd "$BACKUP"

# Update skills tarball
tar -czf hermes-skills-backup.tar.gz \
    --exclude='__pycache__' --exclude='*.pyc' \
    -C ~/.hermes skills/

# Copy latest cron outputs
mkdir -p cron-output/
cp ~/.hermes/cron/output/github-daily-zh-*.txt cron-output/
cp ~/.hermes/cron/output/mingpao_digest_*.txt cron-output/

# Copy config
cp ~/.hermes/config.yaml .

# Commit & push
git add -A
git commit -m "Backup $(date +%Y-%m-%d)"
GITHUB_TOKEN=$(grep '^GITHUB_TOKEN=' ~/.hermes/.env | cut -d'=' -f2)
git push https://${GITHUB_TOKEN}@github.com/arslansky/hermes-backup.git main
```

## Setup (first time only)

```bash
# Create the git repo if not exists
gh repo create hermes-backup --public --confirm
cd ~/.hermes/hermes-backup
git remote set-url origin https://github.com/arslansky/hermes-backup.git
git push -u origin main
```
