---
name: hermes-backup-sync
description: Sync Hermes system evaluation and backup to GitHub — arslansky/hermes-backup repo
category: devops
---

# Hermes Backup Sync

## Backup Repo
- GitHub: `arslansky/hermes-backup`
- Status: **pending** — not yet set up

## What's Backed Up
- `~/.hermes/hermes_agent_evaluation_report.*` (html/css/pdf/md)
- `~/.hermes/backups/superpowers-*` folders (dated backups)

## Backup Schedule
- Manual trigger only for now

## Commands
```bash
# Manual sync
cd ~/.hermes && git add hermes_agent_evaluation_report.* backups/
git commit -m "Backup $(date +%Y-%m-%d)"
git push origin main
```
