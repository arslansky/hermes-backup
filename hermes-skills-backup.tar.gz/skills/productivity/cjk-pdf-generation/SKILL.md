---
name: cjk-pdf-generation
description: Generate PDFs with Chinese/Japanese/Korean (CJK) text using WeasyPrint + extracted Noto CJK TTF fonts — fixes garbled CJK in ReportLab PDFs
triggers:
  - Chinese text shows as "I" or blank boxes in PDF
  - generate PDF with CJK characters
  - PDF 中文 亂碼
  - ReportLab CJK font not working
---

# CJK PDF Generation — Chinese/Japanese/Korean Text in PDFs

## Problem
ReportLab-generated PDFs show Chinese/Japanese/Korean text as blank boxes or "I" characters because ReportLab's built-in fonts don't support CJK.

## Root Cause
The Book of Secret Knowledge analysis PDF used ReportLab with default fonts. Chinese characters (中文) were rendered as "I" because no CJK font was registered.

## Solution: WeasyPrint + Extracted TTF from TTC

### Step 1 — Extract TTF from TTC (Noto CJK)
Noto CJK fonts come as TTC (TrueType Collection) files. ReportLab doesn't support TTC directly. Extract individual TTF using fontTools:

```python
/usr/bin/python3 << 'EOF'
from fontTools.ttLib import TTCollection
import os

# Noto CJK TTC files at: /usr/share/fonts/google-noto-cjk/NotoSansCJK-*.ttc

ttc_path = '/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc'
col = TTCollection(ttc_path)

# Traditional Chinese font is typically index 8 in Regular TTC
font_tc = col.fonts[8]
font_tc.save('/tmp/NotoSansCJK-TC.ttf')
print("Extracted, size:", os.path.getsize('/tmp/NotoSansCJK-TC.ttf'))
EOF
```

### Step 2 — Generate PDF with WeasyPrint
```python
/usr/bin/python3 << 'PYEOF'
from weasyprint import HTML
import re

html_content = open('/tmp/content.html').read()

css = '''@font-face {
    font-family: "Noto Sans CJK TC";
    src: url("file:///tmp/NotoSansCJK-TC.ttf");
}'''

with open('/tmp/font.css', 'w') as f:
    f.write(css)

HTML(filename='/tmp/content.html').write_pdf(
    '/tmp/output.pdf',
    stylesheets=['/tmp/font.css']
)
print("Done!")
PYEOF
```

### Step 3 — Verify
```python
/usr/bin/python3 -c "
import fitz  # PyMuPDF - available in /usr/bin/python3
doc = fitz.open('/tmp/output.pdf')
print('Pages:', doc.page_count)
print('Page 1:', doc[0].get_text()[:300])  # Should show Chinese chars
"
```

## Key Environment Notes

| Tool | Python | Path |
|------|--------|------|
| PyMuPDF (fitz) | /usr/bin/python3 (3.9) | /home/opc/.local/lib/python3.9/site-packages |
| WeasyPrint | /usr/bin/python3 (3.9) | system |
| fontTools | /usr/bin/python3 (3.9) | system |
| ReportLab | venv python3 (3.11) | venv site-packages |

**Critical:** Use `/usr/bin/python3` for PDF work, NOT the hermes-agent venv Python (3.11). The venv has reportlab but NOT PyMuPDF/WeasyPrint/fontTools.

## Why Not ReportLab?
- `canvas.drawString()` does NOT support Unicode beyond Latin-1
- TTC files (Noto CJK) not directly supported even with `registerFont()`
- WeasyPrint uses Pango + Cairo which handle CJK properly with TTF fonts

## Verification Checklist
- [ ] Chinese characters render correctly (use fitz extract + check)
- [ ] PDF has correct page count
- [ ] Font file size >10MB (full CJK coverage)
- [ ] Using /usr/bin/python3 not venv python
