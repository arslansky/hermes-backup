---
name: chinese-pdf-generation
description: Generate PDF reports with Chinese/CJK text using WeasyPrint instead of ReportLab (which cannot handle TTC CJK fonts on Linux)
triggers:
  - "chinese pdf"
  - "cjk pdf"
  - "中文 pdf"
  - "pdf 中文 乱码"
---

# Chinese PDF Generation

## When to use
- Generating PDF reports with Chinese / CJK text (Traditional Chinese, Simplified Chinese, Japanese, Korean)
- Large structured documents (inventories, catalogs, reports) that need proper CJK rendering
- When reportlab produces garbled characters or "tofu" (□) for Chinese text

## Key Insight

ReportLab's `TTFont` class cannot handle TTC (TrueType Collection) files that use PostScript outlines — this includes all major CJK font files on Linux (Noto Sans CJK, WenQuanYi, etc.). Even trying `subfontIndex` fails because the TTC file structure itself is unsupported.

**WeasyPrint** uses a browser rendering engine (WebKit via Pango + Cairo) and treats the document as HTML/CSS — Chinese text renders correctly so long as a suitable web font is available via Google Fonts CDN.

## Python Script Pattern

```python
from weasyprint import HTML
import os

html = """<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400;700&display=swap');
  body {
    font-family: 'Noto Sans TC', 'WenQuanYi Micro Hei', 'Microsoft JhengHei', sans-serif;
    font-size: 9pt;
    padding: 1.5cm 1.8cm;
  }
  table { border-collapse: collapse; width: 100%; }
  th, td { border: 1px solid #B8CFE0; padding: 5px 7px; }
  th { background: #D6E8F5; color: #1B4F7A; }
</style>
</head>
<body>
  <!-- your content -->
</body>
</html>"""

output_path = os.path.expanduser("~/.hermes/output.pdf")
HTML(string=html, base_url=os.path.expanduser("~/.hermes/")).write_pdf(output_path)
print(f"Done: {output_path}")
```

## Key tips

- Always include Google Fonts import for CJK fonts:
  - Traditional Chinese: `family=Noto+Sans+TC:wght@400;700`
  - Simplified Chinese: `family=Noto+Sans+SC:wght@400;700`
  - Japanese: `family=Noto+Sans+JP:wght@400;700`
- `base_url` is needed so relative asset paths resolve correctly
- WeasyPrint respects standard CSS — flexbox, grid, tables all work as expected
- Much better text wrapping and line breaking for CJK than reportlab
- CSS `@page` rule can control page size, margins for print output

## Limitations
- Requires system dependencies (pango, cairo, gdk-pixbuf) — available on Oracle VM via `apt install weasyprint`
- Slower than ReportLab for simple documents (browser engine startup overhead)
- Not suitable for very high-volume batch generation (100+ PDFs in a loop)

## Verification

Open the PDF and check:
- No □ characters (tofu / missing glyphs)
- No overlapping text
- Proper line breaks in Chinese sentences
- Table columns don't overflow page width