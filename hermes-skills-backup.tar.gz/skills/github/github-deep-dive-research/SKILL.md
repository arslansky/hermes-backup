---
name: github-deep-dive-research
description: 對 GitHub repo 做深入研究（deep dive），fetch README + API data + 結構化輸出
category: github
---

# GitHub Deep Dive Research Skill

## Trigger
用戶要求對 GitHub repo 做深入研究（"深入研究"、"deep dive"）。

## Approach

### Step 1: Get repo metadata via GitHub API
```bash
curl -s "https://api.github.com/repos/{owner}/{repo}" \
  -H "Authorization: token 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" \
  | python -c "import json,sys; r=json.load(sys.stdin); print(f'Stars: {r[\"stargazers_count\"]} | Lang: {r.get(\"language\")} | Topics: {r.get(\"topics\",[])}')"
```

### Step 2: Fetch README
```bash
curl -s --max-time 10 "https://api.github.com/repos/{owner}/{repo}/readme" \
  -H "Authorization: token ghp_..." \
  -H "Accept: application/vnd.github.v3.raw" | head -80
```

### Step 3: Use delegate_task for parallel README fetching
多個 repo 建議用 `delegate_task` 並行處理，每個 subagent fetch 一個 repo。

### Step 4: Compile structured report
輸出格式：
```
┌─────────────────────────────────────┐
│ ⭐ X,XXX — owner/repo               │
│ Language | License                  │
└─────────────────────────────────────┘
📌 係乜？
⚙️ 點運作？
✨ 關鍵功能？
🚀 安裝？
💡 適用場景？
```

## Pitfalls
- GitHub API 有 rate limit，記得加 `--max-time`
- README 有機會好大，只要前面部分
- 如果 API timeout，試 `delegate_task` 方式

## Verification
每個 repo summary 包含：stars、language、what it does、how it works、key features、install command、use case