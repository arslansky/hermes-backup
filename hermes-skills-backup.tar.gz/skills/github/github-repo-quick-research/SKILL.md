---
name: github-repo-quick-research
description: Rapidly research GitHub repos — extract stars, features, architecture, contributors without cloning
triggers:
  - research github repo
  - check out this project
  - github project analysis
  - extract features from github
---

# GitHub Repo Quick Research

Rapid extraction of project structure, features, and key data from GitHub repositories without cloning.

## When to Use
- User asks to "research X on GitHub" or "check out this repo"
- Need to extract project stats, features, architecture quickly
- Don't want to clone large repos

## GitHub API Endpoints

### Basic repo info
```bash
curl -s "https://api.github.com/repos/OWNER/REPO" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('Stars:', d.get('stargazers_count'))
print('Forks:', d.get('forks_count'))
print('Language:', d.get('language'))
print('License:', d.get('license',{}).get('name'))
print('Description:', d.get('description'))
print('Created:', d.get('created_at'))
print('Pushed:', d.get('pushed_at'))
print('Open issues:', d.get('open_issues_count'))
print('URL:', d.get('html_url'))
"
```

### Latest release
```bash
curl -s "https://api.github.com/repos/OWNER/REPO/releases/latest" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('Version:', d.get('tag_name'))
print('Published:', d.get('published_at'))
for a in d.get('assets',[]):
    print(f'  {a[\"name\"]}: {a[\"download_count\"]} downloads')
"
```

### Contributors
```bash
curl -s "https://api.github.com/repos/OWNER/REPO/contributors?per_page=5" | python3 -c "
import json,sys
d=json.load(sys.stdin)
for c in d[:5]:
    print(f'{c[\"login\"]}: {c[\"contributions\"]} commits')
"
```

### File tree (recursive) — great for architecture
```bash
curl -s "https://api.github.com/repos/OWNER/REPO/git/trees/main?recursive=1" | \
  python3 -c "
import json,sys
d=json.load(sys.stdin)
for f in d.get('tree',[]):
    print(f['path'])
"
```

### README (raw)
```bash
curl -s "https://raw.githubusercontent.com/OWNER/REPO/main/README.md" | head -200

# specific tag/version
curl -s "https://raw.githubusercontent.com/OWNER/REPO/v2.13.2/README.md"
```

## Docker Hub Stats
```bash
curl -s "https://hub.docker.com/v2/repositories/IMAGE" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('Pulls:', d.get('pull_count'), 'Stars:', d.get('star_count'))
"
```

## Feature Extraction Pattern

When features aren't in README, extract from file structure:

### Java Spring (controller-based)
```bash
curl -s "https://api.github.com/repos/OWNER/REPO/git/trees/main?recursive=1" | \
  python3 -c "
import json,sys
d=json.load(sys.stdin)
controllers = sorted([f['path'] for f in d.get('tree',[])
    if 'controller/api/' in f.get('path','') and f['type']=='blob'])
for c in controllers:
    name = c.split('/')[-1].replace('Controller.java','').replace('.java','')
    print(name)
"
# Output: Merge, SplitPDF, OCR, Compress... → each controller = one feature
```

### Python (route-based)
```bash
# Look for routes, views, endpoints in file structure
curl -s "https://api.github.com/repos/OWNER/REPO/git/trees/main?recursive=1" | \
  python3 -c "
import json,sys
d=json.load(sys.stdin)
paths = [f['path'] for f in d.get('tree',[])
    if any(x in f.get('path','') for x in ['routes/','views/','endpoints/','handlers/'])
    and f['type']=='blob']
for p in paths: print(p)
"
```

## Latency Testing
```bash
# Ping
ping -c 3 -W 2 HOST

# curl connect + total time
curl -s -o /dev/null -w "Connect: %{time_connect}s | Total: %{time_total}s\n" \
  --max-time 5 "https://HOST"
```

## Pitfalls
- GitHub API: 60 req/hr unauthenticated. Use token if many calls.
- RAW URLs: use `raw.githubusercontent.com`, not `github.com`
- Wiki is separate git repo: `.wiki.git` (may need auth)
- Tags vs branches: specify `main` or tag like `v2.13.2`
