---
name: self-improving-agent
description: Self-Improving Agent System — background workers that continuously research, patch outdated skills, optimize workflows, and evolve the Hermes agent stack. Three-layer closed-loop evolution pipeline.. Use when: self-improving, background worker, automated improvement
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [self-evolution, cron, worker, skill-management, harness]
    related_skills: [hermes-research-harness, harness-engineering-research, blogwatcher]
---

# Self-Improving Agent System

## Concept

A background cron-driven system that makes Hermes continuously evolve without manual intervention. Three layers:

1. **Self-Evolution Worker** — scans GitHub trending / Hacker News / ArXiv for new agent framework developments, compares existing skills, auto-patches outdated ones
2. **Harness Engineering Evolution** — auto-extends the 10-component harness (Node.js workflow engine, message bus, eval framework...) by detecting new tech and generating new workflow definitions
3. **恆常 Learning Pipeline** — time-based daily schedule for scanning different sources

## Trigger Conditions

- User asks about self-improvement, auto-evolution, or making the agent "constantly improve"
- User says "去背後跑" or "background run" with an evolution/research task
- When setting up a new cron/scheduler job for Hermes
- When reviewing skill health (outdated detection needed)

## Proposed Architecture

### Layer 1 — Self-Evolution Worker

```python
# Run daily via cron (hermes cron system)
1. Scan GitHub Trending (language:python, topic:ai-agents)
2. Scan Hacker News top stories (keyword: agent framework)
3. Scan ArXiv (cs.AI, cs.MA, cs.Multi-Agent)
4. For each new finding:
   a. Compare with existing skills (skills_list + skill_view)
   b. If outdated pattern found → open subagent to research
   c. Subagent produces patch → skill_manage(action='patch')
   d. If net-new → skill_manage(action='create')
5. Generate evolution report (markdown, save to cron output)
```

### Layer 2 — Harness Evolution

```
Harness components (Node.js, 10 modules):
- Workflow Engine, Message Bus, Eval Framework
- Plugin System, Distributed Runner, Result Aggregator
- State Manager, Metric Collector, Config Manager, CLI

Evolution mechanism:
- Worker detects new paper/tool in agent framework space
- Maps to which harness component it could enhance
- Generates new module / extends existing one
- Saves as PR/skill update
```

### Layer 3 — Learning Pipeline Schedule

| Time | Source | Action |
|------|--------|--------|
| 08:00 | Blogwatcher (RSS/Atom) | Tech news scan |
| 12:00 | GitHub trending | AI repos |
| 16:00 | ArXiv / OpenAlex | Paper search |
| 21:00 | All sources | Nightly analysis + evolution report |

## Implementation Steps

1. **Check existing cron infrastructure** — look at `cron/` directory in Hermes codebase (jobs.py, scheduler.py)
2. **Create `self_evolution_job.py`** — main worker logic
3. **Create skill health check utility** — compares skill metadata with current best practices
4. **Register cron job** — add to scheduler
5. **Wire up patching pipeline** — subagent with structured output for skill patches
6. **Add evolution report output** — directory in cron outputs

## Pitfalls

- Don't spam GitHub API — use caching, rate limit awareness
- Don't auto-patch without any diff review — include "generated" markers
- Skills with user-customized content should be excluded from auto-patches
- Harness components are in Node.js (not Python) — worker must respect language boundaries
- Avoid infinite evolution loops — set max patches per run, log all changes
- Cron job needs Hermes config access (API keys for GitHub, ArXiv, etc.)

## Verification

- Run worker manually first: `python -m hermes cron run self-evolution`
- Check evolution output directory for report
- Verify skill patches are valid (skill_view shows updated content)
- Check cron logs for errors
