---
name: hermes-unified-system-guide
description: 統一系統說明筆記 — 涵蓋 Hermes 核心概念、運行模式、Cron、Memory、Skill、Session_search。隨時溫習、整理、理解系統。
---

# Hermes 統一系統說明筆記

## 目標讀者
- 用家（你）想理解 Hermes 點運作
- 每次溫習可以快速上手
- 遇到問題知道去邊度搵答案

---

## 一、核心概念（最重要）

### Hermes 係乜？

**你喺度操控緊嘅 AI Agent 系統。**

```
你（用家）
    │
    │  Telegram message / CLI command
    ▼
┌─────────────────────────────────────────┐
│           Hermes Agent                  │  ◄── 你嘅大腦
│                                         │
│  你叫佢做嘢，佢幫你完成                  │
│  佢有記憶、會學習、有技能                │
└─────────────────────────────────────────┘
```

---

### Hermes 有幾個「分身」

| 分身 | 職責 | 位置 |
|------|------|------|
| **Gateway** | 接收消息、路由、派發任務 | `gateway/run.py` |
| **Agent** | 執行工具、做嘢嘅大腦 | `run_agent.py` |
| **Scheduler** | 自動化 job 觸發（喺 Gateway 內） | `cron/scheduler.py` |

**重要：Cron Scheduler 係長響 Gateway 入面，唔係獨立存在。**

---

## 二、運行模式（點様起動 Hermes）

### 三種方式

| 模式 | 說明 | 生產用？ |
|------|------|----------|
| **Systemd** | Server 自動啟動，後台運行 | ✅ 推薦 |
| **手動** | 你 SSH 入去打 command 啟動 | ❌ 開發用 |
| **Docker** | 容器隔離運行 | ✅ 可選 |

### Systemd（推薦）— 生產環境標配

```
好處：
  ✅ Server 重啟 → Gateway 自動起身
  ✅ 崩潰了 → 自動重啟
  ✅ 後台運行，唔使你操心

設定後：
  systemctl status hermes-gateway   # 睇狀態
  systemctl restart hermes-gateway   # 重啟
```

### 手動 — Debug / 開發用

```
問題：Server 重啟就停了，要手動重啟
適合：即時測試、睇 log、debug
```

### Docker — 隔離環境

```
適合：多實例、測試、快速部署
注意：Container 停了 Cron 就停
```

---

## 三、Cron / Job（自動化排程）

### 係乜？

你叫 Hermes 做一次，但幫你設定時間自動再做。

```
你：「聽日 6:15 自動幫我做 GitHub report」
         ↓
我幫你創建 job
         ↓
每日 6:15 自動跑
```

### Cron Job 運作流程

```
jobs.json（所有 jobs 列表）
    │
    ├── job_1: daily-morning  [06:15 every day] ✅ enabled
    ├── job_2: pricepulse     [every 30min]      ⏸ paused
    └── job_3: 明報 digest    [07:00 every day]  ⏸ paused

每 60 秒：Scheduler check jobs.json → 觸發到期嘅 jobs
```

### Delivery（結果送去邊）

| 選項 | 意思 |
|------|------|
| `origin` | 送返呢個 chat（Telegram Hermes Workshop）|
| `local` | 只 save 檔案，唔發送 |
| `telegram:-100...` | 指定去邊個 chat |

### Origin 概念（重要）

```
origin = {
    "platform": "telegram",
    "chat_id": "-1003654034759",
    "thread_id": "1907"
}
```

**Cron job 創建時必須捕獲 origin，否則 `deliver=origin` 會失敗。**

### 常見問題：origin=null

```
原因：Job 創建時未傳入 origin（通常係 API/script 創建）
現象："no delivery target resolved for deliver=origin"
解决：
  1. 確保 caller 傳入正確 origin
  2. 設置 <PLATFORM>_HOME_CHANNEL 環境變量
  3. 新代碼有 _validate_delivery_config() 提前 warning
```

---

## 四、Memory（記憶）

### 係乜？

跨 session 持久化嘅資料，確保我記得你嘅偏好同環境。

### 你應該記乜？

| 類別 | 例子 | 放邊 |
|------|------|------|
| 用戶偏好 | 語言、溝通風格、delivery 方式 | **User Profile** |
| 環境事實 | Oracle VM pip quirk、的路徑 | **Memory Notes** |

### 你唔應該記乜？

| 類別 | 點解 | 應該點 |
|------|------|--------|
| Code bugs | 係代碼問題，唔係事實 | 修 code |
| Session 結果 | 係過程，唔係事實 | session_search |
| 臨時 workaround | 會造成技術債 | 修 code 或留 file:line |

### Memory Decision Framework（决策框架）

```
創建 memory 之前問自己：

1. 用戶關心嘅偏好？ → User Profile
2. 環境fact，3個月後仍然 relevant？ → Memory Notes
3. Code bug？ → 修 code，唔係 memory
4. 可重用 workflow？ → Skill
5. Session state/output？ → session_search
```

### 目標

- Memory < 60% full
- 每加 1 新 entry，考虑刪 1 舊 entry
- 每 2-4 週 review 一次

---

## 五、Skill（技能）

### 係乜？

可重用嘅步驟集合，等我遇到相類似工作時自動調用。

### 例子

```
skill: github-daily-report-zh
  → 步驟1: 爬 GitHub Trending
  → 步驟2: 爬 Hacker News
  → 步驟3: 整合成報告
  → 步驟4: 儲存並送俾你
```

### 你應該創建 Skill 嗎？

```
問：你會唔會喺 3 週後再做呢個任務？
  ✅ 會 → 做 skill
  ❌ 唔會 → 直接做
```

### Skill vs Memory

| | Skill | Memory |
|---|---|---|
| **用途** | 可重用嘅流程 | 跨 session 嘅事實 |
| **例子** | Cron 設定、爬蟲流程 | 用戶偏好、環境路徑 |
| **格式** | 完整 markdown 步驟 | 1-3 行 entry |

---

## 六、Session_search（對話歷史）

### 係乜？

搜索我哋之前做過嘅嘢，我唔使重複問你。

### 例子

```
你：「上次我哋點樣修個 delivery bug？」
我 → session_search → 搵到相關對話
```

### 你應該用嗎？

```
直接問我，唔使自己記得我做過乜
冇特別需要就唔使主動用
```

---

## 七、系統架構圖

```
┌─────────────────────────────────────────────────────────┐
│                    User (Telegram / CLI)                 │
└──────────────────────┬──────────────────────────────────┘
                       │ message
                       ▼
┌─────────────────────────────────────────────────────────┐
│              Gateway (run.py) — Message Router           │
│  - 接收消息 from 平台 adapters                           │
│  - 路由到 AIAgent                                       │
│  - 管理 sessions                                        │
│  - Cron Scheduler（每60秒 tick）                        │
│  - Delivery resolution                                  │
└──────┬──────────────────────────┬───────────────────────┘
       │                          │
       ▼                          ▼
┌──────────────────┐    ┌────────────────────────────────┐
│  Platform        │    │   AIAgent (run_agent.py)        │
│  Adapters        │    │   - Tool orchestration           │
│  (Telegram,      │    │   - Model client                │
│   Discord...)    │    │   - Context management          │
└──────────────────┘    └──────────┬─────────────┬─────────┘
                                   │             │
                    ┌──────────────┼─────────────┼──────────┐
                    │              │             │          │
                    ▼              ▼             ▼          ▼
            ┌──────────────┐ ┌──────────────┐ ┌────────────┐ ┌──────────┐
            │ Tools        │ │ Skills       │ │ Cron       │ │ Memory   │
            │ (registry)   │ │ (skills/)    │ │ (scheduler)│ │ (notes)  │
            └──────────────┘ └──────────────┘ └────────────┘ └──────────┘
```

---

## 八、配置位置速查

| 用途 | 路徑 |
|------|------|
| 主配置 | `~/.hermes/config.yaml` |
| Cron jobs | `~/.hermes/cron/jobs.json` |
| Cron output | `~/.hermes/cron/output/{job_id}/{timestamp}.md` |
| Skills | `~/.hermes/skills/` |
| Cookies（爬蟲）| `~/.hermes/cookies/` |
| Profiles | `~/.hermes/profiles/` |

---

## 九、現在的運行狀態（2026-06-06）

```
Systemd Service: ❌ 不存在（沒有自動啟動）
Gateway 進程:    ✅ 運行中（hermes_cli.main gateway run）
Docker:          ❌ 沒有使用
```

**問題：** 手動運行 = Server 重啟後 Gateway 停了 = Cron 不會自動觸發

**建議：** 設定 Systemd service

---

## 十、常见问题

### Q: Cron job deliver=origin 失敗

**原因：** Job 創建時未傳入 origin  
**解决：** 確保 caller 傳入正確 origin，設置 `<PLATFORM>_HOME_CHANNEL`

### Q: Memory 越來越大

**解决：** 用 Decision Framework，code bugs 修 code，唔係 memory workaround

### Q: Tool 找不到

**原因：** 環境變量未設置、toolset 未加載、tool 文件未 import  
**解决：** 檢查 check_fn、toolset 配置

---

## Revision History
- 2026-06-06: Created — 統一系統說明，包含運行模式、Cron、Memory、Skill、Session_search
- 2026-06-06: 添加現狀確認（systemd不存在，手動運行中）