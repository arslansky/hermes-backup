---
name: hermes-system-architecture
description: 教科式系統架構筆記 — 涵蓋 Hermes Agent 的核心組件、數據流、决策框架。適用於理解、維護、開發。
---

# Hermes System Architecture — 教科式筆記

## 1. 系統 Overview

```
┌─────────────────────────────────────────────────────────┐
│                    User (Telegram / CLI / etc.)          │
└──────────────────────┬──────────────────────────────────┘
                       │ message
                       ▼
┌─────────────────────────────────────────────────────────┐
│              Gateway (run.py) — Message Router          │
│  - Receives messages from platform adapters             │
│  - Routes to AIAgent                                   │
│  - Handles slash commands                               │
│  - Manages sessions + delivery                          │
└──────┬─────────────────────────────────┬────────────────┘
       │                                 │
       ▼                                 ▼
┌──────────────────┐          ┌──────────────────────────┐
│  Platform        │          │   AIAgent (run_agent.py)  │
│  Adapters        │          │   - Tool orchestration     │
│  (Telegram,      │          │   - Model client          │
│   Discord, etc.) │          │   - Context management    │
└──────────────────┘          └──────────┬───────────────┘
                                         │
                    ┌────────────────────┼────────────────────┐
                    │                    │                    │
                    ▼                    ▼                    ▼
            ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
            │ Tools        │    │ Skills       │    │ Cron         │
            │ (registry)   │    │ (skills/)    │    │ (scheduler)  │
            └──────────────┘    └──────────────┘    └──────────────┘
```

---

## 2. 核心組件

### 2.1 Gateway (`gateway/run.py`)

**職責：**
- 消息接收 + 路由
- Session 管理（`session.py` — SQLite）
- Slash commands 分發
- Cron job trigger（每60秒 tick）
- Delivery target resolution

**關鍵概念 — Origin:**
```
origin = {
    "platform": "telegram",
    "chat_id": "-1003654034759",
    "thread_id": "1907"
}
```
cron job 創建時需要捕獲 origin，否則 `deliver=origin` 會 fail。

**Delivery Target Resolution (`scheduler.py:77-107`):**
```
deliver="origin" + origin有值 → 直接用 origin
deliver="origin" + origin=null → 嘗試 <PLATFORM>_HOME_CHANNEL env fallback
deliver="local" → 不 delivery，只存檔
deliver="telegram:-100..." → 直接用指定 target
```

### 2.2 AIAgent (`run_agent.py`)

**職責：**
- Main agent loop（model 調用 + tool orchestration）
- Tool discovery (`model_tools.py`)
- Context compression
- Trajectory saving

**工具發現流程：**
```
model_tools.py _discover_tools()
  → import all tools/*.py
  → each calls registry.register()
  → schema collected → passed to model
```

### 2.3 Tool Registry (`tools/registry.py`)

**核心：**
- `register()` — 註冊工具（name, schema, handler, check_fn）
- `get_tool_definitions()` — 返回所有工具 schema
- `check_requirements()` — 檢查環境變量

### 2.4 Cron System (`cron/`)

**組件：**
- `jobs.py` — Job CRUD + storage (jobs.json)
- `scheduler.py` — Tick loop + execution + delivery
- `jobs.json` — 持久化 jobs 數據

**Job 結構：**
```json
{
  "id": "f773ef526e98",
  "name": "daily-morning-combined",
  "prompt": "...",
  "skills": ["github-daily-report-zh"],
  "schedule": {"kind": "cron", "expr": "15 6 * * *", "display": "15 6 * *"},
  "deliver": "origin",
  "origin": {"platform": "telegram", "chat_id": "...", "thread_id": "..."},
  "state": "scheduled",
  "last_status": "ok",
  "last_delivery_error": null
}
```

**Pre-flight Validation (jobs.py):**
新 jobs 創建時 `_validate_delivery_config()` 檢查 `deliver=origin` 但 `origin=null` 的情况，提前 warning。

---

## 3. 數據流

### 3.1 消息處理流程

```
User sends message
  → Platform Adapter (Telegram/Discord/...)
    → Gateway.run() receives
      → SessionStore lookup (session_id)
        → AIAgent.run_conversation()
          → Model API call (MiniMax/Anthropic/etc.)
            → Tool calls (if any)
              → handle_function_call() → tool result
            → Final response
          → SessionStore save
        → Delivery (cron: send to origin / direct)
```

### 3.2 Cron Job 執行流程

```
Scheduler tick (every 60s)
  → Load jobs.json
    → Filter enabled + due jobs
      → Run each: execute in fresh AIAgent session
        → Script output (if any) → prepended to prompt
        → Skill loading
        → Model call
        → Output saved to ~/.hermes/cron/output/{job_id}/{timestamp}.md
        → Delivery: _resolve_delivery_target() → send to target
```

---

## 4. 關鍵設計模式

### 4.1 Tool Registration Pattern

每個 tool 是獨立模塊，import 時自動註冊：
```python
# tools/example_tool.py
def check_requirements() -> bool:
    return bool(os.getenv("EXAMPLE_API_KEY"))

def handler(args, task_id):
    return json.dumps({"success": True})

registry.register(
    name="example_tool",
    toolset="example",
    schema={"name": "example_tool", ...},
    handler=handler,
    check_fn=check_requirements,
)
```

### 4.2 Profile / HERMES_HOME

每個 profile 有獨立的 `HERMES_HOME`，確保多實例隔離：
```python
get_hermes_home()  # 讀取 HERMES_HOME 環境變量
Path.home() / ".hermes"  # 僅用於 profiles root
```

### 4.3 Skill Loading

Skills 是 markdown 文件，agent 在執行前自動加載：
```
~/.hermes/skills/{category}/{skill_name}/SKILL.md
```

---

## 5. 常見問題與解决方案

### Q: Cron job deliver=origin 失敗，origin=null

**原因：** Job 創建時未傳入 origin 參數（通常係 API/script 創建）

**解决：**
1. 確保 caller 在創建 job 時傳入正確 origin
2. 設置 `<PLATFORM>_HOME_CHANNEL` 環境變量作為 fallback
3. 新代碼已有 `_validate_delivery_config()` 提前 warning

### Q: Memory 越來越大

**决策框架：**
- 用戶偏好 → user profile
- 環境 facts → memory notes
- Code bug → 修 code，唔係 memory workaround
- Workflow → skill
- Session state → session_search

### Q: Tool 找不到

**原因：** 
1. 環境變量未設置（check_fn 返回 False）
2. Toolset 未加載
3. Tool 文件未 import（`_discover_tools()` 未涵蓋）

---

## 6. 配置位置

| 用途 | 路徑 |
|------|------|
| 主配置 | `~/.hermes/config.yaml` |
| Cron jobs | `~/.hermes/cron/jobs.json` |
| Cron output | `~/.hermes/cron/output/{job_id}/{timestamp}.md` |
| Skills | `~/.hermes/skills/` |
| Cookies (爬蟲) | `~/.hermes/cookies/` |
| Profiles | `~/.hermes/profiles/` |

---

## 7. 關鍵文件索引

| 文件 | 作用 |
|------|------|
| `run_agent.py` | AIAgent 主循環 |
| `model_tools.py` | 工具發現 + 調度 |
| `tools/registry.py` | 工具註冊中心 |
| `gateway/run.py` | Gateway 主循環 |
| `gateway/session.py` | Session 持久化 |
| `cron/jobs.py` | Job CRUD |
| `cron/scheduler.py` | Job 執行 + delivery |
| `hermes_cli/main.py` | CLI 入口 |
| `hermes_cli/config.py` | 配置管理 |

---

## Revision History
- 2026-06-06: Created — based on jobs.json analysis + system investigation