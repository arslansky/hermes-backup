---
name: hermes-memory-framework
description: Systematic decision framework for what belongs in Hermes memory vs. skills vs. session_search. Use before every memory call and during reviews.
---

# Hermes Memory Decision Framework

## Purpose
Systematic framework for deciding what belongs in persistent memory (user profile / memory notes) vs. what should be handled differently. Used before every `memory()` call and during periodic reviews.

---

## Core Decision Matrix

### Category 1: USER PREFERENCES → always save to user profile
Examples:
- Communication style (Cantonese, formal/informal, emoji usage)
- Delivery preferences (file types, formatting, channel choices)
- Task preferences (concise vs detailed, options vs direct answers)
- Personal context (name, role, timezone, projects)

**Decision:** "Would I need to ask this again if I forgot it?"
If yes → save immediately to user profile.

---

### Category 2: ENVIRONMENT FACTS → save to memory notes
Examples:
- OS quirks (Oracle VM pip vs python3 different venvs)
- Network constraints (IP ranges, ports, VPN requirements)
- Tool limitations (specific API quirks, rate limits)
- Path conventions (custom Hermes home, profile structure)
- Credentials locations

**Decision:** "Will this fact still be true and relevant in 3+ months?"
If uncertain but likely yes → save to memory notes.
If no (e.g., task progress, session outcomes) → do NOT save.

---

### Category 3: CODE BUGS / SYSTEM ISSUES → NEVER workaround in memory
Examples:
- Cron delivery fails when origin=null
- Config migration bugs
- Tool registry errors

**Decision:** "Is this a code problem or an environment problem?"
If code problem → **Fix the code or file a bug report, NOT memory workaround.**
Memory workarounds for code bugs create technical debt and inflate memory.

**Exception:** If code fix is out of scope (e.g., upstream library bug, requires major refactor), document as: "Known issue - see [file:line]" in memory notes with specific file reference, NOT the workaround.

---

### Category 4: WORKFLOW / PROCESS → consider as skill
Examples:
- Recurring multi-step tasks (DSE data pipeline)
- Useful command sequences (github trending + hn combined report)
- Non-obvious tool combinations

**Decision:** "Will this exact workflow be needed again in 3+ weeks?"
If yes → save as skill with exact steps, not memory.
If one-off → execute and forget.

---

### Category 5: SESSION OUTCOMES / TASK RESULTS → NEVER in memory
Examples:
- "Completed X, found Y results"
- "Test passed/failed for Z"
- "Job output was 500 lines"

**Decision:** These belong in session history (session_search), NOT memory.
Memory is for cross-session facts, not within-session records.

---

## Red Flags (Do NOT write to memory)

| Red Flag | Why | Alternative |
|----------|-----|-------------|
| "This happened once" | Likely won't recur | session_search instead |
| "X is broken" | Should be fixed, not worked around | Fix code or file issue |
| "Temporary workaround" | Creates technical debt | Document file:line reference |
| "Task progress" | Session-bound state | session_search |
| "Raw data dump" | Not a fact | File storage |

---

## Memory Review Cadence

Every 2-4 weeks or after significant system changes:

1. **Check memory fill level** — if >70%, trigger review
2. **Scan for stale entries** — things that are now wrong/outdated
3. **Audit for debt** — code bugs being worked around in memory
4. **Consolidate** — merge similar entries, remove obsolete ones

Target: Keep memory <60% with high-value entries only.

---

## Quick Decision Checklist (before memory call)

```
Before calling memory(action='add'):

1. Does the user care about this? → USER PROFILE
2. Will this environment fact still matter in 3+ months? → memory notes
3. Is this a code bug? → Fix code, NOT memory (unless unfixable, then reference file:line)
4. Is this a reusable workflow? → Skill instead
5. Is this session state/output? → session_search instead, never memory
```

---

## Memory vs Skill vs Session_search Quick Reference

| | Memory | Skill | session_search |
|---|---|---|---|
| **Purpose** | Cross-session facts | Reusable procedures | Past conversations |
| **Examples** | User preferences, env facts | Cron setup, multi-step pipelines | "What did we do last week?" |
| **Lifespan** | Months+ | Until process changes | Sessions |
| **Granularity** | Atomic facts | Full workflows with steps | Full transcripts |
| **Format** | 1-3 line entries | Full markdown with steps | Search results |

---

## Pointer-based Memory Hygiene (2026-06-06)

When MEMORY.md entries grow too large or too scattered, use the **pointer approach**:

### When to use pointers
- Entry is detailed/temporal (e.g., scraper issues, proxy configs)
- Entry belongs to a specific file/skill that already exists
- Entry is >3 lines but describes something file-bound

### How to do it
1. Move detailed content to the relevant source file (script header comment, skill SKILL.md)
2. Replace MEMORY.md entry with a pointer: `→ /path/to/file (context)`
3. Keep behavioral instructions (thresholds, preferences) in MEMORY.md

### Example
**Before (MEMORY.md):**
```
## 明報爬蟲 (2026-06-05)
- Proxy c9.hk2.yfip.top:30426 + prs:gru ✅ 仍有效
- CloakBrowser + proxy 可繞過 CF，但明報要聞版需登入才能顯示完整文章
- 0605 scraper 只爬到 76 篇（正常 150-200+），需要先 accept cookies
```

**After (MEMORY.md):**
```
## 明報爬蟲 → ~/.hermes/scripts/mingpao_scraper.py (見 KNOWN ISSUES)
```

**After (scraper file header):**
```python
# ===== KNOWN ISSUES (2026-06-05) =====
# - Proxy c9.hk2.yfip.top:30426 + prs:gru ✅ 仍有效
# - 要聞版需登入才能顯示完整文章
# - 正常應爬到 150-200+ 篇，如只有 76 篇說明被阻擋
# ====================================
```

### Benefits
- MEMORY.md stays lean (<60% target)
- Details live close to the source (easier to update)
- Pointers are scannable at a glance
- No loss of information

### What stays in MEMORY.md
- User preferences (always)
- Critical behavioral thresholds (e.g., ">10 cron jobs notify")
- Environment quirks that can't be documented elsewhere
- Active design decisions that guide my behavior

### What moves out
- Detailed technical issues → source file comments
- Repo/project info → skill SKILL.md
- Obsolete entries → delete entirely
- Design specs → relevant skill or document

---

## Revision History
- 2026-06-06: Created framework based on cron jobs.json analysis
- 2026-06-06: Added pointer-based memory hygiene approach