---
name: cron-delivery-fix-pattern
description: Fix cron job delivery failures — resolve delivery targets and ensure reports reach the user
trigger: cron job ran successfully but delivery failed (e.g. "no delivery target resolved", "Chat not found")
---

# Cron Job Delivery Fix Pattern

When a cron job runs but fails to deliver (no output reaches the user), follow this checklist:

## 1. Check cron job status
```bash
hermes cron list
hermes cron status <job_id>
```

## 2. Check delivery target
The `deliver` field in cron job config determines where the output goes:
- `origin` = deliver to the chat/thread where the cron was created
- Specific chat ID = deliver to that chat

## 3. Find the correct delivery target
If `origin` is null, look up chat IDs in `~/.hermes/channel_directory.json`:
```bash
cat ~/.hermes/channel_directory.json | python3 -m json.tool | grep -A 5 "telegram"
```
Match the chat ID and thread_id to where you want the report delivered.

## 4. Fix delivery — patch jobs.json directly
The `/cron edit` command may not work for origin. Instead, edit `~/.hermes/cron/jobs.json` directly:
```python
import json
jobs_path = '/home/opc/.hermes/cron/jobs.json'
jobs_data = json.load(open(jobs_path))
for j in jobs_data['jobs']:
    if j.get('name') == 'JOB_NAME':
        j['origin'] = {
            'platform': 'telegram',
            'chat_id': '-100XXXXXXXXX',
            'thread_id': 'THREAD_ID'  # omit if no thread
        }
with open(jobs_path, 'w') as f:
    json.dump(jobs_data, f, indent=2, ensure_ascii=False)
```

## 5. Verify fix
```bash
hermes cron run <job_id>
```
Wait ~60s, then check Telegram for the delivered report.

## Common causes
- **"no delivery target resolved"**: The `deliver=origin` job has `origin: null` in jobs.json — the origin chat was lost (e.g. job created via API/script, or session context expired)
- **"Chat not found"**: The stored chat ID is stale or the bot was removed/re-added
- **Solution**: Manually patch `origin` in `~/.hermes/cron/jobs.json` using IDs from `~/.hermes/channel_directory.json`