---
name: youtube-subtitle-extraction
title: YouTube 字幕提取（Oracle Cloud 環境）
description: 在 Oracle Cloud VM 上提取 YouTube 影片字幕的方法，解決 IP 被 YouTube 封鎖的問題
category: media
---

# YouTube 字幕提取

## Oracle Cloud IP 封鎖問題

Oracle Cloud VM 的 IP 段被 YouTube 全面封鎖，幾乎所有方法都會失敗：

| 方法 | Oracle Cloud VM 結果 |
|------|---------------------|
| yt-dlp（無 cookie） | "Sign in to confirm you're not a bot" |
| yt-dlp（--cookies-from-browser）| No cookies database found |
| yt-dlp（--extractor-args curl_cffi）| 同樣被擋 |
| youtube-transcript-api | "IP blocked" |
| Invidious / Piped API | timeout / blocked |
| 直接 curl YouTube caption API | empty response |
| Browserbase（stealth）| "Sign in" — 沒有住宅代理 |

## 解決方案

### Option A：Browserbase（如果有住宅代理）
Browserbase 需要配置 `BROWSERBASE_API_KEY` + `BROWSERBASE_PROJECT_ID`，並使用 `--browser-access-key` 參數。
- 問題：目前 Oracle VM 上的 Browserbase 配置沒有 residential proxy，繼續被 block

### Option B：手動導出 Cookie
喺自己電腦（住宅 IP）的 Chrome 登入 YouTube，用「Export Cookies」擴展導出，再傳到 VM：
```bash
yt-dlp --cookies ~/cookies.txt --skip-download --write-subs --sub-langs zh-HK,en <URL>
```

### Option C：本地住宅 IP 機器
```bash
pip install youtube-transcript-api
python3 << 'PYEOF'
from youtube_transcript_api import YouTubeTranscriptApi
ytt_api = YouTubeTranscriptApi()
transcript_list = ytt_api.list('VIDEO_ID')
for t in transcript_list:
    print(t.language_code, t.is_generated)
    # 下載：t.fetch() → 輸出文字
PYEOF
```

### yt-dlp 字幕下載語法（唔需要繞過的情況下）
```bash
# 列出所有字幕
yt-dlp --list-subs <URL>

# 下載指定語言字幕（不下載影片）
yt-dlp --skip-download --write-subs --write-auto-subs \
  --sub-langs zh-HK,zh-TW,en --convert-subs vtt <URL>

# 轉換格式
yt-dlp --skip-download --write-subs --sub-langs all \
  --convert-subs srt <URL>

# Embed 進影片（需要 ffmpeg）
yt-dlp --write-subs --embed-subs --sub-langs zh-HK <URL>
```

## 關鍵教訓

- Oracle Cloud IP ranges are globally blocked by YouTube
- No amount of TLS fingerprint spoofing (curl_cffi) bypasses this
- The only viable paths: (1) residential proxy, (2) manually exported cookies, (3) run on non-cloud IP
- youtube-transcript-api v1.2.4 API: `YouTubeTranscriptApi()` 實例 → `.list(video_id)` → `.fetch()`