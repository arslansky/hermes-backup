---
name: parallel-large-file-analysis
description: Analyze large files in parallel using byte ranges and subagent delegation — bypasses context limits by splitting content into sections.
category: productivity
---

# Parallel Large File Analysis with Byte Ranges

## When to Use
- Analyzing large files (>50KB) that exceed subagent context limits
- Need to parallelize work across multiple subagents
- File is available locally (or can be downloaded as raw bytes)

## Core Pattern
1. Calculate byte ranges for each section using Python (or terminal + grep/sed)
2. Pass `{start_byte, end_byte}` to each subagent
3. Subagent reads `open(path, 'rb').read()[start:end].decode()` — uses bytes, not chars
4. Subagent performs analysis on its section
5. Merge results in parent

## Why Byte Ranges (not line numbers)?
- Line numbers are fragile across edits
- Byte offsets are stable for content extraction
- Python `read()` works in bytes, not characters
- UTF-8 multibyte chars make char offsets unreliable

## Example: Analyzing 15-Chapter README

```python
# Step 1: Find all chapter headings and their byte offsets
import re
with open('/tmp/README.md', 'rb') as f:
    content = f.read()

chapters = []
for m in re.finditer(rb'^#{4}\s+(.+)$', content, re.M):
    title = m.group(1).decode().strip()
    pos = m.start()
    chapters.append((pos, title))

# Calculate ranges
for i, (start, title) in enumerate(chapters):
    end = chapters[i+1][0] if i+1 < len(chapters) else len(content)
    print(f"{title}: bytes {start}-{end} ({end-start})")
```

## Delegation Strategy (max_concurrent_children=3)

```python
# Batch chapters, max 3 per delegate_task call
BATCH_SIZE = 3
for i in range(0, len(chapters), BATCH_SIZE):
    batch = chapters[i:i+BATCH_SIZE]
    delegate_task(tasks=[
        {"goal": f"Analyze bytes {c['start']}-{c['end']}", ...}
        for c in batch
    ])
```

## Subagent Prompt Template

```
## 章節：{chapter_name}

請用 terminal 讀取 /tmp/README.md 的 bytes {start}-{end} 範圍內容：
```python
with open('/tmp/README.md', 'rb') as f:
    f.seek({start})
    content = f.read({end - start}).decode()
```

分析要求：
1. 識別所有工具和命令
2. 產出中文摘要（200-300字）
3. 列出所有提及的工具
4. 提取 5-10 個關鍵詞
5. 評估實用程度（1-5星）和難度

直接輸出分析結果，不要問問題。
```

## GitHub Repo Name Resolution

If clone fails with 404:
```bash
# Try GitHub search API
curl -s "https://api.github.com/search/repositories?q=book+of+secret+knowledge" | python3 -c "..."

# Or browse to github.com/search with query
browser_navigate("https://github.com/search?q=book+of+secret+knowledge&type=repositories")
```

## Known Pitfalls
- **read_file() cache**: Second read of same file returns "File unchanged..." dedup. Use `terminal()` with `subprocess.run(["cat", path])` to bypass.
- **Subagent output limit**: >~8KB output gets truncated. Keep analysis summaries tight.
- **Unicode/bytes confusion**: Always `.decode()` after byte-range read. Don't use character offsets.
